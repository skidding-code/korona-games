





define wiperight = CropMove(.3, "wiperight")
define wipeleft = CropMove(.3, "wipeleft")
define wipeup = CropMove(.3, "wipeup")

default firstForced = 0
default leftAlley = False

default f_OldTheater = 0
default f_NewCinema = 0
default f_Carnival = 0
default f_DogPark = 0
default chaseDoneCounter = 0

default chaseClock = 3

image alley1F = Movie(play="images/chase/alley1.webm")
image alley2R = Movie(play="images/chase/alley2.webm")
image apt1R = Movie(play="images/chase/apt1.webm")
image apt2L = Movie(play="images/chase/apt2.webm")
image apt3R = Movie(play="images/chase/apt3.webm")
image apt4R = Movie(play="images/chase/apt4.webm")
image apt5F = Movie(play="images/chase/apt5.webm")
image carnival1R = Movie(play="images/chase/carnival1.webm")
image carnival2R = Movie(play="images/chase/carnival2.webm")
image carnival3L = Movie(play="images/chase/carnival3.webm")
image carnival4F = Movie(play="images/chase/carnival4.webm")
image carnival5F = Movie(play="images/chase/carnival5FORWARD.webm")
image carnival5L = Movie(play="images/chase/carnival5LEFT.webm")
image carnival5R = Movie(play="images/chase/carnival5RIGHT.webm")
image dogPark1F = Movie(play="images/chase/dogPark1.webm")
image dogPark2F = Movie(play="images/chase/dogPark2.webm")
image dogPark3L = Movie(play="images/chase/dogPark3LEFT.webm")
image dogPark3R = Movie(play="images/chase/dogPark3RIGHT.webm")
image dogPark4R = Movie(play="images/chase/dogPark4.webm")
image dogPark5F = Movie(play="images/chase/dogPark5FORWARD.webm")
image dogPark5R = Movie(play="images/chase/dogPark5RIGHT.webm")
image dogPark5L = Movie(play="images/chase/dogPark5LEFT.webm")
image newCinema1R = Movie(play="images/chase/newCinema1.webm")
image newCinema2F = Movie(play="images/chase/newCinema2.webm")
image newCinema3L = Movie(play="images/chase/newCinema3.webm")
image newCinema4R = Movie(play="images/chase/newCinema4.webm")
image newCinema5F = Movie(play="images/chase/newCinema5FORWARD.webm")
image newCinema5L = Movie(play="images/chase/newCinema5LEFT.webm")
image newCinema5R = Movie(play="images/chase/newCinema5RIGHT.webm")
image oldTheater1L = Movie(play="images/chase/oldTheater1.webm")
image oldTheater2R = Movie(play="images/chase/oldTheater2.webm")
image oldTheater3L = Movie(play="images/chase/oldTheater3.webm")
image oldTheater4R = Movie(play="images/chase/oldTheater4.webm")
image oldTheater5F = Movie(play="images/chase/oldTheater5FORWARD.webm")
image oldTheater5L = Movie(play="images/chase/oldTheater5LEFT.webm")
image oldTheater5R = Movie(play="images/chase/oldTheater5RIGHT.webm")
image street1R = Movie(play="images/chase/street1.webm")
image street2L = Movie(play="images/chase/street2.webm")
image street3F = Movie(play="images/chase/street3.webm")
image street4R = Movie(play="images/chase/street4.webm")
image street5L = Movie(play="images/chase/street5.webm")

init:
    image bg catEyes = "chase/catEyes.png"
    image bg caughtRed = "redSCREEN.png"
    image bg whiteScreen = "whiteSCREEN.png"
    image bg initialAlley = "normalBGs/alley01.png"
    image bg chaseAlley1 = "chase/chaseAlley01.png"
    image bg chaseAlley2 = "chase/chaseAlley02.png"
    image bg chaseApt1 = "chase/chaseApt01.png"
    image bg chaseApt2 = "chase/chaseApt02.png"
    image bg chaseApt3 = "chase/chaseApt03.png"
    image bg chaseApt4 = "chase/chaseApt04.png"
    image bg chaseApt5 = "chase/chaseApt05.png"
    image bg chaseAptEND = "chase/chaseApt06_END.png"
    image bg chaseCarnival1 = "chase/chaseCarnival01.png"
    image bg chaseCarnival2 = "chase/chaseCarnival02.png"
    image bg chaseCarnival3 = "chase/chaseCarnival03.png"
    image bg chaseCarnival4 = "chase/chaseCarnival04.png"
    image bg chaseCarnival5 = "chase/chaseCarnival05.png"
    image bg chaseDogPark1 = "chase/chaseDogPark01.png"
    image bg chaseDogPark2 = "chase/chaseDogPark02.png"
    image bg chaseDogPark3 = "chase/chaseDogPark03.png"
    image bg chaseDogPark4 = "chase/chaseDogPark04.png"
    image bg chaseDogPark5 = "chase/chaseDogPark05.png"
    image bg chaseNewCinema1 = "chase/chaseNewCinema01.png"
    image bg chaseNewCinema2 = "chase/chaseNewCinema02.png"
    image bg chaseNewCinema3 = "chase/chaseNewCinema03.png"
    image bg chaseNewCinema4 = "chase/chaseNewCinema04.png"
    image bg chaseNewCinema5 = "chase/chaseNewCinema05.png"
    image bg chaseOldTheater1 = "chase/chaseOldTheater01.png"
    image bg chaseOldTheater2 = "chase/chaseOldTheater02.png"
    image bg chaseOldTheater3 = "chase/chaseOldTheater03.png"
    image bg chaseOldTheater4 = "chase/chaseOldTheater04.png"
    image bg chaseOldTheater5 = "chase/chaseOldTheater05.png"
    image bg chaseStreet1 = "chase/chaseStreet01.png"
    image bg chaseStreet2 = "chase/chaseStreet02.png"
    image bg chaseStreet3 = "chase/chaseStreet03.png"
    image bg chaseStreet4 = "chase/chaseStreet04.png"
    image bg chaseStreet5 = "chase/chaseStreet05.png"

    $ chaseFade = Dissolve(5)
    $ c_Red = Fade(.08, 0.1, .5, color="#FF0000")
    $ fade_Red = Dissolve(4)

screen alleyFade1():
    add Image("chase/chaseAlley01.png") alpha 0.25

screen alleyFade2():
    add Image("chase/chaseAlley01.png") alpha 0.50

screen alleyFade3():
    add Image("chase/chaseAlley01.png") alpha 0.75

screen alleyFade4():
    add Image("chase/chaseAlley01.png")

screen chase_timer():
    if chaseClock >= 1:
        timer 1 repeat True action [
                SetVariable("chaseClock", chaseClock - 1),
                renpy.restart_interaction
            ]
    else:
        timer 1 action [
                Hide("chase_timer"),
                Jump("chase_time_out")
            ]



label finalShowdownChase:
    ".."
    "..."
    scene bg initialAlley
    with dissolve
    you "!!"
    you "{i}I'm back in the alley...{/i}"
    show EG emptyBox
    with dissolve
    you "{i}It's not here... Good...{/i}"
    you "{i}I think... {w}I think I need to get home...{/i}"
    scene bg initialAlley
    with dissolve
    ".."
    "..."
    "I uh..."
    "...I step forward? {w}Out of... {w}the alley?"
    you "..."
    you "{i}This is gonna take some getting used to...{/i}"
    "I-I step forward towards the entrance of the thankfully empty alley."
    "I'm almost out of this place..."
    "Almost home-{w=0.5}{nw}"
    play sound "audio/glitch.mp3"
    "{b}{color=#FF0000}when \ s u d d e n l y y y y y . . . {/color}{/b}" with hpunch
    you "!!" with vpunch
    show screen alleyFade1
    with fade_Red
    play sound "audio/beastGrowl.mp3"
    cat "{size=+15}YOUUUU!!{/size}" with vpunch
    you "!!!"
    play sound "audio/glitch.mp3"
    cat "{size=+20}YOU'RE{/size}{w=0.5}{nw}" with vpunch
    hide screen alleyFade1
    show screen alleyFade2
    play sound "audio/glitch.mp3"
    cat "{size=+25}NOT{/size}{w=0.5}{nw}" with vpunch
    hide screen alleyFade2
    show screen alleyFade3
    play sound "audio/glitch.mp3"
    cat "{size=+30}{b}GOING{/b}{/size}{w=0.5}{nw}" with vpunch
    hide screen alleyFade3
    show screen alleyFade4
    play sound "audio/beastRoar.mp3"
    cat "{size=+35}{b}{i}ANYWHERE!!{/i}{/b}{/size}" with vpunch
    scene bg chaseAlley1
    hide screen alleyFade4
    jump alley1

label gotYou:
    $ renpy.block_rollback()
    stop music
    hide static
    hide screen chase_timer
    scene bg catEyes
    play sound "audio/swishQUICK_low.mp3"
    show slash
    pause .1
    hide slash
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with c_Red
    with vpunch
    if chaseDoneCounter == 4:
        play sound "audio/swishQUICK_low.mp3"
        show slash
        pause .05
        hide slash
        play sound "audio/punch_MEDIUM.mp3"
        show screen bloody
        with c_Red
        with vpunch
        pause .15
        play sound "audio/swishQUICK_low.mp3"
        show slash
        pause .05
        hide slash
        play sound "audio/punch_MEDIUM.mp3"
        show screen bloody
        with c_Red
        with vpunch
    scene bg caughtRed
    hide screen bloody
    with fade_Red
    pause .6
    scene black
    with dissolve
    pause .6
    if chaseDoneCounter == 0:
        play sound "audio/theirWill_LOW.mp3"
        show text "{alpha=1}Don't give in to it...{/alpha}" at truecenter
        with dissolve
        " "
        hide text
        with dissolve
        pause .6
    if chaseDoneCounter == 1:
        play sound "audio/theirWill_MEDIUM.mp3"
        show text "{alpha=0.75}Keep going...{/alpha}" at truecenter
        with dissolve
        " "
        hide text
        with dissolve
        pause .6
    if chaseDoneCounter == 2:
        play sound "audio/theirWill_HIGH.mp3"
        show text "{alpha=0.5}{color=#FF0000}IT's{/color} power is fading...{/alpha}" at truecenter
        with dissolve
        " "
        hide text
        with dissolve
        pause .6
    if chaseDoneCounter == 3:
        play sound "audio/theirWill_HIGH.mp3"
        show text "{alpha=0.25}You're almost there...{/alpha}" at truecenter
        with dissolve
        " "
        hide text
        with dissolve
        pause .6
    if chaseDoneCounter == 4:
        play sound "audio/theirWill_LOW.mp3"
        show text "{alpha=0.2}You have the strength to escape...{/alpha}" at truecenter
        with dissolve
        " "
        hide text
        with dissolve
        pause 1
        play sound "audio/theirWill_MEDIUM.mp3"
        show text "{alpha=0.2}At the end of this chaos...{/alpha}" at truecenter
        with dissolve
        " "
        hide text
        with dissolve
        pause 1
        play sound "audio/theirWill_MEDIUM.mp3"
        show text "{alpha=0.2}You will be okay...{/alpha}" at truecenter
        with dissolve
        " "
        hide text
        with dissolve
        pause 1
        play sound "audio/theirWill_HIGH.mp3"
        show text "{alpha=0.2}We are with you...{/alpha}" at truecenter
        with dissolve
        " "
        hide text
        with dissolve
        pause 1
    jump chaseFail


label alley1:
    play music "audio/LOOPS/51chaseLOOP.mp3" loop
    $ chaseClock = 3
    show screen chase_timer
    show alley1F

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            hide screen chase_timer
            hide alley1F
            scene black
            with wipeup
            jump alley2
        "GO RIGHT!":
            jump gotYou


label alley2:
    scene bg chaseAlley2
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show alley2R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump outOfAlley


label outOfAlley:
    $ leftAlley = True
    menu:
        "Go home!!":
            play sound "audio/stare.mp3"
            scene bg catEyes
            with c_Red
            with vpunch
            scene black
            with dissolve
            jump forcedMenu


label forcedMenu:
    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/51chaseLOOP.mp3" loop
    if firstForced == 0:
        "Dammit..! It overrode my choice!"
        "Where the hell do I go?!"
    scene black

    if f_OldTheater == 0 or f_NewCinema == 0 or f_Carnival == 0 or f_DogPark == 0:
        menu:
            "I've got to escape!"
            "go WATCH a {b}movie{/b}" if f_OldTheater == 0 or f_NewCinema == 0:
                if firstForced == 0:
                    "Anywhere but here!"
                    $ firstForced += 1
                jump forcedMovieMenu
            "go {b}to{/b} the CARNIVAL" if f_Carnival == 0:
                if firstForced == 0:
                    "Anywhere but here!"
                    $ firstForced += 1
                jump carnival1
            "GO to {b}dog{/b} park" if f_DogPark == 0:
                if firstForced == 0:
                    "Anywhere but here!"
                    $ firstForced += 1
                jump dogPark1
    else:
        stop music
        play sound "audio/theirWill_HIGH.mp3" volume 0.5
        scene black
        with whiteFlash
        pause .8
        play music "audio/LOOPS/50theirRequiemLOOP.mp3" loop
        you "!!" with vpunch
        you "Did I... do it..?"
        who "thread unraveling... {w}many us escape... {w}many free now..."
        who "{b}{color=#FF0000}I T{/color}{/b} losing us... {w}losing strength..."
        who "your escape... {w}possible now..."
        play sound "audio/glitch.mp3"
        cat "{size=+25}{b}{i}NOOO!!{/i}{/b}{/size}" with vpunch
        play sound "audio/glitch.mp3"
        cat "{size=+25}{b}{i}YOU!!{/i}{/b}{/size}" with vpunch
        play sound "audio/glitch.mp3"
        cat "{size=+25}{b}{i}ARE!!{/i}{/b}{/size}" with vpunch
        play sound "audio/beastRoar.mp3"
        cat "{size=+25}{b}{i}{color=#FF0000}MINE!!{/color}{/i}{/b}{/size}" with vpunch
        who "{alpha=0.8}we go ahead... {w}we go free...{/alpha}"
        who "{alpha=0.5}thank you...{/alpha}"
        who "{i}{alpha=0.3}thank you...{/alpha}{/i}"
        who "..."
        play sound "audio/theirWill_MEDIUM.mp3" volume 0.3
        show text "{alpha=0.25}thank you{/alpha}" at truecenter
        with dissolve
        pause 1
        hide text
        with dissolve
        stop sound fadeout 1.5
        you "..."
        you "Thank you too... all of you..."
        play music "audio/LOOPS/51chaseOUT.mp3"
        queue music "audio/heartbeatEcho.mp3" loop
        you "..."
        you "I won't forget you..."

        menu:
            "They were right... My choice is back!"
            "Go home!!":
                jump street1


label forcedMovieMenu:
    menu:
        "go to old theater." if f_OldTheater == 0:
            jump oldTheater1
        "go to new cinema." if f_NewCinema == 0:
            jump newCinema1


label oldTheater1:
    scene bg chaseOldTheater1
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show oldTheater1L

    menu:
        "GO LEFT!":
            hide screen chase_timer
            scene black
            with wipeleft
            jump oldTheater2
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            jump gotYou

label oldTheater2:
    scene bg chaseOldTheater2
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show oldTheater2R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump oldTheater3

label oldTheater3:
    scene bg chaseOldTheater3
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show oldTheater3L

    menu:
        "GO LEFT!":
            hide screen chase_timer
            scene black
            with wipeleft
            jump oldTheater4
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            jump gotYou

label oldTheater4:
    scene bg chaseOldTheater4
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show oldTheater4R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump oldTheater5a

label oldTheater5a:
    scene bg chaseOldTheater5
    with dissolve
    with vpunch
    you "Crap! A dead end..!"
    play sound "audio/beastRoar.mp3"
    cat "{size=+25}{b}{i}STOP RUNNING!!{/i}{/b}{/size}" with vpunch
    you "!!"

    $ chaseClock = 3
    show screen chase_timer
    show oldTheater5R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump oldTheater5b

label oldTheater5b:
    scene bg chaseOldTheater5
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show oldTheater5L

    menu:
        "GO LEFT!":
            hide screen chase_timer
            scene black
            with wipeleft
            jump oldTheater5c
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            jump gotYou

label oldTheater5c:
    scene bg chaseOldTheater5
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show oldTheater5F

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            hide screen chase_timer
            scene black
            with wipeup
            $ f_OldTheater += 1
            play sound "audio/beastRoar.mp3"
            cat "{size=+15}{b}{i}GET BACK HERE!!{/i}{/b}{/size}" with vpunch
            you "..."
            $ chaseDoneCounter += 1
            jump forcedMenu
        "GO RIGHT!":
            jump gotYou


label newCinema1:
    scene bg chaseNewCinema1
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show newCinema1R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump newCinema2

label newCinema2:
    scene bg chaseNewCinema2
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show newCinema2F

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            hide screen chase_timer
            scene black
            with wipeup
            jump newCinema3
        "GO RIGHT!":
            jump gotYou

label newCinema3:
    scene bg chaseNewCinema3
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show newCinema3L

    menu:
        "GO LEFT!":
            hide screen chase_timer
            scene black
            with wipeleft
            jump newCinema4
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            jump gotYou

label newCinema4:
    scene bg chaseNewCinema4
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show newCinema4R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump newCinema5a

label newCinema5a:
    scene bg chaseNewCinema5
    with dissolve
    with vpunch
    you "Dead end..? Where do I-"
    play sound "audio/beastRoar.mp3"
    cat "{size=+25}{b}{i}FOUND YOU~!!{/i}{/b}{/size}" with vpunch
    you "!!"

    $ chaseClock = 3
    show screen chase_timer
    show newCinema5F

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            hide screen chase_timer
            scene black
            with wipeup
            jump newCinema5b
        "GO RIGHT!":
            jump gotYou

label newCinema5b:
    scene bg chaseNewCinema5
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show newCinema5L

    menu:
        "GO LEFT!":
            hide screen chase_timer
            scene black
            with wipeleft
            jump newCinema5c
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            jump gotYou

label newCinema5c:
    scene bg chaseNewCinema5
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show newCinema5R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wipeleft
            $ f_NewCinema += 1
            play sound "audio/beastRoar.mp3"
            cat "{size=+15}{b}{i}GET BACK HERE!!{/i}{/b}{/size}" with vpunch
            you "..."
            $ chaseDoneCounter += 1
            jump forcedMenu

label carnival1:
    scene bg chaseCarnival1
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show carnival1R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump carnival2

label carnival2:
    scene bg chaseCarnival2
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show carnival2R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump carnival3

label carnival3:
    scene bg chaseCarnival3
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show carnival3L

    menu:
        "GO LEFT!":
            hide screen chase_timer
            scene black
            with wipeleft
            jump carnival4
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            jump gotYou

label carnival4:
    scene bg chaseCarnival4
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show carnival4F

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            hide screen chase_timer
            scene black
            with wipeup
            jump carnival5a
        "GO RIGHT!":
            jump gotYou

label carnival5a:
    scene bg chaseCarnival5
    with dissolve
    with vpunch
    you "How do I get out?!"
    play sound "audio/beastRoar.mp3"
    cat "{size=+25}{b}{i}NO ESCAPE!!{/i}{/b}{/size}" with vpunch
    you "!!"

    $ chaseClock = 3
    show screen chase_timer
    show carnival5R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump carnival5b

label carnival5b:
    scene bg chaseCarnival5
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show carnival5F

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            hide screen chase_timer
            scene black
            with wipeup
            jump carnival5c
        "GO RIGHT!":
            jump gotYou

label carnival5c:
    scene bg chaseCarnival5
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show carnival5L

    menu:
        "GO LEFT!":
            hide screen chase_timer
            scene black
            with wipeleft
            $ f_Carnival += 1
            play sound "audio/beastRoar.mp3"
            cat "{size=+15}{b}{i}GET BACK HERE!!{/i}{/b}{/size}" with vpunch
            you "..."
            $ chaseDoneCounter += 1
            jump forcedMenu
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            jump gotYou

label dogPark1:
    scene bg chaseDogPark1
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show dogPark1F

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            hide screen chase_timer
            scene black
            with wipeup
            jump dogPark2
        "GO RIGHT!":
            jump gotYou

label dogPark2:
    scene bg chaseDogPark2
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show dogPark2F

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            hide screen chase_timer
            scene black
            with wipeup
            jump dogPark3a
        "GO RIGHT!":
            jump gotYou

label dogPark3a:
    scene bg chaseDogPark3
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show dogPark3L

    menu:
        "GO LEFT!":
            hide screen chase_timer
            scene black
            with wipeleft
            jump dogPark3b
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            jump gotYou

label dogPark3b:
    scene bg chaseDogPark3
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show dogPark3R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump dogPark4

label dogPark4:
    scene bg chaseDogPark4
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show dogPark4R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump dogPark5a

label dogPark5a:
    scene bg chaseDogPark5
    with dissolve
    with vpunch
    you "Damn! Gotta escape..!"
    play sound "audio/beastRoar.mp3"
    cat "{size=+25}{b}GOT YOU {i}NOW!!{/i}{/b}{/size}" with vpunch
    you "!!"

    $ chaseClock = 3
    show screen chase_timer
    show dogPark5R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump dogPark5b

label dogPark5b:
    scene bg chaseDogPark5
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show dogPark5L

    menu:
        "GO LEFT!":
            hide screen chase_timer
            scene black
            with wipeleft
            jump dogPark5c
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            jump gotYou

label dogPark5c:
    scene bg chaseDogPark5
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show dogPark5F

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            hide screen chase_timer
            scene black
            with wipeup
            $ f_DogPark += 1
            play sound "audio/beastRoar.mp3"
            cat "{size=+15}{b}{i}GET BACK HERE!!{/i}{/b}{/size}" with vpunch
            you "..."
            $ chaseDoneCounter += 1
            jump forcedMenu
        "GO RIGHT!":
            jump gotYou

label street1:
    scene bg chaseStreet1
    with dissolve
    with vpunch
    play sound "audio/beastRoar.mp3"
    cat "{size=+25}{b}{i}NOOO!!{/i}{/b}{/size}" with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show street1R
    play sound "audio/tvStatic.mp3" loop
    show static

    menu:
        "GO LEFT!":
            stop sound
            jump gotYou
        "GO BACK!":
            stop sound
            jump gotYou
        "GO RIGHT!":
            stop sound
            hide screen chase_timer
            scene black
            with wiperight
            jump street2

label street2:
    scene bg chaseStreet2
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show street2L

    menu:
        "GO LEFT!":
            hide screen chase_timer
            scene black
            with wipeleft
            jump street3
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            jump gotYou

label street3:
    scene bg chaseStreet3
    with dissolve
    with vpunch
    play sound "audio/beastRoar.mp3"
    cat "{size=+25}{b}{i}COME BACK!!{/i}{/b}{/size}" with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show street3F
    play sound "audio/tvStatic.mp3" loop
    show static

    menu:
        "GO LEFT!":
            stop sound
            jump gotYou
        "GO BACK!":
            stop sound
            hide screen chase_timer
            scene black
            with wipeup
            jump street4
        "GO RIGHT!":
            stop sound
            jump gotYou

label street4:
    scene bg chaseStreet4
    with dissolve
    with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show street4R

    menu:
        "GO LEFT!":
            jump gotYou
        "GO BACK!":
            jump gotYou
        "GO RIGHT!":
            hide screen chase_timer
            scene black
            with wiperight
            jump street5

label street5:
    scene bg chaseStreet5
    with dissolve
    with vpunch
    play sound "audio/cat_angry.mp3"
    cat "{size=+25}{b}{i}{color=#FF0000}COME BACK!!{/color}{/i}{/b}{/size}" with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show street5L
    play sound "audio/tvStatic.mp3" loop
    show static

    menu:
        "GO LEFT!":
            stop sound
            hide screen chase_timer
            scene black
            with wipeleft
            jump apt1
        "GO BACK!":
            stop sound
            jump gotYou
        "GO RIGHT!":
            stop sound
            jump gotYou


label apt1:
    scene bg chaseApt1
    with dissolve
    with vpunch
    play sound "audio/cat_beg.mp3"
    cat "{size=+25}{b}{i}{color=#FF0000}PLEASE!!{/color}{/i}{/b}{/size}" with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show apt1R
    play sound "audio/tvStatic.mp3" loop
    show static

    menu:
        "GO LEFT!":
            stop sound
            jump gotYou
        "GO BACK!":
            stop sound
            jump gotYou
        "GO RIGHT!":
            stop sound
            hide screen chase_timer
            scene black
            with wiperight
            jump apt2

label apt2:
    scene bg chaseApt2
    with dissolve
    with vpunch
    play sound "audio/cat_beg.mp3"
    cat "{size=+20}{b}{i}{color=#FF0000}DON'T LEAVE ME!!{/color}{/i}{/b}{/size}" with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show apt2L
    play sound "audio/tvStatic.mp3" loop
    show static

    menu:
        "GO LEFT!":
            stop sound
            hide screen chase_timer
            scene black
            with wipeleft
            jump apt3
        "GO BACK!":
            stop sound
            jump gotYou
        "GO RIGHT!":
            stop sound
            jump gotYou

label apt3:
    scene bg chaseApt3
    with dissolve
    with vpunch
    play sound "audio/cat_beg.mp3"
    cat "{size=+15}{b}{i}{color=#FF0000}I'LL DIE WITHOUT YOU!!{/color}{/i}{/b}{/size}" with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show apt3R
    play sound "audio/tvStatic.mp3" loop
    show static

    menu:
        "GO LEFT!":
            stop sound
            jump gotYou
        "GO BACK!":
            stop sound
            jump gotYou
        "GO RIGHT!":
            stop sound
            hide screen chase_timer
            scene black
            with wiperight
            jump apt4

label apt4:
    scene bg chaseApt4
    with dissolve
    with vpunch
    play sound "audio/cat_sadLONG.mp3"
    cat "{size=+10}{b}{i}{color=#FF0000}I'LL DIE!!{/color}{/i}{/b}{/size}" with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show apt4R
    play sound "audio/tvStatic.mp3" loop
    show static

    menu:
        "GO LEFT!":
            stop sound
            jump gotYou
        "GO BACK!":
            stop sound
            jump gotYou
        "GO RIGHT!":
            stop sound
            hide screen chase_timer
            scene black
            with wiperight
            jump apt5

label apt5:
    scene bg chaseApt5
    with dissolve
    with vpunch
    stop music fadeout 1.5
    play sound "audio/cat_sadLONG.mp3"
    cat "{size=+5}{b}{i}{color=#FF0000}I'LL DIE!!{/color}{/i}{/b}{/size}" with vpunch

    $ chaseClock = 3
    show screen chase_timer
    show apt5F
    play sound "audio/tvStatic.mp3" loop
    play music "audio/heartbeatEcho.mp3" fadein 1
    show static

    menu:
        "PUSH FORWARD!":
            stop sound fadeout 5
            hide screen chase_timer
            scene bg whiteScreen
            with dissolve
            hide static
            pause .5
            scene bg chaseAptEND
            with dissolve
            play sound "audio/cat_beg.mp3"
            cat "WAIT..!"
            scene bg whiteScreen
            with chaseFade
            pause .6
            stop music fadeout 2.5
            play sound "audio/cat_sad.mp3"
            cat "{size=-5}Wait...{/size}"
            scene black
            with dissolve
            jump whereItBegan


label chase_time_out:
    jump gotYou

label chaseFail:
    menu:
        "Persist?":
            if leftAlley:
                jump forcedMenu
            else:
                "I need to dodge AWAY from it!"
                jump finalShowdownChase
        "Give up?":
            jump endChase

label endChase:


    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
