





default end_pocketsChecked = 0
default end_lookedAround = 0

init:
    image bg kill1a = "normalBGs/alleyKill01a.png"
    image bg kill1b = "normalBGs/alleyKill01b.png"
    image bg kill2a = "normalBGs/alleyKill02a.png"
    image bg kill2b = "normalBGs/alleyKill02b.png"
    image bg kill2c = "normalBGs/alleyKill02c.png"
    image bg kill2d = "normalBGs/alleyKill02d.png"
    image bg kill2e = "normalBGs/alleyKill02e.png"
    image bg kill2f = "normalBGs/alleyKill02f.png"
    image bg kill2g = "normalBGs/alleyKill02g.png"
    image bg kill3a = "normalBGs/alleyKill03a.png"
    image bg kill3b = "normalBGs/alleyKill03b.png"
    image bg kill3c = "normalBGs/alleyKill03c.png"
    image bg kill4a = "normalBGs/alleyKill04a.png"
    image bg kill4b = "normalBGs/alleyKill04b.png"
    image bg kill4c = "normalBGs/alleyKill04c.png"
    image bg kill4d = "normalBGs/alleyKill04d.png"
    image bg kill4e = "normalBGs/alleyKill04e.png"
    image bg kill4f = "normalBGs/alleyKill04f.png"
    image bg kill4g = "normalBGs/alleyKill04g.png"
    image bg kill4h = "normalBGs/alleyKill04h.png"
    image bg kill4i = "normalBGs/alleyKill04i.png"





label endCat:
    scene bg kill1a
    with fade_Red
    pause .6
    scene bg kill1b
    with dissolve
    "Really? Are you sure?"

    menu:
        "Maybe not...":
            scene black
            pause .6
            show screen catEyesFade
            with dissolve
            "..."
            hide screen catEyesFade
            scene bg alleyCat2
            jump inAlley_start
        "Yes.":
            jump endCat1

label endCat1:
    scene bg kill2a
    with dissolve
    "..."
    "Once you do this..."
    scene bg kill2b
    with dissolve
    "...you WON'T be able to turn back."

    menu:
        "I've changed my mind, let's go back!":
            scene black
            pause .6
            show screen catEyesFade
            with dissolve
            ".."
            "..."
            hide screen catEyesFade
            scene bg alleyCat2
            jump inAlley_start
        "...Do it.":
            jump endCat2

label endCat2:
    scene bg kill2c
    with dissolve
    "..."
    "Last chance."
    "Are you really, {b}really{/b} sure about this?"

    menu:
        "This is the point of NO return. Are you sure there's nothing else you wish to do?"
        "Take me back, I want us to play forever.":
            $ renpy.music.set_volume(0.0, 0, "music")
            scene black
            pause .6
            show screen catEyesFade
            with dissolve
            "..."
            "...We will."
            "Forever and ever..."
            show text "...and ever." at truecenter
            with dissolve
            pause 2
            hide text
            with dissolve
            $ renpy.music.set_volume(1.0, 0, "music")
            hide screen catEyesFade
            scene bg alleyCat2
            jump inAlley_start
        "{b}{color=#FF0000}k i l l... t h e... c a t...{/color}{/b}":
            jump endCatFinal

label endCatFinal:
    "..."
    you "..."
    cat "..."
    stop music
    scene bg kill2d
    pause .075
    scene bg kill2e
    pause .075
    play sound "audio/stare.mp3"
    scene bg kill2f
    pause .05
    scene bg kill2g
    pause .03
    scene black
    pause .5
    play sound "audio/gooeySquish.mp3"
    scene bg redScreen
    with p_Red
    play sound "audio/splat.mp3"
    show screen bloody
    with vpunch
    scene black
    hide screen bloody
    pause .4
    play sound "audio/gooeySquish.mp3"
    scene bg redScreen
    with p_Red
    play sound "audio/splat.mp3"
    show screen bloody
    with vpunch
    scene black
    hide screen bloody
    pause .4
    play sound "audio/gooeySquish.mp3"
    scene bg redScreen
    with p_Red
    play sound "audio/splat.mp3"
    show screen bloody
    with vpunch
    scene black
    hide screen bloody
    pause .4
    show screen blackOut
    scene bg kill3a
    ".."
    "..."
    "You kill the cat."
    play music "audio/LOOPS/46nineLivesIN.mp3"
    queue music "audio/LOOPS/46nineLivesLOOP.mp3" loop
    hide screen blackOut
    with fade_Red
    "Its corpse lays limp and lifeless in its now bloodstained cardboard box."
    ".."
    "..."

label endCatMenu:
    "What would you like to do?"

    menu:
        "...Check pockets." if end_pocketsChecked == 0:
            jump endPockets
        "...Look around the area." if end_lookedAround == 0:
            jump endLook
        "leave.":
            jump endLeave

label endPockets:
    "There's no point."
    "The cat is dead."
    "You dig in your pockets anyway..."
    "Left pocket..."
    show screen stringPanel
    with dissolve
    "...String. {w}Useless."
    hide screen stringPanel
    with dissolve
    "Right pocket..."
    show screen chocolatePanel
    with dissolve
    "..."
    "{color=#FF0000}{b}...Chocolate.{/b}{/color}"
    show screen blackOut
    hide screen chocolatePanel
    "You eat the chocolate."
    hide screen blackOut
    pause .6
    scene bg kill3b
    with dissolve
    "You have your phone."
    scene bg kill3c
    "Take a picture?"
    "..."
    "No point."
    scene bg kill3a
    with dissolve
    "The cat is dead."
    $ end_pocketsChecked += 1
    jump endCatMenu

label endLook:
    "What are you looking for?"
    "The cat is dead."
    "You look anyway..."
    scene bg alley1
    with dissolve
    "You look to your left and right..."
    "...Nothing but trash."
    "You look up..."
    "...The sun never reaches in here well enough."
    "But you can tell that it's a beautiful day today."
    "You look behind you..."
    ".."
    "..."
    show screen blackOut
    "{size=-10}{b}nobody saw.{/b}{/size}"
    hide screen blackOut
    "You look down in front of you..."
    scene bg kill3a
    ".."
    "..."
    "Oh yeah..."
    "The cat is dead."
    $ end_lookedAround += 1
    jump endCatMenu


label endLeave:
    play music "audio/LOOPS/46nineLivesOUT.mp3" noloop
    scene bg alley1
    with dissolve
    "You're done here."
    scene bg alley2
    with wiperight
    "You turn around and leave the alley..."
    ".."
    "..."
    "..?"
    "At least... {w}You {i}try{/i} to..."
    scene black
    with dissolve
    "As you stand at the edge of the alley's entrance..."
    "...you see that nothing exists beyond it."
    "Just an empty black void."
    you "!!!" with vpunch
    "You turn back..."
    scene bg kill4a
    with fade_Red
    pause 1
    "...and see that the back of the alley has become shrouded in darkness."
    "You can't see a thing."

label endLeave2:
    menu:
        "Leave the alley.":
            scene black
            with dissolve
            "{size=-5}But there's nothing there.{/size}"
            scene bg kill4a
            jump endLeave2
        "Approach the darkness":
            jump endLeave3

label endLeave3:
    "With no other options, you step towards the darkness..."
    "Closer..."
    "..."
    "And closer..."
    "And clo-{w=0.3}{nw}"
    stop music
    scene bg kill4b
    pause .1
    scene bg kill4c
    pause .075
    scene bg kill4d
    pause .05
    scene bg kill4e
    pause .03
    scene bg kill4f
    pause .03
    scene bg kill4g
    pause .03
    play sound "audio/swishQUICK_low.mp3"
    scene bg kill4h
    pause .03
    scene bg kill4i
    pause .01
    scene bg kill4a
    pause .001
    scene bg redScreen
    with p_Red
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    "{size=+10}{b}SLASH!!{/b}{/size}" with hpunch
    you "!!!" with hpunch
    scene bg kill4a
    hide screen bloody
    with dissolve
    pause .4
    ".."
    "..."
    "You're..."
    "You're blee-{w=0.2}{nw}"
    play sound "audio/swishQUICK_low.mp3"
    show slash
    scene bg redScreen
    with p_Red
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    "{size=+15}{b}{i}SLASH!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch
    scene bg kill4a
    hide screen bloody
    pause .4
    play sound "audio/swishQUICK_low.mp3"
    show slash
    pause .1
    scene bg redScreen
    with p_Red
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    "{size=+20}{b}{i}SLASH!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch
    scene bg kill4a
    hide screen bloody
    pause .4
    play sound "audio/swishQUICK_low.mp3"
    show slash
    pause .1
    scene bg redScreen
    with p_Red
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    "{size=+25}{b}{i}SLASH!! SLASH!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch
    scene bg kill4a
    hide screen bloody
    pause .4
    play sound "audio/swishQUICK_low.mp3"
    show slash
    pause .1
    scene bg redScreen
    with p_Red
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    "{size=+30}{b}{i}{color=#FF0000}SLASH!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with vpunch
    scene bg kill4a
    hide screen bloody
    pause .4
    "!!!"
    "..."
    scene bg redScreen
    with fade_Red
    pause 1
    show screen blackOut
    with dissolve
    pause 2
    play sound "audio/splat.mp3"
    scene black
    with p_Red
    play sound "audio/humanImpact.mp3" volume 0.6
    scene black
    with vpunch
    ".."
    "..."
    "You collapse to your knees..."
    hide screen blackOut
    "The front of your body is slashed open, leaking blood and guts and organs down your torso and over your lap."
    show screen catEyesFade
    with dissolve
    who "don't... {w}you... {w}know..."
    who "{size=-10}...that cats have \ {b}{color=#FF0000}N I N E{/color}{/b} \ lives~?{/size}"
    you "Wai-{w=0.3}{nw}"
    play sound "audio/swishQUICK_low.mp3"
    show slash
    pause .1
    scene bg redScreen
    with p_Red
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    "{size=+30}{b}{i}{color=#FF0000}SLASH!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch
    scene black
    hide screen bloody
    pause .4
    play sound "audio/swishQUICK_low.mp3"
    show slash
    pause .1
    scene bg redScreen
    with p_Red
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    "{size=+35}{b}{i}{color=#FF0000}SLASH!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch
    scene black
    hide screen bloody
    pause .4
    play sound "audio/swishQUICK_low.mp3"
    show slash
    pause .1
    scene bg redScreen
    with p_Red
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    "{size=+40}{b}{i}{color=#FF0000}S L A S H ! !{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch
    scene black
    hide screen bloody
    pause .4
    hide screen catEyesFade
    with fade_Red
    ".."
    "..."
    "Ending 36: Eight more left"
    "..."


    if persistent.ending36Done:
        jump beginFinale
    else:
        $ persistent.ending36Done = True
        $ persistent.endCounter += 1
        jump beginFinale



label beginFinale:


    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
