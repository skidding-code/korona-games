

translate pt_br strings:


    old "Self-voicing disabled."
    new "Auto-voz desabilitado."


    old "Clipboard voicing enabled. "
    new "A dublagem da área de transferência está ativada."


    old "Self-voicing enabled. "
    new "Auto-voz habilitado."


    old "bar"
    new "haste"


    old "selected"
    new "escolhido"


    old "viewport"
    new "janela de visualização"


    old "horizontal scroll"
    new "rolagem horizontal"


    old "vertical scroll"
    new "rolagem vertical"


    old "activate"
    new "ativar"


    old "deactivate"
    new "desativar"


    old "increase"
    new "aumentar"


    old "decrease"
    new "diminuir"


    old "Font Override"
    new "Substituição de fonte"


    old "Default"
    new "Padrão"


    old "DejaVu Sans"
    new "DejaVu Sans"


    old "Opendyslexic"
    new "Opendyslexic"


    old "Text Size Scaling"
    new "Dimensionamento do tamanho do texto"


    old "Reset"
    new "Reiniciar"


    old "Line Spacing Scaling"
    new "Escala de espaçamento de linha"


    old "Self-Voicing"
    new "Auto-Voz"


    old "Off"
    new "Desligado"


    old "Text-to-speech"
    new "Conversão de texto em fala"


    old "Clipboard"
    new "Área de transferência"


    old "Debug"
    new "Depurar"


    old "Self-Voicing Volume Drop"
    new "Queda de volume de auto-voz"


    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "As opções neste menu têm a intenção de melhorar a acessibilidade. Elas podem não funcionar com todos os jogos, e algumas combinações de opções podem tornar o jogo impossível de jogar. Isso não é um problema com o jogo ou com o mecanismo. Para obter os melhores resultados ao alterar fontes, tente manter o tamanho do texto igual ao original."


    old "{#weekday}Monday"
    new "{#weekday}Segunda-feira"


    old "{#weekday}Tuesday"
    new "{#weekday}Terça-feira"


    old "{#weekday}Wednesday"
    new "{#weekday}Quarta-feira"


    old "{#weekday}Thursday"
    new "{#weekday}Quinta-feira"


    old "{#weekday}Friday"
    new "{#weekday}Sexta-feira"


    old "{#weekday}Saturday"
    new "{#weekday}Sábado"


    old "{#weekday}Sunday"
    new "{#weekday}Domingo"


    old "{#weekday_short}Mon"
    new "{#weekday_short}Seg"


    old "{#weekday_short}Tue"
    new "{#weekday_short}Ter"


    old "{#weekday_short}Wed"
    new "{#weekday_short}Qua"


    old "{#weekday_short}Thu"
    new "{#weekday_short}Qui"


    old "{#weekday_short}Fri"
    new "{#weekday_short}Sex"


    old "{#weekday_short}Sat"
    new "{#weekday_short}Sáb"


    old "{#weekday_short}Sun"
    new "{#weekday_short}Dom"


    old "{#month}January"
    new "{#month}Janeiro"


    old "{#month}February"
    new "{#month}Fevereiro"


    old "{#month}March"
    new "{#month}Março"


    old "{#month}April"
    new "{#month}Abril"


    old "{#month}May"
    new "{#month}Maio"


    old "{#month}June"
    new "{#month}Junho"


    old "{#month}July"
    new "{#month}Julho"


    old "{#month}August"
    new "{#month}Agosto"


    old "{#month}September"
    new "{#month}Setembro"


    old "{#month}October"
    new "{#month}Outubro"


    old "{#month}November"
    new "{#month}Novembro"


    old "{#month}December"
    new "{#month}Dezembro"


    old "{#month_short}Jan"
    new "{#month_short}Jan"


    old "{#month_short}Feb"
    new "{#month_short}Fev"


    old "{#month_short}Mar"
    new "{#month_short}Mar"


    old "{#month_short}Apr"
    new "{#month_short}Abr"


    old "{#month_short}May"
    new "{#month_short}Maio"


    old "{#month_short}Jun"
    new "{#month_short}Jun"


    old "{#month_short}Jul"
    new "{#month_short}Jul"


    old "{#month_short}Aug"
    new "{#month_short}Ago"


    old "{#month_short}Sep"
    new "{#month_short}Set"


    old "{#month_short}Oct"
    new "{#month_short}Out"


    old "{#month_short}Nov"
    new "{#month_short}Nov"


    old "{#month_short}Dec"
    new "{#month_short}Dez"


    old "%b %d, %H:%M"
    new "%b %d, %H:%M"


    old "Save slot %s: [text]"
    new "Salvar slot %s: [text]"


    old "Load slot %s: [text]"
    new "Carregar slot %s: [text]"


    old "Delete slot [text]"
    new "Excluir slot [text]"


    old "File page auto"
    new "Página de arquivo auto"


    old "File page quick"
    new "Página de arquivo rápido"


    old "File page [text]"
    new "Página de arquivo [text]"


    old "Next file page."
    new "Próxima página do arquivo."


    old "Previous file page."
    new "Página do arquivo anterior."


    old "Quick save complete."
    new "Salvamento rápido concluído."


    old "Quick save."
    new "Salvamento rápido."


    old "Quick load."
    new "Carregamento rápido."


    old "Language [text]"
    new "Idioma [text]"


    old "The interactive director is not enabled here."
    new "O diretor interativo não está habilitado aqui."


    old "⬆"
    new "⬆"


    old "⬇"
    new "⬇"


    old "Done"
    new "Feito"


    old "(statement)"
    new "(declaração)"


    old "(tag)"
    new "(marcação)"


    old "(attributes)"
    new "(atributos)"


    old "(transform)"
    new "(transformar)"


    old "(transition)"
    new "(transição)"


    old "(channel)"
    new "(canal)"


    old "(filename)"
    new "(nome do arquivo)"


    old "Change"
    new "Mudar"


    old "Add"
    new "Adicionar"


    old "Cancel"
    new "Cancelar"


    old "Remove"
    new "Remover"


    old "Statement:"
    new "Declaração:"


    old "Tag:"
    new "Marcação:"


    old "Attributes:"
    new "Atributos:"


    old "Transforms:"
    new "Transformações:"


    old "Behind:"
    new "Atrás:"


    old "Transition:"
    new "Transição:"


    old "Channel:"
    new "Canal:"


    old "Audio Filename:"
    new "Nome do arquivo de áudio:"


    old "Are you sure?"
    new "Tem certeza?"


    old "Are you sure you want to delete this save?"
    new "Tem certeza de que deseja excluir este salvamento?"


    old "Are you sure you want to overwrite your save?"
    new "Tem certeza de que deseja substituir seu salvamento?"


    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "O carregamento perderá o progresso não salvo.\nTem certeza de que deseja fazer isso?"


    old "Are you sure you want to quit?"
    new "Tem certeza de que deseja sair?"


    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Tem certeza de que deseja retornar ao menu principal?\nIsso perderá o progresso não salvo."


    old "Are you sure you want to end the replay?"
    new "Tem certeza de que deseja encerrar o replay?"


    old "Are you sure you want to begin skipping?"
    new "Tem certeza de que deseja começar a pular?"


    old "Are you sure you want to skip to the next choice?"
    new "Tem certeza de que deseja pular para a próxima opção?"


    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "Tem certeza de que deseja pular o diálogo não visto para a próxima opção?"


    old "Failed to save screenshot as %s."
    new "Falha ao salvar a captura de tela como %s."


    old "Saved screenshot as %s."
    new "Captura de tela salva como %s."


    old "Skip Mode"
    new "Modo de pular"


    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Este programa contém software livre sob uma série de licenças, incluindo a Licença MIT e a Licença Pública Geral Menor GNU. Uma lista completa de software, incluindo links para o código-fonte completo, pode ser encontrada {a=https://www.renpy.org/l/license}aqui{/a}."


    old "display"
    new "mostrar"


    old "transitions"
    new "transições"


    old "skip transitions"
    new "pular transições"


    old "video sprites"
    new "sprites de vídeo"


    old "show empty window"
    new "mostrar janela vazia"


    old "text speed"
    new "velocidade do texto"


    old "joystick"
    new "joystick"


    old "joystick..."
    new "joystick..."


    old "skip"
    new "pular"


    old "skip unseen [text]"
    new "pular [text] invisível"


    old "skip unseen text"
    new "pular texto não visto"


    old "begin skipping"
    new "comece a pular"


    old "after choices"
    new "depois das escolhas"


    old "skip after choices"
    new "pular depois das escolhas"


    old "auto-forward time"
    new "tempo de avanço automático"


    old "auto-forward"
    new "avanço automático"


    old "Auto forward"
    new "Avançar automaticamente"


    old "auto-forward after click"
    new "avanço automático após clique"


    old "automatic move"
    new "movimento automático"


    old "wait for voice"
    new "espere pela voz"


    old "voice sustain"
    new "sustentação da voz"


    old "self voicing"
    new "auto voz"


    old "self voicing volume drop"
    new "queda de volume de auto voz"


    old "clipboard voicing"
    new "voz da área de transferência"


    old "debug voicing"
    new "depuração de voz"


    old "emphasize audio"
    new "enfatizar áudio"


    old "rollback side"
    new "lado de reversão"


    old "gl powersave"
    new "gl powersave"


    old "gl framerate"
    new "gl framerate"


    old "gl tearing"
    new "gl tearing"


    old "font transform"
    new "transformação de fonte"


    old "font size"
    new "tamanho da fonte"


    old "font line spacing"
    new "espaçamento entre linhas da fonte"


    old "system cursor"
    new "cursor do sistema"


    old "renderer menu"
    new "menu do renderizador"


    old "accessibility menu"
    new "menu de acessibilidade"


    old "music volume"
    new "volume da música"


    old "sound volume"
    new "volume do som"


    old "voice volume"
    new "volume de voz"


    old "mute music"
    new "música muda"


    old "mute sound"
    new "som mudo"


    old "mute voice"
    new "voz muda"


    old "mute all"
    new "silenciar tudo"


    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Voz da área de transferência habilitada. Pressione 'shift+C' para desabilitar."


    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "A autovoz diria \"[renpy.display.tts.last]\". Pressione 'alt+shift+V' para desabilitar."


    old "Self-voicing enabled. Press 'v' to disable."
    new "Auto-voz habilitado. Pressione 'v' para desabilitar."


    old "Empty Slot."
    new "Espaço vazio."


    old "Previous"
    new "Anterior"


    old "Next"
    new "Próximo"


    old "Joystick Mapping"
    new "Mapeamento de Joystick"


    old "Image [index] of [count] locked."
    new "Imagem [index] de [count] bloqueada."


    old "prev"
    new "anterior"


    old "next"
    new "próximo"


    old "slideshow"
    new "apresentação de slides"


    old "return"
    new "voltar"


    old "Select Gamepad to Calibrate"
    new "Selecione o Gamepad para calibrar"


    old "No Gamepads Available"
    new "Nenhum controle disponível"


    old "Calibrating [name] ([i]/[total])"
    new "Calibrando [name] ([i]/[total])"


    old "Press or move the '[control!s]' [kind]."
    new "Pressione ou mova o '[control!s]' [kind]."


    old "Skip (A)"
    new "Pular (A)"


    old "Back (B)"
    new "Voltar (B)"


    old "Open"
    new "Abrir"


    old "Opens the traceback.txt file in a text editor."
    new "Abre o arquivo traceback.txt em um editor de texto."


    old "Copy BBCode"
    new "Copiar BBCode"


    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copia o arquivo traceback.txt para a área de transferência como BBcode para fóruns como https://lemmasoft.renai.us/."


    old "Copy Markdown"
    new "Copiar Markdown"


    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Copia o arquivo traceback.txt para a área de transferência como Markdown para Discord."


    old "An exception has occurred."
    new "Ocorreu uma exceção."


    old "Rollback"
    new "Reverter"


    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Tenta reverter para um momento anterior, permitindo que você salve ou escolha uma opção diferente."


    old "Ignores the exception, allowing you to continue."
    new "Ignora a exceção, permitindo que você continue."


    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Ignora a exceção, permitindo que você continue. Isso frequentemente leva a erros adicionais."


    old "Reload"
    new "Recarregar"


    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Recarrega o jogo do disco, salvando e restaurando o estado do jogo, se possível."


    old "Console"
    new "Console"


    old "Opens a console to allow debugging the problem."
    new "Abre um console para permitir a depuração do problema."


    old "Quits the game."
    new "Sai do jogo."


    old "Parsing the script failed."
    new "A análise do script falhou."


    old "Opens the errors.txt file in a text editor."
    new "Abre o arquivo errors.txt em um editor de texto."


    old "Copies the errors.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copia o arquivo errors.txt para a área de transferência como BBcode para fóruns como https://lemmasoft.renai.us/."


    old "Copies the errors.txt file to the clipboard as Markdown for Discord."
    new "Copia o arquivo errors.txt para a área de transferência como Markdown para Discord."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
