


translate pt_br prologue_start_984bc6cc:


    "Você não está tendo um dia bom, como sempre."


translate pt_br prologue_start_1481783e:


    you "Ah, ótimo..."


translate pt_br prologue_start_45f04c4f:


    "É a primeira vez em um bom tempo que você sentiu vontade de sair..."


translate pt_br prologue_start_8a152280:


    "Mas no meio da caminhada, começa a chover."


translate pt_br prologue_start_11943181:


    "Típico. Mas..."


translate pt_br prologue_start_be9a673a:


    "...talvez isso seja só um sinal de que você deveria ter ficado em casa hoje?"


translate pt_br prologue_start_aba41a33:


    "É. Você sempre pode tentar de novo amanhã... {w}né?"


translate pt_br prologue_start_f93e972d:


    "Você se vira para voltar para casa quando--"


translate pt_br prologue_start_a1100951:


    who "{size=-5}{alpha=0.25}Miau...{/alpha}{/size}"


translate pt_br prologue_start_4d2575f7:


    you "{i}Hã? O que foi isso..?{/i}"


translate pt_br prologue_start_6b2b7353:


    "Tem só algumas poucas pessoas na rua..."


translate pt_br prologue_start_dd4ef7b8:


    "Faz sentido, devido ao aumento nas pessoas desaparecidas na área recentemente..."


translate pt_br prologue_start_edacd6a8:


    "Bom, {i}isso{/i} e a chuva..."


translate pt_br prologue_start_8dabefc6:


    ".."


translate pt_br prologue_start_a20cefa7:


    "..."


translate pt_br prologue_start_bf8c3d80:


    "Mas {i}nenhuma{/i} delas reage ao som."


translate pt_br prologue_start_01f2bb72:


    "Com a curiosidade guiando seus passos, você segue o som até a entrada de um beco sujo e escuro."


translate pt_br prologue_start_c0632003:


    "Você entra timidamente no beco e segue em frente..."


translate pt_br prologue_start_ee1644f5:


    "O chão molhado da chuva faz com que seus passos soem mais altos e confiantes do que você realmente se sente."


translate pt_br prologue_start_a46fe60b:


    who "Miau! Miau!"


translate pt_br prologue_start_0141658f:


    "Finalmente, a fonte do som aparece na luz fria e tênue do beco..."


translate pt_br prologue_start_7845feba:


    "No fundo do beco, numa caixa grande de papelão..."


translate pt_br prologue_start_69a9648a:


    "...está um gato."


translate pt_br prologue_start_e4ece72d:


    you "Hã. Acho que isso era óbvio..."


translate pt_br prologue_start_fc6b31f2:


    "É um gato com uma aparência interessante. Seus lindos olhos amarelos brilham como ouro entre o mar negro de sua pelagem preta."


translate pt_br prologue_start_3b9482ac:


    "Ele coloca as patas da frente na borda da caixa e olha para você."


translate pt_br prologue_start_085f82bc:


    cat "Miau..."


translate pt_br prologue_start_632d1a35:


    you "!!!" with hpunch


translate pt_br prologue_start_8adec91e:


    you "{i}T-{w}Tão fofo..!{/i}"


translate pt_br prologue_start_443266e6:


    "E ele definitivamente {i}sabe{/i} disso..."


translate pt_br prologue_start_51df6142:


    "Você nunca teve uma opinião formada sobre gatos antes..."


translate pt_br prologue_start_6d340fc5:


    "Mas se todos forem como esse aqui..."


translate pt_br prologue_start_1074677c:


    "...é chocante que eles ainda não tenham achado um jeito de dominar o mundo."


translate pt_br prologue_start_1eb5cc4a:


    "Você não acha que se importaria em se curvar a um lorde soberano felino."


translate pt_br prologue_start_dae0ec55:


    you "..."


translate pt_br prologue_start_1ca0cd0e:


    "Você olha descontente ao redor do beco."


translate pt_br prologue_start_1d578264:


    you "Quem deixa gatos em caixas de papelão hoje em dia, afinal? Eles não acabariam pulando pra fora da caixa eventualmente?"


translate pt_br prologue_start_7f0ac95c:


    cat "..."


translate pt_br prologue_start_1325c2b8:


    "O gato não te responde. {w}Obviamente."


translate pt_br prologue_start_926d62e7:


    "Ele também não sai da caixa como você sugeriu."


translate pt_br prologue_start_c6acd156:


    "Ele fica só... olhando para você?"


translate pt_br prologue_start_67f65235:


    "Como se esperasse você dar o próximo passo..."


translate pt_br prologueChoice1_c86cf436:


    "Com um suspiro, você dá um passo decisivo para trás."


translate pt_br prologueChoice1_e66a2c52:


    "Por mais fofo que o gato seja, você não pode se dar ao luxo de adotar um animal por impulso."


translate pt_br prologueChoice1_76b01b01:


    "O aluguel está chegando. E seu trabalho não exatamente te deixa nadando em dinheiro..."


translate pt_br prologueChoice1_ecf3c1ab:


    "Você acena triste para o gato."


translate pt_br prologueChoice1_8199e4d6:


    you "Foi mal... Boa sorte por aí, tá?"


translate pt_br prologueChoice1_7f0ac95c:


    cat "..."


translate pt_br prologueChoice1_4b339222:


    "Você se vira, deixando o gato e o beco para trás."


translate pt_br prologueChoice1_93d0f774:


    "A chuva está piorando."


translate pt_br prologueChoice1_a20cefa7:


    "..."


translate pt_br prologueChoice1_dd6fc7c7:


    "Tá na hora de ir para casa."


translate pt_br prologueChoice2_8dabefc6:


    ".."


translate pt_br prologueChoice2_a20cefa7:


    "..."


translate pt_br prologueChoice2_4122aacf:


    you "Quer saber..?"


translate pt_br prologueChoice2_5743aa48:


    "Você alcança a caixa e pega o gato, o segurando na sua frente."


translate pt_br prologueChoice2_4907ebc0:


    you "...por que não?"


translate pt_br prologueChoice2_e5fab8a0:


    cat "Miau!"


translate pt_br prologueChoice2_3abd7e46:


    you "Você está sozinho e, bom... Meio que eu estou no mesmo barco. Então..."


translate pt_br prologueChoice2_7dc50f87:


    "Você coloca o gato próximo."


translate pt_br prologueChoice2_bf60a3c6:


    "Você não percebeu que ele estava tremendo até aquele momento... Mas ele começa a respirar com mais facilidade à medida que encosta em seu peito."


translate pt_br prologueChoice2_5498dacc:


    you "...por que não ficarmos juntos, né? Pelo menos por um tempo."


translate pt_br prologueChoice2_55355e09:


    cat "Purr... Purr..."


translate pt_br prologueChoice2_d091f8d9:


    "Você acha que \"por um tempo\" tá mais pra um dia. Você será responsável e o levará a um abrigo amanhã, mas por enquanto..."


translate pt_br prologueChoice2_a7af763b:


    you "Vamos te tirar da chuva, tá bem?"


translate pt_br prologueChoice2_085f82bc:


    cat "Miau..."


translate pt_br prologueChoice2_6139ffca:


    "Você para em um pequeno pet shop local para comprar ração para gatos, então, vai para casa."


translate pt_br prologueChoice2_df101305:


    "Você vive em um apartamento humilde."


translate pt_br prologueChoice2_247ad3ce:


    "Um quarto. Um banheiro."


translate pt_br prologueChoice2_2d3f71e5:


    "Só {i}você{/i} sozinho vivendo nele..."


translate pt_br prologueChoice2_f380a402:


    "Então, é estranho ter outro ser vivo aí dentro depois de tanto tempo."


translate pt_br prologueChoice2_8b0c916e:


    "Mesmo que {i}seja{/i} só um gato."


translate pt_br prologueChoice2_566e1d7f:


    "Depois de trancar a porta e colocar o gato no chão, você observa enquanto ele explora curiosamente o novo ambiente."


translate pt_br prologueChoice2_fddd40fa:


    "Deixando o felino à vontade, você começa a preparar o jantar para vocês dois."


translate pt_br prologueChoice2_c9d1a483:


    "Você pega a lata de ração para gatos e a abre com a aba no topo."


translate pt_br prologueChoice2_e15d0030:


    "Você coloca um pouco de ração para gatos em um pratinho e estala a língua para chamar o gato."


translate pt_br prologueChoice2_b5c20577:


    "Ele se anima com seu chamado e corre para perto de você."


translate pt_br prologueChoice2_be0440b9:


    "Ele olha para o prato de comida..."


translate pt_br prologueChoice2_8dabefc6_1:


    ".."


translate pt_br prologueChoice2_a20cefa7_1:


    "..."


translate pt_br prologueChoice2_655f9b6a:


    "...e o ignora completamente."


translate pt_br prologueChoice2_a5cadf35:


    you "Tá sem fome, eu acho..."


translate pt_br prologueChoice2_e322cfa9:


    "Você tenta não deixar isso te incomodar."


translate pt_br prologueChoice2_ce62169f:


    "O gato não compreende o conceito de dinheiro para ficar agradecido que você gastou seu dinheiro suado com ele."


translate pt_br prologueChoice2_562ebb7f:


    "É só um gato, afinal de contas."


translate pt_br prologueChoice2_bf6a731d:


    you "Então eu vou... deixar aqui caso fique com fome mais tarde, viu?"


translate pt_br prologueChoice2_369ea70f:


    "O gato se esfrega nas suas pernas, ronronando."


translate pt_br prologueChoice2_94dc0c23:


    "Você sorri. Isso é o suficiente como agradecimento para você."


translate pt_br prologueChoice2_0bb73e9b:


    "Ele te segue para a cozinha enquanto você prepara seu próprio jantar."


translate pt_br prologueChoice2_41ce0cbe:


    "Você decide que tem ingredientes suficientes para um sanduíche."


translate pt_br prologueChoice2_edb918a9:


    "Pão tostado... {w}Maionese e mostarda espalhadas... {w}Peru, queijo e alface perfeitamente colocados... {w}Tomate fatiado--{w=0.3}{nw}"


translate pt_br prologueChoice2_dfc857fd:


    you "AI!" with vpunch


translate pt_br prologueChoice2_0d62a972:


    "Você faz uma cara feia ao cortar o dedo com a faca enquanto fatiava um tomate."


translate pt_br prologueChoice2_04d2c1e4:


    you "Burro..."


translate pt_br prologueChoice2_970b6c6e:


    "Você se sente meio envergonhado por um erro tão besta e suspira, jogando a faca sobre a tábua de cortar."


translate pt_br prologueChoice2_3047da37:


    "Você está prestes a ir ao banheiro buscar um curativo quando o gato pula para cima do balcão."


translate pt_br prologueChoice2_316203fa:


    "Ele cheira a faca e mia diretamente para você."


translate pt_br prologueChoice2_eddf2ff6:


    you "Hehe... Não se preocupe, eu tô bem. Foi só um--"


translate pt_br prologueChoice2_ca13fffe:


    you "!!" with hpunch


translate pt_br prologueChoice2_e32ed4c0:


    "Você observa enquanto o gato começa a..."


translate pt_br prologueChoice2_40d9ca73:


    "..?"


translate pt_br prologueChoice2_2f1c2108:


    "...lamber suavemente, mas {b}com entusiasmo{/b}, o sangue da faca."


translate pt_br prologueChoice2_fe70304c:


    "O {i}seu{/i} sangue."


translate pt_br prologueChoice2_31324b11:


    "Você fica tão chocado que, quando volta a si, a faca estava completamente limpa."


translate pt_br prologueChoice2_8477717d:


    "O gato senta, encarando você."


translate pt_br prologueChoice2_dae0ec55:


    you "..."


translate pt_br prologueChoice2_9b097520:


    "Você... {w}se sente um pouco desconfortável."


translate pt_br prologueChoice2_23fd2960:


    "Claro que gatos são predadores carnívoros, mas isso foi um pouco estranho."


translate pt_br prologueChoice2_01fb927e:


    "Né..?"


translate pt_br prologueChoice2_7de205f2:


    "Claro, você não é um especialista em gatos... mas isso definitivamente não é algo que um gato normal faria..."


translate pt_br prologueChoice2_a20cefa7_2:


    "..."


translate pt_br prologueChoice2_c65aa055:


    "{size=-5}...Né?{/size}"


translate pt_br prologueChoice2_e5fab8a0_1:


    cat "Miau!"


translate pt_br prologueChoice2_dae0ec55_1:


    you "..."


translate pt_br prologueChoice2_252add1f:


    "Enfim... Você não vai abandonar um gato necessitado enquanto ainda está chovendo lá fora. Não depois de todo esse esforço."


translate pt_br prologueChoice2_94b91a9f:


    "Você ia levá-lo ao abrigo amanhã de qualquer jeito. O que é uma noite desconfortável?"


translate pt_br prologueChoice2_e1de2017:


    "Estranho ou não..."


translate pt_br prologueChoice2_e8d99b4a:


    "...é só um gato."


translate pt_br prologueChoice2_4141585e:


    "O resto da noite, infelizmente, só piora a partir daí."


translate pt_br prologueChoice2_a2f3b22c:


    "Mesmo depois de cobrir o corte com um curativo, o gato continua tentando lamber a ferida."


translate pt_br prologueChoice2_d1ec5fd6:


    "Enquanto você come o sanduíche..."


translate pt_br prologueChoice2_20bbb144:


    "Enquanto você limpa a cozinha..."


translate pt_br prologueChoice2_960243fa:


    "Enquanto você tenta assistir TV..."


translate pt_br prologueChoice2_59387313:


    "Você gentilmente o afasta toda vez, mas começa a ficar preocupado com o comportamento estranho."


translate pt_br prologueChoice2_f35db5a7:


    "E se ele tem gosto por sangue e agora acha que você é comida? Você não tem certeza do que fazer se ele começar a ficar mais agressivo."


translate pt_br prologueChoice2_851a5259:


    "Você continua pensando na ração do gato no canto..."


translate pt_br prologueChoice2_f303bb24:


    "...Intacta."


translate pt_br prologueChoice2_e5fab8a0_2:


    cat "Miau!"


translate pt_br prologueChoice2_5e84b463:


    cat "Miau! Miau!"


translate pt_br prologueChoice2_699a0b08:


    cat "Miau! Miau! {b}{i}Miau!{/i}{/b}" with hpunch


translate pt_br prologueChoice2_2d1f6e2d:


    you "Ahh, qual é! Já {i}chega{/i}!"


translate pt_br prologueChoice2_2a835de7:


    "Você o afasta com um pouco mais de força desta vez, irritado."


translate pt_br prologueChoice2_80296b88:


    "Você se sente mal na mesma hora, mas antes que possa fazer algo, o gato mia alto para você e sai correndo pelo canto e para o corredor."


translate pt_br prologueChoice2_116e7855:


    "Você suspira profundamente."


translate pt_br prologueChoice2_eb31519a:


    "Neste ponto, você só está preocupado que ele arranque um pedaço de você enquanto dorme."


translate pt_br prologueChoice2_5cac017b:


    you "{i}Talvez um veterinário tenha idéia de como acalmá-lo..?{/i}"


translate pt_br prologueChoice2_760ce1f2:


    "Só lhe resta esperar. Você não tem muita opção além de largar o gato no meio da chuva..."


translate pt_br prologueChoice2_7e95c19a:


    "Depois de encontrar o número de um veterinário local..."


translate pt_br prologueChoice2_684db044:


    "...você pega o telefone e--{w=1.0}{nw}"


translate pt_br prologueChoice2_28b3ac41:


    you "!!"


translate pt_br prologueChoice2_8ca8510a:


    you "!!!" with vpunch


translate pt_br prologueChoice2_a66b8231:


    "As luzes..."


translate pt_br prologueChoice2_f41aa0f8:


    "...apagaram?"


translate pt_br prologueChoice2_dec218fc:


    "Ótimo. Perfeito. A chuva deve ter feito a energia cair."


translate pt_br prologueChoice2_eb2b6f8b:


    "Você olha o celular e descobre que a bateria acabou."


translate pt_br prologueChoice2_adcad194:


    "Você deve ter se esquecido de carregar antes de sair mais cedo."


translate pt_br prologueChoice2_b129dbc5:


    "A saída foi tão no impulso que, sem dúvida, bagunçou sua rotina habitual."


translate pt_br prologueChoice2_a7869f4a:


    "Você pega uma lanterna e liga."


translate pt_br prologueChoice2_8dabefc6_2:


    ".."


translate pt_br prologueChoice2_a20cefa7_3:


    "..."


translate pt_br prologueChoice2_eff9b4f7:


    "Tá quieto."


translate pt_br prologueChoice2_a3038114:


    "Tá quieto {i}demais{/i}."


translate pt_br prologueChoice2_f816a0f7:


    "A chuva parou?"


translate pt_br prologueChoice2_3e305a49:


    "Mas então... por que a energia caiu?"


translate pt_br prologueChoice2_a20cefa7_4:


    "..."


translate pt_br prologueChoice2_b6a58494:


    "Você olha lá fora."


translate pt_br prologueChoice2_0eccd9ec:


    "O céu tá completamente preto. Que horas são?"


translate pt_br prologueChoice2_22796bbb:


    "Você se vira para olhar o relógio..."


translate pt_br prologueChoice2_479c3431:


    you "!!" with vpunch


translate pt_br prologueChoice2_67438124:


    "O gato senta em cima do seu relógio digital, te encarando."


translate pt_br prologueChoice2_cc2a0af7:


    "Parando pra pensar, você percebe que o relógio não deveria estar funcionando com a falta de energia, mas os números estão acesos..."


translate pt_br prologueChoice2_8ce74938:


    "...e completamente fora de controle."


translate pt_br prologueChoice2_a4473e29:


    "O gato te encara. Completamente imóvel. Você pensaria ser uma estátua se não soubesse."


translate pt_br prologueChoice2_1859d2a8:


    "Não está dando nenhum indício de que está vivo."


translate pt_br prologueChoice2_e2df05b3:


    "Não está piscando. Nem mesmo respirando. Mas..."


translate pt_br prologueChoice2_e9e5efea:


    "...seus olhos..."


translate pt_br prologueChoice2_a20cefa7_5:


    "..."


translate pt_br prologueChoice2_31ac1903:


    "Isso... não é normal."


translate pt_br prologueChoice2_9804c7b0:


    "Você está com medo."


translate pt_br prologueChoice2_65973cff:


    "Você quer correr, mas tem medo de perder o gato de vista."


translate pt_br prologueChoice2_9c9d6223:


    "Você considera jogar o gato na rua no final das contas..."


translate pt_br prologueChoice2_bf0874e3:


    "Mas..."


translate pt_br prologueChoice2_d73fee82:


    "...assim que o pensamento vem à sua cabeça, {w}você sente uma vontade forte de vomitar."


translate pt_br prologueChoice2_f0883f9b:


    "Aqueles olhos... Eles te paralisam."


translate pt_br prologueChoice2_3a7a79cb:


    "Mesmo com sua lanterna apontada para ele..."


translate pt_br prologueChoice2_f6f81472:


    "Suas pupilas são grandes e redondas, como poços de tinta--{w=2.0}{nw}"


translate pt_br prologueChoice2_28b3ac41_1:


    you "!!"


translate pt_br prologueChoice2_82828c42:


    "A lanterna pisca..."


translate pt_br prologueChoice2_8dabefc6_3:


    ".."


translate pt_br prologueChoice2_a20cefa7_6:


    "..."


translate pt_br prologueChoice2_c6952d96:


    "...e o gato some."


translate pt_br prologueChoice2_14176a20:


    "O medo imediatamente consome sua mente."


translate pt_br prologueChoice2_447e9442:


    "O silêncio interrompido pelo rápido batimento do seu coração..."


translate pt_br prologueChoice2_5f6e3577:


    "...é substituído à medida que seus ouvidos começam a captar lentamente o som de estática ao seu redor."


translate pt_br prologueChoice2_84a95582:


    "Como o relógio está funcionando sem energia..?"


translate pt_br prologueChoice2_2a8eb917:


    "Você não sabe por que uma pergunta dessas importa neste momento..."


translate pt_br prologueChoice2_e79a1e8f:


    "...mas você sente que ter a resposta dará sentido a tudo o que está acontecendo."


translate pt_br prologueChoice2_741f7e05:


    "Que a ordem será restaurada."


translate pt_br prologueChoice2_a20cefa7_7:


    "..."


translate pt_br prologueChoice2_30396cff:


    "Mas nenhuma resposta vem à mente."


translate pt_br prologueChoice2_f028268f:


    "Você se afasta do relógio..."


translate pt_br prologueChoice2_dbe9efe4:


    "...e sente como se o próprio ar te sufocasse abruptamente em resposta..."


translate pt_br prologueChoice2_cc431bef:


    "...como um predador pronto para atacar..."


translate pt_br prologueChoice2_7331e0b1:


    "...mas à espera."


translate pt_br prologueChoice2_d877d809:


    "À espera... do seu próximo movimento."


translate pt_br prologueChoice2_e0dc85ac:


    "Mas você está com medo de se mover. {w}Está com medo até de respirar."


translate pt_br prologueChoice2_a20cefa7_8:


    "..."


translate pt_br prologueChoice2_ac25f573:


    "Mas você não pode ficar parado para sempre... certo?"


translate pt_br prologueChoice2_c2f2e565:


    "O que quer que esteja te vigiando... você já pode sentir sua impaciência."


translate pt_br prologueChoice2_af10a9a1:


    "Está ansioso demais."


translate pt_br prologueChoice2_80a275c9:


    "Você não sabe como sabe disso... {w}Mas pode sentir claramente, como se tivesse sussurrado--"


translate pt_br prologueChoice2_a20cefa7_9:


    "..."


translate pt_br prologueChoice2_4bca7969:


    "...bem no seu ouvido."


translate pt_br prologueChoice2_176e11ae:


    "Bem na sua {i}alma...{/i}"


translate pt_br prologueChoice2_a20cefa7_10:


    "..."


translate pt_br prologueChoice2_590cf3c1:


    "Essa coisa não vai deixar você esperar até passar. Não que você {i}pudesse{/i}, mesmo que deixasse."


translate pt_br prologueChoice2_7b913dcf:


    "Você não pode ficar aqui."


translate pt_br prologueChoice2_55578b69:


    "Você tem que {i}correr{/i}."


translate pt_br prologueChoice2_8f91c31e:


    "Com esse pensamento, um súbito instinto primitivo desperta dentro de você..."


translate pt_br prologueChoice2_b8f3a2d1:


    "...fazendo com que você se lance em um movimento rápido."


translate pt_br prologueChoice2_9d930911:


    "De {i}ação{/i}."


translate pt_br prologueChoice2_bf0874e3_1:


    "Mas..."


translate pt_br prologueChoice2_314b731c:


    "...Você ainda está fraco pela influência do medo em sua mente."


translate pt_br prologueChoice2_aaefb8e2:


    "Na pressa, suas pernas se enroscam sob você, fazendo você cair no chão."


translate pt_br prologueChoice2_8ca8510a_1:


    you "!!!" with vpunch


translate pt_br prologueChoice2_75f6eebc:


    "Do nada você sente uma dor aguda no centro do seu pé."


translate pt_br prologueChoice2_741dce68:


    "A princípio, você pensa ter quebrado o tornozelo..."


translate pt_br prologueChoice2_b904d1f8:


    "...mas algo quente e {i}úmido{/i} escorre pela lateral do seu pé, formando uma poça."


translate pt_br prologueChoice2_b7ab4763:


    "Você ouve o som de metal raspando nos azulejos após deslizar pelo chão... como se tivesse sido chutado..."


translate pt_br prologueChoice2_db2b1596:


    "Sem fôlego por causa da queda, você olha para cima atordoado e vê o objeto reluzindo sob uma luz estranha vinda de fora..."


translate pt_br prologueChoice2_05b49e6d:


    "...luz essa que entra pela porta da frente agora {b}aberta{/b}."


translate pt_br prologueChoice2_b61a396d:


    "Pensamentos de como, quando, quem, {i}o que{/i} em relação à sua porta inexplicavelmente aberta param abruptamente..."


translate pt_br prologueChoice2_d4e0cc13:


    "...assim que seu cérebro finalmente identifica o objeto metálico que você estava encarando..."


translate pt_br prologueChoice2_40d9ca73_1:


    "..?"


translate pt_br prologueChoice2_2e361f97:


    "É sua faca de cozinha..."


translate pt_br prologueChoice2_8546520a:


    "E ainda tingida de vermelho pelo seu erro anterior..? Mas isso não está certo."


translate pt_br prologueChoice2_38a7b342:


    "Não tinha sido completamente limpa pelo..?"


translate pt_br prologueChoice2_dae0ec55_2:


    you "..."


translate pt_br prologueChoice2_f5f34102:


    "Você engole seco devido à dor no seu pé."


translate pt_br prologueChoice2_fe5b649d:


    "Você mal tem tempo de pensar em como a faca acabou no {i}chão da sala de estar{/i} para ser pisada..."


translate pt_br prologueChoice2_21d29f45:


    "...em vez de estar na sua tábua de cortar na {i}cozinha{/i}, onde você a havia deixado..."


translate pt_br prologueChoice2_f0b53c63:


    "...quando você vê algo na escuridão logo além da faca..."


translate pt_br prologueChoice2_a20cefa7_11:


    "..."


translate pt_br prologueChoice2_e77542e3:


    "Essa coisa olha de volta pra você."


translate pt_br prologueChoice2_10142e0e:


    "Um par de olhos dourados e brilhantes surge à medida que o gato emerge das sombras para a luz que vem da porta."


translate pt_br prologueChoice2_e5652646:


    "Ele se aproxima da faca com passos leves, como se estivesse pulando de alegria..."


translate pt_br prologueChoice2_70938f8a:


    "...e se inclina para lamber a sangue que escorre da lâmina."


translate pt_br prologueChoice2_ed5ea61e:


    you "Ah..."


translate pt_br prologueChoice2_393f5166:


    "Seus sentidos lentamente começam a te sobrecarregar."


translate pt_br prologueChoice2_2a730601:


    "O frio do ar enquanto começa a te sufocar com seu peso..."


translate pt_br prologueChoice2_1593a3aa:


    "O som das suas respirações trêmulas, ressonante em relação à estática que agora penetra sua cabeça..."


translate pt_br prologueChoice2_ed11f665:


    "A secura na sua língua se espalhando para a garganta..."


translate pt_br prologueChoice2_34bcc68c:


    "A visão incompreensível do vira-lata que você havia acolhido... {w}{i}lambendo{/i} a sua faca de cozinha... completamente limpa de novo..."


translate pt_br prologueChoice2_b0a9a5c6:


    "O cheiro de sangue da ferida fresca no seu pé..."


translate pt_br prologueChoice2_40d9ca73_2:


    "..?"


translate pt_br prologueChoice2_eed16faf:


    "Sangue..?"


translate pt_br prologueChoice2_7f0ac95c:


    cat "..."


translate pt_br prologueChoice2_50e9be35:


    "Os olhos dourados se voltam para você como se em resposta à sua súbita compreensão..."


translate pt_br prologueChoice2_281091c2:


    "Sangue..."


translate pt_br prologueChoice2_8ffe853a:


    "Você está ferido..."


translate pt_br prologueChoice2_9224c60b:


    "Seu pé está sangrando..."


translate pt_br prologueChoice2_8121a06c:


    "Você está sangrando..."


translate pt_br prologueChoice2_00bb4f59:


    "Você está {b}{i}{color=#FF0000}sangrando{/color}{/i}{/b}."


translate pt_br prologueChoice2_2da587a4:


    "O gato mal se move, os ombros se contraindo como se apenas estivesse {i}considerando{/i} avançar em sua direção..."


translate pt_br prologueChoice2_a20cefa7_12:


    "..."


translate pt_br prologueChoice2_3b91b0ca:


    "Mas você já está de pé e do lado de fora da porta."


translate pt_br prologueChoice2_5f801ea2:


    "Você corre, ou melhor, {i}manca{/i}, pela rua vazia."


translate pt_br prologueChoice2_ccea669c:


    "O céu está preto e sangrando vermelho..."


translate pt_br prologueChoice2_cfd4e5e1:


    "...mas há uma luz estranha que emana de lugar nenhum e deixa tudo em branco.."


translate pt_br prologueChoice2_09cf8ffc:


    "As casas, as árvores, a estrada, até mesmo você..."


translate pt_br prologueChoice2_e4427836:


    "{i}Tudo{/i}..."


translate pt_br prologueChoice2_220b03d6:


    "...exceto o seu sangue."


translate pt_br prologueChoice2_a7c4df5f:


    "Você consegue apenas vislumbrar as marcas de sangue que seu pé machucado deixa para trás a cada impacto com o chão."


translate pt_br prologueChoice2_62c0c671:


    "Isso dói..."


translate pt_br prologueChoice2_e6f06c3d:


    "Isso {i}dói{/i}."


translate pt_br prologueChoice2_3dd82419:


    "Mas você não pode parar. Você {i}não pode{/i} parar."


translate pt_br prologueChoice2_511a53e8:


    "Não quando as sombras se erguem à sua volta..."


translate pt_br prologueChoice2_c94026dc:


    "Não quando você sente o olhar de vários olhos sobre você..."


translate pt_br prologueChoice2_11fab02e:


    "Não quando o caminho à sua frente está escurecido por uma longa sombra de {i}alguma coisa{/i} atrás de você."


translate pt_br prologueChoice2_24687875:


    "Mesmo assim... você não para de correr. Porque..."


translate pt_br prologueChoice2_d31c0957:


    "Se aquele é o gato bem à sua frente..."


translate pt_br prologueChoice2_f64ee9d8:


    "Então..."


translate pt_br prologueChoice2_a20cefa7_13:


    "..."


translate pt_br prologueChoice2_39b2e350:


    "{size=-8}...o que, afinal, está atrás de você?{/size}"


translate pt_br prologueEND1_45eb1440:


    "Final ?: Nyão Sou Idiota"


translate pt_br prologueEND2_6f50b679:


    who "..."


translate pt_br prologueEND2_2821b9de:


    who "Hum... {w}Interessante..."


translate pt_br prologueEND2_c29791ce:


    who "Muito, muito... interessante..."


translate pt_br prologueEND2_a20cefa7:


    "..."


translate pt_br prologueEND2_b715ae86:


    "Final 0: O Início"

translate pt_br strings:


    old "Do not take cat home"
    new "Não levar o gato para casa"


    old "Take cat home"
    new "Levar o gato para casa"

    old "Let's play~"
    new "Vamos brincar~"


    old "Look behind you."
    new "Olhar atrás de você."


    old "Keep running."
    new "Continuar correndo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
