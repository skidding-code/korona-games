


translate pt_br encounterCat_a20cefa7:


    "..."


translate pt_br encounterCat_07879361:


    "De volta, hein?"


translate pt_br encounterCat_310653c5:


    "Você já alcançou o melhor resultado possível."


translate pt_br encounterCat_4961a2a7:


    "O que mais você espera conseguir?"


translate pt_br encounterCat_8dabefc6:


    ".."


translate pt_br encounterCat_a20cefa7_1:


    "..."


translate pt_br encounterCat_ebdf273c:


    "Você não estaria pensando em voltar atrás na sua promessa de se juntar a mim..."


translate pt_br encounterCat_810e5b21:


    "{color=#FF0000}...certo?{/color}"


translate pt_br encounterCat_beec6484:


    "Ainda não consegui satisfazer sua curiosidade?"


translate pt_br encounterCat_a20cefa7_2:


    "..."


translate pt_br encounterCat_90b68c87:


    you "..?"


translate pt_br encounterCat_19d97e41:


    you "{i}Onde... {w}Onde eu tô..?{/i}"


translate pt_br encounterCat_a20cefa7_3:


    "..."


translate pt_br encounterCat_3fdc70e9:


    "{alpha=0.4}E então...{/alpha}"


translate pt_br encounterCat_ef29c92b:


    "{alpha=0.7}Você se encontra aqui...{/alpha}"


translate pt_br encounterCat_5032d21f:


    "...mais uma vez."


translate pt_br encounterCat_28b3ac41:


    you "!!"


translate pt_br encounterCat_5991bb93:


    you "O qu-"


translate pt_br encounterCat_548c1316:


    you "Quem disse isso?!"


translate pt_br encounterCat_964f0af4:


    you "E onde é {i}\"aqui\"?{/i} {w}Eu não consigo {i}ver{/i} nada!"


translate pt_br encounterCat_a20cefa7_4:


    "..."


translate pt_br encounterCat_f27122fb:


    who "Ora..."


translate pt_br encounterCat_a995ea3c:


    cat "...\"aqui\" é {i}aqui,{/i} bobinho!"


translate pt_br encounterCat_56ebb028:


    you "!!!"


translate pt_br encounterCat_2a440d93:


    you "V... Você é..."


translate pt_br encounterCat_49e410bc:


    cat "Bem? {w}Você se lembra de mim, dessa vez?"


translate pt_br encounterCat_187ca1e5:


    cat "Nunca me imaginei como alguém fácil de esquecer..."


translate pt_br encounterCat_cfb7cc33:


    cat "...mas, pelo visto, sempre há uma primeira vez para tudo~!"


translate pt_br encounterCat_dae0ec55:


    you "..."


translate pt_br encounterCat_48bb4310:


    "Sua memória lentamente junta os pedaços de um momento... {w}Um encontro..."


translate pt_br encounterCat_b4fa62a0:


    you "Um gato em... {w}em um beco..."


translate pt_br encounterCat_b5914067:


    you "Eu... {w}te levei para casa comigo... {w}não levei?"


translate pt_br encounterCat_c46e050e:


    cat "{size=+5}{b}Correto!{/b}{/size}" with hpunch


translate pt_br encounterCat_e32fc389:


    cat "Você ficou sonhando acordado por tanto tempo que até {i}eu{/i} fiquei preocupado! {w}Dá pra imaginar?"


translate pt_br encounterCat_42fcd5d4:


    cat "Aqui estou eu, me divertindo um pouco brincando com minha presa..."


translate pt_br encounterCat_8cf8606b:


    cat "...e você simplesmente fica distraído!"


translate pt_br encounterCat_dc1e93f2:


    cat "A brincadeira não tem graça se você não estiver {i}presente{/i}, sabe..."


translate pt_br encounterCat_99f64913:


    you "Eu..."


translate pt_br encounterCat_d26ddf18:


    you "Não, eu {i}não{/i} sei! Eu não tô entendendo nada do que tá acontecendo!"


translate pt_br encounterCat_10cb6b4e:


    cat "Hmm... Curioso como você é, eu devia imaginar que teria perguntas..."


translate pt_br encounterCat_c3e84f44:


    cat "Bem, acho que você me deixou de bom humor o suficiente para ser generoso e ouvir o que tem a dizer..."


translate pt_br encounterCat_6a840c3c:


    cat "Muito bem..."


translate pt_br questionCat_44076b5e:


    cat "O que você gostaria de saber~?"


translate pt_br noMoreQuestions_be011780:


    "É mesmo?"


translate pt_br noMoreQuestions_b132aa27:


    "Talvez você não seja tão curioso quanto pensei..."


translate pt_br noMoreQuestions_b3e12ea5:


    "Ainda assim..."


translate pt_br moreQuestions_e92c7456:


    "Muito bem... Vou perguntar de novo..."


translate pt_br moreQuestions_92e00d5e:


    "Tenho certeza de que você escolherá a resposta correta."


translate pt_br moreQuestions_cc5f9d9d:


    "Você vai se juntar a mim..."


translate pt_br moreQuestions_560e6e27:


    "...ou perecer?"


translate pt_br moreQuestions_6b3fef84:


    "Não?"


translate pt_br moreQuestions_76297ef4:


    "Bem, nesse caso..."


translate pt_br questionCat1_c495dba3:


    cat "Hm... Foi a primeira coisa que me veio à mente, na verdade."


translate pt_br questionCat1_64bab19b:


    cat "Você estava à beira da morte..."


translate pt_br questionCat1_0c0abb1c:


    cat "Mas, em vez de ver sua vida passar diante dos olhos..."


translate pt_br questionCat1_fa75ee80:


    cat "...você ficou preso relembrando o momento em que nos conhecemos... {w}subconscientemente criando cenários em que conseguiria sobreviver."


translate pt_br questionCat1_e15e92be:


    cat "Bem. {w}Talvez você {i}conseguisse{/i}... mas..."


translate pt_br questionCat1_c0153aab:


    cat "Não consegui resistir e brinquei um pouco com sua imaginação~"


translate pt_br questionCat1_7b103b48:


    cat "Afinal, você {i}começou{/i} a me ignorar do nada."


translate pt_br questionCat1_e24fd6e6:


    cat "Você já sabe o quanto eu adoro atenção~"


translate pt_br questionCat1_5f80ea18:


    cat "Seus pequenos experimentos mentais foram bastante divertidos..."


translate pt_br questionCat1_315adaa1:


    cat "Mas... Se me permite dizer..."


translate pt_br questionCat1_23467746:


    cat "...você deve ter tido uma vida {i}bem{/i} chata para deixar de se entregar a memórias preciosas de dias que se foram..."


translate pt_br questionCat1_d06d7a92:


    cat "...em vez disso, sonhou acordado sobre um único encontro..."


translate pt_br questionCat1_05c50243:


    cat "...várias e várias vezes."


translate pt_br questionCat1_6de8f265:


    cat "Já ouvi falar de arrependimentos no leito de morte, mas isso tem sido ridículo!"


translate pt_br questionCat1_a20cefa7:


    "..."


translate pt_br questionCat1_d4a2484f:


    cat "...Ridiculamente {i}intrigante,{/i} quero dizer!"


translate pt_br questionCat1_89d17f6f:


    cat "Ou talvez, em vez de arrependimentos, foi {i}{b}eu{/b}{/i} quem você achou intrigante~?"


translate pt_br questionCat1_153670a4:


    cat "Você está lúcido, eu diria. Já que finalmente se lembrou de mim e tudo mais..."


translate pt_br questionCat1_f61b0df4:


    cat "Parece que você está finalmente pronto para acabar com essa farsa... por mais divertida que tenha sido."


translate pt_br questionCat2_78b85363:


    cat "Dentro da sua cabeça, bobo!"


translate pt_br questionCat2_3b6637ed:


    cat "Nossas versões reais estão suspensas no tempo na sua realidade. Embora eu duvide que muito tempo tenha realmente passado."


translate pt_br questionCat2_cea70401:


    cat "Essas coisas tendem a acontecer em um piscar de olhos, afinal..."


translate pt_br questionCat2_90ceece1:


    cat "Bem... {w}{i}geralmente,{/i} de qualquer forma."


translate pt_br questionCat3_91c433ff:


    cat "Ah, não seja tão dramático~"


translate pt_br questionCat3_628a0e7a:


    cat "Eu não {i}fico{/i} te matando! Eu não cheguei a te matar nem {i}uma vez{/i} ainda..."


translate pt_br questionCat3_d29cd430:


    cat "Eram apenas pensamentos e ideias pairando pela sua cabeça..."


translate pt_br questionCat3_03a9b169:


    cat "...com os quais eu admito ter me divertido um pouco."


translate pt_br questionCat3_faf0ac79:


    cat "Dá pra me culpar? Eu teria ficado {i}entediado{/i} só esperando você acordar."


translate pt_br questionCat3_444467b1:


    cat "Hum, sim... Suponho que eu estava curioso para ver se você realmente faria isso."


translate pt_br questionCat3_bbec1b37:


    cat "Você com certeza não se conteve... {w}Você deve ter ficado bem bravo comigo~"


translate pt_br questionCat3_142ac461:


    cat "Mas tudo bem. Você sabe o que dizem sobre a curiosidade, não é?"


translate pt_br questionCat3_9d6e8628:


    cat "Foi uma escolha minha. E além disso..."


translate pt_br questionCat3_7b530356:


    cat "{color=#FF0000}...Eu trouxe você de volta, não foi~?{/color}"


translate pt_br questionCat4_346e4804:


    cat "..? O que quer dizer?"


translate pt_br questionCat4_723b2270:


    cat "Eu sempre estive falando com você."


translate pt_br questionCat4_2537f593:


    cat "Por mais intrigante que seja sua imaginação, ela teria se descontrolado sem a minha ajuda."


translate pt_br questionCat4_6dea765f:


    "Eu estava {b}guiando{/b} você o tempo {i}todo{/i}..."


translate pt_br questionCat4_8ca8510a:


    you "!!!" with vpunch


translate pt_br questionCat4_a7b878cb:


    "Você não me ouviu nos seus pensamentos..?"


translate pt_br questionCat4_40a8ff0b:


    "Tipo {i}assim~?{/i}"


translate pt_br questionCat4_dae0ec55:


    you "..."


translate pt_br questionCat4_4ee1bb0a:


    cat "Sou bastante poderoso, sim... mas nem tanto assim."


translate pt_br questionCat4_f6a21734:


    you "{i}E o que {b}isso{/b} quer dizer..?{/i}"


translate pt_br questionCat4_6f7f3d7e:


    cat "Além disso, o que te faz ter tanta certeza de que sou um gato?"


translate pt_br questionCat4_9f54e05d:


    cat "Minha aparência? Duvido que eu me pareça com qualquer gato que você já tenha visto, certo?"


translate pt_br questionCat4_8e3ec6ea:


    you "Então, se não é um gato, que porra é você?"


translate pt_br questionCat4_2373210e:


    cat "Eu não disse que {i}não sou{/i} um gato, disse?"


translate pt_br questionCat4_dae0ec55_1:


    you "..."


translate pt_br questionCat4_7f0ac95c:


    cat "..."


translate pt_br questionCat4_0c9311a0:


    cat "Posso ser um demônio... {w}ou um deus... {w}ou um alienígena de outra galáxia... {w}ou uma abominação interdimensional..."


translate pt_br questionCat4_7338daf3:


    cat "...ou eu realmente {i}posso{/i} ser apenas um gato."


translate pt_br questionCat4_0239290e:


    cat "Não importa {i}de verdade{/i} o que eu sou, importa?"


translate pt_br questionCat4_1c318240:


    cat "Certamente o que eu posso {b}fazer{/b} seria uma questão mais urgente, não acha?"


translate pt_br questionCat4_a00b7c5d:


    you "Um gato de verdade não poderia ter feito tudo isso!"


translate pt_br questionCat4_5ef345ac:


    cat "Você realmente está preso às aparências, não é..."


translate pt_br questionCat4_ec53df3b:


    cat "Você tem algum tipo de prova de que gatos {i}não{/i} possuem poderes como os meus? {w}Duvido~"


translate pt_br questionCat4_89c7e144:


    cat "E sabe, é bem rude da sua parte ficar falando e falando sobre {i}o que{/i} eu sou..."


translate pt_br questionCat4_6ab4c9ee:


    cat "...antes mesmo de perguntar {i}quem{/i} eu sou ou qual é o meu {i}nome{/i}!"


translate pt_br questionCat4_dae0ec55_2:


    you "..."


translate pt_br questionCat4_976ad5e8:


    you "*suspiro* Tá... qual é o seu nome então-"


translate pt_br questionCat4_7494f9b5:


    cat "Bom, eu não vou te contar {i}{b}agora!{/b}{/i}"


translate pt_br questionCat4_bf0f44ce:


    cat "Aprenda um pouco de educação primeiro e veremos. {w}Bem..."


translate pt_br questionCat4_23bc3a7d:


    cat "...talvez na sua {i}próxima{/i} vida, quem sabe."


translate pt_br questionCat5_0a5f3e64:


    cat "Hmm..."


translate pt_br questionCat5_9dde11ef:


    cat "Se estamos falando dos meus objetivos originais... são um pouco pessoais, eu diria~"


translate pt_br questionCat5_dae0ec55:


    you "..."


translate pt_br questionCat5_b3148994:


    cat "E, de qualquer forma, as coisas mudaram!"


translate pt_br questionCat5_c5905ab0:


    cat "Agora?"


translate pt_br questionCat5_ea6e786a:


    cat "Bem, no momento, eu gostaria de me divertir um pouco mais com você. {w}Sua companhia tem sido muito divertida até agora."


translate pt_br questionCat5_03ab381b:


    cat "Dado mais tempo... {w}e em outras circunstâncias... {w}quem sabe nós até pudéssemos ter sido..."


translate pt_br questionCat5_7f0ac95c:


    cat "..."


translate pt_br questionCat5_c38e7b98:


    cat "Bem... tudo que é bom precisa chegar ao fim."


translate pt_br questionCat5_1029e671:


    cat "Você não pode realmente querer passar o pouco tempo que lhe resta em arrependimento e ilusão, certo?"


translate pt_br questionCat5_d4182ef1:


    cat "Por outro lado, {w}também estou bastante {i}faminto{/i} depois de esperar tanto para você acordar."


translate pt_br questionCat5_fd56ebb0:


    cat "Neste ponto, tanto faz para mim."


translate pt_br finalQuestion_1e7e7eba:


    cat "Satisfiz sua curiosidade agora?"


translate pt_br finalQuestion_dae0ec55:


    you "..."


translate pt_br finalQuestion_97e7bd6b:


    you "Só tenho mais uma pergunta..."


translate pt_br finalQuestion_36d620f5:


    you "Por que eu? Por que logo {i}eu{/i} fui chamado no meio de tanta gente..?"


translate pt_br finalQuestion_91cd85d7:


    cat "Tudo o que eu fiz foi chamar para {i}alguém{/i} me ouvir."


translate pt_br finalQuestion_aae09cc1:


    cat "Eu chamei... e você foi a primeira pessoa que veio até mim. {w}Simples assim."


translate pt_br finalQuestion_dae0ec55_1:


    you "..."


translate pt_br finalQuestion_25add7f4:


    cat "...Você estava esperando alguma razão especial?"


translate pt_br finalQuestion_dae0ec55_2:


    you "..."


translate pt_br finalQuestion_e304cf84:


    cat "...Receio não ter nenhuma."


translate pt_br finalQuestion_5d037f74:


    cat "Tudo o que passei a gostar em você foram coisas que descobri {i}depois{/i} do nosso primeiro encontro."


translate pt_br finalQuestion_9e1cd95d:


    you "Então não tem um grande motivo por trás de nada disso?"


translate pt_br finalQuestion_c86c8dcc:


    cat "O motivo é bem menos interessante do que os resultados que vieram da nossa interação."


translate pt_br finalQuestion_1ff3d913:


    cat "Eu só chamei para saciar minha fome, mas, ao fazer isso, encontrei algo muito mais valioso."


translate pt_br finalQuestion_8f6f37e7:


    cat "Tenho certeza de que, independentemente de como isso termine..."


translate pt_br finalQuestion_f1cd85f2:


    cat "...nunca vou me esquecer de você."


translate pt_br finalQuestion_fec1fe3c:


    you "Como assim?"


translate pt_br returnOrigin_bf22af67:


    cat "Eu criei uma afeição por você, humano. Então... vou te conceder outra chance..."


translate pt_br returnOrigin_42029590:


    cat "Outra escolha..."


translate pt_br returnOrigin_479c3431:


    you "!!" with vpunch


translate pt_br returnOrigin_8e03588c:


    you "{i}Este lugar é...{/i}"


translate pt_br returnOrigin_a20cefa7:


    "..."


translate pt_br returnOrigin_9c3e8dd9:


    "Você {i}{b}se lembra{/b}{/i} deste lugar..."


translate pt_br returnOrigin_f1426fe6:


    "Sendo perseguido..."


translate pt_br returnOrigin_626dfd4e:


    "Sendo {b}caçado{/b}..."


translate pt_br returnOrigin_c204d717:


    "Sentindo medo..."


translate pt_br returnOrigin_7591fb3e:


    "{b}Tanto{/b} medo..."


translate pt_br returnOrigin_642290f0:


    "Esse medo que {i}tanto{/i} me atraiu para você..."


translate pt_br returnOrigin_eee55388:


    "...esse desespero instintivo de sobreviver..."


translate pt_br returnOrigin_f7d54ac5:


    "Eu ansiava por tudo isso..."


translate pt_br returnOrigin_738c58c2:


    "Afinal, sou a origem dessas emoções deliciosas..."


translate pt_br returnOrigin_850be2a3:


    "...você {i}já{/i} é \ {b}m e u .{/b}"


translate pt_br returnOrigin_a20cefa7_1:


    "..."


translate pt_br returnOrigin_bf0874e3:


    "Mas..."


translate pt_br returnOrigin_9042cfe9:


    "Eu ainda lhe darei a chance de aceitar a realidade do seu destino."


translate pt_br returnOrigin_186f39f2:


    cat "Humano..."


translate pt_br returnOrigin_e8f7c347:


    cat "Junte-se a mim..."


translate pt_br returnOrigin_aca58e0a:


    cat "...ou pereça."


translate pt_br joinCat_cd8ba4c0:


    cat "Esplêndido."


translate pt_br joinCat_1ab5bac9:


    cat "Aproxime-se, meu humano."


translate pt_br joinCat_2c7927e3:


    "Você dá um passo a frente e pega o gato."


translate pt_br joinCat_e00dae14:


    "Você o aconchega em seus braços, estendendo a mão para esfregar sua cabeça."


translate pt_br joinCat_67107e6c:


    cat "Purr..."


translate pt_br joinCat_f8342e66:


    "De repente..."


translate pt_br joinCat_b0821d91:


    you "O qu..?"


translate pt_br joinCat_d401595a:


    "...você começa a se sentir... {w}sonolento."


translate pt_br joinCat_69c0188b:


    "Mas a onda repentina de fadiga não faz você desequilibrar ou tropeçar."


translate pt_br joinCat_cedc8e66:


    you "O que... O que tá acon... ecendo...?"


translate pt_br joinCat_5e8da3e5:


    cat "Shh..."


translate pt_br joinCat_b474b001:


    cat "Não se preocupe... Você não precisa se preocupar com mais nada, nunca mais..."


translate pt_br joinCat_85b30929:


    cat "Apenas durma... durma e sonhe com os anjos... por mim..."


translate pt_br joinCat_dae0ec55:


    you "..."


translate pt_br joinCat_2f74697b:


    you "... {w}... {w}..."


translate pt_br joinCat_60daf151:


    cat "...Excelente."


translate pt_br joinCat_7a46e73a:


    cat "Com isso, você em breve se tornará parte de mim..."


translate pt_br joinCat_8dabefc6:


    ".."


translate pt_br joinCat_a20cefa7:


    "..."


translate pt_br joinCat_a110b86c:


    "Final 37: \ {b}P a r a S e m p r e{/b}"


translate pt_br refuseCat_4599308d:


    cat ".."


translate pt_br refuseCat_7f0ac95c:


    cat "..."


translate pt_br refuseCat_1280d577:


    cat "Entendo. Então não há mais nada a dizer."


translate pt_br refuseCat_dae0ec55:


    you "..."


translate pt_br refuseCat_401c177b:


    cat "...{w}\"Conformado com o seu destino...\""


translate pt_br refuseCat_568bc2ee:


    "...você finalmente {w}{b} s e {w} v i r a .{/b}"


translate pt_br refuseCat_8dabefc6:


    ".."


translate pt_br refuseCat_a20cefa7:


    "..."


translate pt_br refuseCat_998be557:


    "...É {i}{b}enorme.{/b}{/i}"


translate pt_br refuseCat_073f9da6:


    "Desforme... ondulando como fumaça espessa ao vento..."


translate pt_br refuseCat_2e28e1bd:


    "A entidade sombria se ergue acima de você..."


translate pt_br refuseCat_9e637eeb:


    "Tão alta que parece que o céu a derramou sobre a Terra... e {i}ainda{/i} está derramando..."


translate pt_br refuseCat_1d4c6563:


    "É... incompreensível... que seu ínfimo mundo sequer consiga suportar..."


translate pt_br refuseCat_1aee61d8:


    "...sob o peso da {i}realidade{/i} da existência de tal ser..."


translate pt_br refuseCat_57d2ac22:


    "...e que {i}você{/i} e sua mente frágil não tenham caído em ruína também."


translate pt_br refuseCat_a20cefa7_1:


    "..."


translate pt_br refuseCat_bedb2983:


    "Você dá um passo à frente no miasma monstruoso..."


translate pt_br refuseCat_a20cefa7_2:


    "..."


translate pt_br refuseCat_b290aff1:


    "...e se oferece a isso."


translate pt_br refuseCat_8dabefc6_1:


    ".."


translate pt_br refuseCat_a20cefa7_3:


    "..."


translate pt_br refuseCat_ce151d3e:


    "{b}{size=+5}e s c u r i d ã o . . .{/size}{/b}"


translate pt_br refuseCat_9255f3aa:


    "Cercado por uma absoluta e pura escuridão..."


translate pt_br refuseCat_1ecc4a0c:


    "...você é subitamente tomado pela sensação..."


translate pt_br refuseCat_ba4f1a80:


    "{size=-10}...de que você {b}não{/b} está sozinho.{/size}"


translate pt_br refuseCat_0a4a23c7:


    "Como se você acabasse de entrar em um espaço insuportavelmente, {i}impossivelmente{/i} lotado..."


translate pt_br refuseCat_7e162144:


    "Seus ouvidos começam a zumbir com a sensação de inúmeras conversas..."


translate pt_br refuseCat_403137b9:


    "Palavras, sussurros, {i}gritos{/i}... {w}todos sobrepostos..."


translate pt_br refuseCat_bf0874e3:


    "Mas..."


translate pt_br refuseCat_134c63de:


    "Você não vê ou ouve realmente algo ou alguém..."


translate pt_br refuseCat_93bc4adf:


    "Você está sozinho..."


translate pt_br refuseCat_1a0c257a:


    "Mesmo enquanto seus sentidos mentem para você, tentando fazer você pensar o contrário..."


translate pt_br refuseCat_3fa3800d:


    "{size=-8}...você está mais sozinho do que nunca.{/size}"


translate pt_br refuseCat_237125a9:


    who "mentiras... {w}mentiras... {w}ouça... {w}ouça, {i}por favor{/i}..."


translate pt_br refuseCat_90b68c87:


    you "..?"


translate pt_br refuseCat_ba0d7c87:


    you "Tem alguém mesmo...?"


translate pt_br refuseCat_955160b2:


    you "Não consigo te ver..."


translate pt_br refuseCat_0d7e3dc7:


    you "Onde você tá?"


translate pt_br refuseCat_986b4bb4:


    who "nada... {w}não sobrou nada... {w}para ver... {w}apenas ouvir... {w}nos ouvir..."


translate pt_br refuseCat_2d7097aa:


    who "ouça... {w}por favor..."


translate pt_br refuseCat_30099ff9:


    you "Vocês... Vocês todos estão presos também? Nesse lugar..?"


translate pt_br refuseCat_da793f6a:


    who "sem lugar... {w}nós... {w}tudo que vê... {w}ouve... {w}sente... {w}somos {i}nós{/i}..."


translate pt_br refuseCat_0e4deed6:


    who "nós... {w}e {b}{color=#FF0000}I S S O...{/color}{/b}"


translate pt_br refuseCat_b46126fe:


    who "nós somos vítimas... {w}presas... {w}como você... {w}somos muitos... {w}incontáveis..."


translate pt_br refuseCat_5306dd79:


    who "nossos corpos se foram... {w}com o tempo..."


translate pt_br refuseCat_174a45b9:


    who "desejos abandonados... {w}nós... {w}nós... {w}nos tornamos... {w}o que você vê... {w}esse \"lugar\"..."


translate pt_br refuseCat_f03c0d18:


    who "precisamos de você... {w}precisamos da sua ajuda... {w}ajuda..."


translate pt_br refuseCat_3abb33dd:


    you "Mas... O que {i}eu{/i} posso fazer..?"


translate pt_br refuseCat_82878ab6:


    who "{b}{color=#FF0000}I S S O{/color}{/b} é muito ganancioso... {w}cometeu erro... {w}comeu muitos... {w}somos muitos... {w}agora fortes..."


translate pt_br refuseCat_70c5c2af:


    who "fizemos {b}{color=#FF0000}I S S O{/color}{/b} forte... {w}mas cometeu erro... {w}erro... {w}descuido... {w}falha..."


translate pt_br refuseCat_85afd939:


    who "{i}fraqueza{/i}..."


translate pt_br refuseCat_5d0fa6b9:


    you "Então por que não escapam por conta própria?"


translate pt_br refuseCat_88e7cfa8:


    who "muito tempo aqui... {w}muito tempo... {w}um... {w}somos um... {w}com {b}{color=#FF0000}I S S O...{/color}{/b}"


translate pt_br refuseCat_1eaa7cb8:


    who "corpos perdidos... {w}mentes... {w}desejos... {w}nós... {w}todos corrompidos... {w}sem corpo... {w}sem fuga..."


translate pt_br refuseCat_c9b4decc:


    who "você também... {w}você... {w}nós... {w}{b}{color=#FF0000}I S S O...{/color}{/b} {w}um... {w}todos nós... {w}agora somos um..."


translate pt_br refuseCat_6f50b679:


    who "..."


translate pt_br refuseCat_028c3ae6:


    who "mas você... {w}{i}novo{/i}... {w}corpo... {w}fresco..."


translate pt_br refuseCat_4cfc5eb7:


    who "ainda tem corpo..."


translate pt_br refuseCat_40326cc1:


    who "fuga é possível..."


translate pt_br refuseCat_dd4998c0:


    who "porque ainda um... {w}com {b}{color=#FF0000}I S S O...{/color}{/b}"


translate pt_br refuseCat_b6dc0c49:


    who "mesmo só você... {w}se fugir... {w}com mente... {w}com corpo..."


translate pt_br refuseCat_793d75bf:


    who "{b}{color=#FF0000}I S S O{/color}{/b} se desfaria..."


translate pt_br refuseCat_2bd9b13a:


    who "perderia poder... {w}perderia força... {w}{i}nos{/i} perderia..."


translate pt_br refuseCat_8e7cd0c9:


    who "nós... {w}libertos... {w}para sempre... {w}finalmente... {w}fuga... {w}ajuda..."


translate pt_br refuseCat_73dce3cc:


    you "Como faço isso?"


translate pt_br refuseCat_5e2c21a6:


    who "lembre-se {b}{color=#FF0000}I S S O{/color}{/b} repousa... {w}escondido em verdades... {w}e mentiras... {w}mentiras..."


translate pt_br refuseCat_482c36ac:


    who "fuja... {w}avance... {w}{b}{color=#FF0000}I S S O{/color}{/b} repousa..."


translate pt_br refuseCat_bd01a240:


    who "{size=-8}{b}persista...{/b}{/size}"


translate pt_br refuseCat_dae0ec55_1:


    you "..."


translate pt_br fakePerish_8dabefc6:


    ".."


translate pt_br fakePerish_a20cefa7:


    "..."


translate pt_br fakePerish_0d3bcba3:


    "{size=-10}você ignora suas palavras.{/size}"


translate pt_br fakePerish_479c3431:


    you "!!" with vpunch


translate pt_br fakePerish_96593730:


    "no fundo você sabe, não há como alguém como você ganhar de alguém como {b}{color=#FF0000}I S S O...{/color}{/b}"


translate pt_br fakePerish_9b198811:


    "o gato..."


translate pt_br fakePerish_44a490b1:


    "tentar seria inútil-{w=0.5}{nw}"


translate pt_br fakePerish_4b851161:


    "absurdo{w=0.15}{nw}"


translate pt_br fakePerish_0dc07c58:


    "fútil{w=0.15}{nw}"


translate pt_br fakePerish_5028df96:


    "insignficante{w=0.15}{nw}"


translate pt_br fakePerish_3369598c:


    "sem sentido{w=0.15}{nw}"


translate pt_br fakePerish_527621cb:


    "estúpido{w=0.15}{nw}"


translate pt_br fakePerish_9eed9e56:


    "sem propósito{w=0.15}{nw}"


translate pt_br fakePerish_a20cefa7_1:


    "..."


translate pt_br fakePerish_127944b9:


    "...um esforço em vão."


translate pt_br fakePerish_3e0d2470:


    "a esperança dessas palavras... seus desejos..."


translate pt_br fakePerish_0f38a5d5:


    "...tudo isso seria desperdiçado em você."


translate pt_br fakePerish_69c369af:


    "então..."


translate pt_br fakePerish_05311e61:


    "você aceita seu destino..."


translate pt_br fakePerish_bfe65f60:


    "...e escolhe {b}p e r e c e r.{/b}"


translate pt_br fakePerish_8dabefc6_1:


    ".."


translate pt_br fakePerish_a20cefa7_2:


    "..."


translate pt_br fakePerish_92f9f8f7:


    "você não sabe quanto tempo levaria, mas seus apelos patéticos eventualmente se silenciariam."


translate pt_br fakePerish_2b4577cf:


    "você quase deseja que eles simplesmente tivessem se tornado insultos e ameaças..."


translate pt_br fakePerish_f1634dcc:


    "esse silêncio interminável... carrega o peso da sua culpa e vergonha..."


translate pt_br fakePerish_2214de5d:


    "...muito tempo depois de seu corpo se desfazer..."


translate pt_br fakePerish_4bc243e3:


    "...e se tornar um..."


translate pt_br fakePerish_b21d553c:


    "{alpha=0.5}um...{/alpha}"


translate pt_br fakePerish_e1317257:


    "{alpha=0.3}...comigo.{/alpha}"


translate pt_br fakePerish_a20cefa7_3:


    "..."


translate pt_br fakePerish_5a9b49fc:


    "Ending ???: Deus me livre"


translate pt_br finalShowdown_8dabefc6:


    ".."


translate pt_br finalShowdown_a20cefa7:


    "..."


translate pt_br finalShowdown_dae0ec55:


    you "..."


translate pt_br finalShowdown_8105eadd:


    you "Não..."


translate pt_br finalShowdown_4d6b47c4:


    you "Não, estou... Estou \"sonhando acordado\" de novo..."


translate pt_br finalShowdown_ed47dfcc:


    you "...não é?"


translate pt_br finalShowdown_f0fcfbb0:


    cat "!!"


translate pt_br finalShowdown_d9b65ba2:


    cat "Você está lúcido de novo? {w}{i}Aqui{/i} dentro?"


translate pt_br finalShowdown_f6c6b67c:


    cat "Mas... como você..?"


translate pt_br finalShowdown_dae0ec55_1:


    you "..."


translate pt_br finalShowdown_685847ec:


    you "Bem..."


translate pt_br finalShowdown_62715eb3:


    you "Quando você está sonhando com o mesmo dia de novo e de novo... {w}você começa a notar os padrões..."


translate pt_br finalShowdown_7f0ac95c:


    cat "..."


translate pt_br finalShowdown_16651853:


    you "Escuta... {w}Eu não sou nada especial."


translate pt_br finalShowdown_0560b398:


    you "Na verdade, eu não tenho amigos."


translate pt_br finalShowdown_28a71a07:


    you "Não gosto de multidões ou de sair na maior parte do tempo."


translate pt_br finalShowdown_ddfefb8c:


    you "E na maioria das vezes..."


translate pt_br finalShowdown_ff3731cf:


    you "...Eu estou sozinho."


translate pt_br finalShowdown_6c53330d:


    you "Mesmo na minha casa..."


translate pt_br finalShowdown_0c78bdf6:


    you "Um quarto... {w}um banheiro... {w}e só {i}eu{/i} vivendo sozinho nela."


translate pt_br finalShowdown_ea6f4afe:


    you "Seria fácil dizer que não tenho muito a perder."


translate pt_br finalShowdown_e7a5aced:


    you "Minha vida, admito, é bem chata."


translate pt_br finalShowdown_dae0ec55_2:


    you "..."


translate pt_br finalShowdown_9af744e4:


    you "Mas {i}é{/i}... {w}{i}{b}a minha{/b}{/i}... {w}vida."


translate pt_br finalShowdown_bccf0c1b:


    you "E se esse é {i}meu{/i} sonho..."


translate pt_br finalShowdown_b8c07162:


    you "...então você não está mais no controle."


translate pt_br finalShowdown_7f0ac95c_1:


    cat "..."


translate pt_br finalShowdown_a20cefa7_1:


    "..."


translate pt_br finalShowdown_97790092:


    "{size=-8}Acho que você não está entendendo o que está acontecendo aqui.{/size}"


translate pt_br finalShowdown_55077811:


    you "Não, {i}você{/i} é quem não está entendendo."


translate pt_br finalShowdown_a513413e:


    "..!"


translate pt_br finalShowdown_a86ce62e:


    you "{b}Você{/b} que {i}me{/i} chamou."


translate pt_br finalShowdown_4a5124d3:


    you "{b}Você{/b} é quem precisa de {i}mim.{/i}"


translate pt_br finalShowdown_0833d501:


    you "Seja para me comer, me matar ou me fazer seu para sempre, não importa."


translate pt_br finalShowdown_64ab99ef:


    you "Já {b}acabei{/b} por aqui."


translate pt_br finalShowdown_dae0ec55_3:


    you "..."


translate pt_br finalShowdown_144a76cd:


    you "Tô indo pra {b}casa.{/b}"


translate pt_br finalShowdown_62708cb5:


    "{size=+15}PONHA-SE NO SEU LUGAR, HUMANO!{/size}" with vpunch


translate pt_br finalShowdown_a20cefa7_2:


    "..."


translate pt_br finalShowdown_0f5de544:


    "Sua..."


translate pt_br finalShowdown_944b8194:


    "Sua criaturinha ingrata..."


translate pt_br finalShowdown_0476e12b:


    "Eu lhe dou minha paciência... minha atenção... meu {i}amor...{/i} e você acha que pode só {i}{b}ir embora?{/b}{/i}"


translate pt_br finalShowdown_c1890fde:


    "Eu não {i}precisava{/i}, sabia? Eu poderia ter apenas te {b}devorado{/b} quando quisesse, mas em vez disso..."


translate pt_br finalShowdown_111422a8:


    "Dei a você tempo para entender... tempo para aceitar o que estava acontecendo..."


translate pt_br finalShowdown_6ce15ddb:


    "Dei a você uma {b}escolha.{/b}"


translate pt_br finalShowdown_262e06a7:


    "{b}A VOCÊ.{/b}"


translate pt_br finalShowdown_e4b6e292:


    "Uma existência insignificante cuja ausência NINGUÉM sequer notaria se eu o tivesse tomado como quisesse."


translate pt_br finalShowdown_5ec00c47:


    "Sonhando inutilmente com possibilidades infinitas..."


translate pt_br finalShowdown_27e84286:


    "Nunca mais precisando se preocupar com consequências permanentes de novo... Sobre escolher errado..."


translate pt_br finalShowdown_94c81802:


    "Um pequeno mundo só seu dentro da sua cabeça..."


translate pt_br finalShowdown_4be86aa8:


    "Eu te ofereci tudo isso... Eu te dei a escolha de se juntar a mim e ter tudo..."


translate pt_br finalShowdown_8e138c4d:


    "E você recusou."


translate pt_br finalShowdown_7ab438d2:


    "Você disse preferir morrer, não disse? E ainda assim, aqui está você, tentando voltar atrás em suas escolhas..."


translate pt_br finalShowdown_ee2480c9:


    "...apenas para continuar me rejeitando."


translate pt_br finalShowdown_ec08c7ee:


    "Rejeitando meu amor..."


translate pt_br finalShowdown_380a9730:


    "Tão tolo..."


translate pt_br finalShowdown_ed1d138e:


    "Tão ingrato..."


translate pt_br finalShowdown_f5ff6d04:


    "Assim como os outros, você não sabe nem o que quer..."


translate pt_br finalShowdown_08772fff:


    "Outro emaranhado de contradições..."


translate pt_br finalShowdown_ea286119:


    "Você deseja solidão, ainda assim teme ficar sozinho..."


translate pt_br finalShowdown_38a1d032:


    "Teme ser esquecido... indesejado... não amado..."


translate pt_br finalShowdown_427c7ef2:


    "Ainda assim, mesmo eu, que amo você e o desejo..."


translate pt_br finalShowdown_26d7a1f6:


    "Mesmo que eu tenha prometido nunca esquecer você..."


translate pt_br finalShowdown_9b5e410c:


    "Mesmo que {b}eu{/b} seja o {i}único{/i} disposto a nunca deixá-lo..."


translate pt_br finalShowdown_a5b54e8a:


    "VOCÊ AINDA ME REJEITA."


translate pt_br finalShowdown_3e31e4a4:


    "{b}{i}Criança{/i}{/b} estúpida."


translate pt_br finalShowdown_fe885e9e:


    "Estou {i}cansado{/i} de esperar."


translate pt_br finalShowdown_90c94c9e:


    "Você não terá uma segunda chance. Você fez sua escolha e {b}{i}irá{/i}{/b} aceitar suas consequências."


translate pt_br finalShowdown_a4585081:


    "Você vai ficar aqui com o resto desses ingratos..."


translate pt_br finalShowdown_9ab7bfe1:


    ".{w=0.7}.{w=0.7}.{w=0.7}.{w=0.7}p{w=0.7}a{w=0.7}r{w=0.7}a{w=0.7} {w=0.7}s{w=0.7}e{w=0.7}m{w=0.7}p{w=0.7}r{w=0.7}e{w=0.7}."


translate pt_br finalShowdown_dae0ec55_4:


    you "..."


translate pt_br finalShowdown_21096a12:


    you "Você nunca ouviu falar em mudar de ideia?"


translate pt_br finalShowdown_240d387e:


    "Isso não apaga a sua decisão original. Ela foi gravada permanentemente na realidade."


translate pt_br finalShowdown_985e2f87:


    "Você se acha tão importante a ponto de estar {b}acima{/b} de encarar a verdade dessa realidade?"


translate pt_br finalShowdown_49817c9e:


    you "Não... Mas isso não significa que eu não possa fazer o meu melhor para corrigir as coisas."


translate pt_br finalShowdown_6346d171:


    you "Eu ainda estou aqui, não estou? Isso significa que sempre posso fazer mais escolhas... Escolhas melhores..."


translate pt_br finalShowdown_a20cefa7_3:


    "..."


translate pt_br finalShowdown_c6c45632:


    "Você se entregou a mim... {w}{i}Você{/i} já faz parte de {b}mim{/b}..."


translate pt_br finalShowdown_f79cd161:


    "Isso pode ser uma ilusãozinha patética sua..."


translate pt_br finalShowdown_0e17c1eb:


    "...mas não se esqueça de que {i}eu{/i} é que estou no controle aqui, humano."


translate pt_br finalShowdown_4d71bde9:


    you "Ah, é mesmo. {w}Aquelas \"escolhas\" distorcidas nos meus sonhos foram todas você, não foram?"


translate pt_br finalShowdown_297c677e:


    who "{alpha=0.3}nós ajudamos... ajudamos...{/alpha}"


translate pt_br finalShowdown_697cd04e:


    who "{alpha=0.5}rodando...{/alpha} acabarSonho.exe..."


translate pt_br finalShowdown_3c44db14:


    "O que está-"


translate pt_br finalShowdown_d8c402b1:


    who "P {w=0.3}E {w=0.3}R {w=0.3}S {w=0.3}I {w=0.3}S {w=0.3}T {w=0.3}A"


translate pt_br finalShowdown_210d572a:


    "!!!" with hpunch


translate pt_br finalShowdown_10402de1:


    "O que estão fazendo, seus traidores inúteis?!"


translate pt_br finalShowdown_7daca311:


    "{size=+15}PAREM!{/size}" with hpunch


translate pt_br finalShowdown_7bbc0a26:


    you "Acho que já era hora de eu começar a fazer minhas {i}próprias{/i} escolhas."


translate pt_br finalShowdown_c7b05810:


    cat "{size=+35}{b}PAR-!!{/b}{/size}{w=0.3}{nw}" with hpunch


translate pt_br whereItBegan_8dabefc6:


    ".."


translate pt_br whereItBegan_a20cefa7:


    "..."


translate pt_br whereItBegan_a20cefa7_1:


    "..."


translate pt_br whereItBegan_355c83da:


    "Tô de volta..."


translate pt_br whereItBegan_e91717e2:


    "De volta aonde tudo começou..."


translate pt_br whereItBegan_939db7b6:


    "O beco..."


translate pt_br whereItBegan_99fcd215:


    "E na caixa de papelão... {w}no fundo do beco..."


translate pt_br whereItBegan_8dabefc6_1:


    ".."


translate pt_br whereItBegan_a20cefa7_2:


    "..."


translate pt_br whereItBegan_dae0ec55:


    you "..."


translate pt_br whereItBegan_b0381c02:


    "Lá está você..."


translate pt_br whereItBegan_3064d8e1:


    "Não se parece em nada com o gato incrivelmente fofo que conheci... {w}bom... {w}o que parece ter sido há séculos..."


translate pt_br whereItBegan_c94b4764:


    "Depois de fugir e libertar os desejos de todas as suas vítimas..."


translate pt_br whereItBegan_46986469:


    "...tudo o que sobrou de você agora é uma massa preta viscosa fervendo diante de mim."


translate pt_br whereItBegan_87df935d:


    cat3 "..."


translate pt_br whereItBegan_c127cc5c:


    "O ódio interminável emanando do seu único olho..."


translate pt_br whereItBegan_a20cefa7_3:


    "..."


translate pt_br whereItBegan_083faea7:


    "...não me assusta nem um pouco."


translate pt_br whereItBegan_7e6715dd:


    cat3 "não vá"


translate pt_br whereItBegan_5071d7c2:


    cat3 "você é meu"


translate pt_br whereItBegan_8105eadd:


    you "Não..."


translate pt_br whereItBegan_5288c6f4:


    "Não sou."


translate pt_br whereItBegan_9a3acbc4:


    cat3 "você os tirou de mim"


translate pt_br whereItBegan_472c0f2d:


    cat3 "eles eram meus"


translate pt_br whereItBegan_ba12304a:


    cat3 "e agora se foram"


translate pt_br whereItBegan_9a3acbc4_1:


    cat3 "você os tirou de mim"


translate pt_br whereItBegan_94d1d734:


    cat3 "você tirou tudo de mim"


translate pt_br whereItBegan_dae0ec55_1:


    you "..."


translate pt_br whereItBegan_77bc0354:


    you "Eles também nunca foram seus."


translate pt_br whereItBegan_f379ba27:


    cat3 "sozinho"


translate pt_br whereItBegan_dae0ec55_2:


    you "..."


translate pt_br whereItBegan_9d45b838:


    "Você nunca {i}teve{/i} de ser..."


translate pt_br whereItBegan_85be2ed9:


    "Se você estava solitário... {w}Poderia simplesmente ter sido amigo deles..."


translate pt_br whereItBegan_a17d72a6:


    "Mas você não queria amizade."


translate pt_br whereItBegan_8fe47c61:


    "Eles foram embora porque você enganou eles..."


translate pt_br whereItBegan_4fe27187:


    "Sequestrou eles..."


translate pt_br whereItBegan_5f26a1dd:


    "{b}Machucou{/b} eles..."


translate pt_br whereItBegan_139aec37:


    "Roubou suas vidas... {w}Seu tempo... {w}E eles nunca poderão recuperar isso..."


translate pt_br whereItBegan_a20cefa7_4:


    "..."


translate pt_br whereItBegan_7b3789fb:


    "Você causou tudo isso."


translate pt_br whereItBegan_46dd9501:


    cat3 "você é perfeito"


translate pt_br whereItBegan_60798589:


    you "Não sou."


translate pt_br whereItBegan_b18d5776:


    cat3 "você {i}é{/i}"


translate pt_br whereItBegan_1cddd9bb:


    cat3 "não preciso dos outros"


translate pt_br whereItBegan_057f9031:


    cat3 "só de você"


translate pt_br whereItBegan_3f0d14d7:


    cat3 "fique comigo"


translate pt_br whereItBegan_3ee5d6e5:


    you "Não vou."


translate pt_br whereItBegan_51949c19:


    cat3 "posso te dar tudo"


translate pt_br whereItBegan_eeb62c46:


    cat3 "posso ser tudo por você"


translate pt_br whereItBegan_ff690f3e:


    you "Não... Você não pode."


translate pt_br whereItBegan_1244bbaf:


    "Não poderia nem mesmo {i}antes...{/i}"


translate pt_br whereItBegan_0c8bb1e9:


    "Definitivamente não pode {i}agora...{/i}"


translate pt_br whereItBegan_cb64e404:


    "E..."


translate pt_br whereItBegan_d38bed87:


    "Mesmo que você {i}pudesse{/i} me dar tudo que sempre quis e mais..."


translate pt_br whereItBegan_a20cefa7_5:


    "..."


translate pt_br whereItBegan_2dad4a80:


    "Eu {b}ainda assim{/b} nunca ficaria."


translate pt_br whereItBegan_68cdb263:


    cat3 "eu te amo"


translate pt_br whereItBegan_9cf90ed4:


    you "Você não-{w=0.3}{nw}"


translate pt_br whereItBegan_d49ea8d6:


    cat3 "eu {b}amo{/b}"


translate pt_br whereItBegan_dae0ec55_3:


    you "..."


translate pt_br whereItBegan_258ecaf3:


    cat3 "tanto"


translate pt_br whereItBegan_68cdb263_1:


    cat3 "eu te amo"


translate pt_br whereItBegan_6cdd727d:


    cat3 "{size=-5}eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo {/size}"


translate pt_br whereItBegan_f9bff14e:


    you "{b}{i}Para.{/i}{/b}"


translate pt_br whereItBegan_87df935d_1:


    cat3 "..."


translate pt_br whereItBegan_8753550f:


    you "Talvez você {i}realmente{/i} me ame..."


translate pt_br whereItBegan_26b2f544:


    you "De um jeito estranho e distorcido que eu nunca vou entender..."


translate pt_br whereItBegan_8d59fc22:


    you "Mas mesmo que seja o caso..."


translate pt_br whereItBegan_dae0ec55_4:


    you "..."


translate pt_br whereItBegan_a4a76912:


    you "...Isso não basta."


translate pt_br whereItBegan_87df935d_2:


    cat3 "..."


translate pt_br whereItBegan_ce7d4730:


    cat3 "por favor"


translate pt_br whereItBegan_4f636a45:


    cat3 "não vá"


translate pt_br whereItBegan_5b4c342f:


    cat3 "vou ser bom"


translate pt_br whereItBegan_dae0ec55_5:


    you "..."


translate pt_br whereItBegan_97b5d2b0:


    you "Eu não acredito eu você."


translate pt_br whereItBegan_dc4cb259:


    cat3 "eu prometo"


translate pt_br whereItBegan_dae0ec55_6:


    you "..."


translate pt_br whereItBegan_e301b7d9:


    you "Não posso confiar em você."


translate pt_br whereItBegan_944f9217:


    cat3 "{size=+10}eu prometo{/size}" with hpunch


translate pt_br whereItBegan_c8d092d5:


    cat3 "só não {b}vá{/b}"


translate pt_br whereItBegan_1b817c48:


    cat3 "{size=-5}não me deixe sozinho{/size}"


translate pt_br whereItBegan_e81e0eae:


    cat3 "{size=-8}por favor{/size}"


translate pt_br whereItBegan_556d4f53:


    cat3 "{size=-8}vou morrer{/size}"


translate pt_br whereItBegan_9a0ddf1d:


    cat3 "{size=-8}vou {b}morrer{/b} sem você{/size}"


translate pt_br whereItBegan_dae0ec55_7:


    you "..."


translate pt_br whereItBegan_26f6da8b:


    cat3 ".."


translate pt_br whereItBegan_87df935d_3:


    cat3 "..."


translate pt_br whereItBegan_e94cd667:


    cat3 "{size=-10}eu {color=#FF0000}{b}odeio{/b}{/color} você{/size}"


translate pt_br whereItBegan_dae0ec55_8:


    you "..."


translate pt_br whereItBegan_8d18066c:


    you "Agora, {b}{i}isso{/i}{/b} sim... {w}Eu {i}consigo{/i} acreditar."


translate pt_br whereItBegan_87df935d_4:


    cat3 "..."


translate pt_br whereItBegan_8dabefc6_2:


    ".."


translate pt_br whereItBegan_a20cefa7_6:


    "..."


translate pt_br whereItBegan_bca6c5f8:


    "Não há mais nada a dizer."


translate pt_br whereItBegan_2e1ef17d:


    "Você assiste em silêncio enquanto o gato..."


translate pt_br whereItBegan_53a0111a:


    "...enquanto {color=#FF0000}{b}isso{/b}{/color}... {w}se desfaz por completo..."


translate pt_br whereItBegan_a20cefa7_7:


    "..."


translate pt_br whereItBegan_dae0ec55_9:


    you "..."


translate pt_br whereItBegan_0214ad62:


    "{i}Adeus...{/i}"


translate pt_br whereItBegan_d831204f:


    "Com um último vislumbre pelo beco..."


translate pt_br whereItBegan_18671b5a:


    "Eu me viro..."


translate pt_br whereItBegan_78e07a96:


    "...e vou embora."


translate pt_br whereItBegan_8dabefc6_3:


    ".."


translate pt_br whereItBegan_a20cefa7_8:


    "..."


translate pt_br whereItBegan_ebb653f4:


    "Final 38: NÃO Leve Esse Gato Para Casa"

translate pt_br strings:


    old "What do you mean I was \"daydreaming\"?"
    new "Como assim eu tava \"sonhando acordado\"?"


    old "Where are we right now?"
    new "Onde a gente tá agora?"


    old "Why do you keep killing me?!"
    new "Por que você fica me matando?!"


    old "You're a cat, how are you talking?"
    new "Você é um gato, como consegue falar?"


    old "What do you want?"
    new "O que você quer?"


    old "Nothing, I don't care!"
    new "Nada, tô cagando e andando!"






    old "No..."
    new "Não..."


    old "Am I still dreaming?"
    new "Ainda estou sonhando?"


    old "You even made me kill {i}you{/i} in the end!"
    new "Você fez até eu {i}te{/i} matar no final!"


    old "But you're a {i}cat!{/i} How are you doing this?!"
    new "Mas você é um {i}gato!{/i} Como tá fazendo isso?!"


    old "\"I'll join you...\""
    new "\"Vou me juntar a você...\""


    old "\"I'd rather die.\""
    new "\"Prefiro morrer.\""


    old "{size=-6}persist...{/size}"
    new "{size=-6}persistir...{/size}"


    old "{b}P E R S I S T{/b}"
    new "{b}P E R S I S T I R{/b}"


    old "Do not take this cat home."
    new "Não leve esse gato para casa."


    old "Do {b}NOT{/b} take this cat home."
    new "{b}NÃO{/b} leve esse gato para casa."

    old "lies..."
    new "mentiras..."

    old "is {i}us{/i}..."
    new "somos {i}nós{/i}..."

    old "{i}we{/i} are strong..."
    new "{i}somos{/i} fortes..."

    old "persist..."
    new "persista..."

    old "{i}persist...{/i}"
    new "{i}persista...{/i}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
