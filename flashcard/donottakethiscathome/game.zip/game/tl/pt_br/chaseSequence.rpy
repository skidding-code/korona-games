


translate pt_br finalShowdownChase_8dabefc6:


    ".."


translate pt_br finalShowdownChase_a20cefa7:


    "..."


translate pt_br finalShowdownChase_28b3ac41:


    you "!!"


translate pt_br finalShowdownChase_d780f384:


    you "{i}Voltei pro beco...{/i}"


translate pt_br finalShowdownChase_f7ab12f7:


    you "{i}Não tá aqui... Ainda bem...{/i}"


translate pt_br finalShowdownChase_06674a63:


    you "{i}Acho... {w}Acho que preciso ir pra casa...{/i}"


translate pt_br finalShowdownChase_8dabefc6_1:


    ".."


translate pt_br finalShowdownChase_a20cefa7_1:


    "..."


translate pt_br finalShowdownChase_d545054f:


    "Eu, hã..."


translate pt_br finalShowdownChase_0c089aed:


    "...dou um passo à frente? {w}Saindo... {w}do beco?"


translate pt_br finalShowdownChase_dae0ec55:


    you "..."


translate pt_br finalShowdownChase_edaac27f:


    you "{i}Vou demorar um tempo pra me acostumar com isso...{/i}"


translate pt_br finalShowdownChase_c6ca505e:


    "E-eu dou um passo à frente em direção à entrada do beco, que felizmente está vazio."


translate pt_br finalShowdownChase_a762f582:


    "Tô quase fora daqui..."


translate pt_br finalShowdownChase_c23d8f1d:


    "Quase em casa-{w=0.5}{nw}"


translate pt_br finalShowdownChase_f29a87f6:


    "{b}{color=#FF0000}quando \ d e \ r e p e n t e e e e . . . {/color}{/b}" with hpunch


translate pt_br finalShowdownChase_479c3431:


    you "!!" with vpunch


translate pt_br finalShowdownChase_ba5843f8:


    cat "{size=+15}VOCÊEEE!!{/size}" with vpunch


translate pt_br finalShowdownChase_56ebb028:


    you "!!!"


translate pt_br finalShowdownChase_d9cfa56f:


    cat "{size=+20}VOCÊ{/size}{w=0.5}{nw}" with vpunch


translate pt_br finalShowdownChase_c62afa20:


    cat "{size=+25}NÃO VAI{/size}{w=0.5}{nw}" with vpunch


translate pt_br finalShowdownChase_66fe51fb:


    cat "{size=+30}{b}A LUGAR{/b}{/size}{w=0.5}{nw}" with vpunch


translate pt_br finalShowdownChase_f73f59ae:


    cat "{size=+35}{b}{i}NENHUM!!{/i}{/b}{/size}" with vpunch


translate pt_br gotYou_9ea2f78c:


    " "


translate pt_br gotYou_9ea2f78c_1:


    " "


translate pt_br gotYou_9ea2f78c_2:


    " "


translate pt_br gotYou_9ea2f78c_3:


    " "


translate pt_br gotYou_9ea2f78c_4:


    " "


translate pt_br gotYou_9ea2f78c_5:


    " "


translate pt_br gotYou_9ea2f78c_6:


    " "


translate pt_br gotYou_9ea2f78c_7:


    " "


translate pt_br forcedMenu_11e8f724:


    "Merda..! Me leu como um livro!"


translate pt_br forcedMenu_11da515d:


    "Pra onde eu vou?!"


translate pt_br forcedMenu_80dcf355:


    "Qualquer lugar, menos aqui!"


translate pt_br forcedMenu_80dcf355_1:


    "Qualquer lugar, menos aqui!"


translate pt_br forcedMenu_80dcf355_2:


    "Qualquer lugar, menos aqui!"


translate pt_br forcedMenu_479c3431:


    you "!!" with vpunch


translate pt_br forcedMenu_bd221748:


    you "Eu... consegui..?"


translate pt_br forcedMenu_7f923745:


    who "fio se desenrolando... {w}muitos nós escapam... {w}muitos livres agora..."


translate pt_br forcedMenu_3c5590a3:


    who "{b}{color=#FF0000}I S S O{/color}{/b} nos perdendo... {w}perdendo força..."


translate pt_br forcedMenu_1c5a04cd:


    who "sua fuga... {w}possível agora..."


translate pt_br forcedMenu_0f670756:


    cat "{size=+25}{b}{i}NÃOOO!!{/i}{/b}{/size}" with vpunch


translate pt_br forcedMenu_2dadc39a:


    cat "{size=+25}{b}{i}VOCÊ!!{/i}{/b}{/size}" with vpunch


translate pt_br forcedMenu_7e3cb0cc:


    cat "{size=+25}{b}{i}É!!{/i}{/b}{/size}" with vpunch


translate pt_br forcedMenu_3291da01:


    cat "{size=+25}{b}{i}{color=#FF0000}MEU!!{/color}{/i}{/b}{/size}" with vpunch


translate pt_br forcedMenu_32f51c80:


    who "{alpha=0.8}nós seguimos em frente... {w}nós nos libertamos...{/alpha}"


translate pt_br forcedMenu_c54506c0:


    who "{alpha=0.5}obrigado...{/alpha}"


translate pt_br forcedMenu_63e75705:


    who "{i}{alpha=0.3}obrigado...{/alpha}{/i}"


translate pt_br forcedMenu_6f50b679:


    who "..."


translate pt_br forcedMenu_dae0ec55:


    you "..."


translate pt_br forcedMenu_62914fe0:


    you "Obrigado também... a todos vocês..."


translate pt_br forcedMenu_dae0ec55_1:


    you "..."


translate pt_br forcedMenu_0ac72f08:


    you "Eu não vou esquecer vocês..."


translate pt_br oldTheater5a_b3a0900b:


    you "Droga! Sem saída..!"


translate pt_br oldTheater5a_0b089920:


    cat "{size=+25}{b}{i}PARA DE CORRER!!{/i}{/b}{/size}" with vpunch


translate pt_br oldTheater5a_28b3ac41:


    you "!!"


translate pt_br oldTheater5c_c52bbb18:


    cat "{size=+15}{b}{i}VOLTA AQUI!!{/i}{/b}{/size}" with vpunch


translate pt_br oldTheater5c_dae0ec55:


    you "..."


translate pt_br newCinema5a_7e60013d:


    you "Sem saída..? Pra onde eu-"


translate pt_br newCinema5a_2dea9288:


    cat "{size=+25}{b}{i}TE ACHEI~!!{/i}{/b}{/size}" with vpunch


translate pt_br newCinema5a_28b3ac41:


    you "!!"


translate pt_br newCinema5c_c52bbb18:


    cat "{size=+15}{b}{i}VOLTA AQUI!!{/i}{/b}{/size}" with vpunch


translate pt_br newCinema5c_dae0ec55:


    you "..."


translate pt_br carnival5a_af46df21:


    you "Como eu saio daqui?!"


translate pt_br carnival5a_9290bf8e:


    cat "{size=+25}{b}{i}NÃO HÁ FUGA!!{/i}{/b}{/size}" with vpunch


translate pt_br carnival5a_28b3ac41:


    you "!!"


translate pt_br carnival5c_c52bbb18:


    cat "{size=+15}{b}{i}VOLTA AQUI!!{/i}{/b}{/size}" with vpunch


translate pt_br carnival5c_dae0ec55:


    you "..."


translate pt_br dogPark5a_5d305961:


    you "Porra! Tenho que escapar..!"


translate pt_br dogPark5a_cf455219:


    cat "{size=+25}{b}TE PEGUEI {i}AGORA!!{/i}{/b}{/size}" with vpunch


translate pt_br dogPark5a_28b3ac41:


    you "!!"


translate pt_br dogPark5c_c52bbb18:


    cat "{size=+15}{b}{i}VOLTA AQUI!!{/i}{/b}{/size}" with vpunch


translate pt_br dogPark5c_dae0ec55:


    you "..."


translate pt_br street1_0f670756:


    cat "{size=+25}{b}{i}NÃOOO!!{/i}{/b}{/size}" with vpunch


translate pt_br street3_85039274:


    cat "{size=+25}{b}{i}VOLTA!!{/i}{/b}{/size}" with vpunch


translate pt_br street5_3ef5df1c:


    cat "{size=+25}{b}{i}{color=#FF0000}VOLTA!!{/color}{/i}{/b}{/size}" with vpunch


translate pt_br apt1_cad1cfa2:


    cat "{size=+25}{b}{i}{color=#FF0000}POR FAVOR!!{/color}{/i}{/b}{/size}" with vpunch


translate pt_br apt2_8805a939:


    cat "{size=+20}{b}{i}{color=#FF0000}NÃO ME DEIXA!!{/color}{/i}{/b}{/size}" with vpunch


translate pt_br apt3_3088931f:


    cat "{size=+15}{b}{i}{color=#FF0000}VOU MORRER SEM VOCÊ!!{/color}{/i}{/b}{/size}" with vpunch


translate pt_br apt4_d1378a7d:


    cat "{size=+10}{b}{i}{color=#FF0000}VOU MORRER!!{/color}{/i}{/b}{/size}" with vpunch


translate pt_br apt5_9f2b0199:


    cat "{size=+5}{b}{i}{color=#FF0000}VOU MORRER!!{/color}{/i}{/b}{/size}" with vpunch


translate pt_br apt5_b75195fe:


    cat "ESPERA..!"


translate pt_br apt5_3e0cf073:


    cat "{size=-5}Espera...{/size}"


translate pt_br chaseFail_436e4a4f:


    "Preciso fugir PARA LONGE disso!"

translate pt_br strings:


    old "GO LEFT!"
    new "IR PRA ESQUERDA!"


    old "GO BACK!"
    new "IR PRA TRÁS!"


    old "GO RIGHT!"
    new "IR PRA DIREITA!"


    old "Go home!!"
    new "Ir pra casa!!"


    old "I've got to escape!"
    new "Tenho que fugir!"


    old "go WATCH a {b}movie{/b}"
    new "ir ASSISTIR um {b}filme{/b}"


    old "go {b}to{/b} the CARNIVAL"
    new "ir {b}ao{/b} FESTIVAL"


    old "GO to {b}dog{/b} park"
    new "IR ao parque para {b}cachorros{/b}"


    old "They were right... My choice is back!"
    new "Eles estavam certos... Minha escolha voltou!"


    old "go to old theater."
    new "ir ao cinema antigo."


    old "go to new cinema."
    new "ir ao cinema novo."


    old "PUSH FORWARD!"
    new "VÁ EM FRENTE!"


    old "Persist?"
    new "Persistir?"


    old "Give up?"
    new "Desistir?"

    old "{alpha=1}Don't give in to it...{/alpha}"
    new "{alpha=1}Não deixe isso te vencer...{/alpha}"

    old "{alpha=0.75}Keep going...{/alpha}"
    new "{alpha=0.75}Continue...{/alpha}"

    old "{alpha=0.5}{color=#FF0000}IT's{/color} power is fading...{/alpha}"
    new "{alpha=0.5}O poder {color=#FF0000}DISSO{/color} está enfraquecendo...{/alpha}"

    old "{alpha=0.25}You're almost there...{/alpha}"
    new "{alpha=0.25}Você está quase lá...{/alpha}"

    old "{alpha=0.2}You have the strength to escape...{/alpha}"
    new "{alpha=0.2}Você tem a força para fugir...{/alpha}"

    old "{alpha=0.2}At the end of this chaos...{/alpha}"
    new "{alpha=0.2}Quando esse caos acabar...{/alpha}"

    old "{alpha=0.2}You will be okay...{/alpha}"
    new "{alpha=0.2}Você estará bem...{/alpha}"

    old "{alpha=0.2}We are with you...{/alpha}"
    new "{alpha=0.2}Estamos com você...{/alpha}"

    old "{alpha=0.25}thank you{/alpha}"
    new "{alpha=0.25}obrigado{/alpha}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
