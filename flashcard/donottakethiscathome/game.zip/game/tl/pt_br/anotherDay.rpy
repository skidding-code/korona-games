


translate pt_br newDay_8dabefc6:


    ".."


translate pt_br newDay_a20cefa7:


    "..."


translate pt_br newDay_a20cefa7_1:


    "..."


translate pt_br newDay_9ca326b8:


    "Hoje o dia foi... {w}surpreendente..?"


translate pt_br newDay_a20cefa7_2:


    "..."


translate pt_br newDay_f75e011d:


    "É... {w} De um jeito {i}bom{/i}."


translate pt_br newDay_82fa61bd:


    "Um dia de folga que começou com um tempo bem ruim me levou ao velho teatro..."


translate pt_br newDay_6b209dab:


    "...onde curti um filme sozinho. {w}Minha risada preencheu o cinema vazio."


translate pt_br newDay_5d4d31f0:


    "A chuva já tinha parado quando o filme acabou..."


translate pt_br newDay_4e355058:


    "...e eu estava tão de bom humor que fui até o cinema não-tão-novo."


translate pt_br newDay_5074d7cd:


    "Não para assistir outro filme..."


translate pt_br newDay_112fac01:


    "...mas sim para brincar no fliperama e marcar alguns recordes."


translate pt_br newDay_5c2bbf14:


    "Com o gamer dentro de mim despertado, fui ao festival para jogar mais um pouco..."


translate pt_br newDay_61e5a43c:


    "...e logo fui colocado no meu lugar."


translate pt_br newDay_008b7bea:


    "Mas eu {i}consegui{/i} ganhar um pequeno bicho de pelúcia na barraca de arremesso de argolas..."


translate pt_br newDay_1c428f6d:


    "A aparência é... {w}questionável..."


translate pt_br newDay_8dabefc6_1:


    ".."


translate pt_br newDay_a20cefa7_3:


    "..."


translate pt_br newDay_cf798fa8:


    "...e eu simplesmente {b}amo{/b} isso."


translate pt_br newDay_8944ff2f:


    "Os passeios também não foram tão ruins."


translate pt_br newDay_4294899b:


    "Fui integrado a um grupo por um tempo, enquanto esperava na fila da roda-gigante..."


translate pt_br newDay_0c68408c:


    "...unindo forças com nossa desconfiança compartilhada em relação aos vendedores de jogos do festival."


translate pt_br newDay_e9c1e26b:


    "Até compartilhei uma cabine na roda-gigante com alguns deles..."


translate pt_br newDay_2246cb2d:


    "...e trocamos números antes de seguirmos caminhos diferentes."


translate pt_br newDay_35f5ea23:


    "Não sei se vou vê-los novamente ou se algum deles vai me ligar..."


translate pt_br newDay_df3e5ab9:


    "...ou se eu tenho coragem para ligar para algum {i}deles...{/i}"


translate pt_br newDay_bf0874e3:


    "Mas..."


translate pt_br newDay_51014aa6:


    "...ter a opção de fazer isso é... {w}legal."


translate pt_br newDay_5fae18ae:


    "É legal."


translate pt_br newDay_a20cefa7_4:


    "..."


translate pt_br newDay_75f35366:


    "Pequenos passos..."


translate pt_br newDay_3aa81c02:


    "Afinal, mesmo aquele pouquinho de interação, {w}embora divertido... {w}me deixou exausto."


translate pt_br newDay_ff72ab2e:


    "Então fui recarregar as energias no parque para cachorros..."


translate pt_br newDay_a0654299:


    "...me sentindo rejuvenescido ao ver os cachorros... {w}velhos, jovens, grandes e pequenos, {w}todos correndo..."


translate pt_br newDay_b8191da0:


    "...alegres e despreocupados."


translate pt_br newDay_26f7c165:


    "Alguns dos donos até me deixaram tirar fotos."


translate pt_br newDay_81757b6b:


    "...É."


translate pt_br newDay_c8368ac2:


    "Hoje foi um bom dia."


translate pt_br newDay_a20cefa7_5:


    "..."


translate pt_br newDay_c70fb4a0:


    "Não penso muito no gato, ou \"isso\", eu acho... ultimamente..."


translate pt_br newDay_79c0fad2:


    "Foi difícil no começo..."


translate pt_br newDay_37f75de5:


    "Nos dias e semanas seguintes..."


translate pt_br newDay_4a9c65e2:


    "...o que aconteceu comigo era tudo o que eu conseguia pensar."


translate pt_br newDay_25500d1f:


    "Houve dias em que me culpei..."


translate pt_br newDay_d712875a:


    "Dias em que questionei minhas escolhas..."


translate pt_br newDay_5d330940:


    "Voltei ao beco mais vezes do que gostaria de admitir..."


translate pt_br newDay_06bc579c:


    "A sensação que sempre me invadia ao ver aquela caixa de papelão vazia..."


translate pt_br newDay_af9d6393:


    "...era tão indescritível... {w}tão {i}{b}avassaladora{/b}...{/i}"


translate pt_br newDay_d7e56945:


    "...que às vezes eu desabava e chorava bem onde estava."


translate pt_br newDay_1933371e:


    "Demorou um pouco, mas eventualmente aquela estranha emoção se tornou cada vez mais clara..."


translate pt_br newDay_28266ef4:


    "...até que eu tive coragem de reconhecê-la pelo que era..."


translate pt_br newDay_a20cefa7_6:


    "..."


translate pt_br newDay_d38a0dc6:


    "...\"Alívio.\""


translate pt_br newDay_e22ded33:


    "Eu tive medo de sentir isso por tanto tempo..."


translate pt_br newDay_3ed17d31:


    "...apavorado demais para abaixar a guarda."


translate pt_br newDay_a20cefa7_7:


    "..."


translate pt_br newDay_364a8cff:


    "Mas aquele sentimento de alívio finalmente voltou."


translate pt_br newDay_0e307cdc:


    "Alívio por \"isso\" ter ido embora..."


translate pt_br newDay_c6ae1854:


    "Alívio por eu estar livre para viver minha vida..."


translate pt_br newDay_a20cefa7_8:


    "..."


translate pt_br newDay_78dc6ac8:


    "...de um jeito simples ou extraordinário, do jeito que {b}{i}eu{/i}{/b} quisesse."


translate pt_br newDay_5374d191:


    "Aqueles que \"isso\" aprisionou..."


translate pt_br newDay_4893c26e:


    "Nunca mais ouvi suas vozes também..."


translate pt_br newDay_1f6ffbc9:


    "Mas é melhor assim..."


translate pt_br newDay_4bc19197:


    "Vivendo aqui e agora..."


translate pt_br newDay_9c8d77ec:


    "Nunca esquecendo o que fizeram por mim..."


translate pt_br newDay_475a8b7e:


    "...e o que eu fiz por eles também..."


translate pt_br newDay_a20cefa7_9:


    "..."


translate pt_br newDay_b361ea6b:


    "Por enquanto... acho que isso é suficiente..."


translate pt_br newDay_298a3c15:


    "Pelo menos, espero que sim..."


translate pt_br newDay_0a2444b8:


    "...e que onde quer que estejam, finalmente tenham encontrado paz."


translate pt_br newDay_9e6de573:


    "Eu estou lutando pela minha própria paz também..."


translate pt_br newDay_0f1329f4:


    "Um dia após o outro..."


translate pt_br newDay_a1af867c:


    "Um amanhã após o outro..."


translate pt_br newDay_5795957d:


    "Finalmente... {w}Vou para casa..."


translate pt_br newDay_3347a2a8:


    "...para meu pequeno apartamento."


translate pt_br newDay_49ae6019:


    "Um quarto... {w}um banheiro... {w}Só {i}eu{/i} vivendo sozinho nele."


translate pt_br newDay_8dabefc6_2:


    ".."


translate pt_br newDay_a20cefa7_10:


    "..."


translate pt_br newDay_bfab167e:


    "Bom..."


translate pt_br newDay_f1fea4b8:


    "{i}Quase{/i} isso..."


translate pt_br newDay_15ad7189:


    you "Tô em casa, benzinho~!"


translate pt_br newDay_f845d69b:


    who "Miiiiiau!" with hpunch


translate pt_br newDay_426e1e56:


    "Um gatinho se agita enquanto corre desajeitadamente até mim, miando..."


translate pt_br newDay_12ef594f:


    kitten "Miiiiiau~"


translate pt_br newDay_1c0fd25a:


    "Me ajoelho, olhando carinhosamente para seu olho verde-avelã."


translate pt_br newDay_c3369978:


    "O coitadinho tinha se machucado e estava faminto quando encontrei ele há algumas semanas..."


translate pt_br newDay_1b8a6de6:


    "...mas com certeza recuperou suas energias depois de um pouco de comida e cuidado."


translate pt_br newDay_a0beacdc:


    you "Sentiu saudade?"


translate pt_br newDay_e2c8cb1d:


    kitten "Miiiiau!" with hpunch


translate pt_br newDay_2efd6520:


    you "Com fome, hã?"


translate pt_br newDay_a27db5c6:


    kitten "Miii..."


translate pt_br newDay_01d545ca:


    you "Hehe! Eu também. Foi um {b}{i}longo{/i}{/b} dia..."


translate pt_br newDay_5a6703df:


    "Eu sorrio todo bobão para seu rostinho fofo."


translate pt_br newDay_24ea3155:


    you "Vamos arrumar algo pra comer, tá bom?"


translate pt_br newDay_bc1c78d9:


    kitten "Purr..."


translate pt_br newDay_c6f7b15a:


    "Bem... acho que {i}tem{/i} mais uma coisa vivendo na minha casa..."


translate pt_br newDay_8a9eb749:


    "E... {w}pelo menos por {i}agora{/i}..."


translate pt_br newDay_a20cefa7_11:


    "..."


translate pt_br newDay_89839a09:


    "...Não gostaria que fosse diferente."


translate pt_br newDay_8dabefc6_3:


    ".."


translate pt_br newDay_a20cefa7_12:


    "..."


translate pt_br newDay_f883a887:


    "Final N/A: Outro dia..."


translate pt_br rollCredits_9ea2f78c:


    " "

translate pt_br strings:

    old "{color=#FF0000}Backgrounds & BG/Art References{/color}\n\nPexels.com"
    new "{color=#FF0000}Cenários & Referências de Arte/Cenário{/color}\n\nPexels.com"

    old "{color=#FF0000}Sound Effects{/color}\n\nPixabay.com"
    new "{color=#FF0000}Efeitos Sonoros{/color}\n\nPixabay.com"

    old "{color=#FF0000}Programmed With{/color}\n\nRen'Py"
    new "{color=#FF0000}Programado Com{/color}\n\nRen'Py"

    old "{color=#FF0000}Português-BR Translation{/color}\n\nGeorge Ribeiro"
    new "{color=#FF0000}Tradução Português-BR{/color}\n\nGeorge Ribeiro"

    old "{color=#FF0000}Italian Translation{/color}\n\nStar Words Team\n-----\nAlagna Mattia\nCasamassima Stefania\nDe Vincenzi Roberta\nNanni Lucia"
    new "{color=#FF0000}Tradução Italiano{/color}\n\nStar Words Team\n-----\nAlagna Mattia\nCasamassima Stefania\nDe Vincenzi Roberta\nNanni Lucia"

    old "{color=#FF0000}And you...{/color}\n\nThank you for playing"
    new "{color=#FF0000}E à você...{/color}\n\nObrigado por jogar"

    old "The End"
    new "Fim"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
