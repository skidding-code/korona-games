

translate pt_br strings:


    old "Back"
    new "Voltar"


    old "History"
    new "Histórico"


    old "Skip"
    new "Pular"


    old "Auto"
    new "Auto"


    old "Save"
    new "Salvar"


    old "Q.Save"
    new "R.Salvar"


    old "Q.Load"
    new "R.Carregar"


    old "Prefs"
    new "Opções"


    old "..."
    new "..."


    old "Continue"
    new "Continuar"


    old "Start"
    new "Começar"


    old "Load"
    new "Carregar"


    old "Preferences"
    new "Opções"


    old "End Replay"
    new "Terminar repetição"


    old "Main Menu"
    new "Menu Principal"


    old "Endings"
    new "Finais"


    old "???"
    new "???"


    old "About"
    new "Sobre"


    old "Help"
    new "Ajuda"


    old "Credits"
    new "Créditos"


    old "Quit"
    new "Sair"


    old "Return"
    new "Voltar"

    old "\nYou find a cat on your day off. From there, you decide what happens next.\n"
    new "\nVocê encontra um gato no seu dia de folga. \nA partir daí, você decide o que acontece a seguir.\n"

    old "...Or {i}do{/i} you?"
    new "...Ou {i}será{/i} que não?"

    old "\n{size=+20}Content/Trigger Warnings{/size}"
    new "{size=+20}Avisos de Conteúdo/Gatilhos{/size}"


    old "{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n"
    new "{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n"


    old "\nContains {color=#FF0000}spoilers{/color}!\n\n"
    new "\nContém {color=#FF0000}spoilers{/color}!\n\n"


    old "Abuse / abusive relationship(s)"
    new "Abuso / Relacionamento(s) abusivo(s)"


    old "Agoraphobia"
    new "Agorafobia"


    old "Amnesia"
    new "Amnésia"


    old "Amputation / Dismemberment"
    new "Amputação / Desmembramento"


    old "Animal abuse"
    new "Abuso de animais"


    old "Animal death"
    new "Morte de animais"


    old "Animals/monsters eating humans"
    new "Animais/monstros comendo humanos"


    old "Anxiety / Social Anxiety"
    new "Ansiedade / Ansiedade Social"


    old "Blood & gore"
    new "Sangue & gore"


    old "Body horror"
    new "Horror corporal"


    old "Body injury"
    new "Lesão corporal"


    old "Cannibalism"
    new "Canibalismo"


    old "Child abuse (minor mention/hint of)"
    new "Abuso infantil (menção/insinuação leve)"


    old "Cosmic horror"
    new "Horror cósmico"


    old "Dead bodies & body parts"
    new "Corpos mortos & partes do corpo"


    old "Death / dying"
    new "Morte"


    old "Decapitation"
    new "Decapitação"


    old "Depression"
    new "Depressão"


    old "Dissociation"
    new "Dissociação"


    old "Doll animation"
    new "Animação de bonecos"


    old "Emotional abuse"
    new "Abuso emocional"


    old "Entrapment"
    new "Confinamento"


    old "Epilepsy warning - flashing images & lights/static"
    new "Aviso de epilepsia - imagens e luzes/padrões piscantes"


    old "Glitches"
    new "Glitches"


    old "Hallucinations"
    new "Alucinações"


    old "Heart attack"
    new "Ataque cardíaco"


    old "Intrusive thoughts"
    new "Pensamentos intrusivos"


    old "Isolation"
    new "Isolamento"


    old "Kidnapping / abduction"
    new "Sequestro / abdução"


    old "Loss of vision"
    new "Perda de visão"


    old "Loud, sudden and/or repeating noises"
    new "Ruídos altos, repentinos e/ou repetitivos"


    old "Manipulation / gaslighting"
    new "Manipulação / gaslighting"


    old "Mental illness"
    new "Doença mental"


    old "Mind control"
    new "Controle mental"


    old "Murder"
    new "Assassinato"


    old "Paranoia"
    new "Paranóia"


    old "Poison / venom"
    new "Veneno / toxinas"


    old "Psychological horror"
    new "Horror psicológico"


    old "Scary / disturbing images & messages"
    new "Imagens e mensagens assustadoras / perturbadoras"


    old "Scopophobia"
    new "Escopofobia"


    old "Seizure"
    new "Convulsão"


    old "Self-harm"
    new "Autolesão"


    old "Stalking"
    new "Perseguição"


    old "Suicide / Suicidal ideation"
    new "Suicídio / Ideação suicida"


    old "Tense situations / gameplay"
    new "Situações / jogabilidade tensas"


    old "Thalassophobia"
    new "Talassofobia"


    old "Timed gameplay"
    new "Jogabilidade com limite de tempo"


    old "Violence"
    new "Violência"


    old "Vomiting"
    new "Vômito"


    old "\n{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n"
    new "\n{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n"


    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Feito com {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"


    old "Endings Found: {color=#fff}[persistent.endCounter] / 40{/color}"
    new "Finais Descobertos: {color=#fff}[persistent.endCounter] / 40{/color}"


    old "Ending 0: It Begins -- {color=#FF0000}Complete{/color}"
    new "Final 0: O Início -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Something... happened. You {b}think{/b}, anyway. You can't really remember what...{/size}{/i}"
    new "    {i}{size=-3}Algo... aconteceu. Pelo menos é o que você {b}acha{/b}. Você não consegue se lembrar do quê...{/size}{/i}"


    old "\nEnding 0: It Begins -- {color=#FF0000}Complete{/color}"
    new "\nFinal 0: O Início -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}The first time you took {color=#FF0000}{b}it{/b}{/color} home.{/size}{/i}"
    new "    {i}{size=-3}A primeira vez que você levou {color=#FF0000}{b}isso{/b}{/color} para casa.{/size}{/i}"


    old "\nEnding 1: A (Not So) Clean Getaway -- {color=#FF0000}Complete{/color}"
    new "\nFinal 1: Uma Fuga (Não Tão) Limpa -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You tried to clean your apartment but apparently you're not very good at it.{/size}{/i}"
    new "    {i}{size=-3}Você tentou limpar seu apartamento, mas aparentemente você não é tão bom nisso.{/size}{/i}"


    old "\nEnding 2: Double Trouble -- {color=#FF0000}Complete{/color}"
    new "\nFinal 2: Problema Em Dobro -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You found the ones responsible for making a mess of your apartment. Haha, those little pranksters...{/size}{/i}"
    new "    {i}{size=-3}Você encontrou os responsáveis pela bagunça no seu apartamento. Haha, essas pestinhas...{/size}{/i}"


    old "\nEnding 3: Silent Film -- {color=#FF0000}Complete{/color}"
    new "\nFinal 3: O Mal Interior -– {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You let the cat sit in your favorite chair and watched a scary movie together. Just an ordinary movie night.{/size}{/i}"
    new "    {i}{size=-3}Você deixou o gato se sentar na sua poltrona favorita e assistiram a um filme de terror juntos. Apenas mais uma noite de filmes.{/size}{/i}"


    old "\nEnding 4: Real \"Subtle\" -- {color=#FF0000}Complete{/color}"
    new "\nFinal 4: Bem \"Sutil\" -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You took back the chair from the cat and enjoyed some silly, little jumpscares alone.{/size}{/i}"
    new "    {i}{size=-3}Você tomou de volta a poltrona do gato e curtiu alguns sustinhos sozinho.{/size}{/i}"


    old "\nEnding 5: Do {i}Nyaa-t{/i} Disturb -- {color=#FF0000}Complete{/color}"
    new "\nFinal 5: Não {i}Mia Corde{/i} -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You shouldn't bother a cat while it's trying to nap...{/size}{/i}"
    new "    {i}{size=-3}Você não deveria incomodar um gato enquanto ele tenta cochilar...{/size}{/i}"


    old "\nEnding 6: Just A Cat Nap -- {color=#FF0000}Complete{/color}"
    new "\nFinal 6: Só Um Cochilo -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Resting's good but you should get up and stretch every now and then... and eat... and {b}drink{/b}...{/size}{/i}"
    new "    {i}{size=-3}Descansar é bom, mas você deveria se levantar e alongar de vez em quando... e comer... e {b}beber{/b}...{/size}{/i}"


    old "\nEnding 7: Personal Boundaries -- {color=#FF0000}Complete{/color}"
    new "\nFinal 7: Limites Pessoais -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Knowing how to take \"no\" for an answer is an important life lesson.{/size}{/i}"
    new "    {i}{size=-3}Saber aceitar um \"não\" como resposta é uma lição de vida importante.{/size}{/i}"


    old "\nEnding 8: Fish Out of Water -- {color=#FF0000}Complete{/color}"
    new "\nFinal 8: Peixe Fora D'Água -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You fed the cat some tuna. It liked it okay...{/size}{/i}"
    new "    {i}{size=-3}Você deu um pouco de atum para o gato. Até que ele gostou...{/size}{/i}"


    old "\nEnding 9: Leftovers -- {color=#FF0000}Complete{/color}"
    new "\nFinal 9: Sobras -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You fed the cat some leftover meatloaf. It liked it okay...{/size}{/i}"
    new "    {i}{size=-3}Você deu um pouco de bolo de carne que sobrou para o gato. Até que ele gostou...{/size}{/i}"


    old "\nEnding 10: \"You are what you eat...\" -- {color=#FF0000}Complete{/color}"
    new "\nFinal 10: \"Você é o que você come...\" -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You fed the cat... {b}something{/b}... It really, {b}really{/b} liked it...{/size}{/i}"
    new "    {i}{size=-3}Você deu para o gato... {b}alguma coisa{/b}... Ele gostou muito, {b}muito{/b} mesmo…{/size}{/i}"


    old "\nEnding 11: At The End of Your Rope -- {color=#FF0000}Complete{/color}"
    new "\nFinal 11: Fim Da Linha -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}What cat doesn't love playing with some yarn?{/size}{/i}"
    new "    {i}{size=-3}Que tipo de gato não ama brincar com um novelo de lã?{/size}{/i}"


    old "\nEnding 12: Targeted -- {color=#FF0000}Complete{/color}"
    new "\nFinal 12: Alvo -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}The cat loses its mind over a tiny red dot. Hilarious!{/size}{/i}"
    new "    {i}{size=-3}O gato fica louco por causa de um pontinho vermelho. Hilário!{/size}{/i}"


    old "\nEnding 13: Disappointing Prey -- {color=#FF0000}Complete{/color}"
    new "\nFinal 13: Presa Decepcionante -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You can't run. Apparently you can't hide either.{/size}{/i}"
    new "    {i}{size=-3}Você não pode correr. Aparentemente também não pode se esconder.{/size}{/i}"


    old "\nEnding 14: Bath Hater -- {color=#FF0000}Complete{/color}"
    new "\nFinal 14: Anti-Banho -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Note to self: DO NOT THROW CATS INTO A BATHTUB FULL OF WATER{/size}{/i}"
    new "    {i}{size=-3}Nota pessoal: NÃO JOGAR GATOS EM UMA BANHEIRA CHEIA DE ÁGUA{/size}{/i}"


    old "\nEnding 15: Self-Care Buddies -- {color=#FF0000}Complete{/color}"
    new "\nFinal 15: Amigões Vaidosos -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}After you give the cat the full spa treatment, it tries its best to return the favor.{/size}{/i}"
    new "    {i}{size=-3}Após dar ao gato um tratamento de spa completo, ele dá o seu melhor para retribuir o favor.{/size}{/i}"


    old "\nEnding 16: Poor Screening Arrangements -- {color=#FF0000}Complete{/color}"
    new "\nFinal 16: Péssima Administração -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You go to the old theater and enjoy a film with an interesting stranger.{/size}{/i}"
    new "    {i}{size=-3}Você vai ao velho teatro e assiste um filme com um estranho peculiar.{/size}{/i}"


    old "\nEnding 17: Black Sheep -- {color=#FF0000}Complete{/color}"
    new "\nFinal 17: Ovelha Negra -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You weren't a big fan of the movie at the new cinema. The rest of the audience might have opinions about that.{/size}{/i}"
    new "    {i}{size=-3}Você não foi o maior fã do filme no cinema novo. O resto do público pode ter outra opinião sobre isso.{/size}{/i}"


    old "\nEnding 18: Happy Birthday -- {color=#FF0000}Complete{/color}"
    new "\nFinal 18: Feliz Aniversário -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You have a front-row seat to the touching reunion of multiple siblings at the new cinema.{/size}{/i}"
    new "    {i}{size=-3}Você tem um assento na primeira fila para a emocionante reunião de vários irmãos no cinema novo.{/size}{/i}"


    old "\nEnding 19: You beat the maze :D -- {color=#FF0000}Complete{/color}"
    new "\nFinal 19: Você venceu o labirinto :D -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Whoa, you beat the maze on {b}hard mode?!{/b/} Holy COW! You're a real gamer, ain't ya?{/size}{/i}"
    new "    {i}{size=-3}Uau, você venceu o labirinto no {b}modo difícil?!{/b/} Puxa vida! Você é um verdadeiro gamer, não é mesmo?{/size}{/i}"


    old "    {i}{size=-3}Congratulations! You beat the maze.{/size}{/i}"
    new "    {i}{size=-3}Parabéns! Você venceu o labirinto.{/size}{/i}"


    old "\nEnding 20: You failed the maze :( -- {color=#FF0000}Complete{/color}"
    new "\nFinal 20: Você falhou no labirinto :( -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Better luck next time...{/size}{/i}"
    new "    {i}{size=-3}Mais sorte na próxima...{/size}{/i}"


    old "\nEnding 21: {color=#FF0000}d o g{/color}  person -- {color=#FF0000}Complete{/color}"
    new "\nFinal 21: prefiro  {color=#FF0000}c a c h o r r o s{/color} -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}...You had a pleasant day at the  {color=#FF0000}{b}d o g{/b}{/color}  park.{/size}{/i}"
    new "    {i}{size=-3}...Você teve um dia agradável no parque para  {color=#FF0000}{b}c a c h o r r o s{/b}{/color} .{/size}{/i}"


    old "\nEnding 22: Not Alone -- {color=#FF0000}Complete{/color}"
    new "\nFinal 22: Não Estou Sozinho -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Isn't it nice to feel heard?{/size}{/i}"
    new "    {i}{size=-3}Não é ótimo se sentir ouvido?{/size}{/i}"


    old "\nEnding 23: Feedback loop -- {color=#FF0000}Complete{/color}"
    new "\nFinal 23: Ciclo sem fim -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You try to leave the alley. It doesn't work. You try to leave the alley. It doesn't work. You try to leave the alley. It doesn't{/size}{/i}"
    new "    {i}{size=-3}Você tenta sair do beco. Não dá certo. Você tenta sair do beco. Não dá certo. Você tenta sair do beco. Não dá{/size}{/i}"


    old "\nEnding 24: Fishing for pardon -- {color=#FF0000}Complete{/color}"
    new "\nFinal 24: {i}Pesco{/i} desculpas -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Silly you! Chocolate is bad for cats! {s}{color=#FF0000}But you knew that, didn't you?{/color}{/s}{/size}{/i}"
    new "    {i}{size=-3}Bobalhão! Chocolate faz mal para gatos! {s}{color=#FF0000}Mas você sabia disso, não sabia?{/color}{/s}{/size}{/i}"


    old "\nEnding 25: Seafood Sacrifice -- {color=#FF0000}Complete{/color}"
    new "\nFinal 25: Sacrifício de Frutos do Mar -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You kindly feed some poor, hungry cats a fish. How nice of you!{/size}{/i}"
    new "    {i}{size=-3}Você gentilmente alimentou pobres gatos famintos com peixe. Que bacana da sua parte!{/size}{/i}"


    old "\nEnding 26: A life spared -- {color=#FF0000}Complete{/color}"
    new "\nFinal 26: Uma vida poupada -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You decide not to feed the poor, hungry cat a {s}helpless{/s} mouse. Meanie...{/size}{/i}"
    new "    {i}{size=-3}Você decide não alimentar o pobre gato faminto com um rato {s}indefeso{/s}. Maldade...{/size}{/i}"


    old "\nEnding 27: Well-Fed -- {color=#FF0000}Complete{/color}"
    new "\nFinal 27: Bem Alimentado -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Cats are supposed to eat mice. Huh, wonder what mice are supposed to eat...{/size}{/i}"
    new "    {i}{size=-3}Gatos costumam comer ratos. Hum, fico imaginando o que os ratos comem…{/size}{/i}"


    old "\nEnding 28: Personal care package -- {color=#FF0000}Complete{/color}"
    new "\nFinal 28: Pacote de cuidados pessoais -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You share a nice meal with the cat. A bit high in iron though.{/size}{/i}"
    new "    {i}{size=-3}Você divide uma refeição agradável com o gato. Um pouco alta em ferro, porém.{/size}{/i}"


    old "\nEnding 29: All You Can Eat Blood-fey -- {color=#FF0000}Complete{/color}"
    new "\nFinal 29: Rodízio Sangrento -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You give the cat an endless supply of food. Generous.{/size}{/i}"
    new "    {i}{size=-3}Você dá ao gato um suprimento infinito de comida. Generoso.{/size}{/i}"


    old "\nEnding 30: Photo bomber -- {color=#FF0000}Complete{/color}"
    new "\nFinal 30: Fotogênico -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You really nailed your good side in this one!{/size}{/i}"
    new "    {i}{size=-3}Você arrasou com seu melhor ângulo nessa foto!{/size}{/i}"


    old "\nEnding 31: Headshot -- {color=#FF0000}Complete{/color}"
    new "\nFinal 31: Perdendo a cabeça -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}It's okay, we all get a little camera shy sometimes.{/size}{/i}"
    new "    {i}{size=-3}Tudo bem, todos ficamos tímidos na frente das câmeras de vez em quando.{/size}{/i}"


    old "\nEnding 32: Fear Quitter -- {color=#FF0000}Complete{/color}"
    new "\nFinal 32: Medroso -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}\"When the going gets tough, just give up.\" That's how the saying goes, right?{/size}{/i}"
    new "    {i}{size=-3}\"Quando as coisas ficarem difíceis, é só desistir.\" É como diz o ditado, né?{/size}{/i}"


    old "\nEnding 33: {b}eRRoR{/b} \\ FoUnD -- {color=#FF0000}Complete{/color}"
    new "\nFinal 33: {b}eRRo{/b}  EnCoNtRaDo -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}\"An exception has occurred. Please refrain from going outside of permitted parameters.\"{/size}{/i}"
    new "    {i}{size=-3}\"Ocorreu uma exceção. Por favor, evite sair dos parâmetros permitidos.\"{/size}{/i}"


    old "\nEnding 34: Living doll -- {color=#FF0000}Complete{/color}"
    new "\nFinal 34: Brinquedo vivo -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You end up getting the cat a nice companion!{/size}{/i}"
    new "    {i}{size=-3}Você acabou encontrando uma ótima companhia pro gato!{/size}{/i}"


    old "\nEnding 35: Cotton Headed -- {color=#FF0000}Complete{/color}"
    new "\nFinal 35: Bonequinho -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You're the only friend it needs.{/size}{/i}"
    new "    {i}{size=-3}Você é o único amigo que ele precisa.{/size}{/i}"


    old "\nEnding 36: Eight more left -- {color=#FF0000}Complete{/color}"
    new "\nFinal 36: Só mais oito -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Well that's {b}one{/b} down... Good luck on the rest.{/size}{/i}"
    new "    {i}{size=-3}Bom, {b}uma{/b} já foi... Boa sorte no resto.{/size}{/i}"


    old "\nEnding 37: {b}F o r e v e r{/b} -- {color=#FF0000}Complete{/color}"
    new "\nFinal 37: {b}P a r a  S e m p r e{/b} -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You join the cat. Now you'll always be together. At least... until...{/size}{/i}"
    new "    {i}{size=-3}Você se une ao gato. Agora vocês estarão sempre juntos. Pelo menos... até que...{/size}{/i}"


    old "\nEnding 38: Do NOT Take This Cat Home -- {color=#FF0000}Complete{/color}"
    new "\nFinal 38: NÃO Leve Esse Gato Para Casa -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Bad kitty.{/size}{/i}"
    new "    {i}{size=-3}Gatinho mau.{/size}{/i}"


    old "\nEnding N/A: Another day... -- {color=#FF0000}Complete{/color}"
    new "\nFinal N/A: Outro dia… -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You have a nice day off and go home to spend the rest of the evening with your cute, little kitten.{/size}{/i}"
    new "    {i}{size=-3}Você tem um ótimo dia de folga e vai para casa passar o resto da noite com seu adorável gatinho.{/size}{/i}"


    old "Page {}"
    new "Página {}"


    old "Automatic saves"
    new "Save automático"


    old "Quick saves"
    new "Save rápido"


    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"


    old "empty slot"
    new "slot vazio"


    old "<"
    new "<"


    old "{#auto_page}A"
    new "{#auto_page}A"


    old "{#quick_page}Q"
    new "{#quick_page}R"


    old ">"
    new ">"


    old "Display"
    new "Exibir"


    old "Window"
    new "Janela"


    old "Fullscreen"
    new "Tela cheia"


    old "Rollback Side"
    new "Lado de reversão"


    old "Disable"
    new "Desativar"


    old "Left"
    new "Esquerda"


    old "Right"
    new "Direita"


    old "Unseen Text"
    new "Texto Invisível"


    old "After Choices"
    new "Depois das Escolhas"


    old "Transitions"
    new "Transições"


    old "Language"
    new "Idioma"


    old "Text Speed"
    new "Velocidade do texto"


    old "Auto-Forward Time"
    new "Tempo de avanço automático"


    old "Music Volume"
    new "Volume da música"


    old "Sound Volume"
    new "Volume de som"


    old "Test"
    new "Teste"


    old "Voice Volume"
    new "Volume de voz"


    old "Mute All"
    new "Silenciar tudo"


    old "The dialogue history is empty."
    new "O histórico de diálogo está vazio."


    old "Keyboard"
    new "Teclado"


    old "Mouse"
    new "Mouse"


    old "Gamepad"
    new "Controle"


    old "Enter"
    new "Enter"


    old "Advances dialogue and activates the interface."
    new "Pula o diálogo e ativa a interface."


    old "Space"
    new "Espaço"


    old "Advances dialogue without selecting choices."
    new "Pula o diálogo sem selecionar escolhas."


    old "Arrow Keys"
    new "Setinhas"


    old "Navigate the interface."
    new "Navegar pela interface."

    old "*Delete Save"
    new "*Deletar Save"


    old "Escape"
    new "Esc"


    old "Accesses the game menu."
    new "Acessa o menu do jogo."


    old "Ctrl"
    new "Ctrl"


    old "Skips dialogue while held down."
    new "Pula o diálogo quando pressionado."


    old "Tab"
    new "Tab"


    old "Toggles dialogue skipping."
    new "Alterna a opção de pular diálogos."


    old "Page Up"
    new "Page Up"


    old "Rolls back to earlier dialogue."
    new "Retorna ao diálogo anterior."


    old "Page Down"
    new "Page Down"


    old "Rolls forward to later dialogue."
    new "Pula para o diálogo posterior."


    old "Hides the user interface."
    new "Oculta a interface do usuário."


    old "Takes a screenshot."
    new "Faz uma captura de tela."


    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Alterna a assistência de {a=https://www.renpy.org/l/voicing}voz.{/a}"


    old "Select save file with directional pad and press \"delete\" key."
    new "Selecione salvar arquivo com as setinhas e pressione a tecla \"delete\"."


    old "Left Click"
    new "Botão esquerdo"


    old "Middle Click"
    new "Botão do meio"


    old "Right Click"
    new "Botão direito"


    old "Mouse Wheel Up\nClick Rollback Side"
    new "Roda do mouse para cima\nBotão lateral"


    old "Mouse Wheel Down"
    new "Roda do mouse para baixo"


    old "Hover mouse over save file and press \"delete\" key."
    new "Passe o mouse sobre o arquivo salvo e pressione a tecla \"delete\"."


    old "Right Trigger\nA/Bottom Button"
    new "Gatilho direito\nA/Botão inferior"


    old "Left Trigger\nLeft Shoulder"
    new "Gatilho esquerdo\nSuperior esquerdo"


    old "Right Shoulder"
    new "Superior direito"


    old "D-Pad, Sticks"
    new "Setinhas, Analógico"


    old "Start, Guide"
    new "Start, Guia"


    old "Y/Top Button"
    new "Y/Botão superior"


    old "Calibrate"
    new "Calibrar"


    old "Backgrounds &"
    new "Fundos e Imagens de fundo /"


    old "BG/Art References"
    new "Referências de arte"


    old "Pexels.com\n"
    new "Pexels.com\n"


    old "Sound Effects"
    new "Efeitos sonoros"


    old "Pixabay.com\n"
    new "Pixabay.com\n"


    old "Programmed with"
    new "Programado com"


    old "Ren'Py\n"
    new "Ren'Py\n"

    old "Português-BR Translation"
    new "Tradução Português-BR"

    old "Italian Translation"
    new "Tradução Italiano"

    old "George Ribeiro\n"
    new "George Ribeiro\n"


    old "And you..."
    new "E você..."


    old "Thank you for playing!\n"
    new "Obrigado por jogar!\n"

    old "{size=+40}Do Not Take{/size}"
    new "{size=+40}Não Leve{/size}"

    old "{size=+40}{color=#FF0000}I T {/color} Home{/size}"
    new "{size=+40}{color=#FF0000}I S S O {/color} Para Casa{/size}"

    old "{size=+40}This Cat Home{/size}"
    new "{size=+40}Esse Gato Para Casa{/size}"


    old "Skipping"
    new "Pulando"


    old "Menu"
    new "Menu"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
