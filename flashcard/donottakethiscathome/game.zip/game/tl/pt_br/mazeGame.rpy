


translate pt_br mazeStart_a48e0df5:


    who "Olá, ousado aventureiro~!"


translate pt_br mazeStart_8ca8510a:


    you "!!!" with vpunch


translate pt_br mazeStart_95254b2e:


    "Quem disse is--{w=0.3}{nw}"


translate pt_br mazeStart_5149a957:


    who "Bem-vindo ao Labirinto de Espelhos!"


translate pt_br mazeStart_75539f95:


    who "Gostaria de saber como navegar pelo labirinto?" nointeract


translate pt_br mazeStart_58e7d283:


    who "Tá bom, tá bom! {w}Não precisa ficar irritado..."


translate pt_br mazeStart_1bc7b06c:


    who "Vamos começar então!"


translate pt_br mazeStart_1847df9a:


    who "3... {w}2... {w}1..."


translate pt_br mazeStart_7486d4f4:


    who "{size=+25}{b}JÁ!{/b}{/size}" with vpunch


translate pt_br mazeTutorial_523cd98e:


    "Mais uma vez... {w}Bem-vindo ao Labirinto de Espelhos!"


translate pt_br mazeTutorial_b20052dc:


    "Você está em uma sinuca de bico, mas não se preocupe!"


translate pt_br mazeTutorial_39fb6b3b:


    "Você está em {i}boas{/i} mãos!"


translate pt_br mazeTutorial_9985c05f:


    "Ou melhor..."


translate pt_br mazeTutorial_0c5f5726:


    "...boas {b}patas!{/b}"


translate pt_br mazeTutorial_5fc3dcc7:


    "Está vendo essas fofurinhas aqui?"


translate pt_br mazeTutorial_ff9fc1d5:


    "Elas vão fazer o seu melhor para te guiar pelo labirinto!"


translate pt_br mazeTutorial_9043d317:


    "Não são um doce~?"


translate pt_br mazeTutorial_59691f37:


    "Quando você entrar em uma sala... a luz de emergência vai piscar, te permitindo ver os caminhos à sua frente por um instante."


translate pt_br mazeTutorial_dcc59543:


    "E também o que há além deles."


translate pt_br mazeTutorial_0d753b90:


    "Sempre que vir esses gatinhos gentis..."


translate pt_br mazeTutorial_824e766c:


    "...basta ir onde eles estão e você chegará à próxima sala!"


translate pt_br mazeTutorial_96380374:


    "Mas infelizmente..."


translate pt_br mazeTutorial_74dfdecc:


    "...eles não são os únicos por aqui."


translate pt_br mazeTutorial_93e0e5fe:


    "É {i}altamente{/i} recomendado que você evite seguir {i}qualquer um{/i} dos nossos outros... {w}{b}{i}convidados.{/i}{/b}"


translate pt_br mazeTutorial_22a32adf:


    "Eles podem ser sorrateiros ou distraí-lo... {w}mas são {b}sempre{/b} hostis."


translate pt_br mazeTutorial_106eb8ca:


    "Eles podem ser sorrateiros ou distraí-lo... {w}mas são {b}sempre{/b} hostis."


translate pt_br mazeTutorial_e361bedb:


    "Claro que isso não seria bem um labirinto de espelhos sem espelhos!"


translate pt_br mazeTutorial_7fa0fc05:


    "\"Eles podem te machucar?\""


translate pt_br mazeTutorial_1907bcc0:


    "Não! São apenas espelhos, bobinho!"


translate pt_br mazeTutorial_c4e8c1f8:


    "Eles não podem fazer nadinha~!"


translate pt_br mazeTutorial_d7a493b8:


    "E você também não pode fazer nada com eles."


translate pt_br mazeTutorial_fa242737:


    "São apenas um obstáculo que você não pode atravessar."


translate pt_br mazeTutorial_876495c2:


    "Vá pela {b}esquerda{/b}, {w}pelo {b}meio{/b}, {w}ou pela {b}direita{/b}!"


translate pt_br mazeTutorial_4931dda6:


    "Você que sabe!"


translate pt_br mazeTutorial_23e939ae:


    "No entanto..."


translate pt_br mazeTutorial_15510f8f:


    "Se você encontrar uma sala sem nenhum gatinho prestativo à vista..."


translate pt_br mazeTutorial_d32e4fb5:


    "...e todos os caminhos levarem a um espelho ou... {w}{color=#FF0000}{b}alguma outra coisa...{/b}{/color}"


translate pt_br mazeTutorial_a78f88cc:


    "É recomendável que você {b}fique parado{/b}... {w}e talvez isso se resolva por conta própria!"


translate pt_br mazeTutorial_4dfacc44:


    "Agora, para suas ferramentas de navegação!"


translate pt_br mazeTutorial_194e688a:


    "Essa {b}lanterna{/b} que você encontrou não tem muita carga sobrando..."


translate pt_br mazeTutorial_0ba8aaf5:


    "Ela só permitirá que você dê uma {b}rápida{/b} olhada nos arredores cerca de cinco vezes."


translate pt_br mazeTutorial_f28a1cba:


    "Então, tente não gastar tudo de uma vez!"


translate pt_br mazeTutorial_7938b891:


    "Você pode acompanhar seu progresso pelas {b}salas{/b} em cima à esquerda..."


translate pt_br mazeTutorial_519aa538:


    "...e suas {b}vidas{/b} à direita!"


translate pt_br mazeTutorial_238bd2a4:


    "Você tem três vidas, então fique atento para evitar os convidados pouco amigáveis à espreita."


translate pt_br mazeTutorial_69a6fef7:


    "\"Por que só {b}três{/b} vidas\", você pergunta?"


translate pt_br mazeTutorial_f56b6035:


    "Porque você é mole e flácido!"


translate pt_br mazeTutorial_d3a59e2c:


    "Não precisa de muito para te danificar além do reparo..."


translate pt_br mazeTutorial_a20cefa7:


    "..."


translate pt_br mazeTutorial_53b3ffb5:


    "Além disso..."


translate pt_br mazeTutorial_781b2cf3:


    "...você é humano. E humanos costumam ter apenas {b}uma{/b} vida, sim?"


translate pt_br mazeTutorial_91cf105d:


    "E ainda assim, aqui, você tem três!"


translate pt_br mazeTutorial_8dabefc6:


    ".."


translate pt_br mazeTutorial_a20cefa7_1:


    "..."


translate pt_br mazeTutorial_00557775:


    "Você não acha... {w}que deveria demonstrar... {w}um pouco mais de..."


translate pt_br mazeTutorial_40553271:


    "{b}...g {w=0.2}r {w=0.2}a {w=0.2}t {w=0.2}i {w=0.2}d {w=0.2}ã {w=0.2}o {w=0.2}?{/b}"


translate pt_br mazeTutorial_8dabefc6_1:


    ".."


translate pt_br mazeTutorial_a20cefa7_2:


    "..."


translate pt_br mazeTutorial_e4ba3fc6:


    "E esse é o fim do seu tutorial!!"


translate pt_br mazeTutorial_c4fbff42:


    "Espero que tenha sido útil!"


translate pt_br mazeTutorial_bf623419:


    "Está pronto para jogar?"


translate pt_br mazeSettings_02557781:


    who "O que você gostaria de saber?~" nointeract


translate pt_br mazeSettings_1ff6beab:


    "Ok!"


translate pt_br mazeSettings_a05e1dc4:


    "3... {w}2... {w}1..."


translate pt_br mazeSettings_e5f078db:


    "{size=+25}{b}JÁ!{/b}{/size}" with vpunch


translate pt_br mazeSettings_909322d8:


    who "Seu pedido de desistência foi negado!~"


translate pt_br mazeSettings_74a88101:


    you "Me deixa sair daqui!" with vpunch


translate pt_br mazeSettings_616c59ce:


    who "Não é permitido gritar no labirinto!~"


translate pt_br mazeSettings_0862e669:


    who "Certamente!"


translate pt_br mazeSettings_7ee6eac8:


    who "Flash {b}LIGADO!{/b}"


translate pt_br mazeSettings_0862e669_1:


    who "Certamente!"


translate pt_br mazeSettings_4388c99c:


    who "Flash {b}DESLIGADO!{/b}"


translate pt_br mazeSettings_b56089a4:


    who "Ah, tudo bem..."


translate pt_br mazeSettings_dca85608:


    who "Sua lanterna te dará {b}sete{/b} segundas chances agora..."


translate pt_br mazeSettings_412f0fff:


    who "{i}E{/i} a luz vai durar mais..."


translate pt_br mazeSettings_1d4dacaf:


    who "Melhor assim~?"


translate pt_br mazeSettings_6f50b679:


    who "..."


translate pt_br mazeSettings_6647ecc8:


    who "É {b}mesmo?{/b}"


translate pt_br mazeSettings_8dabefc6:


    ".."


translate pt_br mazeSettings_a20cefa7:


    "..."


translate pt_br mazeSettings_24c97862:


    who "Vejamos... {w}pronto!"


translate pt_br mazeSettings_95022402:


    you "Pera, o que você fez?"


translate pt_br mazeSettings_6f50b679_1:


    who "..."


translate pt_br mazeSettings_279d8c4f:


    who "Você vai ver~"


translate pt_br mazeSettings_3ab9acb5:


    who "Deixa comigo!"


translate pt_br mazeSettings_6bf745f8:


    who "Como desejar!"


translate pt_br maze1Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze1Menu_76061708_1:


    you "AI! Por aí não!"


translate pt_br maze1Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze1Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze1Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze2Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze2Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze2Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze2Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze2Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze2Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze3Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze3Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze3Menu_76061708_1:


    you "AI! Por aí não!"


translate pt_br maze3Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze3Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze4Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze4Menu_76061708_1:


    you "AI! Por aí não!"


translate pt_br maze4Menu_76061708_2:


    you "AI! Por aí não!"


translate pt_br maze4Menu_dc06f641:


    you "Essa sala parece estranha..."


translate pt_br maze4Menu_1ad23f1f:


    you "Melhor esperar..."


translate pt_br maze4Menu_dae0ec55:


    you "..."


translate pt_br maze4Menu_e4612ec1:


    you "..!"


translate pt_br maze4Menu_ceb48012:


    you "Acho que alguma coisa mudou..."


translate pt_br maze4Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze5Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze5Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze5Menu_76061708_1:


    you "AI! Por aí não!"


translate pt_br maze5Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze5Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze6Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze6Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze6Menu_76061708_1:


    you "AI! Por aí não!"


translate pt_br maze6Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze6Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze7Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze7Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze7Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze7Menu_76061708_1:


    you "AI! Por aí não!"


translate pt_br maze7Menu_dc06f641:


    you "Essa sala parece estranha..."


translate pt_br maze7Menu_1ad23f1f:


    you "Melhor esperar..."


translate pt_br maze7Menu_dae0ec55:


    you "..."


translate pt_br maze7Menu_e4612ec1:


    you "..!"


translate pt_br maze7Menu_ceb48012:


    you "Acho que alguma coisa mudou..."


translate pt_br maze7Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze8Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze8Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze8Menu_76061708_1:


    you "AI! Por aí não!"


translate pt_br maze8Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze8Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze9Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze9Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze9Menu_ef682bac_1:


    "*CLANG!*"


translate pt_br maze9Menu_9af1e7a3_1:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze9Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze9Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze9Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze10Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze10Menu_76061708_1:


    you "AI! Por aí não!"


translate pt_br maze10Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze10Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze10Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze11Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze11Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze11Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze11Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze11Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze11Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze12Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze12Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze12Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze12Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze12Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze12Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze13Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze13Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze13Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze13Menu_ef682bac_1:


    "*CLANG!*"


translate pt_br maze13Menu_9af1e7a3_1:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze13Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze13Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze14Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze14Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze14Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze14Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze14Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze14Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze15Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze15Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze15Menu_ef682bac_1:


    "*CLANG!*"


translate pt_br maze15Menu_9af1e7a3_1:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze15Menu_ef682bac_2:


    "*CLANG!*"


translate pt_br maze15Menu_9af1e7a3_2:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze15Menu_dc06f641:


    you "Essa sala parece estranha..."


translate pt_br maze15Menu_1ad23f1f:


    you "Melhor esperar..."


translate pt_br maze15Menu_dae0ec55:


    you "..."


translate pt_br maze15Menu_e4612ec1:


    you "..!"


translate pt_br maze15Menu_ceb48012:


    you "Acho que alguma coisa mudou..."


translate pt_br maze15Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze16Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze16Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze16Menu_76061708_1:


    you "AI! Por aí não!"


translate pt_br maze16Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze16Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze17Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze17Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze17Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze17Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze17Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze17Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze18Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze18Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze18Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze18Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze18Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze18Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze19Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze19Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze19Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze19Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze19Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze19Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze20Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze20Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze20Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze20Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze20Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze20Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze21Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze21Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze21Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze21Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze21Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze21Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze22Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze22Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze22Menu_76061708_1:


    you "AI! Por aí não!"


translate pt_br maze22Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze22Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze23Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze23Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze23Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze23Menu_ef682bac_1:


    "*CLANG!*"


translate pt_br maze23Menu_9af1e7a3_1:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze23Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze23Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze24Menu_a9f7373b:


    you "Tá, próxima sala..."


translate pt_br maze24Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze24Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze24Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze24Menu_5a213e14:


    you "Tenho certeza de que essa sala tem uma saída..."


translate pt_br maze24Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br maze25Menu_76061708:


    you "AI! Por aí não!"


translate pt_br maze25Menu_76061708_1:


    you "AI! Por aí não!"


translate pt_br maze25Menu_ef682bac:


    "*CLANG!*"


translate pt_br maze25Menu_9af1e7a3:


    you "Um espelho? Não posso ir por aqui!"


translate pt_br maze25Menu_dc06f641:


    you "Essa sala parece estranha..."


translate pt_br maze25Menu_1ad23f1f:


    you "Melhor esperar..."


translate pt_br maze25Menu_dae0ec55:


    you "..."


translate pt_br maze25Menu_e4612ec1:


    you "..!"


translate pt_br maze25Menu_ceb48012:


    you "Acho que alguma coisa mudou..."


translate pt_br maze25Menu_c3c3f39d:


    "Droga... Acabou a lanterna..."


translate pt_br mazeWin_8dabefc6:


    ".."


translate pt_br mazeWin_a20cefa7:


    "..."


translate pt_br mazeWin_a513413e:


    "..!"


translate pt_br mazeWin_0c52a734:


    "Você vê! É a saída!"


translate pt_br mazeWin_bb7d045b:


    "Você corre até ela, mas enquanto faz isso..."


translate pt_br mazeWin_2fa70f34:


    "...o cenário... {b}muda{/b}."


translate pt_br mazeWin_ca8b0a70:


    "A princípio, só um pouco..."


translate pt_br mazeWin_a20cefa7_1:


    "..."


translate pt_br mazeWin_ee3778a5:


    "...mas você está correndo rápido demais para evitar bater no vidro."


translate pt_br mazeWin_a20cefa7_2:


    "..."


translate pt_br mazeWin_a513413e_1:


    "..!"


translate pt_br mazeWin_a5cb5de7:


    "Só que..."


translate pt_br mazeWin_1bd92e64:


    "...você não vai exatamente {i}contra{/i} o vidro."


translate pt_br mazeWin_3c2eb60a:


    "Também não chega a {i}bater{/i} nele também."


translate pt_br mazeWin_77c290a9:


    "Você simplesmente... {w}{b}passa{/b} por ele."


translate pt_br mazeWin_c7791603:


    "E do outro lado, você vê um vazio branco infinito e..."


translate pt_br mazeWin_40d9ca73:


    "..?"


translate pt_br mazeWin_bb6dce2b:


    "...você mesmo?"


translate pt_br mazeWin_6f2f53b2:


    "Dezenas de você."


translate pt_br mazeWin_f99b0994:


    "{i}Centenas{/i} de você vagando por aí..."


translate pt_br mazeWin_d5c80074:


    "Sem propósito..."


translate pt_br mazeWin_d4aabc08:


    "Sem um rosto..."


translate pt_br mazeWin_a20cefa7_3:


    "..."


translate pt_br mazeWin_2bfa9431:


    "E vazios..."


translate pt_br mazeWin_8a444783:


    "Tão vazios e apáticos que nem mesmo reconhecem sua presença."


translate pt_br mazeWin_28b3ac41:


    you "!!"


translate pt_br mazeWin_b9a65d59:


    "Você tenta voltar..."


translate pt_br mazeWin_a20cefa7_4:


    "..."


translate pt_br mazeWin_8df49ab6:


    "...mas o vidro não cede."


translate pt_br mazeWin_e6523116:


    "Atrás do vidro..."


translate pt_br mazeWin_c3b5585c:


    "...um gato preto familiar surge e olha para você."


translate pt_br mazeWin_6e960518:


    "Você pensa que ele miou para você..."


translate pt_br mazeWin_a20cefa7_5:


    "..."


translate pt_br mazeWin_b1b87e48:


    "...mas você não consegue ouvir o som."


translate pt_br mazeWin_7f0ac95c:


    cat "..."


translate pt_br mazeWin_38c1149b:


    "Ele inclina sua cabeça..."


translate pt_br mazeWin_e391259c:


    "...e vai embora."


translate pt_br mazeWin_7d5b08ef:


    "O vidro escurece..."


translate pt_br mazeWin_ed2c108e:


    "Então, você assiste impotente enquanto ele desaparece completamente..."


translate pt_br mazeWin_8dabefc6_1:


    ".."


translate pt_br mazeWin_a20cefa7_6:


    "..."


translate pt_br mazeWin_15e0cbf3:


    "Você está preso..."


translate pt_br mazeWin_5bbdfcf4:


    "...apenas consigo mesmo como companhia."


translate pt_br mazeWin_a20cefa7_7:


    "..."


translate pt_br mazeWin_cbc07846:


    "Final 19: Você venceu o labirinto :D"


translate pt_br mazeLose_8dabefc6:


    ".."


translate pt_br mazeLose_a20cefa7:


    "..."


translate pt_br mazeLose_f8342e66:


    "De repente..."


translate pt_br mazeLose_054e707a:


    "As luzes acendem..."


translate pt_br mazeLose_539b0333:


    "Seus olhos ardem com o clarão repentino..."


translate pt_br mazeLose_da4b1c21:


    "À medida que sua visão se ajusta, você vê que está completamente cercado por espelhos..."


translate pt_br mazeLose_71354367:


    "Os reflexos, um mais grotesco que o outro..."


translate pt_br mazeLose_f0156f30:


    "...não se parecem nada com você."


translate pt_br mazeLose_a20cefa7_1:


    "..."


translate pt_br mazeLose_b19017ca:


    "Mas eles {i}parecem{/i}..."


translate pt_br mazeLose_a20cefa7_2:


    "..."


translate pt_br mazeLose_515f36c9:


    "...{b}f a m i n t o s.{/b}"


translate pt_br mazeLose_28b3ac41:


    you "!!"


translate pt_br mazeLose_3106400c:


    "Você dá um passo para trás. {w}Você não sabe para onde ir. {w}Havia mesmo uma saída, pra início de conversa?"


translate pt_br mazeLose_39d54166:


    "Você esbarra em um espelho..."


translate pt_br mazeLose_f38c3a4c:


    "...e sente uma mão segurando firme seu ombro."


translate pt_br mazeLose_c84580e0:


    "{size=+25}{b}CHOMP!!{/b}{/size}"


translate pt_br mazeLose_bbe064f5:


    you "{b}GAHH!!{/b}" with vpunch


translate pt_br mazeLose_3360de48:


    "Há uma dor aguda em seu outro ombro."


translate pt_br mazeLose_aa4f8089:


    "Você se solta, olha para trás e vê alguma... {i}{b}coisa{/b}{/i} saindo do espelho."


translate pt_br mazeLose_a1e48554:


    "Seu rosto não tem feições... {w}Exceto por uma grande boca escancarada..."


translate pt_br mazeLose_5244ba66:


    "...suja com seu sangue."


translate pt_br mazeLose_44a8fb9b:


    "Olhando ao redor em pânico, você acha que os espelhos parecem mais próximos do que antes."


translate pt_br mazeLose_a01def9f:


    "O caminho por onde você entrou sumiu."


translate pt_br mazeLose_7f1405b1:


    "Você está cercado... e cada vez que pisca..."


translate pt_br mazeLose_986a69fb:


    "...pode {i}jurar{/i} que os espelhos chegam mais perto..."


translate pt_br mazeLose_57fba23d:


    "E mais perto..."


translate pt_br mazeLose_0650d5b6:


    "...e mais perto."


translate pt_br mazeLose_7865cabc:


    "Seus reflexos horripilantes parecem mais famintos..."


translate pt_br mazeLose_10364f30:


    "...e mais famintos..."


translate pt_br mazeLose_becd9a7d:


    "...e mais famin--{w=0.3}{nw}"


translate pt_br mazeLose_8dabefc6_1:


    ".."


translate pt_br mazeLose_a20cefa7_3:


    "..."


translate pt_br mazeLose_e1f94697:


    "Final 20: Você falhou no labirinto :("

translate pt_br strings:


    old "Yes, I need help!"
    new "Sim, preciso de ajuda!"


    old "No! I don't even know you!"
    new "Não! Eu nem te conheço!"


    old "No, but I have some questions..."
    new "Não, mas tenho algumas perguntas..."


    old "{b}{size=+5}I'm ready to play!{/size}{/b}"
    new "{b}{size=+5}Tô pronto pra jogar!{/size}{/b}"


    old "Can you let me go?"
    new "Pode me deixar ir?"


    old "Can you turn {b}ON{/b} the flash, please?"
    new "Pode {b}LIGAR{/b} o flash, por favor?"


    old "Can you turn {b}OFF{/b} the flash, please?"
    new "Pode {b}DESLIGAR{/b} o flash, por favor?"


    old "This game is too hard..."
    new "Esse jogo é muito difícil..."


    old "Psh! This game's {i}{b}way{/b}{/i} too easy!"
    new "Pff! Esse jogo é fácil {i}{b}demais{/b}{/i}!"


    old "Reset Settings"
    new "Redefinir Configurações"


    old "Can you tell me about the maze again?"
    new "Pode me falar sobre o labirinto de novo?"


    old "LEFT"
    new "ESQUERDA"


    old "CENTER"
    new "MEIO"


    old "RIGHT"
    new "DIREITA"


    old "STAY"
    new "FICAR"


    old "Flashlight ([flashlight]/[maxLight])"
    new "Lanterna ([flashlight]/[maxLight])"

    old "LIVES: [mazeLives]/[maxLives]"
    new "VIDAS: [mazeLives]/[maxLives]"

    old "Room [roomCounter]/25"
    new "Salas [roomCounter]/25"

    old "[mazeClock]"
    new "[mazeClock]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
