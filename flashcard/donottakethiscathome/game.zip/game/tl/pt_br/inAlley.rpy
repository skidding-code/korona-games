


translate pt_br inAlley_start_a20cefa7:


    "..."


translate pt_br inAlley_start_28a9f6c1:


    "{b}{size=-10}Você não está pronto.{/size}{/b}"


translate pt_br inAlley_start_e3e320e6:


    "Só mais uma coisa..."


translate pt_br inAlley_start_42b896f8:


    "Então..."


translate pt_br inAlley_start_71219ec6:


    "O que você deveria fazer com um gato que tem sido {i}muito...{/i}"


translate pt_br inAlley_start_8794b742:


    "{i}muito...{/i}"


translate pt_br inAlley_start_ba6b8484:


    "{i}{size=+10}muito...{/size}{/i}"


translate pt_br inAlley_start_7cf748e5:


    "{color=#FF0000}{b}l e v a d o . . ?{/b}{/color}"


translate pt_br leaveCat_dae0ec55:


    you "..."


translate pt_br leaveCat_569a4a54:


    "Você não acha uma boa ideia dar esperanças para o gato de que alguém vai cuidar dele se você não está disposto a se comprometer."


translate pt_br leaveCat_0035fbdc:


    "E se ele se apegar, e de alguma forma, te seguir até sua casa?"


translate pt_br leaveCat_5330941f:


    "{size=-10}Aí sim, você nunca conseguiria se livrar dele.{/size}{w=0.4}{nw}"


translate pt_br leaveCat_a85b90f1:


    you "Foi mal... Te vejo por aí, eu acho."


translate pt_br leaveCat_21aa06c6:


    "Você se levanta, com o gato observando cada movimento seu."


translate pt_br leaveCat_bcd29f0b:


    "Você chega à metade do caminho pra sair do beco quando o gato mia quase como se quisesse te fazer sentir pena."


translate pt_br leaveCat_708ef71a:


    cat "Miaau... Miaau... Miaaaau..."


translate pt_br leaveCat_dae0ec55_1:


    you "..."


translate pt_br leaveCat_9590def2:


    "Não. De jeito nenhum. Você precisa cortar isso pela raiz e seguir com o seu dia."


translate pt_br leaveCat_c45c05a0:


    "É o melhor para vocês dois."


translate pt_br leaveCat_57513084:


    "Você sai do beco e segue seu caminho."


translate pt_br leaveCat_b844458f:


    you "Espera, o que eu estava fazendo..?"


translate pt_br leaveCat_8b6a5b93:


    "Na correria de lidar com seu problema peludo..."


translate pt_br leaveCat_5dec36ba:


    "...Você havia se esquecido de que ainda não tinha decidido o que faria no seu dia de folga."


translate pt_br leaveCat_cda3a886:


    "Owwwnt~"


translate pt_br leaveCat_f75bff4c:


    "Como você poderia deixar essa {i}coisinha{/i} para trás?"


translate pt_br leaveCat_f3abd822:


    "Que tipo de {b}monstro{/b} você seria se deixasse?"


translate pt_br goToMovies_74698f4f:


    "Já faz um tempo que lançou um filme que parecesse interessante o suficiente para você ir ao cinema..."


translate pt_br goToMovies_16041c5e:


    "...mas um desses filmes está passando no cinema antigo."


translate pt_br goToMovies_08ebae1d:


    "O filme era nichado demais para ser exibido no cinema novo que abriu bem do outro lado da rua."


translate pt_br goToMovies_b01bac60:


    "Mas tudo bem. Você não é exatamente fã de multidões."


translate pt_br goToMovies_6430cdc2:


    "E nada estraga mais a experiência de assistir a um filme novo para você do que um público barulhento."


translate pt_br moviesMenu_927147c9:


    "Você não sabe porque...{w} mas você não se sente muito bem com a idea de estar sozinho agora."


translate pt_br oldTheater_1be5a36c:


    "Você compra ansiosamente seu ingresso com o gentil senhor na bilheteira e entra."


translate pt_br oldTheater_db3599c5:


    "Não tem nenhum sinal de vida, e a decoração parece que não mudou desde os anos oitenta..."


translate pt_br oldTheater_77b6ae49:


    "...talvez até setenta."


translate pt_br oldTheater_599278f5:


    "Mas é exatamente o que você esperava."


translate pt_br oldTheater_7ad62eb8:


    "Você pensa em comprar um pouco de pipoca..."


translate pt_br oldTheater_025c7a51:


    "...mas não consegue não se preocupar de que tudo no quiosque possa estar vencido."


translate pt_br oldTheater_52bad82a:


    "Você continua e percorre os corredores, finalmente encontrando a sala indicada no seu bilhete."


translate pt_br oldTheater_2bf14d35:


    "Como esperado, a sala que seu filme está sendo exibido está completamente vazia."


translate pt_br oldTheater_5a0a5807:


    "Perfeito."


translate pt_br oldTheater_d0351c7d:


    "Você escolhe um lugar bem no meio, contando os assentos e levando em consideração até o espaço das escadas."


translate pt_br oldTheater_408d2f47:


    "Enquanto você se acomoda, as luzes fracas se apagam, deixando a sala completamente escura por alguns segundos..."


translate pt_br oldTheater_8dabefc6:


    ".."


translate pt_br oldTheater_a20cefa7:


    "..."


translate pt_br oldTheater_a4fb4a3e:


    "...antes que a tela se acenda."


translate pt_br oldTheater_dd520a72:


    "Nenhum comercial ou trailer aparece – o filme simplesmente começa."


translate pt_br oldTheater_a5c79df4:


    "Contente, você se deixa envolver pela cena inicial."


translate pt_br oldTheater_1b0c5dc9:


    "Mas, justo quando você começa a se envolver pela trama..."


translate pt_br oldTheater_b6693490:


    "...as portas se abrem atrás de você, iluminando momentaneamente a sala e estragando o clima."


translate pt_br oldTheater_e56dc443:


    "Você segura o suspiro de frustração."


translate pt_br oldTheater_c6d5d2d2:


    "É um estabelecimento público, afinal."


translate pt_br oldTheater_4fa1403a:


    "O lugar não pode se manter de pé se {i}você{/i} for o único cliente."


translate pt_br oldTheater_93c887ef:


    "Você tenta se concentrar novamente no filme, mas percebe a nova presença se movendo lentamente pelo cinema..."


translate pt_br oldTheater_b4c5e205:


    "...antes de se dirigir na sua direção.."


translate pt_br oldTheater_8dabefc6_1:


    ".."


translate pt_br oldTheater_a20cefa7_1:


    "..."


translate pt_br oldTheater_4d11e7f3:


    you "..?! O qu-"


translate pt_br oldTheater_b0959e10:


    "Você fica boquiaberto em descrença total enquanto o estranho caminha pelo corredor e se senta {b}BEM{/b} na sua frente."


translate pt_br oldTheater_dae0ec55:


    you "..."


translate pt_br oldTheater_8ff13d0b:


    "Não há ninguém aqui e muitos lugares para se sentar."


translate pt_br oldTheater_67b56825:


    "O estranho também é..."


translate pt_br oldTheater_2264fca6:


    "...{i}excepcionalmente{/i} alto."


translate pt_br oldTheater_d21b2508:


    "Mesmo com a disposição das cadeiras no formato de estádio, bem inclinadas, ele bloqueia completamente sua visão."


translate pt_br oldTheater_452114d6:


    "Isso é estranho demais."


translate pt_br oldTheater_f9c856d9:


    "Se sentindo desconfortável, você decide sair do cinema. Ainda sobrou tempo do seu dia pra fazer outra coisa."


translate pt_br oldTheater_16617c12:


    "E agora?"


translate pt_br moveTheater1_40036af7:


    "Você não quer arriscar escalar mais ainda a situação. Isso tudo já tá te deixando desconfortável."


translate pt_br moveTheater1_30d6713a:


    "Por que ele escolheria sentar bem na sua frente? Certamente ele sabe que você não pode ver através dele?"


translate pt_br moveTheater1_badbf0f2:


    "Balançando a cabeça com um resmungo passivo-agressivo na direção do estranho... você, relutantemente, escolhe outro assento, menos perfeito..."


translate pt_br moveTheater1_bf0874e3:


    "Mas..."


translate pt_br moveTheater1_cc8c4a97:


    "Enquanto você se acomoda..."


translate pt_br moveTheater1_62c67dd0:


    "...você vê o estranho se levantar..."


translate pt_br moveTheater1_89af2519:


    "...só para, mais uma vez, sentar-se {i}exatamente{/i} na sua frente."


translate pt_br moveTheater1_56ebb028:


    you "!!!"


translate pt_br moveTheater1_51a47b38:


    "Você olha em volta, um tanto desamparado, esperando que alguém concorde silenciosamente com você sobre o quão estranho é tudo isso."


translate pt_br moveTheater1_e5a8d006:


    "Ou para, pelo menos, lhe informar que foi tudo uma pegadinha."


translate pt_br moveTheater1_4bc7f00e:


    "Mas não há mais ninguém aqui com você. É como você sempre preferiu, mas..."


translate pt_br moveTheater1_a20cefa7:


    "..."


translate pt_br moveTheater1_b0de34e0:


    "Você não consegue evitar de pensar que seria legal ter mais {i}alguém{/i} aqui, se isso significar não estar sozinho com esse idiota bizarro..."


translate pt_br moveTheater1_452114d6:


    "Isso é estranho demais."


translate pt_br moveTheater1_f9c856d9:


    "Se sentindo desconfortável, você decide sair do cinema. Ainda sobrou tempo do seu dia pra fazer outra coisa."


translate pt_br moveTheater1_16617c12:


    "E agora?"


translate pt_br moveTheater2_287d233d:


    "Você muda de novo..."


translate pt_br moveTheater2_cc9a5909:


    "!!!"


translate pt_br moveTheater2_198c5f02:


    "...e {i}de novo,{/i} ele senta bem na sua frente."


translate pt_br moveTheater2_1cea2bd2:


    "Você se irrita, incomodado e um tanto humilhado."


translate pt_br moveTheater2_663c60ce:


    "Será que ele está se divertindo com isso ou algo assim?"


translate pt_br moveTheater2_22dd2b12:


    "Você já perdeu tanto tempo com esse idiota que nem sabe mais o que está acontecendo no filme."


translate pt_br moveTheater2_dae0ec55:


    you "..."


translate pt_br moveTheater2_452114d6:


    "Isso é estranho demais."


translate pt_br moveTheater2_f9c856d9:


    "Se sentindo desconfortável, você decide sair do cinema. Ainda sobrou tempo do seu dia pra fazer outra coisa."


translate pt_br moveTheater2_16617c12:


    "E agora?"


translate pt_br confrontTheater_d20e8806:


    "Você odeia confrontos. Só de pensar, você já pode sentir a palma das suas mãos começando a suar."


translate pt_br confrontTheater_a9c192bd:


    "Sua garganta fechando e seu corpo começando a tremer."


translate pt_br confrontTheater_2938ac47:


    "Você sempre foi mais um ‘fujento’ do que um ‘briguento’..."


translate pt_br confrontTheater_ba742fb9:


    "...mas você pagou pelo ingresso. {w}Você quer ver esse filme há tempos..."


translate pt_br confrontTheater_4133c851:


    "...e agora esse total estranho arruinou completamente a sua experiência."


translate pt_br confrontTheater_31224555:


    "Você está sozinho nesse cinema. Não há ninguém para te ajudar caso as coisas deem errado..."


translate pt_br confrontTheater_56f5734b:


    "Mas você está com tanta raiva que ignora os sinais do seu corpo, que implora para que se distancie o máximo possivel desse estranho."


translate pt_br confrontTheater_4d121ecf:


    "Você se levanta. Mesmo de pé e em uma parte mais alta do cinema, o estranho ainda é {i}pelo menos{/i} uma cabeça mais alto que você."


translate pt_br confrontTheater_7ecc8825:


    "O filme continua passando no fundo, mas você sente como se um silêncio pesado caísse imediatamente sobre o cinema com o seu movimento..."


translate pt_br confrontTheater_61ee470d:


    "...como se você pudesse sentir o estranho antecipando o que você planeja fazer a seguir."


translate pt_br confrontTheater_36eaf556:


    "Você endireita os ombros e engrossa um pouco a voz."


translate pt_br confrontTheater_635cbfd8:


    you "{size=+10}{b}EI!{/b}{/size}" with hpunch


translate pt_br confrontTheater_c6fd0e1b:


    "Suas palavras saem mais duras do que você pretendia, como um latido repentino e agressivo..."


translate pt_br confrontTheater_77452538:


    "...mas você lembra que ele merece mesmo."


translate pt_br confrontTheater_72a25472:


    you "Você tá sendo um otário, sabia? O que você quer, hein? Tá querendo me deixar puto?"


translate pt_br confrontTheater_6f50b679:


    who "..."


translate pt_br confrontTheater_dae0ec55:


    you "..."


translate pt_br confrontTheater_8dabefc6:


    ".."


translate pt_br confrontTheater_a20cefa7:


    "..."


translate pt_br confrontTheater_f6344799:


    "O silêncio que se segue às suas palavras é {b}ensurdecedor{/b}..."


translate pt_br confrontTheater_93861255:


    "...tanto que você olha para a tela e percebe que o filme foi..."


translate pt_br confrontTheater_fee70e3c:


    "...pausado?"


translate pt_br confrontTheater_90b68c87:


    you "..?"


translate pt_br confrontTheater_28b3ac41:


    you "!!"


translate pt_br confrontTheater_169210d3:


    "Sua atenção é imediatamente puxada de volta para o estranho à sua frente enquanto ele se mexe ligeiramente."


translate pt_br confrontTheater_dbc8ab64:


    "Como um animalzinho tentando desesperadamente antecipar os movimentos de um predador... {w}{b}você não move um centímetro.{/b}"


translate pt_br confrontTheater_74dfd95b:


    "Você não desvia o olhar. {w}Você não ousa sequer {i}piscar.{/i}"


translate pt_br confrontTheater_0dd1ea0a:


    "Pelo contrário, seus olhos se arregalam à medida que a cabeça da pessoa gira..."


translate pt_br confrontTheater_5654bfb2:


    "Então gira mais um pouco..."


translate pt_br confrontTheater_a20cefa7_1:


    "..."


translate pt_br confrontTheater_b88269b6:


    "E gira mais... {i}além{/i} do que poderia ser possível... com os ossos do pescoço {i}estalando{/i}..."


translate pt_br confrontTheater_61ab54e3:


    "...para te encarar diretamente."


translate pt_br confrontTheater_17cf9e73:


    you "...ah..."


translate pt_br confrontTheater_c6ce8445:


    "Você não consegue se mexer."


translate pt_br confrontTheater_d758f471:


    "Olhos brilhantes e arregalados acima de uma boca sorridente ainda mais larga, olhando para você."


translate pt_br confrontTheater_6b167f7f:


    "O estranho abre sua boca, e o que sai dela..."


translate pt_br confrontTheater_2177217c:


    "...é algo incompreensível."


translate pt_br confrontTheater_742b5efd:


    who "Nyaaaa-a-a-a-a-a-ahh~{w=2.75}{nw}"


translate pt_br confrontTheater_24840d69:


    you "?!{w=0.3}{nw}"


translate pt_br confrontTheater_65a6a073:


    who "Nyaaaa-a-a-a-a-a-ahh~{w=2.5}{nw}"


translate pt_br confrontTheater_d46cc080:


    who "Nyaaaa{w=0.75}-a{w=0.75}-a{w=0.75}-a{w=0.75}-aaahhh~"


translate pt_br confrontTheater_8ca8510a:


    you "!!!" with vpunch


translate pt_br confrontTheater_8d5e95ad:


    "A voz é infinitamente profunda e range como uma porta pesada, ameaçadora e estranhamente melódica..."


translate pt_br confrontTheater_98a755c6:


    "Sedutora..."


translate pt_br confrontTheater_2ff3b202:


    "Mas que também te tira do seu transe aterrorizado e, antes que perceba, você já está saindo da porta."


translate pt_br confrontTheater_0051e82f:


    "Você corre pelos corredores do cinema vazio, procurando a saída."


translate pt_br confrontTheater_3a3a66e0:


    "Você sente algo nas suas costas, te vigiando..."


translate pt_br confrontTheater_10fd18e4:


    "{size=-5}...mas você está com medo demais para olhar.{/size}"


translate pt_br confrontTheater_a376e0ce:


    "Com a saída agora à vista, você corre em direção às portas e as arromba."


translate pt_br confrontTheater_c6a8f088:


    "Você olha ao redor freneticamente e avista o cinema lotado do outro lado da rua."


translate pt_br confrontTheater_1b77491a:


    "Pessoas! É isso que você precisa. Segurança na multidão e tudo mais..."


translate pt_br confrontTheater_e6eacea8:


    "Sem pensar, você corre para a rua, quando um arrepio percorre sua espinha de cima a baixo, fazendo você olhar para trás."


translate pt_br lookBehindYou_movie_d5f8a487:


    "Se recusando a sequer arriscar uma olhada por cima do ombro, você atravessa a rua correndo em direção ao cinema novo."


translate pt_br lookBehindYou_movie_a724453f:


    "Você não percebeu que estava se sentindo envolto por uma espécie de pressão aterrorizante..."


translate pt_br lookBehindYou_movie_a20cefa7:


    "..."


translate pt_br lookBehindYou_movie_1812debc:


    "...até que ela desaparece de repente. Deixando você um tanto abalado."


translate pt_br lookBehindYou_movie_4036cbd4:


    "Mas pelo menos ficou mais fácil de respirar."


translate pt_br lookBehindYou_movie_e1da1ba0:


    "{size=-7}Você pensa que é melhor ignorar {b}tudo{/b} que acabou de acontecer.{/size}"


translate pt_br lookBehindYou_movie_a20cefa7_1:


    "..."


translate pt_br lookBehindYou_movie_4914da37:


    "É..."


translate pt_br endOldMovie_8dabefc6:


    ".."


translate pt_br endOldMovie_a20cefa7:


    "..."


translate pt_br endOldMovie_5583c4ca:


    "Apesar de sua resistência..."


translate pt_br endOldMovie_0fcf7c3b:


    "...você sente sua cabeça se virando para olhar para trás por conta própria."


translate pt_br endOldMovie_7f250539:


    "Enquanto está no meio da rua..."


translate pt_br endOldMovie_dfc24e13:


    "...você vislumbra uma figura grotesca atrás das portas de vidro do antigo cinema..."


translate pt_br endOldMovie_67373714:


    "Te observando intensamente..."


translate pt_br endOldMovie_747a081d:


    "Segurando alguma coisa em seus braços..."


translate pt_br endOldMovie_973413d4:


    "Algo..."


translate pt_br endOldMovie_8ae0fc15:


    "{size=-10}...familiar.{/size}"


translate pt_br endOldMovie_a20cefa7_1:


    "..."


translate pt_br endOldMovie_bf0874e3:


    "Mas..."


translate pt_br endOldMovie_a9494a86:


    "{size=+30}{b}{i}BIIII!{/i}{/b}{/size}" with hpunch


translate pt_br endOldMovie_90b68c87:


    you "..?"


translate pt_br endOldMovie_8ca8510a:


    you "!!!" with vpunch


translate pt_br endOldMovie_f5377255:


    "Um vislumbre é tudo que você consegue..."


translate pt_br endOldMovie_e22cae7b:


    "...antes que um caminhão se aproxime em alta velocidade e {b}passe por cima{/b} de você."


translate pt_br endOldMovie_8dabefc6_1:


    ".."


translate pt_br endOldMovie_a20cefa7_2:


    "..."


translate pt_br endOldMovie_0b13bd09:


    "Você morre no impacto, seu corpo espalhado pela estrada e esmagado sob os pneus pesados."


translate pt_br endOldMovie_a20cefa7_3:


    "..."


translate pt_br endOldMovie_7444e453:


    "Final 16: Péssima Administração"


translate pt_br newCinema_fb646a70:


    "Decidindo esperar o filme que você tanto aguardava ficar disponível em DVD ou em streaming..."


translate pt_br newCinema_e6448215:


    "...você entra na longa fila do lado de fora do cinema novo."


translate pt_br newCinema_0f82186d:


    "Quando você finalmente chega à bilheteria, só quer entrar logo..."


translate pt_br newCinema_2e8f7eeb:


    "...então você escolhe um filme qualquer e pega o ingresso com o adolescente aparentemente cansado que cuida da bilheteria."


translate pt_br newCinema_6fcdd2f1:


    "A decoração é chique e elegante, e o interior está movimentado."


translate pt_br newCinema_df337005:


    "Não é bem o que você costuma curtir..."


translate pt_br newCinema_ebfd36e0:


    "...mas até que é legal não estar sozinho..."


translate pt_br newCinema_16ea2ab5:


    "...mesmo que você se sinta um pouco solitário ao ver famílias e grupos de amigos rindo entre si."


translate pt_br newCinema_8a84e9c7:


    "Você até compraria pipoca, mas as filas do quiosque são enormes e os preços são uma facada."


translate pt_br newCinema_f8963506:


    "Você atravessa os corredores..."


translate pt_br newCinema_6a610267:


    "...e segue as placas até a sala indicada no seu ingresso antes de entrar."


translate pt_br newCinema_8dabefc6:


    ".."


translate pt_br newCinema_a20cefa7:


    "..."


translate pt_br newCinema_cfd045e6:


    you "*Suspiro*..."


translate pt_br newCinema_a0c7900b:


    "Você suspira ao se deparar com uma sala completamente lotada."


translate pt_br newCinema_2aeb5f16:


    "Você se dirige para um assento, só para ouvir pela pessoa ao lado de que ele está reservado para alguém."


translate pt_br newCinema_2c48e4bd:


    "Isso acontece mais algumas vezes antes de você finalmente conseguir se acomodar em um assento que está irritantemente fora de ângulo em relação à tela."


translate pt_br newCinema_66e2f315:


    "Mas pelo menos a tela está visível, só um pouco próxima demais. Então, você range os dentes e suporta."


translate pt_br newCinema_84b297cd:


    "As luzes se apagam..."


translate pt_br newCinema_76f1cc33:


    "...mas a conversa continua."


translate pt_br newCinema_ccf5589e:


    "O resto do público parece contente em conversar durante os comerciais e até mesmo durante os trailers."


translate pt_br newCinema_e5244e34:


    "Você imagina que o converseiro vá parar quando o filme começar de verdade..."


translate pt_br newCinema_42922d85:


    "...mas não fica nem mesmo {i}um pouco{/i} mais quieto assim que a cena de abertura começa a passar."


translate pt_br newCinema_056cb5d7:


    "Você suspira alto, imaginando que ninguém te ouviria, de qualquer forma."


translate pt_br newCinema_fe9b2aa2:


    "É por isso que você evita tanto cinemas."


translate pt_br newCinema_c70c22ac:


    "De repente, a tela muda, mostrando a face de um gato preto..."


translate pt_br newCinema_a20cefa7_1:


    "..."


translate pt_br newCinema_5bd888eb:


    "{size=-8}Um gato preto {b}familiar{/b}.{/size}"


translate pt_br newCinema_bf2cad6b:


    "Sussurros confusos enchem a sala... até que... {w}o gato na tela..."


translate pt_br newCinema_7f5ff8a8:


    "{b}...mia.{/b}"


translate pt_br newCinema_d752482c:


    catOnScreen "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."


translate pt_br newCinema_28b3ac41:


    you "!!"


translate pt_br newCinema_2e7e53ad:


    "O som é... {i}estranho{/i} e de forma alguma como um gato {i}deveria{/i} soar."


translate pt_br newCinema_4a94d4f7:


    "Fantasmagórico... Quase melódico..."


translate pt_br newCinema_d7d1f702:


    "E sobreposto, como se fosse feito de várias vozes de criaturas diferentes."


translate pt_br newCinema_96a32759:


    "Criaturas que provavelmente nunca falariam-"


translate pt_br newCinema_d752482c_1:


    catOnScreen "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."


translate pt_br newCinema_dae0ec55:


    you "..."


translate pt_br newCinema_7865d364:


    "Você se senta, confuso, se perguntando por que ainda não se levantou e foi reclamar com os funcionários do cinema..."


translate pt_br newCinema_04be082d:


    "Mas então você {b}ouve{/b}..."


translate pt_br newCinema_b5b4f2e8:


    "Está picotado e dissonante no início... mas entre a multidão... pessoas começam a entoar junto com o gato na tela."


translate pt_br newCinema_b67f4dca:


    audience "{size=-10}Nyaa... Nyaa... Nyaaa-a-a-a-ah...{/size}"


translate pt_br newCinema_45f08096:


    audience "{size=-5}Nyaa... Nyaa... Nyaaa-a-a-a-ah...{/size}"


translate pt_br newCinema_764e589b:


    audience "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."


translate pt_br newCinema_b95dc8fe:


    "Logo... toda a sala está entoando em perfeito uníssono, todos encarando diretamente o gato na tela."


translate pt_br newCinema_9eb4296f:


    "Você se sente estranhamente atraído pela tela também..."


translate pt_br newCinema_59b62632:


    "...mas a compulsão de olhar fixamente como os outros não é tão forte..."


translate pt_br newCinema_53224b1d:


    "...por {b}enquanto.{/b}"


translate pt_br newCinema_3595f06e:


    "Além disso... {w}você começa a notar de canto de olho..."


translate pt_br newCinema_fc9293fc:


    "...que algumas pessoas próximas estão... {w}{i}olhando{/i} para você..."


translate pt_br newCinema_7072f3b4:


    "Não..."


translate pt_br newCinema_8adc7d4f:


    "Elas estão simplesmente te {b}comendo{/b} com os olhos, enquanto continuam entoando."


translate pt_br newCinema_46abeb33:


    "Elas não perdem o ritmo, ao mesmo tempo que começam a lentamente franzir a testa em clara desaprovação..."


translate pt_br newCinema_c4ad1bed:


    "Suas carrancas pioram conforme o tempo passa, como se elas estivessem ficando...{w} {i}impacientes...{/i}"


translate pt_br leaveCinema_b24b4053:


    you "{i}Isso é estranho demais... tenho que dar o fora daqui...{/i}"


translate pt_br leaveCinema_14daa181:


    "Juntando sua coragem...{w} ou talvez aproveitando seu medo, você se levanta,{w} com a plena intenção de sair do cinema..."


translate pt_br leaveCinema_a20cefa7:


    "..."


translate pt_br leaveCinema_ad7223b1:


    "...quando tudo chega a um abrupto {b}PAREM.{/b}"


translate pt_br leaveCinema_dff334e8:


    "Todo o cântico para, até mesmo o entoar do gato na tela."


translate pt_br leaveCinema_dae0ec55:


    you "..."


translate pt_br leaveCinema_2f1c4fb2:


    "Você arrisca um olhar tenso ao redor do cinema."


translate pt_br leaveCinema_8ca8510a:


    you "!!!" with vpunch


translate pt_br leaveCinema_fe50f822:


    "Todos estão te encarando."


translate pt_br leaveCinema_50e5017d:


    "Cada. {w}Um. {w}Deles."


translate pt_br leaveCinema_352295ee:


    "Eles não se movem. Eles não estão nem mesmo {i}piscando.{/i}"


translate pt_br leaveCinema_99a1a0e1:


    "Sua garganta repentinamente fica seca, embora o suor de nervoso tenha encharcado completamente suas roupas."


translate pt_br leaveCinema_661663c4:


    "Você engole seco. Você duvida muito que se sentar de volta resolva a situação."


translate pt_br leaveCinema_213963ee:


    "Suas pernas tremem sob a observação anormalmente intensa do público..."


translate pt_br leaveCinema_f71571f9:


    "...mas você se força a avançar e avançar e {i}avançar{/i} até finalmente alcançar o final do corredor."


translate pt_br leaveCinema_dba70b8c:


    "Você sente o olhar coletivo deles piorar nas escadas."


translate pt_br leaveCinema_87d1ef1d:


    "Todas as cabeças se viraram desconfortavelmente para a esquerda para te encarar diretamente."


translate pt_br leaveCinema_f70351ce:


    "A tela ilumina seus rostos... evidenciando claramente suas expressões vazias e carrancudas."


translate pt_br leaveCinema_004b0a78:


    "Eles parecem ainda {i}mais{/i} irritados do que estavam minutos atrás, com as mesmas rugas de expressão se aprofundando entre suas sobrancelhas."


translate pt_br leaveCinema_dae0ec55_1:


    you "..."


translate pt_br leaveCinema_3252a987:


    "Você continua, e a atmosfera pesada se torna cada vez mais opressiva a cada passo."


translate pt_br leaveCinema_fb8531cb:


    "Você está tão tenso e ansioso que tem certeza de que alguém vá te agarrar por trás..."


translate pt_br leaveCinema_8dabefc6:


    ".."


translate pt_br leaveCinema_a20cefa7_1:


    "..."


translate pt_br leaveCinema_0a4bb949:


    "...mas ninguém faz nada."


translate pt_br leaveCinema_40a5c55d:


    "Você não ouve nenhum deles sequer se levantar."


translate pt_br leaveCinema_6bc983be:


    "Você sai do cinema, prendendo a respiração enquanto as portas se fecham atrás de você."


translate pt_br leaveCinema_ffbf4484:


    "Você anda rapidamente pelos corredores, tentando se distanciar o máximo possível daquela sala cheia de pessoas."


translate pt_br leaveCinema_26c08f03:


    "Finalmente chegando à entrada, você mal consegue se sustentar e evita cair no chão enquanto inspira profunda e repetidamente."


translate pt_br leaveCinema_83668abb:


    you "*ofegante*... *ofegante*... *ofegante*..."


translate pt_br leaveCinema_52ec6324:


    "Você espera sentir alívio à medida que sua respiração se acalma..."


translate pt_br leaveCinema_a1d9994b:


    "...mas sente uma sensação persistente de terror que só aumenta quando você finalmente a percebe..."


translate pt_br leaveCinema_9a5f33b8:


    "...assim como sua origem."


translate pt_br leaveCinema_1aa73f86:


    "Você olha para cima...{w} e seu estômago {b}se revira.{/b}"


translate pt_br leaveCinema_8ca8510a_1:


    you "!!!" with vpunch


translate pt_br leaveCinema_a20cefa7_2:


    "..."


translate pt_br leaveCinema_af1c2015:


    "Todas as pessoas na entrada do cinema..."


translate pt_br leaveCinema_a38e0614:


    "...todos na fila do quiosque..."


translate pt_br leaveCinema_0e53b020:


    "...{i}todos{/i} eles..."


translate pt_br leaveCinema_b615e9cc:


    "...estão te encarando."


translate pt_br leaveCinema_b88c436c:


    "E eles..."


translate pt_br leaveCinema_a20cefa7_3:


    "..."


translate pt_br leaveCinema_fc56246f:


    "{size=-8}Eles parecem ainda mais irritados do que as pessoas na sala do cinema.{/size}"


translate pt_br leaveCinema_87f864e9:


    "Dessa vez você não hesita."


translate pt_br leaveCinema_3d21a06a:


    "Você baixa a cabeça, evitando contato visual, e deixa o cinema."


translate pt_br leaveCinema_f685e7ad:


    "Você ignora os olhares de todos na bilheteria e na fila que leva até ela."


translate pt_br leaveCinema_80db9421:


    "Você segue seu caminho para casa."


translate pt_br leaveCinema_f0a2809d:


    "Sempre que se atreve a olhar para alguém pelo caminho..."


translate pt_br leaveCinema_bda94720:


    "...você se estremece com a raiva, fúria e {i}desgosto{/i} explícitos no rosto deles."


translate pt_br leaveCinema_964bc827:


    "Você começa a achar estar ouvindo o som fraco de um gato miando atrás de você... talvez de um filhote?"


translate pt_br leaveCinema_57e876a1:


    "Não importa. Você só quer ir para casa."


translate pt_br leaveCinema_b807a344:


    "Você alcança porta de casa e se atrapalha com as chaves..."


translate pt_br leaveCinema_f4f2f1d2:


    "...temendo o olhar de puro ódio no rosto do seu vizinho enquanto ele te encara da porta dele."


translate pt_br leaveCinema_8dabefc6_1:


    ".."


translate pt_br leaveCinema_a20cefa7_4:


    "..."


translate pt_br leaveCinema_cddd7eac:


    "Finalmente, você entra no seu apartamento..."


translate pt_br leaveCinema_4632e734:


    "...tranca todas as fechaduras da porta..."


translate pt_br leaveCinema_490b851e:


    "...e desliza com as costas contra ela até se sentar no chão."


translate pt_br leaveCinema_157a374f:


    you "*ofegante*... *ofegante*... *gulp*... *ofegante*..."


translate pt_br leaveCinema_57aaf835:


    "Você se permite respirar por um momento."


translate pt_br leaveCinema_f125ce05:


    "Agora em casa, seu coração se acalma e seu medo lentamente se esvai, fazendo você se sentir estranhamente..."


translate pt_br leaveCinema_0f7ae6ad:


    "...vazio."


translate pt_br leaveCinema_a20cefa7_5:


    "..."


translate pt_br leaveCinema_bf467465:


    "Você passa pela cozinha, segue para seu quarto, e se cobre nas cobertas na sua cama, tentando se pôr a dormir."


translate pt_br leaveCinema_dbaf51d5:


    "Talvez tudo tenha sido só um sonho ruim."


translate pt_br leaveCinema_f54febea:


    "Enquanto você cai em um sono agitado, certamente cheio de pesadelos com olhos te encarando..."


translate pt_br leaveCinema_83eadebb:


    "...você tenta ignorar os sons cada vez mais altos de gatos miando e berrando ao longe, do lado de fora do seu apartamento."


translate pt_br leaveCinema_a20cefa7_6:


    "..."


translate pt_br leaveCinema_d23cedee:


    "Final 17: Ovelha Negra"


translate pt_br blendInCinema_6757b12e:


    audience "..."


translate pt_br blendInCinema_af2b87f0:


    "Pensando rápido, você olha para a tela e começa a entoar o cântico junto com a multidão."


translate pt_br blendInCinema_baf609ba:


    you "N-Nyaa... Nyaa... Nyaaa-a-a-a-ah..."


translate pt_br blendInCinema_6757b12e_1:


    audience "..."


translate pt_br blendInCinema_3f83d36c:


    you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."


translate pt_br blendInCinema_6757b12e_2:


    audience "..."


translate pt_br blendInCinema_6757b12e_3:


    audience "..."


translate pt_br blendInCinema_d090b91d:


    "Você sente a pressão do olhar coletivo deles começando a se dissipar..."


translate pt_br blendInCinema_5580b6b9:


    "...o clima na sala de cinema ficando mais leve de novo."


translate pt_br blendInCinema_764e589b:


    audience "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."


translate pt_br blendInCinema_0b4d7107:


    "Você expira de forma trêmula, só agora percebendo que estava prendendo a respiração."


translate pt_br blendInCinema_a20cefa7:


    "..."


translate pt_br blendInCinema_b2294dd7:


    "Você se sente preso."


translate pt_br blendInCinema_042d621e:


    "Certamente você não pode só se levantar e sair {i}agora...{/i}"


translate pt_br blendInCinema_cf356d17:


    "Não depois de... {i}seja lá{/i} o que foi tudo aquilo..."


translate pt_br blendInCinema_ed742197:


    "As pessoas ao seu redor parecem tranquilas agora..."


translate pt_br blendInCinema_15fcd1a9:


    "...mas não há como saber se elas ficariam agressivas com você até mesmo por se mexer demais..."


translate pt_br blendInCinema_b896225e:


    "...quanto mais se levantar e ir embora."


translate pt_br blendInCinema_68b1d26e:


    "Você decide deixar as coisas acontecerem. Com sorte, alguém aparece..."


translate pt_br blendInCinema_9979a58c:


    "Né?"


translate pt_br blendInCinema_4cc0ec01:


    "{size=-5}Ou, pelo menos, desliga o filme?{/size}"


translate pt_br blendInCinema_a20cefa7_1:


    "..."


translate pt_br blendInCinema_0de27b67:


    "Você continua entoando com todo mundo..."


translate pt_br blendInCinema_3f83d36c_1:


    you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."


translate pt_br blendInCinema_8dabefc6:


    ".."


translate pt_br blendInCinema_a20cefa7_2:


    "..."


translate pt_br blendInCinema_397110ce:


    "Você começa a se sentir tonto..."


translate pt_br blendInCinema_8b1e92a6:


    "Você sente como se fosse adormecer, mas seus olhos não estão nem um pouco pesados."


translate pt_br blendInCinema_7ff2d155:


    "Você tenta olhar ao redor e avaliar o estado emocional dos outros..."


translate pt_br blendInCinema_a20cefa7_3:


    "..."


translate pt_br blendInCinema_40d9ca73:


    "..?"


translate pt_br blendInCinema_a90dd9a4:


    "Mas você não consegue desviar o olhar da tela."


translate pt_br blendInCinema_2a365272:


    "Você tenta de novo, mas ainda está fixado no olhar do gato na tela."


translate pt_br blendInCinema_d752482c:


    catOnScreen "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."


translate pt_br blendInCinema_764e589b_1:


    audience "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."


translate pt_br blendInCinema_3f83d36c_2:


    you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."


translate pt_br blendInCinema_496d9edf:


    "You tenta forçar fisicamente seu campo de visão para longe."


translate pt_br blendInCinema_d9f4b72f:


    "Você se prepara mentalmente, pronto para se jogar no chão se for necessário..."


translate pt_br blendInCinema_3e3a5b69:


    "Mas seu corpo só consegue tensionar por um momento antes de relaxar por completo novamente..."


translate pt_br blendInCinema_2fb3a1df:


    "...fazendo você se recostar frouxamente no assento."


translate pt_br blendInCinema_2a71630f:


    "Você acha que deveria estar em pânico agora..."


translate pt_br blendInCinema_a6dd5ae6:


    "Mas até mesmo seu cérebro parece frouxo..."


translate pt_br blendInCinema_8cf039a1:


    "...seus pensamentos têm uma cor rosa pastel meio desbotada..."


translate pt_br blendInCinema_1beaa2de:


    "...delicado..."


translate pt_br blendInCinema_ced05056:


    "...enjoativamente doce e com uma textura leve..."


translate pt_br blendInCinema_57ea3fbe:


    "...como algodão doce."


translate pt_br blendInCinema_a20cefa7_4:


    "..."


translate pt_br blendInCinema_0f5de544:


    "Você..."


translate pt_br blendInCinema_54c46a6d:


    "Você gosta de algodão doce..."


translate pt_br blendInCinema_cb63a8d9:


    "Você pensa que não se importaria que seus pensamentos e corpo sejam como algodão doce..."


translate pt_br blendInCinema_7c477b17:


    "Então... {w}por que levantar e {i}arruinar{/i} isso?"


translate pt_br blendInCinema_ba89262e:


    "Tá ótimo aqui."


translate pt_br blendInCinema_e24de160:


    "Você está mais em paz do que jamais se sentiu em uma sala tão cheia."


translate pt_br blendInCinema_c24bdd0d:


    "Ainda entoando, você nunca se sentiu tão alinhado e em sintonia com outra pessoa..."


translate pt_br blendInCinema_31f93be4:


    "...{i}quanto mais{/i} com uma sala inteira cheia de completos estranhos."


translate pt_br blendInCinema_04d14b81:


    "Você não está..."


translate pt_br blendInCinema_a20cefa7_5:


    "..."


translate pt_br blendInCinema_9d11f320:


    "Você não está sozinho..."


translate pt_br blendInCinema_ae0146e0:


    "Vendo de canto do olho, a pessoa ao seu lado começa a afundar ainda mais na cadeira..."


translate pt_br blendInCinema_5f0ca8c0:


    "Então afunda mais."


translate pt_br blendInCinema_5929012b:


    "E então {i}mais.{/i}"


translate pt_br blendInCinema_ab0534b1:


    "Não é como se estivesse se encurvando ou se deitando, é mais como se estivesse..."


translate pt_br blendInCinema_8dabefc6_1:


    ".."


translate pt_br blendInCinema_a20cefa7_6:


    "..."


translate pt_br blendInCinema_a20cefa7_7:


    "..."


translate pt_br blendInCinema_38fb2682:


    "{size=-5}...{b}esvaziando.{/b}{/size}"


translate pt_br blendInCinema_e38a1999:


    "Sua pele se amassa e enruga como tecido, como se seus músculos... seus {i}ossos...{/i} estivessem começando a se desintegrar."


translate pt_br blendInCinema_debf73aa:


    "Seus olhos escurecem antes de afundarem nas órbitas."


translate pt_br blendInCinema_35c42551:


    "Sua boca, ainda tentando entoar, se abre com um 'Nya-' interrompido..."


translate pt_br blendInCinema_a9055c48:


    "...a palavra termina em um terrível {i}{b}sibilo{/b}{/i}... uma última e fraca liberação de ar."


translate pt_br blendInCinema_a20cefa7_8:


    "..."


translate pt_br blendInCinema_16800af4:


    "Você reflete pensativamente se deveria ou não se angustiar com a cena..."


translate pt_br blendInCinema_b9788577:


    "...mas mesmo {i}assim,{/i} o manto de paz não se desfaz."


translate pt_br blendInCinema_214e33b0:


    "De repente, do monte de pele e roupas ao seu lado... {w}você vê um volume se movendo..."


translate pt_br blendInCinema_594564ce:


    "Você observa, fascinado e atordoado, enquanto o volume se move em direção à parte da pele onde costumava ser a cabeça..."


translate pt_br blendInCinema_67dceeae:


    "E de dentro da boca..."


translate pt_br blendInCinema_7c9b7fd7:


    "...sai um pequeno gatinho preto."


translate pt_br blendInCinema_a20cefa7_9:


    "..."


translate pt_br blendInCinema_3f83d36c_3:


    you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."


translate pt_br blendInCinema_193a0367:


    "Você agora pode ouvir o familiar som de sibilo ao seu redor, enquanto os cânticos começam a desaparecer..."


translate pt_br blendInCinema_83fb5231:


    "...sendo substituídos pelo fraco miado dos gatinhos."


translate pt_br blendInCinema_51f8946e:


    "Finalmente, sua voz é a única ainda entoando... ainda humano..."


translate pt_br blendInCinema_31826a8b:


    "E sozinho... {w}de novo."


translate pt_br blendInCinema_5d0ac8cd:


    "{size=-8}Você não quer isso. {w}Não pode voltar a isso. {w}De novo não. {w}De novo não... {w}{b}Por favor...{/b}{/size}"


translate pt_br blendInCinema_a927f418:


    "Então, você fica completamente mole."


translate pt_br blendInCinema_84c8a0dd:


    "Você sente seu corpo leve, mas poderia estar pesando várias toneladas..."


translate pt_br blendInCinema_92382baf:


    "...porque você percebe de repente que não consegue se mover..."


translate pt_br blendInCinema_c3f227f7:


    "Nem um {b}centímetro.{/b}"


translate pt_br blendInCinema_e963d3dd:


    "Você não consegue mexer os olhos para olhar em volta..."


translate pt_br blendInCinema_c72a7267:


    "Você não consegue nem {i}respirar...{/i}"


translate pt_br blendInCinema_0c96f132:


    "Mas de alguma forma..."


translate pt_br blendInCinema_9096c895:


    "...o cântico continua a sair timidamente da sua boca."


translate pt_br blendInCinema_af288514:


    you "{size=-5}N-Nyaa... Nyaa... N-Nyaaa-a-a-a-ah...{/size}"


translate pt_br blendInCinema_635a2b3f:


    "Alguns gatinhos se aproximam e se acomodam nas cadeiras ao seu redor..."


translate pt_br blendInCinema_a149e153:


    "...observando seu corpo afundar..."


translate pt_br blendInCinema_d292541d:


    "...miando enquanto esperam o irmão mais novo deles emergir..."


translate pt_br blendInCinema_5d4fa878:


    "...de {i}você.{/i}"


translate pt_br blendInCinema_7a472b2f:


    "Dezenas de olhos brilhantes observam você..."


translate pt_br blendInCinema_d4e4181d:


    "...e enquanto {i}seus{/i} olhos começam a afundar nas órbitas do seu crânio amolecido..."


translate pt_br blendInCinema_24c93db0:


    "...você consegue distinguir a silhueta de um gato {b}familiar{/b}, sentado no assento bem à sua frente..."


translate pt_br blendInCinema_cb38fcb2:


    "Sua visão finalmente se apaga..."


translate pt_br blendInCinema_0af14a4f:


    "E enquanto aquele mesmo sibilo de ar sai da sua boca..."


translate pt_br blendInCinema_cc2adb18:


    "...a última coisa que você sente é algo pequeno e {b}{i}vivo{/i}{/b} se movendo entusiasmado sob sua pele."


translate pt_br blendInCinema_8dabefc6_2:


    ".."


translate pt_br blendInCinema_a20cefa7_10:


    "..."


translate pt_br blendInCinema_d2ce5919:


    "Final 18: Feliz Aniversário."


translate pt_br goToCarnival_54663883:


    "Você passa o dia no festival."


translate pt_br goToCarnival_295775c9:


    "Roda-gigante, montanha-russa, barco viking... {w}Brinquedos nos quais você já esteve antes."


translate pt_br goToCarnival_0d9e8fc3:


    "Basquete de arcade, arremesso de moedas, dardos... {w}Jogos que você já jogou antes."


translate pt_br goToCarnival_32a40a6e:


    "Bolo de funil, pipoca, algodão doce... {w}Comidas que você já comeu antes."


translate pt_br goToCarnival_d6de1944:


    "Você já fez tudo isso {i}antes.{/i}"


translate pt_br goToCarnival_c3c9efe7:


    "Você está rodeado de grupos de pessoas se divertindo entre si..."


translate pt_br goToCarnival_7598c0f4:


    "Rindo, brincando, comendo, tirando fotos... Criando memórias..."


translate pt_br goToCarnival_b0255334:


    "E aí está você."


translate pt_br goToCarnival_a20cefa7:


    "..."


translate pt_br goToCarnival_a7421486:


    "O sol ainda não começou a se pôr, está ainda bem alto no céu, mas logo vai."


translate pt_br goToCarnival_527d7f2b:


    "Você começa a se perguntar se talvez não seria melhor ir para casa por hoje...{w} quando para abruptamente."


translate pt_br goToCarnival_2f469756:


    "Você vê algo...{w} {i}novo.{/i} {w}Uma atração que nunca tinha visto antes."


translate pt_br goToCarnival_ee0a18bc:


    "Um labirinto... de espelhos?"


translate pt_br goToCarnival_c0de53a5:


    "Parece..."


translate pt_br goToCarnival_a20cefa7_1:


    "..."


translate pt_br goToCarnival_3a26a699:


    "...meio sem graça, honestamente."


translate pt_br goToCarnival_4686437f:


    "Nem tem fila para entrar."


translate pt_br goToCarnival_a20cefa7_2:


    "..."


translate pt_br goToCarnival_cbb84cc7:


    "Mas então... {w}o que mais há para fazer..?"


translate pt_br goToCarnival_ba0e6a77:


    "Tem que haver um jeito melhor de passar seu dia de folga do que vagar por aí olhando para espelhos estranhos..."


translate pt_br goToCarnival_16617c12:


    "E agora?"


translate pt_br enteringMaze_1d094261:


    "Você entra no labirinto."


translate pt_br enteringMaze_8f41cd1a:


    "Após entrar em algumas salas, você percebe que nem {i}todos{/i} os espelhos são estranhos."


translate pt_br enteringMaze_f78b0a7d:


    "Alguns apenas mostram {i}você{/i} se olhando de volta."


translate pt_br enteringMaze_8d2086a8:


    "Um pouco entediado... Bastante cansado... E tão, tão..."


translate pt_br enteringMaze_a20cefa7:


    "..."


translate pt_br enteringMaze_8dabefc6:


    ".."


translate pt_br enteringMaze_a20cefa7_1:


    "..."


translate pt_br enteringMaze_95cd8199:


    "...Talvez tenha sido um erro."


translate pt_br enteringMaze_9712bff9:


    "Por que você pensou que ir num labirinto de {b}espelhos{/b} seria uma boa ideia? Mesmo que seja uma coisa nova para experienciar?"


translate pt_br enteringMaze_14d0b867:


    you "{i}Eu... eu não consigo fazer isso hoje...{/i}"


translate pt_br enteringMaze_316b5d4c:


    "Você se vira para sair por onde você entrou..."


translate pt_br enteringMaze_7515fb32:


    "...e dá de cara com um espelho."


translate pt_br enteringMaze_97c66c9f:


    you "Ai! Mas que..? Cadê a saída?"


translate pt_br enteringMaze_b06acef3:


    "Você tenta de novo e encontra outro espelho bloqueando seu caminho."


translate pt_br enteringMaze_fbd47643:


    "Quando você já está desorientado, percebe que o caminho por onde entrou desapareceu completamente."


translate pt_br enteringMaze_632d1a35:


    you "!!!" with hpunch


translate pt_br enteringMaze_8dabefc6_1:


    ".."


translate pt_br enteringMaze_a20cefa7_2:


    "..."


translate pt_br enteringMaze_7d0d986d:


    you "T-Tá, não entra em pânico. Eu só tenho que... continuar seguindo em frente... né?"


translate pt_br enteringMaze_c0fd94ff:


    "Você passa pela única abertura que consegue encontrar e quase tropeça em algo no chão."


translate pt_br enteringMaze_d113f422:


    "Você se abaixa e pega o objeto."


translate pt_br enteringMaze_90b68c87:


    you "..?"


translate pt_br enteringMaze_1ec82967:


    you "O que {i}isso{/i} tá fazendo aqui?"


translate pt_br enteringMaze_c5a1d33c:


    "Na sua mão está uma lanterna com aparência desgastada."


translate pt_br enteringMaze_cab20fdf:


    "Curioso, você a liga."


translate pt_br enteringMaze_09d06ab8:


    "*Clique*"


translate pt_br enteringMaze_dfb9ab96:


    "... {w}Hã... {w}A luz não parece muito-{w=1.0}{nw}"


translate pt_br enteringMaze_28b3ac41:


    you "!!"


translate pt_br enteringMaze_ed7cc831:


    you "Droga! As luzes!"


translate pt_br enteringMaze_8f63ef28:


    "A energia caiu ou o operador da atração esqueceu que você estava aqui?"


translate pt_br enteringMaze_a20cefa7_3:


    "..."


translate pt_br enteringMaze_2babdbaa:


    "Há quanto tempo você {i}está{/i} aqui, aliás?"


translate pt_br enteringMaze_10b8c8d1:


    "Você pega seu celular pra ver as horas ou quem sabe ligar para a polícia..."


translate pt_br enteringMaze_8dabefc6_2:


    ".."


translate pt_br enteringMaze_a20cefa7_4:


    "..."


translate pt_br enteringMaze_fe084e57:


    "{size=-6}Seu celular está descarregado.{/size}"


translate pt_br enteringMaze_a20cefa7_5:


    "..."


translate pt_br enteringMaze_f293e828:


    "Você segura a lanterna com firmeza."


translate pt_br enteringMaze_776c58c3:


    "A luz que ela emitiu mais cedo era fraca o suficiente para você saber que provavelmente não deve ter muita carga restante."


translate pt_br enteringMaze_e64595f9:


    "Best to reserve it for a worst case scenario and feel your way out."


translate pt_br enteringMaze_60f2d28e:


    "É. É, você consegue."


translate pt_br enteringMaze_ddbe6ff4:


    "Você dá uma respirada para se acalmar."


translate pt_br enteringMaze_fb40dccf:


    you "{i}Bom. {w}Vamos em frente...{/i}"


translate pt_br enteringMaze_a20cefa7_6:


    "..."


translate pt_br goToDogPark_5c14c202:


    "Você decide dar uma volta em um parque ou algo assim."


translate pt_br goToDogPark_e1880432:


    "O único que dá para ir a pé é o parque para cachorros ali perto."


translate pt_br goToDogPark_31ab9223:


    "Você acha que vai te fazer se sentir melhor."


translate pt_br goToDogPark_b35402c8:


    "Primeiro você viu um gato fofo hoje, agora vai poder ver um cachorro fofo!"


translate pt_br goToDogPark_a749d8ba:


    "{i}Vários{/i} deles, na verdade."


translate pt_br goToDogPark_3d36b825:


    "O parque está movimentado com os donos e seus companheiros caninos."


translate pt_br goToDogPark_615bff09:


    "Brincando de frisbee, de ir buscar, correndo, pulando, e até tirando uma soneca~!"


translate pt_br goToDogPark_9df30f1c:


    "Que fofuras-{w=0.5}{nw}"


translate pt_br goToDogPark_40780276:


    "{size=-8}{b}Tanto faz. {w}Como se você quisesse saber desses vira-latas sarnentos.{/b}{/size}"


translate pt_br goToDogPark_a2a49044:


    you "{i}..?!{/i}"


translate pt_br goToDogPark_a20cefa7:


    "..."


translate pt_br goToDogPark_0b798a8a:


    "...O que foi?"


translate pt_br goToDogPark_58b82d2c:


    "Você não pensou isso?"


translate pt_br goToDogPark_8dabefc6:


    ".."


translate pt_br goToDogPark_a20cefa7_1:


    "..."


translate pt_br goToDogPark_50754116:


    "Você decide seguir em frente."


translate pt_br goToDogPark_c5900d2a:


    "Os cachorros são todos tão adoráveis. Você quer fazer carinho em cada um que encontra..."


translate pt_br goToDogPark_e4211dcf:


    "...mas você sabe que nem todos os donos gostam de estranhos se aproximando e pegando nos seus animais."


translate pt_br goToDogPark_4f5fba4a:


    "Nem todos os cachorros gostam disso também."


translate pt_br goToDogPark_4f7be349:


    "Então você dá uma volta, tentando exalar uma aura acolhedora que atraia um desses cachorrinhos fofos até você."


translate pt_br goToDogPark_3dd44abb:


    "Você não precisa esperar muito."


translate pt_br goToDogPark_1176e05a:


    who "Au!"


translate pt_br goToDogPark_08c12ebd:


    "Você para quando o menor e mais fofo filhote que você já viu corre até você, bloqueando seu caminho~"


translate pt_br puppyMenu_11e3ab75:


    who "{b}sim saia saia saia cachorros são estúpidos e todos eles merecem m-{/b}{w=1.5}{nw}"


translate pt_br puppyMenu_16617c12:


    "E agora?"


translate pt_br puppyMenu_4289f415:


    you "{i}...O quê?! É só um filhotinho!{/i}"


translate pt_br puppyMenu_8ca8510a:


    you "!!!" with vpunch


translate pt_br puppyMenu_c19f215c:


    you "{i}{b}NÃO!{/b} Que horrível!!{/i}"


translate pt_br puppyMenu_8ca8510a_1:


    you "!!!" with vpunch


translate pt_br puppyMenu_90c2904a:


    you "{i}Isso é nojento! Acho que vou vomitar...{/i}"


translate pt_br dontHurtPuppy_592a1c9d:


    you "{i}Eu não faria isso de jeito {b}nenhum{/b}!{/i}"


translate pt_br pickUpPup_eef93c07:


    "Você segura o cachorrinho e-{w=0.75}{nw}"


translate pt_br time_outPup_cc83c025:


    you "AAAHH!" with hpunch


translate pt_br time_outPup_2458cb0a:


    "Aterrorizado, você solta o filhotinho no chão... {w}praticamente o jogando para longe."


translate pt_br time_outPup_20de8723:


    "Você se tente horrível imediatamente, se encolhendo de culpa com o ganidinho que o filhote solta ao cair no chão."


translate pt_br time_outPup_23e2545d:


    "O dono te empurra com um olhar cortante e sai furioso com o filhote."


translate pt_br time_outPup_529cf39a:


    you "D-Desculpa!"


translate pt_br time_outPup_4eef1ef7:


    "Você chama, mas ele não se vira nem responde."


translate pt_br time_outPup_7d44f3d1:


    "Você nem esperava que ele fizesse isso."


translate pt_br time_outPup_30fdc351:


    "Você {i}mereceu{/i}."


translate pt_br heldPup_8ca8510a:


    you "!!!" with vpunch


translate pt_br heldPup_8dabefc6:


    ".."


translate pt_br heldPup_a20cefa7:


    "..."


translate pt_br heldPup_209b2328:


    "Você mal consegue conter o reflexo de jogar o filhote o mais longe possível de você."


translate pt_br heldPup_dae0ec55:


    you "..."


translate pt_br heldPup_54632163:


    "Com as mãos tremendo, você rapidamente coloca o filhote na grama e dá vários passos bruscos para trás."


translate pt_br heldPup_3b0e2416:


    "O dono parece confuso com sua reação com o filhote, {w}mas você apenas acena para ele atordoado antes de sair com pressa."


translate pt_br leavePark1_dae0ec55:


    you "..."


translate pt_br leavePark1_6b46ce4b:


    "Você não está se sentindo muito bem em estar no parque no momento. Talvez seja melhor ir embora?"


translate pt_br leavePark1_a20cefa7:


    "..."


translate pt_br leavePark1_c5fa6fdf:


    "Bom."


translate pt_br leavePark1_8dabefc6:


    ".."


translate pt_br leavePark1_a20cefa7_1:


    "..."


translate pt_br stayAtPark_8dabefc6:


    ".."


translate pt_br stayAtPark_a20cefa7:


    "..."


translate pt_br stayAtPark_a20cefa7_1:


    "..."


translate pt_br stayAtPark_7af3e563:


    "{size=+32}{b}VOCÊ FICA NO PARQUE.{/b}{/size}"


translate pt_br stayAtPark_dae0ec55:


    you "..."


translate pt_br stayAtPark_2ae435aa:


    "Você tenta se acalmar observando os cachorros de longe enquanto caminha..."


translate pt_br stayAtPark_e94f558f:


    "...mas de vez em quando, um deles corre até você..."


translate pt_br stayAtPark_f578fbad:


    "E vendo de perto, eles parecem..."


translate pt_br stayAtPark_26921232:


    "...errados."


translate pt_br stayAtPark_659594cd:


    "Seus donos não parecem perceber."


translate pt_br stayAtPark_f9b5bdd2:


    "Você acha um banco e se senta para um descanso rápido, fechando os olhos."


translate pt_br stayAtPark_7cc99210:


    "Talvez... {w}essa não tenha sido a melhor ideia, afinal."


translate pt_br stayAtPark_5917d0bd:


    "Talvez..."


translate pt_br stayAtPark_a20cefa7_2:


    "..."


translate pt_br stayAtPark_a20cefa7_3:


    "..."


translate pt_br stayAtPark_8442ca13:


    "v o c ê \ d e v e r i a \ t e r \ f i c a d o \ c o m i g o"


translate pt_br stayAtPark_dae0ec55_1:


    you "..."


translate pt_br stayAtPark_a20cefa7_4:


    "..."


translate pt_br stayAtPark_90b68c87:


    you "..?"


translate pt_br stayAtPark_895c5168:


    "Você é puxado de volta de seus pensamentos quando algo pousa suavemente em seu colo."


translate pt_br stayAtPark_0a7e463f:


    "Você olha para baixo e vê um frisbee no seu colo."


translate pt_br stayAtPark_1221e21a:


    who "E aí! Foi mal por isso! Pode jogar de volta?"


translate pt_br stayAtPark_bbb377a7:


    "Você olha para cima e vê um dono acenando para você de longe..."


translate pt_br stayAtPark_200e4ba1:


    "Mas mais importante..."


translate pt_br stayAtPark_60fece2b:


    dog "Au! Au! {b}Au!!{/b}" with hpunch


translate pt_br stayAtPark_90b68c87_1:


    you "..?"


translate pt_br stayAtPark_594ff454:


    dog "Au!{w=0.5}{nw}" with hpunch


translate pt_br stayAtPark_594ff454_1:


    dog "Au!{w=0.5}{nw}" with hpunch


translate pt_br stayAtPark_594ff454_2:


    dog "Au!{w=0.5}{nw}" with hpunch


translate pt_br stayAtPark_467ad46e:


    "Uma série de latidos animados atrai seu olhar para frente e você vê um cachorro grande correndo em sua direção."


translate pt_br stayAtPark_dae0ec55_2:


    you "..."


translate pt_br stayAtPark_264ae177:


    dog "au au au au au au au au au au au au au au au au au au au au au au au au au au au au au au au au au au "


translate pt_br stayAtPark_8dabefc6_1:


    ".."


translate pt_br stayAtPark_a20cefa7_5:


    "..."


translate pt_br stayAtPark_b6c8c1b0:


    "Uma série de latidos animados atrai seu olhar para frente e você vê um \ {b}c a c h o r r o{/b} \ grande correndo em sua direção."


translate pt_br stayAtPark_85913fb3:


    who "E-Ei! Joga logo de volta!"


translate pt_br stayAtPark_af2033bb:


    you "Ah! Ãhn..!"


translate pt_br stayAtPark_a20cefa7_6:


    "..."


translate pt_br stayAtPark_5aa3617c:


    "Bom. E não volte mais."


translate pt_br stayAtPark_8dabefc6_2:


    ".."


translate pt_br stayAtPark_a20cefa7_7:


    "..."


translate pt_br didntThrowFrisbee_632d1a35:


    you "!!!" with hpunch


translate pt_br didntThrowFrisbee_519d8628:


    "O cachorro de repente se lança em você, com raiva... {b}feroz{/b}..."


translate pt_br didntThrowFrisbee_ea9a7b78:


    "Ele arranca seus membros do seu {color=#FF0000}corpo-{/color}{w=0.6}{nw}"


translate pt_br didntThrowFrisbee_8ca8510a:


    you "!!!" with vpunch


translate pt_br didntThrowFrisbee_a20cefa7:


    "..."


translate pt_br didntThrowFrisbee_38dcb322:


    you "{i}Isso... {w}Isso foi real..?{/i}"


translate pt_br threwFrisbee_0420908d:


    "Você joga o frisbee e o cachorro corre na direção oposta..."


translate pt_br threwFrisbee_5d168864:


    "...saltando e o pegando no ar."


translate pt_br threwFrisbee_8dabefc6:


    ".."


translate pt_br threwFrisbee_a20cefa7:


    "..."


translate pt_br threwFrisbee_25aa3339:


    "Impressionante."


translate pt_br threwFrisbee_b51ea75d:


    "O cachorro e o dono andam até você."


translate pt_br threwFrisbee_d0cab412:


    who "Opa, valeu. Pode fazer carinho nele se quiser!"


translate pt_br threwFrisbee_8b661a0a:


    "O cachorro olha para você, ansioso pela sua recompensa de muito carinho por pegar o frisbee."


translate pt_br threwFrisbee_dae0ec55:


    you "..."


translate pt_br threwFrisbee_0cee522d:


    you "{i}Será que eu devo..?{/i}"


translate pt_br threwFrisbee_8dabefc6_1:


    ".."


translate pt_br threwFrisbee_a20cefa7_1:


    "..."


translate pt_br threwFrisbee_f5df0148:


    "Sábia decisão."


translate pt_br threwFrisbee_8dabefc6_2:


    ".."


translate pt_br threwFrisbee_a20cefa7_2:


    "..."


translate pt_br threwFrisbee_8dabefc6_3:


    ".."


translate pt_br threwFrisbee_a20cefa7_3:


    "..."


translate pt_br threwFrisbee_f5df0148_1:


    "Sábia decisão."


translate pt_br threwFrisbee_8dabefc6_4:


    ".."


translate pt_br threwFrisbee_a20cefa7_4:


    "..."


translate pt_br threwFrisbee_8dabefc6_5:


    ".."


translate pt_br threwFrisbee_a20cefa7_5:


    "..."


translate pt_br threwFrisbee_f5df0148_2:


    "Sábia decisão."


translate pt_br threwFrisbee_8dabefc6_6:


    ".."


translate pt_br threwFrisbee_a20cefa7_6:


    "..."


translate pt_br threwFrisbee_8dabefc6_7:


    ".."


translate pt_br threwFrisbee_a20cefa7_7:


    "..."


translate pt_br threwFrisbee_f5df0148_3:


    "Sábia decisão."


translate pt_br threwFrisbee_8dabefc6_8:


    ".."


translate pt_br threwFrisbee_a20cefa7_8:


    "..."


translate pt_br threwFrisbee_8dabefc6_9:


    ".."


translate pt_br threwFrisbee_a20cefa7_9:


    "..."


translate pt_br threwFrisbee_f5df0148_4:


    "Sábia decisão."


translate pt_br threwFrisbee_8dabefc6_10:


    ".."


translate pt_br threwFrisbee_a20cefa7_10:


    "..."


translate pt_br threwFrisbee_8dabefc6_11:


    ".."


translate pt_br threwFrisbee_a20cefa7_11:


    "..."


translate pt_br threwFrisbee_f5df0148_5:


    "Sábia decisão."


translate pt_br threwFrisbee_8dabefc6_12:


    ".."


translate pt_br threwFrisbee_a20cefa7_12:


    "..."


translate pt_br threwFrisbee_8dabefc6_13:


    ".."


translate pt_br threwFrisbee_a20cefa7_13:


    "..."


translate pt_br threwFrisbee_f5df0148_6:


    "Sábia decisão."


translate pt_br threwFrisbee_8dabefc6_14:


    ".."


translate pt_br threwFrisbee_a20cefa7_14:


    "..."


translate pt_br lastChance_a20cefa7:


    "..."


translate pt_br lastChance_be011780:


    "Sério?"


translate pt_br lastChance_12c3bc88:


    "Tem certeza?"


translate pt_br lastChance_8dabefc6:


    ".."


translate pt_br lastChance_a20cefa7_1:


    "..."


translate pt_br lastChance_e5bcb204:


    "Estou te avisando."


translate pt_br lastChance_7a59abb9:


    "{b}Não{/b} toque esse vira-lata..."


translate pt_br lastChance_3f44ff49:


    "{size=-10}...ou você {b}vai{/b} se arrepender.{/size}"


translate pt_br lastChance_8dabefc6_1:


    ".."


translate pt_br lastChance_a20cefa7_2:


    "..."


translate pt_br lastChance_6f0c5ba2:


    "{size=+5}{b}B o m.{/b}{/size}"


translate pt_br lastChance_8dabefc6_2:


    ".."


translate pt_br lastChance_a20cefa7_3:


    "..."


translate pt_br petTheDog_8dabefc6:


    ".."


translate pt_br petTheDog_a20cefa7:


    "..."


translate pt_br petTheDog_b546b376:


    "Você estende a mão..."


translate pt_br petTheDog_8dabefc6_1:


    ".."


translate pt_br petTheDog_a20cefa7_1:


    "..."


translate pt_br petTheDog_e3a5738f:


    "...e você faz carinho no {b}c a c h o r r o.{/b}"


translate pt_br petTheDog_dae0ec55:


    you "..."


translate pt_br petTheDog_2f6d34a3:


    dog "ARF! ARF!" with vpunch


translate pt_br petTheDog_2b8101ea:


    "O cachorro parece contente."


translate pt_br petTheDog_8dabefc6_2:


    ".."


translate pt_br petTheDog_a20cefa7_2:


    "..."


translate pt_br petTheDog_92c9b5da:


    "Você não se sente bem."


translate pt_br petTheDog_f8342e66:


    "De repente..."


translate pt_br petTheDog_8802d801:


    "...o céu começa a escurecer rapidamente."


translate pt_br petTheDog_73f12812:


    "Você olha para cima junto com todos os donos de pets e vê que o sol foi eclipsado pela lua num piscar de olhos."


translate pt_br petTheDog_ff907ae0:


    "Você se lembra vagamente de que nunca se deve olhar diretamente para um eclipse... {w}mas por alguma razão..."


translate pt_br petTheDog_906bee7c:


    "...você não desvia o olhar."


translate pt_br petTheDog_9ddc62b3:


    who "{size=+35}{b}REOWWWWRRRRR!!!{/b}{/size}" with vpunch


translate pt_br petTheDog_34554171:


    "Um rugido agudo e estridente enche o ar, fazendo o chão tremer sob você."


translate pt_br petTheDog_509639fb:


    "Você instintivamente se move para levantar suas mãos e proteger os ouvidos..."


translate pt_br petTheDog_bf0874e3:


    "Mas..."


translate pt_br petTheDog_4e2b93b2:


    "...mas a mão que estava cautelosamente apoiada na cabeça do cachorro sai com um pouco de..."


translate pt_br petTheDog_982bff5c:


    "...{b}resistência.{/b}"


translate pt_br petTheDog_990002ee:


    "...{i}Resistência{/i} quase como uma gosma pegajosa colando sua mão à cabeça do cachorro."


translate pt_br petTheDog_8ca8510a:


    you "!!!" with vpunch


translate pt_br petTheDog_2917a3d2:


    "A gosma se estica com seu movimento."


translate pt_br petTheDog_caf85056:


    "A {i}cabeça{/i} do cachorro também se estica... enquanto o cão começa a simplesmente..."


translate pt_br petTheDog_680a68f3:


    "...{b}derreter.{/b}"


translate pt_br petTheDog_8c69f73c:


    "Ele derrete..."


translate pt_br petTheDog_027c5d74:


    "E {b}derrete{/b}..."


translate pt_br petTheDog_8dabefc6_3:


    ".."


translate pt_br petTheDog_a20cefa7_3:


    "..."


translate pt_br petTheDog_d5860291:


    "...até virar uma substância pegajosa aos seus pés."


translate pt_br petTheDog_d1718122:


    you "Ah..! Ah..."


translate pt_br petTheDog_11b3323e:


    "Você olha em volta atordoado procurando o dono do cachorro, mas encontra só uma pilha vazia de roupas no lugar onde ele estava."


translate pt_br petTheDog_02dce559:


    "Você vê pilhas semelhantes de roupas ao lado de pilhas de gosma espalhadas por todo o parque."


translate pt_br petTheDog_91eaf471:


    "Todos os cachorros..."


translate pt_br petTheDog_ce3e3588:


    "E seus donos..."


translate pt_br petTheDog_a20cefa7_4:


    "..."


translate pt_br petTheDog_4b8cc143:


    "A gosma derretida do cachorro à sua frente então começa a se mover com um tremor."


translate pt_br petTheDog_632d1a35:


    you "!!!" with hpunch


translate pt_br petTheDog_ae1a0e2d:


    "Ela se arrasta pela grama em direção ao campo no centro do parque..."


translate pt_br petTheDog_9d855a0a:


    "{size=-5}Todas as outras pilhas de gosma a seguem...{/size}"


translate pt_br petTheDog_74d9ed3c:


    "Elas se misturam e se fundem em uma única entidade que se move, ondula, incha e {b}cresce{/b}..."


translate pt_br petTheDog_56ebb028:


    you "!!!"


translate pt_br petTheDog_14c0cd48:


    "Você assiste completamente horrorizado enquanto ela então toma forma e se molda..."


translate pt_br petTheDog_4f09ae08:


    "...em um cachorro{size=+5} {b}colossal{/b}{/size}."


translate pt_br petTheDog_f6366ef7:


    "Rosnando e espumando pela boca... os olhos vermelhos frenéticos, procurando..."


translate pt_br petTheDog_a20cefa7_5:


    "..."


translate pt_br petTheDog_40b96f53:


    "...até que as esferas brilhantes se fixam diretamente em você."


translate pt_br petTheDog_4a61b65e:


    who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}{w=0.2}{nw}" with hpunch


translate pt_br petTheDog_8d3a4df3:


    who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}{w=0.2}{nw}" with vpunch


translate pt_br petTheDog_3c469b8e:


    who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}" with hpunch


translate pt_br petTheDog_6f38f7c1:


    "O rosnado que sai é tão grave e profundo que você pode sentir o som se chocar contra você..."


translate pt_br petTheDog_8dabefc6_4:


    ".."


translate pt_br petTheDog_a20cefa7_6:


    "..."


translate pt_br petTheDog_bcf6dd4d:


    "Não."


translate pt_br petTheDog_6fc296fe:


    "Você teve sua chance."


translate pt_br petTheDog_7c3bd630:


    "{b}{size=-10}M e l h o r{/size}{size=+20} \ {/size}{size=-10}c o m e ç a r{/size}{size=+20} \ {/size}{size=-10}a \ c o r r e r~{/size}{/b}"


translate pt_br petTheDog_8dabefc6_5:


    ".."


translate pt_br petTheDog_a20cefa7_7:


    "..."


translate pt_br justRunDog_512655b9:


    "Você tenta correr."


translate pt_br justRunDog_a20cefa7:


    "..."


translate pt_br justRunDog_ecb852e9:


    "{size=-8}...Mas você não é rápido o bastante.{/size}"


translate pt_br justRunDog_16f8c477:


    "O colosso mal dá alguns saltos antes de já estar imponente sobre você."


translate pt_br justRunDog_8ca8510a:


    you "!!!" with vpunch


translate pt_br justRunDog_38a2a096:


    you "..!" with vpunch


translate pt_br justRunDog_fa171d08:


    you "..." with vpunch


translate pt_br justRunDog_8dabefc6:


    ".."


translate pt_br justRunDog_a20cefa7_1:


    "..."


translate pt_br justRunDog_cd0aadea:


    "Ele te despedaça até não sobrar {b}nada{/b}."


translate pt_br justRunDog_8dabefc6_1:


    ".."


translate pt_br justRunDog_a20cefa7_2:


    "..."


translate pt_br justRunDog_d7087055:


    "Final 21: prefiro \ {color=#FF0000}c a c h o r r o s{/color}"


translate pt_br turnedBack_f75320e6:


    "Você suspira e volta para o gato."


translate pt_br turnedBack_d26d3e42:


    cat "Miau! Mrriaauuu!" with hpunch


translate pt_br turnedBack_08f3a6f7:


    "Ele parece quase esperançoso... seu rabo balança mais rápido enquanto ele se inclina um pouco mais na sua direção..."


translate pt_br turnedBack_3df2e65f:


    "...como se estivesse ansioso pelo seu próximo movimento.."


translate pt_br stayWithCat_dae0ec55:


    you "..."


translate pt_br stayWithCat_cba272fa:


    "...Esquisito."


translate pt_br stayWithCat_9be0e991:


    "Quanto mais você hesita sair do beco... mais você se pergunta..."


translate pt_br stayWithCat_17dfe7fb:


    "...{i}\"Qual é o sentido disso?\"{/i}"


translate pt_br stayWithCat_a7dcd07a:


    "Você vai para {i}onde?{/i}"


translate pt_br stayWithCat_1c44447e:


    "Fazer {i}o quê?{/i}"


translate pt_br stayWithCat_3e3445a0:


    "Qual é o sentido, quando você sempre faz tudo completamente, totalmente {i}sozinho?{/i}"


translate pt_br stayWithCat_780c15a3:


    "Nem mesmo voltar para o seu apartamento ajudaria, ajudaria...?"


translate pt_br stayWithCat_247ad3ce:


    "Um quarto. Um banheiro."


translate pt_br stayWithCat_2b464023:


    "...Só {i}você{/i} sozinho vivendo nele."


translate pt_br stayWithCat_53cba332:


    "Tem sido assim por tanto, tanto tempo..."


translate pt_br stayWithCat_a20cefa7:


    "..."


translate pt_br stayWithCat_2ce5ae19:


    "{i}Tanto{/i} tempo..."


translate pt_br stayWithCat_aa965c11:


    cat "Miauu..."


translate pt_br stayWithCat_38a2a096:


    you "..!" with vpunch


translate pt_br stayWithCat_cb2e56dc:


    "Você se assusta quando sente uma patinha incrivelmente macia pressionar levemente sua bochecha molhada."


translate pt_br stayWithCat_a20cefa7_1:


    "..."


translate pt_br stayWithCat_e92a5260:


    "Você não tinha percebido que estava chorando."


translate pt_br stayWithCat_6b313aa1:


    "Ou que sua pequena crise literalmente te colocou de joelhos... bem na frente da caixa do gato."


translate pt_br stayWithCat_7a5c58a5:


    "Você se sente um pouco envergonhado, mas o gato reage como se pudesse sentir seus sentimentos autodepreciativos surgindo."


translate pt_br stayWithCat_fbbaa7ef:


    cat "Miau! Miauu!" with hpunch


translate pt_br stayWithCat_59ede497:


    "Ele pressiona a pata em sua bochecha bem rápido três vezes seguidas..."


translate pt_br stayWithCat_b17e43f8:


    "...como se estivesse tentando te dar uns tapas para te tirar do seu estado melancólico..."


translate pt_br stayWithCat_11b3d26b:


    "...mas são tão leves que os tapas parecem mais uns carinhos ansiosamente suaves."


translate pt_br stayWithCat_dae0ec55_1:


    you "..."


translate pt_br stayWithCat_c1ba2b2d:


    you "Heh... Hehe..."


translate pt_br stayWithCat_c169d67d:


    "Você não consegue evitar de soltar um riso."


translate pt_br stayWithCat_43d916f4:


    you "Não acredito que tô tendo um colapso nesse beco sujo e velho... com um gato de rua me consolando..."


translate pt_br stayWithCat_e5fab8a0:


    cat "Miau!"


translate pt_br stayWithCat_a0caf1eb:


    "Você sorri e demonstra sua gratidão fazendo um carinho no queixo do gato."


translate pt_br stayWithCat_67107e6c:


    cat "Purr..."


translate pt_br stayWithCat_b6d97d6f:


    you "Valeu... Tô bem, sério. Isso acontece às vezes..."


translate pt_br stayWithCat_16879ce5:


    cat "Miau?"


translate pt_br stayWithCat_b9131292:


    you "Eu realmente {i}gosto{/i} de estar sozinho a maior parte do tempo."


translate pt_br stayWithCat_638b0480:


    you "É o único momento que me sinto confortável em ser eu mesmo, sabe?"


translate pt_br stayWithCat_bac70924:


    you "...Mas até {i}eu{/i} me sinto solitário de vez em quando."


translate pt_br stayWithCat_5bf669ab:


    you "É fácil de ignorar quando eu me mantenho ocupado..."


translate pt_br stayWithCat_2ba4676d:


    you "Por isso que eu me forcei a sair hoje, eu acho..."


translate pt_br stayWithCat_085f82bc:


    cat "Miau..."


translate pt_br stayWithCat_94d526e4:


    you "Heh, ou talvez eu esperasse fazer um amigo ou algo assim..."


translate pt_br stayWithCat_7393f44f:


    you "...mas acho que isso não seria uma boa ideia."


translate pt_br stayWithCat_623ea201:


    you "Duvido que alguém como eu seria um bom amigo pra qualquer pessoa..."


translate pt_br stayWithCat_33634540:


    cat "Miau! Miau! {i}Miau!{/i}" with hpunch


translate pt_br stayWithCat_37101878:


    you "Hehehe! Ok, ok, talvez eu não vá tão longe a ponto de dizer {i}isso,{/i} mas..."


translate pt_br stayWithCat_8dabefc6:


    ".."


translate pt_br stayWithCat_a20cefa7_2:


    "..."


translate pt_br stayWithCat_e7e24fe2:


    "Você fica."


translate pt_br stayWithCat_319a0073:


    "Você fica e só... conversa com o gato."


translate pt_br stayWithCat_16f8a04a:


    "Sobre qualquer coisa que vier à mente."


translate pt_br stayWithCat_42df3336:


    "Seu isolamento... {w}sua solidão..."


translate pt_br stayWithCat_297381cd:


    "Seus muitos medos... {w}suas derrotas... {w}seu {i}vazio{/i}..."


translate pt_br stayWithCat_8dc6e13c:


    "Embora..."


translate pt_br stayWithCat_ecd85097:


    "Quanto mais você fica ali, menor a solidão que antes parecia tão significativa."


translate pt_br stayWithCat_bd68e443:


    "Já faz tempo desde que alguém simplesmente... ouviu."


translate pt_br stayWithCat_152f4e90:


    "Suas palavras mudam para tópicos mais tranquilos..."


translate pt_br stayWithCat_ae2b8e89:


    "Suas esperanças... {w}seus sonhos... {w}memórias felizes do passado..."


translate pt_br stayWithCat_92865e06:


    "Enquanto você fala, você nem percebe que as frias e duras paredes de concreto do beco se tornaram algo parecido com carne... {w}quente e rosada..."


translate pt_br stayWithCat_87393f7d:


    "...sua maciez lentamente envolve vocês dois."


translate pt_br stayWithCat_8a1fe200:


    "O som da sua própria voz parece hipnótico quando alcança seus ouvidos..."


translate pt_br stayWithCat_fff68cb0:


    "...te encorajando a falar mais sobre as profundezas do seu coração..."


translate pt_br stayWithCat_0e2e8677:


    "Você se entrega facilmente..."


translate pt_br stayWithCat_e7e1c877:


    "Quando você {i}realmente{/i} fica sem palavras, não tem certeza de quanto tempo passou sentado ali."


translate pt_br stayWithCat_0e608ebb:


    "Mas não saber não parece te incomodar."


translate pt_br stayWithCat_b3e12ea5:


    "Ainda assim..."


translate pt_br stayWithCat_eb93532e:


    "Uma pergunta estranha entra na sua mente..."


translate pt_br stayForever_8dabefc6:


    ".."


translate pt_br stayForever_a20cefa7:


    "..."


translate pt_br stayForever_dae0ec55:


    you "..."


translate pt_br stayForever_30bd3818:


    you "{i}Por que eu faria isso..?{/i}"


translate pt_br stayForever_a654ceef:


    "Você está cansado demais para se mover."


translate pt_br stayForever_9655b73f:


    "Se abrir de coração e alma te deixou acabado, mas você não se arrepende."


translate pt_br stayForever_411ac15d:


    "Você está tão..."


translate pt_br stayForever_27a37757:


    "...feliz."


translate pt_br stayForever_1fa1c68c:


    "Você nunca se sentiu tão ouvido..."


translate pt_br stayForever_177b5180:


    "Tão {i}visto{/i}..."


translate pt_br stayForever_925e7315:


    "Você se inclina para descansar a cabeça na caixa."


translate pt_br stayForever_0acae387:


    "Não sente o papelão áspero que esperava..."


translate pt_br stayForever_4d5b0ea2:


    "Em vez disso, sua cabeça encontra um amontoado de... {i}algo...{/i}"


translate pt_br stayForever_a51bed06:


    "Algo macio, ligeiramente úmido e quente."


translate pt_br stayForever_b873f6ae:


    "Tão, tão, {i}tão{/i} quente..."


translate pt_br stayForever_e8057081:


    "Mas você não consegue se importar com o que isso poderia ser."


translate pt_br stayForever_bc4c2b4d:


    "Você está... tão cansado."


translate pt_br stayForever_dec216e1:


    "Você fecha os olhos..."


translate pt_br stayForever_bcb743d5:


    "...e você sente que provavelmente eles nunca mais vão se abrir."


translate pt_br stayForever_9fb636b8:


    "Mas conforme aquele calor envolvente te abraça lentamente, {i}completamente{/i}..."


translate pt_br stayForever_a20cefa7_1:


    "..."


translate pt_br stayForever_6c8098ae:


    "...Você não sente nada além de puro contentamento."


translate pt_br stayForever_8dabefc6_1:


    ".."


translate pt_br stayForever_a20cefa7_2:


    "..."


translate pt_br stayForever_2dacdaff:


    "Final 22: Não Estou Sozinho"


translate pt_br leaveCat2_62d83bb2:


    "Você {i}realmente{/i} não pode arcar com o custo de levar o gato para casa."


translate pt_br leaveCat2_bfab167e:


    "Bom..."


translate pt_br leaveCat2_35db1bfe:


    "Talvez não seja {i}completamente{/i} impossível..."


translate pt_br leaveCat2_45d354de:


    "Só cortar alguns luxos aqui e ali e você pode dar um jeito, com certeza."


translate pt_br leaveCat2_b03adc09:


    "Mas há um probleminha que tem te feito hesitar esse tempo todo..."


translate pt_br leaveCat2_0af247dd:


    "Um que você simplesmente não pode ignorar."


translate pt_br leaveCat2_8335c1ba:


    "O problema é..."


translate pt_br leaveCat2_a20cefa7:


    "..."


translate pt_br leaveCat2_e43e2eb3:


    "{size=-10}...que você não consegue confiar nesse gato.{/size}"


translate pt_br leaveCat2_dae0ec55:


    you "..."


translate pt_br leaveCat2_9bd5d3d6:


    "Isso soa ridículo até na sua cabeça."


translate pt_br leaveCat2_35a1162a:


    "Gatos não precisam de confiança para serem cuidados."


translate pt_br leaveCat2_6e2bb326:


    "Eles são incapazes de trair ou enganar especificamente porque, como outros animais..."


translate pt_br leaveCat2_4a2b5d96:


    "eles buscam apenas o básico para viver, reprodução e conforto."


translate pt_br leaveCat2_03e4f8cf:


    "Malícia não é algo que poderia ser logicamente atribuído a eles..."


translate pt_br leaveCat2_da78fda5:


    "E ainda assim..."


translate pt_br leaveCat2_c353258e:


    "Você sente."


translate pt_br leaveCat2_172fd88c:


    "Que por trás daquela carinha que dá vontade de apertar de tão fofa..."


translate pt_br leaveCat2_95ccc501:


    "...há algo perigoso."


translate pt_br leaveCat2_f41ec9ee:


    "E esse \"algo\"... trouxe você aqui."


translate pt_br leaveCat2_6b709127:


    "{i}Chamou{/i} você aqui."


translate pt_br leaveCat2_cc7203ce:


    "Você é uma pessoa curiosa, mas nem mesmo {i}você{/i} consegue ignorar o profundo desejo instintivo de-"


translate pt_br leaveCat2_7844b763:


    "{size=-10}se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso {/size}"


translate pt_br leaveCat2_dae0ec55_1:


    you "..."


translate pt_br leaveCat2_7f0ac95c:


    cat "..."


translate pt_br leaveCat2_ec8eee8f:


    "A face do gato parece vazia."


translate pt_br leaveCat2_f138e706:


    "É uma expressão que você já viu em muitos gatos antes, mas algo nela parece..."


translate pt_br leaveCat2_9232c2e0:


    "{size=-5}{i}...mais incisivo.{/i}{/size}"


translate pt_br leaveCat2_f9e83d9e:


    "Como se estivesse ciente dos seus pensamentos e da sua intenção de ir embora..."


translate pt_br leaveCat2_26b934d7:


    "...e estivesse desafiando você a {b}tentar.{/b}"


translate pt_br leaveCat2_dae0ec55_2:


    you "..."


translate pt_br leaveCat2_1d0166ae:


    "Você lentamente se levanta."


translate pt_br leaveCat2_428f29c1:


    "O gato acompanha seus movimentos com os olhos, sem se dar ao trabalho de mover a cabeça."


translate pt_br leaveCat2_0e2ae1c1:


    "Você não diz uma palavra."


translate pt_br leaveCat2_7ca87e19:


    "Você tenta nem pensar..."


translate pt_br leaveCat2_7844b763_1:


    "{size=-10}se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso {/size}"


translate pt_br leaveCat2_a20cefa7_1:


    "..."


translate pt_br leaveCat2_58e3ca69:


    "...embora não tenha muito sucesso."


translate pt_br leaveCat2_8fd85953:


    "Você se vira e sai rapidamente do beco, sentindo aqueles olhos penetrantes em você por todo o caminho."


translate pt_br leaveCat2_ec6bd7ee:


    "Quando você pega uma boa distância, finalmente consegue respirar fundo."


translate pt_br leaveCat2_83668abb:


    you "*ofegante*... *ofegante*... *ofegante*..."


translate pt_br leaveCat2_a20cefa7_2:


    "..."


translate pt_br leaveCat2_0f5de544:


    "Você..."


translate pt_br leaveCat2_9d5e507d:


    "Você se sente melhor agora."


translate pt_br leaveCat2_336142e1:


    "E ainda há muito tempo para aproveitar seu dia de folga!"


translate pt_br leaveCat2_8dabefc6:


    ".."


translate pt_br leaveCat2_a20cefa7_3:


    "..."


translate pt_br leaveCat2_e666a796:


    "Contanto que você esqueça tudo que acabou de acontecer."


translate pt_br leaveCat2_33744274:


    "{b}Mas o que fazer?{/b}"


translate pt_br getAway1_e4612ec1:


    you "..!"


translate pt_br getAway1_7f0ac95c:


    cat "..."


translate pt_br getAway1_71b06060:


    "Mas que..?!"


translate pt_br getAway1_5fd62bd2:


    "Como você voltou aqui?!"


translate pt_br getAway1_a20cefa7:


    "..."


translate pt_br getAway1_f2809dbd:


    "{size=-10}{color=#FF0000}se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso {/color}{/size}"


translate pt_br getAway1_8dabefc6:


    ".."


translate pt_br getAway1_a20cefa7_1:


    "..."


translate pt_br getAway1_d4f2db8f:


    "Você deixa o beco. {i}Rapidamente.{/i}"


translate pt_br getAway1_8dabefc6_1:


    ".."


translate pt_br getAway1_a20cefa7_2:


    "..."


translate pt_br getAway1_bcf48cbf:


    "E agora..?"


translate pt_br getAway2_e4612ec1:


    you "..!"


translate pt_br getAway2_7f0ac95c:


    cat "..."


translate pt_br getAway2_82f0e91d:


    "A cara do gato parece..."


translate pt_br getAway2_a20cefa7:


    "..."


translate pt_br getAway2_f2809dbd:


    "{size=-10}{color=#FF0000}se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso {/color}{/size}"


translate pt_br getAway2_8dabefc6:


    ".."


translate pt_br getAway2_a20cefa7_1:


    "..."


translate pt_br getAway2_d4f2db8f:


    "Você deixa o beco. {i}Rapidamente.{/i}"


translate pt_br getAway2_8dabefc6_1:


    ".."


translate pt_br getAway2_a20cefa7_2:


    "..."


translate pt_br getAway2_bcf48cbf:


    "E agora..?"


translate pt_br getAway3_e4612ec1:


    you "..!"


translate pt_br getAway3_7f0ac95c:


    cat "..."


translate pt_br getAway3_82f0e91d:


    "A cara do gato parece..."


translate pt_br getAway3_a20cefa7:


    "..."


translate pt_br getAway3_f2809dbd:


    "{size=-10}{color=#FF0000}se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso {/color}{/size}"


translate pt_br getAway3_8dabefc6:


    ".."


translate pt_br getAway3_a20cefa7_1:


    "..."


translate pt_br getAway3_d4f2db8f:


    "Você deixa o beco. {i}Rapidamente.{/i}"


translate pt_br getAway3_8dabefc6_1:


    ".."


translate pt_br getAway3_a20cefa7_2:


    "..."


translate pt_br getAway3_bcf48cbf:


    "E agora..?"


translate pt_br getAway4_dd4a8909:


    you "..!" with hpunch


translate pt_br getAway4_7f0ac95c:


    cat "..."


translate pt_br getAway4_82f0e91d:


    "A cara do gato parece..."


translate pt_br getAway4_90b93b6a:


    "Está..."


translate pt_br getAway4_a20cefa7:


    "..."


translate pt_br getAway4_f2809dbd:


    "{size=-10}{color=#FF0000}se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso {/color}{/size}"


translate pt_br getAway4_52402223:


    cat "{b}miau miau miau miau miau miau miau miau miau miau miau miau miau miau{/b}"


translate pt_br getAway4_8dabefc6:


    ".."


translate pt_br getAway4_a20cefa7_1:


    "..."


translate pt_br getAway4_d4f2db8f:


    "Você deixa o beco. {i}Rapidamente.{/i}"


translate pt_br getAway4_8dabefc6_1:


    ".."


translate pt_br getAway4_a20cefa7_2:


    "..."


translate pt_br getAway4_bcf48cbf:


    "E agora..?"


translate pt_br goToMoviesFAKE_74698f4f:


    "Já faz um tempo que lançou um filme que parecesse interessante o suficiente para você ir ao cinema..."


translate pt_br goToMoviesFAKE_16041c5e:


    "...mas um desses filmes está passando no cinema antigo."


translate pt_br goToMoviesFAKE_86d53b16:


    "Era nichado demais para ser exibido no cinema novo que abriu bem do outro lado da rua."


translate pt_br goToMoviesFAKE_b01bac60:


    "Mas tudo bem. Você não é exatamente fã de multidões."


translate pt_br goToMoviesFAKE_6430cdc2:


    "E nada estraga mais a experiência de assistir a um filme novo para você do que um público barulhento."


translate pt_br oldTheaterFAKE_2c8cdd54:


    "Você compra ansiosamente seu ingresso com o gentil senhor na bilheteira e entra..."


translate pt_br oldTheaterFAKE_8dabefc6:


    ".."


translate pt_br oldTheaterFAKE_a20cefa7:


    "..."


translate pt_br newCinemaFAKE_927147c9:


    "Você não sabe porque...{w} mas você não se sente muito bem com a idea de estar sozinho agora."


translate pt_br newCinemaFAKE_fb646a70:


    "Decidindo esperar o filme que você tanto aguardava ficar disponível em DVD ou em streaming..."


translate pt_br newCinemaFAKE_e6448215:


    "...você entra na longa fila do lado de fora do cinema novo."


translate pt_br newCinemaFAKE_0f82186d:


    "Quando você finalmente chega à bilheteria, só quer entrar logo..."


translate pt_br newCinemaFAKE_78abbe21:


    "...então você escolhe um filme qualquer e pega o ingresso com o adolescente aparentemente cansado que cuida da bilheteria."


translate pt_br newCinemaFAKE_259b126d:


    "Você entra..."


translate pt_br newCinemaFAKE_8dabefc6:


    ".."


translate pt_br newCinemaFAKE_a20cefa7:


    "..."


translate pt_br goToCarnivalFAKE_54663883:


    "Você passa o dia no festival."


translate pt_br goToCarnivalFAKE_295775c9:


    "Roda-gigante, montanha-russa, barco viking... {w}Brinquedos nos quais você já esteve antes."


translate pt_br goToCarnivalFAKE_0d9e8fc3:


    "Basquete de arcade, arremesso de moedas, dardos... {w}Jogos que você já jogou antes."


translate pt_br goToCarnivalFAKE_32a40a6e:


    "Bolo de funil, pipoca, algodão doce... {w}Comidas que você já comeu antes."


translate pt_br goToCarnivalFAKE_d6de1944:


    "Você já fez tudo isso {i}antes.{/i}"


translate pt_br goToCarnivalFAKE_c3c9efe7:


    "Você está rodeado de grupos de pessoas se divertindo entre si..."


translate pt_br goToCarnivalFAKE_7598c0f4:


    "Rindo, brincando, comendo, tirando fotos... Criando memórias..."


translate pt_br goToCarnivalFAKE_b0255334:


    "E aí está você."


translate pt_br goToCarnivalFAKE_a20cefa7:


    "..."


translate pt_br goToCarnivalFAKE_a7421486:


    "O sol ainda não começou a se pôr, está ainda bem alto no céu, mas logo vai."


translate pt_br goToCarnivalFAKE_527d7f2b:


    "Você começa a se perguntar se talvez não seria melhor ir para casa por hoje...{w} quando para abruptamente."


translate pt_br goToCarnivalFAKE_2f469756:


    "Você vê algo...{w} {i}novo.{/i} {w}Uma atração que nunca tinha visto antes."


translate pt_br goToCarnivalFAKE_ee0a18bc:


    "Um labirinto... de espelhos?"


translate pt_br goToCarnivalFAKE_c0de53a5:


    "Parece..."


translate pt_br goToCarnivalFAKE_3a26a699:


    "...meio sem graça, honestamente"


translate pt_br goToCarnivalFAKE_4686437f:


    "Nem tem fila para entrar."


translate pt_br goToCarnivalFAKE_a20cefa7_1:


    "..."


translate pt_br goToCarnivalFAKE_cbb84cc7:


    "Mas então... {w}o que mais há para fazer..?"


translate pt_br enteringMazeFAKE_d4f61e22:


    "Você entra no labirinto..."


translate pt_br enteringMazeFAKE_8dabefc6:


    ".."


translate pt_br enteringMazeFAKE_a20cefa7:


    "..."


translate pt_br goToDogParkFAKE_5c14c202:


    "Você decide dar uma volta em um parque ou algo assim."


translate pt_br goToDogParkFAKE_184323de:


    "O único que dá para ir a pé é o parque para cachorros ali perto."


translate pt_br goToDogParkFAKE_31ab9223:


    "Você acha que vai te fazer se sentir melhor."


translate pt_br goToDogParkFAKE_b35402c8:


    "Primeiro você viu um gato fofo hoje, agora vai poder ver um cachorro fofo!"


translate pt_br goToDogParkFAKE_a749d8ba:


    "{i}Vários{/i} deles, na verdade."


translate pt_br goToDogParkFAKE_3d36b825:


    "O parque está movimentado com os donos e seus companheiros caninos."


translate pt_br goToDogParkFAKE_615bff09:


    "Brincando de frisbee, de ir buscar, correndo, pulando, e até tirando uma soneca~!"


translate pt_br goToDogParkFAKE_479e8904:


    "Que fofuras-{w=0.5}{nw}"


translate pt_br goToDogParkFAKE_9b32ff27:


    "{size=+25}{b}{i}CACHORROS SÃO NOJENTOS!!{/i}{/b}{/size}{w=0.8}{nw}" with hpunch


translate pt_br goToDogParkFAKE_f222b266:


    "{size=+30}{b}{i}TODOS ELES DEVIAM MORREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEER!!{/i}{/b}{/size}{w=0.8}{nw}" with vpunch


translate pt_br goToDogParkFAKE_3d1b02dc:


    you "{i}!!!{/i}" with vpunch


translate pt_br goToDogParkFAKE_8dabefc6:


    ".."


translate pt_br goToDogParkFAKE_a20cefa7:


    "..."


translate pt_br goToDogParkFAKE_0f5de544:


    "Você..."


translate pt_br goToDogParkFAKE_a20cefa7_1:


    "..."


translate pt_br goToDogParkFAKE_b21fc0cc:


    "{size=-8}Você decide seguir em frente.{/size}"


translate pt_br goToDogParkFAKE_c5900d2a:


    "Os cachorros são todos tão adoráveis. Você quer fazer carinho em cada um que encontra..."


translate pt_br goToDogParkFAKE_e4211dcf:


    "...mas você sabe que nem todos os donos gostam de estranhos se aproximando e pegando nos seus animais."


translate pt_br goToDogParkFAKE_4f5fba4a:


    "Nem todos os cachorros gostam disso também."


translate pt_br goToDogParkFAKE_4f7be349:


    "Então você dá uma volta, tentando exalar uma aura acolhedora que atraia um desses cachorrinhos fofos até você."


translate pt_br goToDogParkFAKE_3dd44abb:


    "Você não precisa esperar muito."


translate pt_br goToDogParkFAKE_8dabefc6_1:


    ".."


translate pt_br goToDogParkFAKE_a20cefa7_2:


    "..."


translate pt_br goToDogParkFAKE_08c12ebd:


    "Você para quando o menor e mais fofo filhote que você já viu corre até você, bloqueando seu caminho~"


translate pt_br pickUpPupFAKE_a20cefa7:


    "..."


translate pt_br pickUpPupFAKE_b6fd4c68:


    "Você pega o filhote e-"


translate pt_br pickUpPupFAKE_8dabefc6:


    ".."


translate pt_br pickUpPupFAKE_a20cefa7_1:


    "..."


translate pt_br escapeAlley_71862052:


    "...Espera."


translate pt_br escapeAlley_754ba1f6:


    "Você não..."


translate pt_br escapeAlley_9c5945d1:


    "Você não fez isso antes?"


translate pt_br escapeAlley_a20cefa7:


    "..."


translate pt_br escapeAlley_eda5b581:


    "Você sente um mal-estar."


translate pt_br escapeAlley_a9ce0125:


    "Olhando em volta, você de repente percebe que, diferente de antes..."


translate pt_br escapeAlley_09fb1093:


    "...não há uma única pessoa à vista."


translate pt_br escapeAlley_39499d9b:


    "Você está sozinho."


translate pt_br escapeAlley_107c4642:


    "Você está {i}completamente{/i} sozinho..."


translate pt_br escapeAlley_a20cefa7_1:


    "..."


translate pt_br escapeAlley_2d017637:


    "{size=-10}...Então, por que você sente que está sendo observado agora?{/size}"


translate pt_br escapeAlley_dae0ec55:


    you "..."


translate pt_br escapeAlley_24944022:


    "Você sente seu coração começar a acelerar."


translate pt_br escapeAlley_167183bf:


    "Você precisa ir para casa."


translate pt_br escapeAlley_e42d7264:


    "{b}Agora.{/b}"


translate pt_br escapeAlley_d2c662af:


    "Você volta para casa, com a sensação de estar sendo observado pelas costas piorando a cada passo."


translate pt_br escapeAlley_c746b9ce:


    "Enquanto tenta encontrar as chaves na porta, você está ficando encharcado de suor frio."


translate pt_br escapeAlley_c6dde281:


    "Sua pele começa a coçar e formigar..."


translate pt_br escapeAlley_173b31a9:


    "...o olhar pesado que você sente é quase como se os olhos estivessem pressionando fisicamente sua carne... {w}pegajoso e sobrenatural."


translate pt_br escapeAlley_a73461a6:


    "Você finalmente consegue entrar e..."


translate pt_br escapeAlley_8dabefc6:


    ".."


translate pt_br escapeAlley_a20cefa7_2:


    "..."


translate pt_br escapeAlley_bfcb9214:


    you "Haaahhhh..!" with hpunch


translate pt_br escapeAlley_9200f492:


    "O alívio que você sente ao suspirar é tão {b}grande{/b} que você fica completamente {i}arrepiado.{/i}"


translate pt_br escapeAlley_9a73ee02:


    "Aquela sensação horrível de antes desaparece imediatamente, como se nunca tivesse estado lá."


translate pt_br escapeAlley_940938e5:


    "Após esse sentimento sumir, você começa a tremer e sentir frio nas roupas encharcadas de suor..."


translate pt_br escapeAlley_d1777533:


    "...mas está tão aliviado que não se importa."


translate pt_br escapeAlley_c0c88e96:


    "Exausto, você {i}sequer{/i} cogita a ideia de comer e vai direto para o seu quarto."


translate pt_br escapeAlley_dae0ec55_1:


    you "..."


translate pt_br escapeAlley_935de6d6:


    "Você abre a porta, pronto para cair no sono imediat--{w=0.75}{nw}"


translate pt_br escapeAlley_7f0ac95c:


    cat "..."


translate pt_br escapeAlley_8ca8510a:


    you "!!!" with vpunch


translate pt_br escapeAlley_b640810c:


    "De novo não! Não..."


translate pt_br escapeAlley_cbb4eb55:


    "{size=+25}NÃO!{/size}" with vpunch


translate pt_br escapeAlley_e96e16bd:


    "Você recua com medo... {w}seus olhos se fixam no gato e no seu sorriso aterrorizante."


translate pt_br escapeAlley_42a6e76b:


    "Você precisa fugir."


translate pt_br escapeAlley_20a8bb11:


    "Você precisa ir embora."


translate pt_br escapeAlley_cc7f2700:


    "Mas se nem mesmo sua {b}casa{/b} está segura..."


translate pt_br escapeAlley_b120d39e:


    "Para onde você {i}vai{/i}..?"


translate pt_br escapeAlley_a013ff83:


    "Você arrisca um olhar ao seu redor e-"


translate pt_br escapeAlley_8ca8510a_1:


    you "!!!" with vpunch


translate pt_br escapeAlley_9f28660e:


    "Você vê que as paredes ao seu redor criaram carne e estão cheias de dentes afiados..."


translate pt_br escapeAlley_e633f9bf:


    "O chão agora é uma língua se contorcendo sob seus pés..."


translate pt_br escapeAlley_69312007:


    "Horrorizado, você percebe que a entrada do beco está ficando cada vez menor..."


translate pt_br escapeAlley_eb65f2ee:


    "{i}Fechando{/i}... {w}como uma boca..."


translate pt_br escapeAlley_51da09f7:


    "Você tenta correr até a saída..."


translate pt_br escapeAlley_650717a6:


    "{size=-10}{i}impossível se esconder impossível se esconder impossível se esconder impossível se esconder impossível se esconder impossível se esconder impossível se esconder impossível se esconder impossível se esconder {/i}{/size}"


translate pt_br escapeAlley_9bb38d7d:


    "...mas tentar correr na língua diminui sua velocidade significativamente, fazendo você tropeçar e cair."


translate pt_br escapeAlley_546d120e:


    you "{size=-8}Não...{/size}"


translate pt_br escapeAlley_5ad13b7d:


    "Você observa impotente enquanto o último feixe de luz da entrada diminui para um tamanho que você nunca conseguiria passar..."


translate pt_br escapeAlley_e8c1286e:


    "À medida que a escuridão cai sobre você... {w}você sente a umidade da boca ao seu redor..."


translate pt_br escapeAlley_634c4b03:


    "As paredes... as paredes de dentes... {i}presas...{/i}"


translate pt_br escapeAlley_dbef0163:


    "...demoram a se fechar."


translate pt_br escapeAlley_624b526a:


    "Fechando cada mais..."


translate pt_br escapeAlley_57fba23d:


    "E mais..."


translate pt_br escapeAlley_12317a15:


    "E-{w=0.2}{nw}"


translate pt_br escapeAlley_632d1a35:


    you "!!!" with hpunch


translate pt_br escapeAlley_dae0ec55_2:


    you "..."


translate pt_br escapeAlley_8dabefc6_1:


    ".."


translate pt_br escapeAlley_a20cefa7_3:


    "..."


translate pt_br escapeAlley_59e53cf3:


    "Final 23: Ciclo sem fim"


translate pt_br feedAlley_60ed29e3:


    "O gato deve estar com fome, certo?"


translate pt_br feedAlley_ca7535de:


    "Você imagina que ele não tenha comido muito se está tão apegado àquela caixa em que está."


translate pt_br feedAlley_15894b36:


    "Embora... ele também não pareça desnutrido..."


translate pt_br feedAlley_91d870df:


    "Certamente ele {i}deve{/i} ter saído da caixa para procurar comida, não é..?"


translate pt_br feedAlley_a20cefa7:


    "..."


translate pt_br feedAlley_63420a88:


    "Por alguma razão... algo no fundo da sua mente diz que não é esse o caso."


translate pt_br feedAlley_f8c64864:


    "{size=-10}...E que é melhor não pensar mais sobre isso.{/size}"


translate pt_br feedAlley_dae0ec55:


    you "..."


translate pt_br feedAlley_d93fe1cb:


    "Bom, de qualquer forma..."


translate pt_br feedAlley_b7ea0fa5:


    "Você não pode curtir seu dia sabendo que deixou um gato com fome para trás."


translate pt_br feedAlley_0d1b62a9:


    "Especialmente quando poderia ter feito algo para ajudar."


translate pt_br feedAlleyMenu_42b896f8:


    "Então..."


translate pt_br feedAlleyMenu_949c2306:


    "O que fazer a respeito do gatinho faminto?"


translate pt_br feedAlleyMenu_a2c5487f:


    "Ainda não..."


translate pt_br feedPockets_5cfb3464:


    "Você revira os bolsos."


translate pt_br feedPockets_f8c73033:


    "Você encontra um pequeno pedaço de linha no bolso esquerdo. Não vai ajudar muito."


translate pt_br feedPockets_ab3079c6:


    "A linha é curta demais."


translate pt_br feedPockets_c0209341:


    "Um gato ansioso e animado pulando para pegá-la facilmente levaria você a ser{w=1.0}{nw}"


translate pt_br feedPockets_632d1a35:


    you "!!!" with hpunch


translate pt_br feedPockets_8dabefc6:


    ".."


translate pt_br feedPockets_a20cefa7:


    "..."


translate pt_br feedPockets_f42805d9:


    "Um gato ansioso e animado pulando para pegá-la facilmente levaria você a ser mordido e arranhado."


translate pt_br feedPockets_f8cb7b4a:


    "No seu bolso direito..."


translate pt_br feedPockets_d38263f6:


    "{size=-10}...tem uma barra de {color=#FF0000}chocolate.{/color}{/size}"


translate pt_br feedPockets_f3654da7:


    "{size=-5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}descul {/size}{w=0.2}{nw}"


translate pt_br feedPockets_dae0ec55:


    you "..."


translate pt_br feedPockets_31772800:


    "...tem uma barra de chocolate."


translate pt_br feedPockets_3d145f61:


    "Você encontra uma {i}barra de chocolate?!{/i}"


translate pt_br feedPockets_1bd01551:


    "Será que..? Nem, Não tá nem vencida!"


translate pt_br feedPockets_7ee41c3c:


    "Um baita achado, de fato!"


translate pt_br feedPockets_5fd3d678:


    "Você está prestes a oferecer ao gato..."


translate pt_br feedPockets_632d1a35_1:


    you "!!!" with hpunch


translate pt_br feedPockets_f4a2553e:


    "...quando, de repente, você é tomado pela culpa ao se lembrar de algo que revira seu estômago..."


translate pt_br feedPockets_a20cefa7_1:


    "..."


translate pt_br feedPockets_c0157c69:


    "Chocolate é {color=#FF0000}{b}tóxico{/b}{/color} para gatos."


translate pt_br feedPockets_8abfb425:


    you "Meu Deus! Eu..."


translate pt_br feedPockets_44e1c462:


    "Você resiste ao impulso de vomitar diante do erro que quase cometeu."


translate pt_br feedPockets_71316bbd:


    "Você se sente tão culpado que joga a barra de chocolate em uma lixeira próxima."


translate pt_br feedPockets_3c3040ce:


    "Um quase assassino de gatos não merece chocolate."


translate pt_br feedPockets_87694524:


    "Você volta para o gato, mal conseguindo suportar sua expressão inocente e alheia."


translate pt_br feedPockets_16879ce5:


    cat "Miau?"


translate pt_br feedPockets_dae0ec55_1:


    you "..."


translate pt_br feedPockets_2c29b15f:


    "Ele nem sabe que você quase..."


translate pt_br feedPockets_a20cefa7_2:


    "..."


translate pt_br feedPockets_f37947e9:


    you "Eu... Eu sinto muito... Eu nem sei o que dizer..."


translate pt_br feedPockets_8b57cab4:


    cat "Miauuu?"


translate pt_br feedPockets_a20cefa7_3:


    "..."


translate pt_br feedPockets_5cd20361:


    "você é uma pessoa {b}h o r r í v e l{/b}..."


translate pt_br feedPockets_0bfbcb68:


    you "...Q-Quer saber? Fica paradinho aí, eu já volto!"


translate pt_br feedPockets_16879ce5_1:


    cat "Miau?"


translate pt_br feedPockets_ab8229b4:


    "Você deixa o beco..."


translate pt_br feedPockets_8dabefc6_1:


    ".."


translate pt_br feedPockets_a20cefa7_4:


    "..."


translate pt_br feedPockets_82310cee:


    "...E volta com um {i}peixe inteiro{/i} que você comprou em um mercadinho próximo."


translate pt_br feedPockets_3926ea50:


    "Foi um pouco caro..."


translate pt_br feedPockets_2b3ea52c:


    "{size=-8}...mas era o {b}mínimo{/b} que você podia fazer.{/size}"


translate pt_br feedPockets_ec1974d4:


    cat "Miau!" with hpunch


translate pt_br feedPockets_8c4b404a:


    "O gato aceita seu presente com entusiasmo, mastigando contentemente o peixe depois que você o colocou na caixa."


translate pt_br feedPockets_1c62c81c:


    cat "Miau! Miau! Miau!!" with hpunch


translate pt_br feedPockets_be47b116:


    "Você gostaria de sorrir ao ver isso, mas se sente..."


translate pt_br feedPockets_b690d28d:


    "...{i}péssimo.{/i}"


translate pt_br feedPockets_d14a2a5b:


    you "...D-Desculpa de novo."


translate pt_br feedPockets_dd5772de:


    "O gato aparentemente não presta muita atenção em você enquanto você sai do beco."


translate pt_br feedPockets_7b39a56c:


    "Sentindo que não merece ter um dia tranquilo, você decide voltar para casa."


translate pt_br feedPockets_8dabefc6_2:


    ".."


translate pt_br feedPockets_a20cefa7_5:


    "..."


translate pt_br feedPockets_730bba6f:


    who "Reow..."


translate pt_br feedPockets_90b68c87:


    you "..?"


translate pt_br feedPockets_3c4d90d1:


    "No caminho para casa, você percebe mais gatos do que o normal, o observando de seus esconderijos..."


translate pt_br feedPockets_905314c8:


    "...mas você tenta não pensar muito nisso."


translate pt_br feedPockets_2d48655c:


    "Você não consegue deixar de se perguntar..."


translate pt_br feedPockets_c4bde9d1:


    "...se eles sabem o que você quase {b}fez.{/b}"


translate pt_br feedPockets_bf0874e3:


    "Mas..."


translate pt_br feedPockets_703b363c:


    "Não é como se você tivesse a intenção de machucar alguém..."


translate pt_br feedPockets_c53bacd0:


    "{size=-8}...certo?{/size}"


translate pt_br feedPockets_8dabefc6_3:


    ".."


translate pt_br feedPockets_a20cefa7_6:


    "..."


translate pt_br feedPockets_3eb6f147:


    "Finalmente chegando ao seu prédio, você está prestes a destrancar a porta quando..."


translate pt_br feedPockets_0fcae0c9:


    who "Reow... Reow... Reowwww...!"


translate pt_br feedPockets_90b68c87_1:


    you "..?"


translate pt_br feedPockets_8ca8510a:


    you "!!!" with vpunch


translate pt_br feedPockets_eefed842:


    "Você olha para trás... e vê {i}dezenas{/i} de gatos parados ali."


translate pt_br feedPockets_3c7fb7cb:


    "Olhando para você."


translate pt_br feedPockets_4184a661:


    "Será que eles viram você alimentando o gato no beco e acharam que você tinha comida para todos eles..?"


translate pt_br feedPockets_f32454e0:


    you "Foi... Foi mal, não tenho mais comida para vocês..."


translate pt_br feedPockets_4bb08b75:


    "Nenhum deles move um centímetro."


translate pt_br feedPockets_7f4239d9:


    "Você começa a ficar um pouco desconfortável, até que, finalmente, um único gato dá um passo para frente e..."


translate pt_br feedPockets_7f0ac95c:


    cat "..."


translate pt_br feedPockets_06197af2:


    you "Ah! É vo-!"


translate pt_br feedPockets_8ca8510a_1:


    you "!!!" with vpunch


translate pt_br feedPockets_9ed134ce:


    "Oh..."


translate pt_br feedPockets_90b93b6a:


    "Está..."


translate pt_br feedPockets_a20cefa7_7:


    "..."


translate pt_br feedPockets_3f4e0e68:


    "Cuidadosamente colocada entre seus dentes está a barra de chocolate que você havia jogado fora antes."


translate pt_br feedPockets_ba9d5a1b:


    "Ele coloca a barra de chocolate no chão à sua frente antes de olhar de volta para você."


translate pt_br feedPockets_0fa5f48b:


    "{i}Todos{/i} os gatos olham para você..."


translate pt_br feedPockets_a20cefa7_8:


    "..."


translate pt_br feedPockets_cb8b1ea4:


    "{size=-5}Você consegue sentir o julgamento deles...{/size}"


translate pt_br feedPockets_ca13fffe:


    you "!!" with hpunch


translate pt_br feedPockets_8ca8510a_2:


    you "!!!" with vpunch


translate pt_br feedPockets_61c83dbb:


    "Você sente seus pecados pesando sobre suas costas."


translate pt_br feedPockets_3a1db100:


    "Mas sem dinheiro para comprar comida suficiente para todos eles..."


translate pt_br feedPockets_f1fb8cef:


    "Você não sabe o que fazer..."


translate pt_br begForgive_c11b9ea5:


    "Você cai de joelhos e se curva, começando a implorar sinceramente pelo perdão deles."


translate pt_br begForgive_5d26ba72:


    you "Sinto muito! Eu juro!" with vpunch


translate pt_br begForgive_11f39ee6:


    you "Eu... Eu faria qualquer coisa para compensar, mas...!"


translate pt_br begForgive_0b6b468c:


    "...mas você está sem opções."


translate pt_br begForgive_f8342e66:


    "De repente..."


translate pt_br begForgive_b3351a0a:


    you "Argh! Hmp! *engasgo*!!" with vpunch


translate pt_br begForgive_1a0306e2:


    "Você sente algo se agitar em seu estômago e subir até a sua garganta..."


translate pt_br begForgive_9d069fba:


    "...fechando suas vias aéreas enquanto tenta forçar a saída pelo seu esôfago."


translate pt_br begForgive_f00aa018:


    you "Bl-Blgh!" with vpunch


translate pt_br begForgive_7e07a3c9:


    "Finalmente consegue, com a ajuda da sua ânsia."


translate pt_br begForgive_c76c10fb:


    you "Blergh!!" with hpunch


translate pt_br begForgive_dae0ec55:


    you "..."


translate pt_br begForgive_90b68c87:


    you "..?"


translate pt_br begForgive_632d1a35:


    you "!!!" with hpunch


translate pt_br begForgive_9035e3f2:


    you "{size=-8}Mas... que...?{/size}"


translate pt_br begForgive_30e5bd77:


    "Caído no chão à sua frente..."


translate pt_br begForgive_3c6fad90:


    "...está um peixe se debatendo."


translate pt_br begForgive_0fa59e4c:


    "Você simplesmente... {w}vomitou um peixe {i}vivo{/i}..."


translate pt_br begForgive_2e05a79f:


    you "{size=-8}Mas que porra...?{/size}"


translate pt_br begForgive_28305204:


    "Os gatos avançam, todos famintos, atacando o peixe com voracidade."


translate pt_br begForgive_23a3bbe5:


    "Você está..."


translate pt_br begForgive_a360cc29:


    "Você está {i}feliz{/i} por finalmente poder ajudar, de verdade... {w}mas como-{w=0.2}{nw}"


translate pt_br begForgive_d69064ca:


    you "Blergh!!" with vpunch


translate pt_br begForgive_8dabefc6:


    ".."


translate pt_br begForgive_a20cefa7:


    "..."


translate pt_br begForgive_15d57735:


    "...Você vomita outro peixe."


translate pt_br begForgive_c76c10fb_1:


    you "Blergh!!" with hpunch


translate pt_br begForgive_27069f53:


    "E outro..."


translate pt_br begForgive_c76c10fb_2:


    you "Blergh!!" with hpunch


translate pt_br begForgive_f2db7641:


    "E {i}outro{/i}..."


translate pt_br begForgive_c76c10fb_3:


    you "Blergh!!" with hpunch


translate pt_br begForgive_cb64e404:


    "E..."


translate pt_br begForgive_a20cefa7_1:


    "..."


translate pt_br begForgive_dbd6d155:


    "Seu estômago dói. {w}Você está ficando... tonto."


translate pt_br begForgive_971a5312:


    "Você se ajoelha..."


translate pt_br begForgive_fe9dfa69:


    "Lágrimas e muco escorrem pelo seu rosto quando você tosse um último, pequeno e {i}{color=#FF0000}ensanguentado{/color}{/i} peixe e cai para trás."


translate pt_br begForgive_a7387d16:


    "Sua garganta e estômago {i}queimam{/i} de um jeito que parece perigoso.."


translate pt_br begForgive_0f08eefa:


    "Você começa a apagar..."


translate pt_br begForgive_21f2fb4d:


    "Apesar da dor..."


translate pt_br begForgive_2585da06:


    "...estranhamente, você sente um grande orgulho, que te enche de esperança."


translate pt_br begForgive_56367ba7:


    "Que você compensou suas ações {b}repugnantes{/b}..."


translate pt_br begForgive_f0ecbc05:


    "...Que você foi perdoado."


translate pt_br begForgive_edbc3af1:


    "O som dos gatos felizes comendo seus peixes enche seus ouvidos..."


translate pt_br begForgive_f64ee9d8:


    "Até que..."


translate pt_br begForgive_5bfd48b0:


    "...você sente algo sendo empurrado para dentro da sua mão."


translate pt_br begForgive_f3f141f9:


    "Parece que..."


translate pt_br begForgive_28b3ac41:


    you "!!"


translate pt_br begForgive_5da9aa6a:


    "É a barra de chocolate que você achou no seu bolso."


translate pt_br begForgive_dae0ec55_1:


    you "..."


translate pt_br begForgive_10d5d7ff:


    you "{size=-8}H-Heh...{/size}"


translate pt_br begForgive_254220ed:


    "Você sorri com dificuldade."


translate pt_br begForgive_08515ef1:


    "Você conseguiu se redimir, mas não tem forças para comer sua recompensa."


translate pt_br begForgive_aa483b68:


    "Infelizmente, o último gosto em sua boca ao deixar este mundo não é o de chocolate..."


translate pt_br begForgive_5408dec4:


    "...mas de peixe cru."


translate pt_br begForgive_a20cefa7_2:


    "..."


translate pt_br begForgive_1ecfdb72:


    "Final 24: {i}Pesco{/i} desculpas"


translate pt_br leaveHungryCats_919a1f52:


    "Você decide deixar pra lá e entrar."


translate pt_br leaveHungryCats_32bb90cb:


    "Seus pecados pesam sobre você, mas você é humano. O que mais poderia fazer?"


translate pt_br leaveHungryCats_8f6616fa:


    you "{i}Pô...{/i}"


translate pt_br leaveHungryCats_e7b16877:


    "Você tenta ignorar os miados dos gatos da vizinhança enquanto faz suas tarefas."


translate pt_br leaveHungryCats_5a3d572d:


    "Você pensa em preparar o jantar..."


translate pt_br leaveHungryCats_b1727d2d:


    "...mas como poderia aproveitá-lo sabendo o quanto aqueles pobres gatos lá fora estão com fome?"


translate pt_br leaveHungryCats_d620406e:


    "Gatos esses que você deixou pra trás?"


translate pt_br leaveHungryCats_4814405d:


    "Você decide tomar um banho e ir direto para cama {b}sem{/b} jantar."


translate pt_br leaveHungryCats_f9c0255f:


    "Uma punição adequada para alguém como você."


translate pt_br leaveHungryCats_ae952792:


    "Você abre mão do luxo das bolhas de banho porque acha que não merece e afunda na água com um suspiro."


translate pt_br leaveHungryCats_ff1845cf:


    "Seus pensamentos disparam, mas você não consegue pensar em nenhuma solução imediata que não precise de dinheiro."


translate pt_br leaveHungryCats_2bf55488:


    "Você queria que tivesse algo, {i}qualquer coisa{/i}, que você pudesse fazer para consertar as coisas."


translate pt_br leaveHungryCats_3e71eb84:


    "De repente... {w}suas pernas começam a coçar muito."


translate pt_br leaveHungryCats_17310a3f:


    "Você tenta levantar uma para ver o que está acontecendo, mas o que sai da água não são pernas..."


translate pt_br leaveHungryCats_8ca8510a:


    you "!!!" with vpunch


translate pt_br leaveHungryCats_67f84009:


    "É...{w} É uma cauda de peixe..?"


translate pt_br leaveHungryCats_867810a1:


    "Você... Você fica tonto ao ver aquilo... Talvez esteja alucinando por causa do estresse?"


translate pt_br leaveHungryCats_a20cefa7:


    "..."


translate pt_br leaveHungryCats_5c9b6efd:


    "Você tenta sair da banheira para esfriar a cabeça... mas, em vez de sua mão se levantar para se apoiar..."


translate pt_br leaveHungryCats_d0c358fd:


    "...uma barbatana molhada se estica e bate na borda da banheira."


translate pt_br leaveHungryCats_c20b4b4f:


    "Ela é muito fraca para sustentar seu peso, e você fica tão assustado com a visão..."


translate pt_br leaveHungryCats_479c3431:


    you "!!" with vpunch


translate pt_br leaveHungryCats_dae0ec55:


    you "..."


translate pt_br leaveHungryCats_34e36922:


    "...que você escorrega e bate a cabeça na borda, desmaiando quase imediatamente."


translate pt_br leaveHungryCats_8dabefc6:


    ".."


translate pt_br leaveHungryCats_a20cefa7_1:


    "..."


translate pt_br leaveHungryCats_08a2bbac:


    "Você está... acordado. Pelo menos, é o que {i}acha{/i}."


translate pt_br leaveHungryCats_15f20a2c:


    "Você abre os olhos e..."


translate pt_br leaveHungryCats_36e9324f:


    "..? Você está.. debaixo d'água..?"


translate pt_br leaveHungryCats_80806592:


    "..! Você deve ter escorregado para baixo da superfície da água do banho! Você ofega instintivamente."


translate pt_br leaveHungryCats_29b1a09a:


    "...Mas não foi bem isso."


translate pt_br leaveHungryCats_e46f8488:


    "Uma bolha simplesmente flutua para fora da sua boca... subindo, subindo, {i}subindo{/i} até a superfície."


translate pt_br leaveHungryCats_424a2cfe:


    "Você mal tem onde cair morto, então {i}sabe{/i} que sua banheira não é {i}tão{/i} grande assim."


translate pt_br leaveHungryCats_9e0f57e7:


    "Você..?"


translate pt_br leaveHungryCats_a20cefa7_2:


    "..."


translate pt_br leaveHungryCats_a2da44e5:


    "Você... {w}{b}encolheu?{/b}"


translate pt_br leaveHungryCats_eac07da9:


    "Mas {i}como?{/i}"


translate pt_br leaveHungryCats_e1102cc4:


    "E mesmo que houvesse uma resposta razoável..."


translate pt_br leaveHungryCats_09da957d:


    "...ainda não explicaria como você ainda não se {b}afogou{/b}..."


translate pt_br leaveHungryCats_6d9bb603:


    "Você nada até a borda da banheira e vê a verdade na silhueta da sua sombra..."


translate pt_br leaveHungryCats_28b3ac41:


    you "!!"


translate pt_br leaveHungryCats_18e23bb0:


    "Você... {w}virou um {i}{b}peixe?!{/b}{/i}"


translate pt_br leaveHungryCats_be932f7f:


    you "{i}{size=-5}Isso... Isso não é {b}possível{/b}...{/size}{/i}"


translate pt_br leaveHungryCats_06e0acd2:


    "Infelizmente, você não tem tempo para refletir sobre esse infortúnio..."


translate pt_br leaveHungryCats_2c77c5b6:


    "Porque, naquele instante.."


translate pt_br leaveHungryCats_6274a0c8:


    "...uma sombra se projeta sobre você."


translate pt_br leaveHungryCats_16744c4a:


    "Você olha para cima e vê... o gato?"


translate pt_br leaveHungryCats_7a9ce7a5:


    "Ele olha para você de além da superfície da água..."


translate pt_br leaveHungryCats_dae0ec55_1:


    you "..."


translate pt_br leaveHungryCats_8ca8510a_1:


    you "!!!" with vpunch


translate pt_br leaveHungryCats_a20cefa7_3:


    "..."


translate pt_br leaveHungryCats_637fa4bd:


    "E então..."


translate pt_br leaveHungryCats_1141e85b:


    "Então você {i}percebe.{/i}"


translate pt_br leaveHungryCats_3613f8e2:


    "{b}Essa{/b} é a resposta..."


translate pt_br leaveHungryCats_c16f4226:


    "Assim... {w}é como você deve se redimir."


translate pt_br leaveHungryCats_dae0ec55_2:


    you "..."


translate pt_br leaveHungryCats_2387281a:


    "Com o coração pesado..."


translate pt_br leaveHungryCats_a20cefa7_4:


    "..."


translate pt_br leaveHungryCats_23382f12:


    "...você nada até a superfície."


translate pt_br leaveHungryCats_c44e377e:


    cat "Miauu!" with hpunch


translate pt_br leaveHungryCats_479c3431_1:


    you "!!" with vpunch


translate pt_br leaveHungryCats_49411296:


    "O gato te pega, te jogando para fora da banheira, sobre os azulejos do banheiro."


translate pt_br leaveHungryCats_3c17e5ed:


    "Enquanto você se debate, ofegando por ar..."


translate pt_br leaveHungryCats_26f6c95f:


    "(ou água..?)"


translate pt_br leaveHungryCats_74646257:


    "...você percebe que o gato não está sozinho."


translate pt_br leaveHungryCats_5fa71d4e:


    "Dezenas de olhos famintos olham para você de cima."


translate pt_br leaveHungryCats_6494036d:


    "Você pode ouvir o miado do que parece ser centenas de gatos do lado de fora da janela do banheiro."


translate pt_br leaveHungryCats_2c0a5c25:


    "Você lança um último olhar para o gato antes de fechar os olhos e aceitar seu destino."


translate pt_br leaveHungryCats_716c98f8:


    "À medida que os gatos descem sobre você, rasgando sua carne..."


translate pt_br leaveHungryCats_d6080537:


    "...você se vê lamentando o fato..."


translate pt_br leaveHungryCats_a20cefa7_5:


    "..."


translate pt_br leaveHungryCats_4d9c1486:


    "{size=-6}...de que nem mesmo é grande o suficiente para alimentar todos eles.{/size}"


translate pt_br leaveHungryCats_75e13727:


    "Mesmo no final..."


translate pt_br leaveHungryCats_6e125249:


    "...você não pôde se redimir adequadamente."


translate pt_br leaveHungryCats_0328dbd4:


    "Seus esforços, sua {i}vida{/i}..."


translate pt_br leaveHungryCats_9f0317b6:


    "Tudo isso..."


translate pt_br leaveHungryCats_a20cefa7_6:


    "..."


translate pt_br leaveHungryCats_d2cc2d23:


    "...não valeu {b}nada{/b}."


translate pt_br leaveHungryCats_8dabefc6_1:


    ".."


translate pt_br leaveHungryCats_a20cefa7_7:


    "..."


translate pt_br leaveHungryCats_06568472:


    "Final 25: Sacrifício de Frutos do Mar"


translate pt_br feedLookAround_6adec316:


    "Você olha ao redor do beco escuro e sujo..."


translate pt_br feedLookAround_172f73ee:


    "...e só vê sacos de lixo, latas de lixo, caixas de papelão vazias e sujeira espalhada aqui e ali."


translate pt_br feedLookAround_8a2477ca:


    "Se houvesse algo para o gato comer, com certeza ele já teria encontrado, certo?"


translate pt_br feedLookAround_1c7afc63:


    "Mas você não quer desistir tão fácil."


translate pt_br feedLookAround_1b9dbcae:


    "Você continua procurando."


translate pt_br feedLookAround_37ccdc14:


    "Olha e só vê lixo."


translate pt_br feedLookAround_7206a2c2:


    "Cheira e só sente o odor de lixo."


translate pt_br feedLookAround_15a42f3c:


    "Ouve..."


translate pt_br feedLookAround_8dabefc6:


    ".."


translate pt_br feedLookAround_a20cefa7:


    "..."


translate pt_br feedLookAround_8a367b77:


    "{size=-10}*scritch* *scritch*{/size}"


translate pt_br feedLookAround_a513413e:


    "..!"


translate pt_br feedLookAround_4f966ec3:


    "Você mal consegue distinguir o som de passos rápidos e leves perto de uma lixeira a alguns metros de distância."


translate pt_br feedLookAround_b659571e:


    "Silenciosamente... Muito silenciosamente... você se arrasta até a lixeira..."


translate pt_br feedLookAround_cb64e404:


    "E..."


translate pt_br feedLookAround_8dabefc6_1:


    ".."


translate pt_br feedLookAround_a20cefa7_1:


    "..."


translate pt_br feedLookAround_a513413e_1:


    "..!"


translate pt_br feedLookAround_d8c7093a:


    "{size=+5}Você {i}salta!{/i}{/size}"


translate pt_br feedLookAround_d304d4e5:


    "{size=+20}{b}CRASH!!{/b}{/size}" with vpunch


translate pt_br feedLookAround_a20cefa7_2:


    "..."


translate pt_br feedLookAround_2ea47ee5:


    "O pouso não foi muito gracioso."


translate pt_br feedLookAround_262f7f90:


    "Você tropeçou e derrubou uma pilha de caixas próximas, cheias de mais lixo, {w}mas ao se levantar..."


translate pt_br feedLookAround_5398ed86:


    "...apanhado na sua mão..."


translate pt_br feedLookAround_a20cefa7_3:


    "..."


translate pt_br feedLookAround_7d0b6abb:


    "...está um ratinho."


translate pt_br feedLookAround_9db0dda0:


    rat "Squeak! Squeak!" with vpunch


translate pt_br feedLookAround_2f69184a:


    "O rato chia e grita de aflição, se contorcendo e debatendo desesperadamente em sua mão."


translate pt_br feedLookAround_bb6730d7:


    "Você o está segurando com muita firmeza e cuidado, para que ele não possa te morder ou arranhar."


translate pt_br feedLookAround_204f821b:


    "Eventualmente, ele se cansa e olha para você com esses olhinhos pretos..."


translate pt_br feedLookAround_a20cefa7_4:


    "..."


translate pt_br feedLookAround_0d800538:


    "Está {i}completamente{/i} à sua mercê."


translate pt_br spareMouse_085f82bc:


    cat "Miau..."


translate pt_br spareMouse_37478095:


    "Você... tem certeza?"


translate pt_br spareMouse2_9cad6637:


    cat "Miauuuu..."


translate pt_br spareMouse2_317daa48:


    "Você pode ouvir o estômago do gato roncando."


translate pt_br spareMouse2_3b182f71:


    "Deve estar tão faminto..."


translate pt_br spareMouse2_302b36d5:


    "Deve estar {b}morrendo{/b} de fome..."


translate pt_br spareMouse3_2cea6c44:


    ".{w=1.0}.{w=1.0}.{w=1.0}{nw}"


translate pt_br spareMouse3_8c265d6b:


    cat "{size=+10}{b}MIAAU!{/b}{/size}" with hpunch


translate pt_br spareMouse3_b7235e3b:


    "Você sabe que o gato está com fome."


translate pt_br spareMouse3_33159e4f:


    "Por que está hesitando?"


translate pt_br spareMouse3_f002086d:


    "Você pegou a presa por causa do gato, não foi?"


translate pt_br spareMouse3_e75c361b:


    "Você realmente vai valorizar mais a vida de um rato imundo do que a do gato?"


translate pt_br spareMouse4_8dabefc6:


    ".."


translate pt_br spareMouse4_a20cefa7:


    "..."


translate pt_br spareMouse4_ee44cce1:


    "{size=-8}{color=#FF0000}Tá de sacanagem, né?{/color}{/size}"


translate pt_br spareMouse4_dd07c1d2:


    "Última chance..."


translate pt_br spareMouse4_8f248444:


    "E n t r e g a... {w}a... {w}p r e s a... {w}..."


translate pt_br spareMouse4_e7eb980b:


    "{b}{color=#FF0000}Agora.{/color}{/b}"


translate pt_br freeMouse_8dabefc6:


    ".."


translate pt_br freeMouse_a20cefa7:


    "..."


translate pt_br freeMouse_85bf2796:


    "Você solta o rato."


translate pt_br freeMouse_2dd146aa:


    "Ele corre, se espremendo em um pequeno buraco na parede..."


translate pt_br freeMouse_dac972a5:


    "Mas você não presta muita atenção."


translate pt_br freeMouse_edd804dd:


    "Você não se surpreende quando uma enorme pata com garras lentamente cai na sua frente..."


translate pt_br freeMouse_27890332:


    "...bloqueando seu caminho para a entrada do beco..."


translate pt_br freeMouse_19d2abd9:


    "Não que você tivesse alguma ilusão de escapar."


translate pt_br freeMouse_a20cefa7_1:


    "..."


translate pt_br freeMouse_c4176d5e:


    "O gato está com fome, afinal de contas."


translate pt_br freeMouse_3e1401c3:


    "Você fecha os olhos em aceitação enquanto a pata gentilmente te puxa para trás..."


translate pt_br freeMouse_068b5ee7:


    "E para trás..."


translate pt_br freeMouse_057a9a91:


    "E-{w=0.175}{nw}"


translate pt_br freeMouse_cc8fcc0d:


    "{size=+20}{b}CHOMP!!{/b}{/size}" with hpunch


translate pt_br freeMouse_8dabefc6_1:


    ".."


translate pt_br freeMouse_a20cefa7_2:


    "..."


translate pt_br freeMouse_8b12d547:


    "Final 26: Uma vida poupada"


translate pt_br feedCatMouse_927f34df:


    "O rato parece assustado, como se pudesse sentir suas intenções."


translate pt_br feedCatMouse_7313e03e:


    "Ele tenta se debater novamente, mas sem força."


translate pt_br feedCatMouse_ff457211:


    rat "{size=+10}SQUEAK! SQUEAK! {b}SQUEEEAAK!!{/b}{/size}" with hpunch


translate pt_br feedCatMouse_8dabefc6:


    ".."


translate pt_br feedCatMouse_a20cefa7:


    "..."


translate pt_br feedCatMouse_ca6ee73d:


    "{size=-10}O rato está hesitante.{/size}"


translate pt_br feedCatMouse2_8dabefc6:


    ".."


translate pt_br feedCatMouse2_a20cefa7:


    "..."


translate pt_br feedCatMouse2_32660fc9:


    "Você dá o rato para o gato comer."


translate pt_br feedCatMouse2_0e994b53:


    cat "Miauuu!" with hpunch


translate pt_br feedCatMouse2_d59fd9a8:


    "O gato o despedaça instantaneamente..."


translate pt_br feedCatMouse2_ff68e97c:


    rat "SQUEAK!" with hpunch


translate pt_br feedCatMouse2_b09043ec:


    rat "SQUEAK! {b}SQUEEEAAK!!{/b}" with hpunch


translate pt_br feedCatMouse2_02199255:


    rat "SQUE-{w=0.175}{nw}" with hpunch


translate pt_br feedCatMouse2_a20cefa7_1:


    "..."


translate pt_br feedCatMouse2_6240b97d:


    "Os chiados de dor do rato atravessam você até serem abruptamente interrompidos."


translate pt_br feedCatMouse2_5318aee4:


    "Satisfeito, o gato mia feliz para você, com as presas pintadas de vermelho."


translate pt_br feedCatMouse2_b003a621:


    cat "Miauu!"


translate pt_br feedCatMouse2_dae0ec55:


    you "..."


translate pt_br feedCatMouse2_50910e06:


    "O gato se enrola na sua caixa agora manchada de sangue e adormece."


translate pt_br feedCatMouse2_dae0ec55_1:


    you "..."


translate pt_br feedCatMouse2_f737576e:


    "Você aproveita a chance para sair."


translate pt_br feedCatMouse2_10a52902:


    "Um gato bem alimentado provavelmente vai te seguir até em casa, no fim das contas..."


translate pt_br feedCatMouse2_991cb618:


    "...e por mais que o gato seja fofo, você..."


translate pt_br feedCatMouse2_a20cefa7_2:


    "..."


translate pt_br feedCatMouse2_2316a09e:


    "...você realmente não pode manter um pet agora."


translate pt_br feedCatMouse2_8045cc18:


    "Ainda se sentindo meio culpado pelo rato, você decide ir para casa."


translate pt_br feedCatMouse2_dae0ec55_2:


    you "..."


translate pt_br feedCatMouse2_a20cefa7_3:


    "..."


translate pt_br feedCatMouse2_dae0ec55_3:


    you "..."


translate pt_br feedCatMouse2_a20cefa7_4:


    "..."


translate pt_br feedCatMouse2_dae0ec55_4:


    you "..."


translate pt_br feedCatMouse2_0338822b:


    "Após uma longa caminhada para casa, você finalmente entra em seu apartamento..."


translate pt_br feedCatMouse2_99073e13:


    "Você segue direto para seu quarto..."


translate pt_br feedCatMouse2_fead6e35:


    "...e capota na cama, caindo em um sono leve e perturbado."


translate pt_br feedCatMouse2_8dabefc6_1:


    ".."


translate pt_br feedCatMouse2_a20cefa7_5:


    "..."


translate pt_br feedCatMouse2_9669528e:


    "Mais tarde..."


translate pt_br feedCatMouse2_0e0f046c:


    "Você acorda..."


translate pt_br feedCatMouse2_3ef36ef7:


    "{size=-5}*arranha* *arranha*{/size}"


translate pt_br feedCatMouse2_aed29e03:


    who "{size=-5}squeak squeak squeak...{/size}"


translate pt_br feedCatMouse2_75fd645a:


    "...com sons de chiados e correria em {b}toda{/b} a sua volta..."


translate pt_br feedCatMouse2_731d880d:


    "...tão altos e constantes que parecem {i}gritos.{/i}."


translate pt_br feedCatMouse2_3502244d:


    "Na escuridão do seu quarto..."


translate pt_br feedCatMouse2_a20cefa7_6:


    "..."


translate pt_br feedCatMouse2_3b018980:


    "...você vê as sombras em movimento de {b}{i}centenas{/i}{/b} de ratos cercando sua cama."


translate pt_br feedCatMouse2_56ebb028:


    you "!!!"


translate pt_br feedCatMouse2_a55f18e5:


    "Você tenta correr..."


translate pt_br feedCatMouse2_8ca8510a:


    you "!!!" with vpunch


translate pt_br feedCatMouse2_5c6c5752:


    you "AHH!" with vpunch


translate pt_br feedCatMouse2_2ffa7999:


    "Mas você grita ao sentir uma dor lancinante subindo pelas suas pernas."


translate pt_br feedCatMouse2_a5230802:


    "Você cai da cama ao tentar fugir..."


translate pt_br feedCatMouse2_d6ce36d0:


    "...as hordas de ratos desviam de você enquanto você despenca no chão."


translate pt_br feedCatMouse2_0f5de544:


    "Você..."


translate pt_br feedCatMouse2_a20cefa7_7:


    "..."


translate pt_br feedCatMouse2_ea714275:


    "{size=-8}Você não consegue ficar de pé.{/size}"


translate pt_br feedCatMouse2_191bfb14:


    "Olhando para trás e forçando a vista na escuridão, {w}você consegue quase distinguir a fonte da sua dor..."


translate pt_br feedCatMouse2_4b8f74bf:


    "A carne e os tendões dos seus calcanhares e tornozelos estão mutilados..."


translate pt_br feedCatMouse2_017438eb:


    "{b}Mordidos{/b} através das suas meias..."


translate pt_br feedCatMouse2_2f0d3863:


    you "N-Não... Não! M-Me deixa em paz..!" with hpunch


translate pt_br feedCatMouse2_af41a66d:


    "Desesperado, você rasteja apenas com os braços em direção à porta..."


translate pt_br feedCatMouse2_8dabefc6_2:


    ".."


translate pt_br feedCatMouse2_a20cefa7_8:


    "..."


translate pt_br feedCatMouse2_bc2fabcc:


    "Os ratos descem sobre você..."


translate pt_br feedCatMouse2_8ca8510a_1:


    you "!!!" with vpunch


translate pt_br feedCatMouse2_21d8e99a:


    "...mordendo sua pele."


translate pt_br feedCatMouse2_8ca8510a_2:


    you "!!!" with vpunch


translate pt_br feedCatMouse2_f62320f5:


    "Roendo {b}pedaços{/b} de você..."


translate pt_br feedCatMouse2_dae0ec55_5:


    you "..."


translate pt_br feedCatMouse2_9943b33e:


    "Você começa a desmaiar e a voltar à consciência..."


translate pt_br feedCatMouse2_efcd9d02:


    "...mas ainda estende a mão em direção à maçaneta..."


translate pt_br feedCatMouse2_2cb23dbf:


    "...seu braço pesado, pressionado pelos ratos que se agarram a ele com suas garras pequenas e dentes minúsculos."


translate pt_br feedCatMouse2_fb2f2154:


    "Você consegue girar a maçaneta o suficiente para que a porta se abra lentamente..."


translate pt_br feedCatMouse2_7128cb1f:


    "*PLOP!*" with hpunch


translate pt_br feedCatMouse2_a20cefa7_9:


    "..."


translate pt_br feedCatMouse2_50f50169:


    "...Mas seu braço estendido de repente cai no chão, sem vida."


translate pt_br feedCatMouse2_56ebb028_1:


    you "!!!"


translate pt_br feedCatMouse2_f764243f:


    "Os ratos conseguiram roer a carne e o osso do seu membro agora desmembrado."


translate pt_br feedCatMouse2_3b178dd0:


    "Enquanto alguns ratos se aproximam curiosamente para examinar seu braço, você o encara em estado de choque por um momento antes de desviar o olhar para cima."


translate pt_br feedCatMouse2_9ffc28d3:


    "Na porta recém-aberta, está um..."


translate pt_br feedCatMouse2_40d9ca73:


    "..?"


translate pt_br feedCatMouse2_6d3f28fc:


    "...rato? Familiar..."


translate pt_br feedCatMouse2_115c17a3:


    "Ele te encara."


translate pt_br feedCatMouse2_95e298fc:


    "A escuridão em seus olhos pretos e brilhantes... {w}Você não consegue nem medir sua profundidade..."


translate pt_br feedCatMouse2_a20cefa7_10:


    "..."


translate pt_br feedCatMouse2_bb419a8e:


    "Nem o ódio que emana de dentro deles..."


translate pt_br feedCatMouse2_9f0317b6:


    "Tudo isso..."


translate pt_br feedCatMouse2_fa45f11e:


    "...direcionado a {b}você.{/b}"


translate pt_br feedCatMouse2_63539327:


    you "A-Ah..."


translate pt_br feedCatMouse2_11499480:


    "Você desaba, batendo a cabeça no chão enquanto seu outro braço também é devorado."


translate pt_br feedCatMouse2_771b6f54:


    "Você não sabe como ainda está consciente. A dor deveria ser indescritível..."


translate pt_br feedCatMouse2_595186a8:


    "E ainda assim... você sente apenas uma fria sensação de perda..."


translate pt_br feedCatMouse2_33bce6c6:


    "Os ratos agora estão agrupados nas suas costas..."


translate pt_br feedCatMouse2_c3e0a8e8:


    "...roendo e rasgando um caminho entre suas escápulas..."


translate pt_br feedCatMouse2_8019dadd:


    "Para suas costas... Para seu {i}peito--{/i}"


translate pt_br feedCatMouse2_632d1a35:


    you "!!!" with hpunch


translate pt_br feedCatMouse2_bfc63f92:


    you "*cof*! *cof*!.." with hpunch


translate pt_br feedCatMouse2_30ab43e2:


    "...Você tosse já sem força, expelindo sangue. Eles devem ter danificado algo importante..."


translate pt_br feedCatMouse2_8b59ccb1:


    "Você sente algo sendo {i}arrancado de dentro de você...{/i}"


translate pt_br feedCatMouse2_f2234e60:


    "E, entre os momentos em que os mantos de escuridão obscurecem sua visão..."


translate pt_br feedCatMouse2_13fb74b2:


    "{size=-8}*splat*{/size}"


translate pt_br feedCatMouse2_633ae29e:


    "...você ouve algo molhado cair no chão à sua frente."


translate pt_br feedCatMouse2_bbaaac8d:


    "Você força os olhos a se abrirem e vê {i}isso{/i} na frente do rato..."


translate pt_br feedCatMouse2_b7184c45:


    "Formato estranho, vermelho com seu sangue, {b}pulsando{/b} e..."


translate pt_br feedCatMouse2_9330ef6a:


    "Ah, isso é..."


translate pt_br feedCatMouse2_55a10ea9:


    "Isso é o seu coração... {w}não é..?"


translate pt_br feedCatMouse2_e608f022:


    "Os outros ratos descem sobre ele, abandonando seu corpo semi-devorado."


translate pt_br feedCatMouse2_c5119fab:


    "Você está... perdendo muito sangue."


translate pt_br feedCatMouse2_98bc0f41:


    "Você se sente sonolento... {w}Mas..."


translate pt_br feedCatMouse2_84fb2e85:


    "Você... também sente..."


translate pt_br feedCatMouse2_40d9ca73_1:


    "..?"


translate pt_br feedCatMouse2_1e59d740:


    "Raiva?"


translate pt_br feedCatMouse2_c33553a7:


    "...{b}Sim.{/b}"


translate pt_br feedCatMouse2_f367bb97:


    "Tanta... {i}tanta{/i} raiva."


translate pt_br feedCatMouse2_bc4dfa80:


    "Como eles ousam..?"


translate pt_br feedCatMouse2_a20cefa7_11:


    "..."


translate pt_br feedCatMouse2_481997a6:


    "{size=-6}Como eles {b}ousam{/b}..?{/size}"


translate pt_br feedCatMouse2_b41033e1:


    "A última coisa que você vê antes de sua visão falhar..."


translate pt_br feedCatMouse2_0f017232:


    "...é um par de olhos brilhantes espreitando na escuridão além da porta."


translate pt_br feedCatMouse2_262f03ab:


    "Você pode ouvir chiados e gritos de terror ao seu redor..."


translate pt_br feedCatMouse2_8b513e6c:


    "Uivos graves... {w}rosnados profundos... {w}{i}dentes rangendo...{/i} {w}{b}carne rasgando...{/b}"


translate pt_br feedCatMouse2_9e1e42e3:


    "À medida que seus sentidos restantes te abandonam..."


translate pt_br feedCatMouse2_588df3af:


    "...você sorri timidamente com o resto de sua força..."


translate pt_br feedCatMouse2_7f3c4ffb:


    "...quando algo com pelagem macia, ligeiramente úmida e pegajosa acaricia sua bochecha."


translate pt_br feedCatMouse2_8c8e6f27:


    who "Purr..."


translate pt_br feedCatMouse2_8dabefc6_3:


    ".."


translate pt_br feedCatMouse2_a20cefa7_12:


    "..."


translate pt_br feedCatMouse2_2c38d82c:


    you "{i}Bom gatinho.{/i}"


translate pt_br feedCatMouse2_a20cefa7_13:


    "..."


translate pt_br feedCatMouse2_85830579:


    "Final 27: Bem Alimentado"


translate pt_br feedBlood_9cad6637:


    cat "Miauuu"


translate pt_br feedBlood_81d09fc7:


    "O gato solta um miado baixinho, triste e suplicante."


translate pt_br feedBlood_77603d0b:


    "Está faminto."


translate pt_br feedBlood_2ecc0964:


    "Deve estar morrendo de fome."


translate pt_br feedBlood_42b896f8:


    "Então..."


translate pt_br feedBlood_0f5de544:


    "Você..."


translate pt_br feedBlood_dae0ec55:


    you "..."


translate pt_br feedBlood_5ca2097f:


    "Você olha em volta e vê um caco de vidro próximo..."


translate pt_br feedBlood_6d915dc6:


    "Seu corpo se move como se soubesse o que fazer... {w}O que {i}precisa{/i} ser feito..."


translate pt_br feedBlood_71be69bc:


    "Você pega o caco e..."


translate pt_br feedBlood_a20cefa7:


    "..."


translate pt_br feedBlood_39a0ef61:


    "..?!" with hpunch


translate pt_br feedBlood_1a1c5607:


    "Por qu-"


translate pt_br feedBlood_7ecd134e:


    "{b}{i}Por que você—{/i}{/b}"


translate pt_br feedBlood_a20cefa7_1:


    "..."


translate pt_br feedBlood_01b83f04:


    "{size=-8}Por que você {b}faria{/b} isso?{/size}"


translate pt_br feedBlood_762defa2:


    "Você cuidadosamente segura seu dedo sobre o gato."


translate pt_br feedBlood_7d18846b:


    "Sangue vermelho escuro se acumula na ferida..."


translate pt_br feedBlood_e39facbe:


    "...até pesar o suficiente para pingar nas mandíbulas abertas e ansiosas do gato."


translate pt_br feedBlood_c4ed09d4:


    "Ele mia feliz para você."


translate pt_br feedBlood_ba1796d7:


    cat "Miauuu!"


translate pt_br feedBlood_c2c5bcf6:


    "Você sorri com ternura e abaixa a mão na caixa..."


translate pt_br feedBlood_45c2e033:


    "...acariciando a bochecha do gato antes de deixá-lo lamber suavemente seu dedo ensanguentado."


translate pt_br feedBlood_dbbb8fed:


    "Quando o fluxo diminui e o gato mia por mais, você aperta abaixo da ferida, fazendo sair mais sangue."


translate pt_br feedBlood_28db8729:


    "Você sente uma estranha, mas bem-vinda sensação de conforto com essa troca esquisita."


translate pt_br feedBlood_51e619d4:


    "Um ser além de você estava faminto..."


translate pt_br feedBlood_ebe79259:


    "...e {i}você{/i} conseguiu lhe fornecer sustento."


translate pt_br feedBlood_74acde15:


    "Um pequeno erro no mundo foi corrigido... {w}mesmo que de forma tão estranha e apenas temporariamente."


translate pt_br feedBlood_4c836b64:


    "Ironicamente, é nesse momento que você começa a se sentir... tonto..."


translate pt_br feedBlood_19b6fd1b:


    "Você não achou que estava perdendo tanto sangue assim..."


translate pt_br feedBlood_6207f576:


    "Você se encosta na caixa do gato e ouve ele miar angustiado."


translate pt_br feedBlood_6bbdcd7a:


    cat "Miau! Miaauuu!" with hpunch


translate pt_br feedBlood_31c0a678:


    "Você acha que ele parece preocupado com você. Ou, pelo menos, {i}gostaria{/i} de pensar assim."


translate pt_br feedBlood_7db1edf8:


    "Ele também {i}pode{/i} estar só querendo mais sangue."


translate pt_br feedBlood_cbe24519:


    "O gato pula para fora da caixa e se aconchega no seu colo, encostando na sua barriga e miando descontente."


translate pt_br feedBlood_e33e9f59:


    "Você queria poder acalmá-lo, mas não é como se vocês pudessem simplesmente conversar um com o outro."


translate pt_br feedBlood_7c678cc4:


    "Você tenta se lembrar da última vez que falou com {i}algúem{/i}, na verdade..."


translate pt_br feedBlood_e9b924ed:


    "Se você fosse morrer aqui e agora neste beco..."


translate pt_br feedBlood_78256794:


    "...quanto tempo levaria para alguém perceber seu sumiço?"


translate pt_br feedBlood_dba3e829:


    "Que você {b}{i}se foi{/i}{/b}..?"


translate pt_br feedBlood_a20cefa7_2:


    "..."


translate pt_br feedBlood_b0768480:


    cat "{size=+10}Miaau!!{/size}" with hpunch


translate pt_br feedBlood_28b3ac41:


    you "!!"


translate pt_br feedBlood_1742e74d:


    "Seus pensamentos são interrompidos quando o gato mia alto, ficando nervoso no seu colo."


translate pt_br feedBlood_2183d3c6:


    "Você não tem tempo para se perguntar o porquê, quando uma voz ressoa na entrada do beco."


translate pt_br feedBlood_f44a447d:


    who "Olá..?"


translate pt_br feedBlood_e7a89ae7:


    who "Ei, amigo! Tá tudo... bem?"


translate pt_br feedBlood_d209807a:


    "Você não responde. Você não acha que {i}consegue.{/i}"


translate pt_br feedBlood_8208fd13:


    "Sua voz parece estar trancada... Bem fundo em você."


translate pt_br feedBlood_bc95f001:


    "O gato olha para você por um bom tempo... {w}como se estivesse te avaliando."


translate pt_br feedBlood_c058177f:


    "Ele olha para trás na direção da voz e, com um último afago na sua barriga..."


translate pt_br feedBlood_93a5d8f4:


    "...ele pula do seu colo e caminha em direção à entrada do beco..."


translate pt_br feedBlood_4e4b3a2b:


    "Mas então..."


translate pt_br feedBlood_6e3d0e44:


    "...ele começa a {b}mudar{/b}... enquanto—{w=0.5}{nw}"


translate pt_br feedBlood_922194c3:


    "Crec!" with vpunch


translate pt_br feedBlood_90b68c87:


    you "..?"


translate pt_br feedBlood_56ebb028:


    you "!!!"


translate pt_br feedBlood_bcc1608b:


    "Sua face... {i}se abre{/i}..."


translate pt_br feedBlood_1a0a44a7:


    "{size=+15}{b}CREC!!{/b}{/size}" with vpunch


translate pt_br feedBlood_6a8f2f72:


    "Ela se descasca."


translate pt_br feedBlood_18494b91:


    "...e se abre {i}novamente{/i}..."


translate pt_br feedBlood_54d0e137:


    "...surgindo tentáculos retorcidos de onde você imagina que deveria estar a boca."


translate pt_br feedBlood_30bf4da2:


    "A silhueta do estranho congela na luz além do beco..."


translate pt_br feedBlood_300597e8:


    who "Q-Que porra é-?"


translate pt_br feedBlood_84218509:


    "Mas ele não tem a chance de terminar a pergunta."


translate pt_br feedBlood_aa46e9c3:


    "Os tentáculos se juntam em um só..."


translate pt_br feedBlood_7e5bb0e2:


    "...antes de disparar das mandíbulas do gato-"


translate pt_br feedBlood_168a8ded:


    "...e {i}{b}atravessar{/b}{/i} o ombro do estranho."


translate pt_br feedBlood_71716684:


    who "{size=+10}GAH!!{/size}" with vpunch


translate pt_br feedBlood_c13159e5:


    who "{size=+10}{i}A-AAAHHHHH!{/i}{/size}" with vpunch


translate pt_br feedBlood_e6c19910:


    "Ele solta um grito de dor... um berro cheio de medo."


translate pt_br feedBlood_bc6e9a70:


    "Ele agarra os tentáculos, tentando soltá-los... {w}mas sem sucesso."


translate pt_br feedBlood_55e0cee4:


    "Você... {w}não consegue processar os gritos dele."


translate pt_br feedBlood_d3b6988c:


    "Você encara a criatura à sua frente..."


translate pt_br feedBlood_f2277d90:


    "Tão diferente do gato que antes miou, preocupado com você..."


translate pt_br blood_stopCat_282f048b:


    "Você não pode..."


translate pt_br blood_stopCat_aba81e88:


    "Você não pode deixar isso acontecer.."


translate pt_br blood_stopCat_dae0ec55:


    you "..."


translate pt_br blood_stopCat_e5406a2e:


    "Tremendo, você se arrasta para frente..."


translate pt_br blood_stopCat_b4131218:


    "...e, sem forças, agarra os tentáculos unidos que pulsam enquanto drenam o sangue do estranho."


translate pt_br blood_stopCat_072b7df9:


    "Quando você puxa com toda a força que consegue, o pulsar dos tentáculos para... e o gato se vira para você."


translate pt_br blood_stopCat_36245d43:


    cat "Plrr? Pllrrr?"


translate pt_br blood_stopCat_6fca227b:


    "Ele emite um miado estranho, que soa como uma pergunta..."


translate pt_br blood_stopCat_e1a9cee7:


    "Mas você não tem uma resposta."


translate pt_br blood_stopCat_f007bcff:


    "Você nem consegue entender a pergunta..."


translate pt_br blood_stopCat_b9b06782:


    "Então, você simplesmente pega a criatura... {w}o {i}gato{/i}... {w}acolhendo-o em seus braços."


translate pt_br blood_stopCat_6a141fd0:


    "Você olha quase anseiosamente para a luz além da entrada do beco."


translate pt_br blood_stopCat_f70d6c24:


    "Você não sabe o que está acontecendo..."


translate pt_br blood_stopCat_53834d64:


    "...mas não pode simplesmente ficar sentado e ver alguém ser devorado tão brutalmente..."


translate pt_br blood_stopCat_d84cf8f5:


    "Não quando a pessoa tentou saber se você estava bem..."


translate pt_br blood_stopCat_a20cefa7:


    "..."


translate pt_br blood_stopCat_da22d380:


    "...Não quando você poderia se oferecer em seu lugar."


translate pt_br blood_stopCat_705c4802:


    "Você pensa que o estranho está livre..."


translate pt_br blood_stopCat_0c3e5209:


    "...porque, depois que o som de sapatos arrastando com pressa no chão se afasta..."


translate pt_br blood_stopCat_5b8efe03:


    you "Nn!" with vpunch


translate pt_br blood_stopCat_3a5f5491:


    "...você sente algo afiado perfurando suas costas."


translate pt_br blood_stopCat_183312a6:


    "Parece fino... {w}quase como uma agulha... {w}então a dor passa rapidamente enquanto seu corpo se ajusta à intrusão."


translate pt_br blood_stopCat_123c6d3b:


    "Você tem certeza de que não era tão fina quando atravessou o ombro do estranho mais cedo..."


translate pt_br blood_stopCat_c69f0708:


    "...mas, à medida que sente seu sangue sair do corpo, lentamente, como se estivesse sendo bombeado..."


translate pt_br blood_stopCat_5a001e33:


    "...fica mais difícil pensar e sua visão começa a falhar."


translate pt_br blood_stopCat_67bd589d:


    "A criatura em seus braços emite um som suave."


translate pt_br blood_stopCat_f316015b:


    "Você a segura o mais firme e próximo de você que seus braços fracos aguentam."


translate pt_br blood_stopCat_a20cefa7_1:


    "..."


translate pt_br blood_stopCat_aca7b3c0:


    "Está tudo bem... {w}Você aceita isso..."


translate pt_br blood_stopCat_b8bfa8a5:


    "Você não sabe se isso vai mudar alguma coisa..."


translate pt_br blood_stopCat_07e8897d:


    "Certamente, o gato vai sentir fome de novo em algum momento depois que você se for e..."


translate pt_br blood_stopCat_436f749d:


    "...{i}não for mais uma {b}opção{/b}{/i}..."


translate pt_br blood_stopCat_a20cefa7_2:


    "..."


translate pt_br blood_stopCat_bf0874e3:


    "Mas..."


translate pt_br blood_stopCat_4145e893:


    "Pelo menos {i}dessa{/i} vez..."


translate pt_br blood_stopCat_6cf080cc:


    "...você conseguiu... {w}salvar alguém."


translate pt_br blood_stopCat_8dabefc6:


    ".."


translate pt_br blood_stopCat_a20cefa7_3:


    "..."


translate pt_br blood_stopCat_68d32565:


    "Final 28: Pacote de cuidados pessoais"


translate pt_br blood_letCatFeed_af799a70:


    who "AAAHH!" with hpunch


translate pt_br blood_letCatFeed_f1a276a2:


    who "Alguém! Me ajuda! Socorro!" with vpunch


translate pt_br blood_letCatFeed_7ec51c3a:


    who "*balbucia* Soc..or... ..."


translate pt_br blood_letCatFeed_dae0ec55:


    you "..."


translate pt_br blood_letCatFeed_849e135c:


    "Você desvia o olhar enquanto a criatura devora o estranho..."


translate pt_br blood_letCatFeed_dd2ab70b:


    "...drenando-o até que não reste nada além de uma carcaça de ossos, pele e roupas empilhadas no chão."


translate pt_br blood_letCatFeed_a20cefa7:


    "..."


translate pt_br blood_letCatFeed_b7ce0db6:


    "Você se sente horrível, mas..."


translate pt_br blood_letCatFeed_1357f3f7:


    "O que você você poderia fazer?"


translate pt_br blood_letCatFeed_e77a0648:


    "A criatura também é um ser vivo..."


translate pt_br blood_letCatFeed_44d1ec02:


    "Não deveria ser natural que ela comesse o que precisa?"


translate pt_br blood_letCatFeed_37410cf6:


    "Ela não tem o direito de fazer o que precisa para sobreviver?"


translate pt_br blood_letCatFeed_a20cefa7_1:


    "..."


translate pt_br blood_letCatFeed_53cc9d41:


    "Você ignora a voz na sua cabeça que se pergunta se poderia haver outra saída."


translate pt_br blood_letCatFeed_a6d2e181:


    "Não é como se você tivesse tentado descobrir se poderia alimentar o gato com algo além de sangue... {w}{i}Sangue humano{/i}..."


translate pt_br blood_letCatFeed_48f6f1e3:


    "{size=-10}{b}...você {i}tentou{/i}?{/b}{/size}"


translate pt_br blood_letCatFeed_dae0ec55_1:


    you "..."


translate pt_br blood_letCatFeed_d7365832:


    "A criatura ronrona enquanto se esfrega em seu braço."


translate pt_br blood_letCatFeed_1282871c:


    "Você percebe que após descansar um pouco, já está começando a se sentir melhor."


translate pt_br blood_letCatFeed_a20cefa7_2:


    "..."


translate pt_br blood_letCatFeed_bf0874e3:


    "Mas..."


translate pt_br blood_letCatFeed_84f45571:


    "Você também pensa..."


translate pt_br blood_letCatFeed_3d2f6324:


    "...que algo dentro de você..."


translate pt_br blood_letCatFeed_90f90ddb:


    "{size=-8}...também parece meio quebrado.{/size}"


translate pt_br blood_letCatFeed_a20cefa7_3:


    "..."


translate pt_br blood_letCatFeed_e93c9366:


    "Você ainda não tem muita certeza do quê."


translate pt_br blood_letCatFeed_8dabefc6:


    ".."


translate pt_br blood_letCatFeed_a20cefa7_4:


    "..."


translate pt_br blood_letCatFeed_cbc44f0b:


    "Você se levanta e estende os braços."


translate pt_br blood_letCatFeed_8517210f:


    you "Ainda com fome?"


translate pt_br blood_letCatFeed_f8095b37:


    cat "Pllrrrrrrp!" with hpunch


translate pt_br blood_letCatFeed_3cdc6c20:


    "A criatura dá um miado feliz e pula para seus braços."


translate pt_br blood_letCatFeed_dae0ec55_2:


    you "..."


translate pt_br blood_letCatFeed_7255bffc:


    you "...Vamos lá então, certo?"


translate pt_br blood_letCatFeed_33f9f94c:


    cat "Plrrrr..."


translate pt_br blood_letCatFeed_a20cefa7_5:


    "..."


translate pt_br blood_letCatFeed_ce06cd2d:


    "Vocês deixam o beco juntos."


translate pt_br blood_letCatFeed_f363c184:


    "Vocês saem para o mundo {i}juntos.{/i}"


translate pt_br blood_letCatFeed_a20cefa7_6:


    "..."


translate pt_br blood_letCatFeed_53d0da23:


    "O gato está faminto..."


translate pt_br blood_letCatFeed_4919a924:


    "...e ele vai estar com fome frequentemente de agora em diante."


translate pt_br blood_letCatFeed_d58fc52c:


    "{i}Muito{/i} frequentemente."


translate pt_br blood_letCatFeed_a20cefa7_7:


    "..."


translate pt_br blood_letCatFeed_701eb808:


    "Gritos de medo e terror seguem vocês dois aonde quer que vão..."


translate pt_br blood_letCatFeed_7a7de0ae:


    "E sem pensar, se importar ou se preocupar com nada disso..."


translate pt_br blood_letCatFeed_d2542ef5:


    "Você apenas se afasta..."


translate pt_br blood_letCatFeed_fb3d9cf0:


    "{size=-8}...e \ {b}a s s i s t e{/b}.{/size}"


translate pt_br blood_letCatFeed_8dabefc6_1:


    ".."


translate pt_br blood_letCatFeed_a20cefa7_8:


    "..."


translate pt_br blood_letCatFeed_637cffb5:


    "Final 29: Rodízio Sangrento"


translate pt_br playAlley_4367a7aa:


    cat "Miau! Miauuuu!"


translate pt_br playAlley_eea1ecbb:


    you "Ownnn... Você só quer um pouco de atenção, não é~?"


translate pt_br playAlley_67107e6c:


    cat "Purr..."


translate pt_br playAlley_4926c274:


    "O coitadinho deve estar entediado de ficar sentado nessa caixa o dia todo."


translate pt_br playAlley_bab8d9a9:


    "Você não tem certeza se é uma companhia muito interessante, mas está disposto a dar o seu melhor."


translate pt_br playAlley_f719e5a9:


    "Deve haver algo com o que você possa entreter essa criaturinha..."


translate pt_br playAlley_66c13733:


    "Mas o quê?"


translate pt_br play_pockets_5cfb3464:


    "Você revira os bolsos."


translate pt_br play_pockets_f8c73033:


    "Você encontra um pequeno pedaço de linha no bolso esquerdo. Não vai ajudar muito."


translate pt_br play_pockets_ab3079c6:


    "A linha é curta demais."


translate pt_br play_pockets_c0209341:


    "Um gato ansioso e animado pulando para pegá-la facilmente levaria você a ser{w=1.0}{nw}"


translate pt_br play_pockets_632d1a35:


    you "!!!" with hpunch


translate pt_br play_pockets_8dabefc6:


    ".."


translate pt_br play_pockets_a20cefa7:


    "..."


translate pt_br play_pockets_f42805d9:


    "Um gato ansioso e animado pulando para pegá-la facilmente levaria você a ser mordido e arranhado."


translate pt_br play_pockets_f8cb7b4a:


    "No seu bolso direito..."


translate pt_br play_pockets_d38263f6:


    "{size=-10}...tem uma barra de {color=#FF0000}chocolate.{/color}{/size}"


translate pt_br play_pockets_f3654da7:


    "{size=-5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}descul {/size}{w=0.2}{nw}"


translate pt_br play_pockets_dae0ec55:


    you "..."


translate pt_br play_pockets_31772800:


    "...tem uma barra de chocolate."


translate pt_br play_pockets_d3dcd610:


    "Também não é muito útil agora."


translate pt_br play_pockets_632cc2c6:


    "A única outra coisa que você tem com você é seu telefone."


translate pt_br play_pockets_a20cefa7_1:


    "..."


translate pt_br play_pockets_6a7c031d:


    "Não é exatamente algo com que o gato possa brincar, mas..."


translate pt_br play_pockets_ff3c3ccc:


    "{i}Tem{/i} uma coisa que {i}você{/i} pode fazer..."


translate pt_br play_pockets_4e248d1e:


    "{size=+15}{b}{i}Tirar fotos~!!!{/i}{/b}{/size}" with hpunch


translate pt_br play_pockets_a20cefa7_2:


    "..."


translate pt_br play_pockets_297839ea:


    you "Isso foi divertido, né?"


translate pt_br play_pockets_7f0ac95c:


    cat "..."


translate pt_br play_pockets_dae0ec55_1:


    you "..."


translate pt_br play_pockets_fa1cff19:


    "Bom, {i}você{/i} se divertiu..."


translate pt_br play_pockets_aa21a61c:


    "Sem mais nada para fazer e sem intenção de levar o gato para casa..."


translate pt_br play_pockets_3d3eeb7e:


    "...você decide que provavelmente é melhor só ir embora."


translate pt_br play_pockets_be1c1ed6:


    "Você não quer que o gato se apegue demais, afinal."


translate pt_br play_pockets_f0eb3116:


    "Pelo menos você terá algumas lembranças para levar com você."


translate pt_br play_pockets_dfcd2239:


    you "Beleza, ééé... A gente se vê, eu acho. Boa sorte?"


translate pt_br play_pockets_7f0ac95c_1:


    cat "..."


translate pt_br play_pockets_fa41c4c2:


    you "...Tá."


translate pt_br play_pockets_18133987:


    "Você se vira e se afasta, mas ao deixar o beco-{w=1.2}{nw}"


translate pt_br play_pockets_1919fb1f:


    "*BZZT*!" with hpunch


translate pt_br play_pockets_5d06f92b:


    you "Hm?"


translate pt_br play_pockets_bc2cce8e:


    "Chega uma mensagem no seu celular."


translate pt_br play_pockets_ab96140d:


    "Você abre e..."


translate pt_br play_pockets_a20cefa7_3:


    "..."


translate pt_br play_pockets_40d9ca73:


    "..?"


translate pt_br play_pockets_74be92cd:


    you "O quê..?"


translate pt_br play_pockets_4b6994e1:


    phoneText "{b}--não sou foffo??--{/b}"


translate pt_br play_pockets_f8a1ca53:


    "É uma foto de um gato familiar..."


translate pt_br play_pockets_c90675bd:


    you "Hã?"


translate pt_br play_pockets_c4799a25:


    "O gato {i}realmente{/i} parece fofo..."


translate pt_br play_pockets_308c65d2:


    "E mais feliz na foto..."


translate pt_br play_pockets_a20cefa7_4:


    "..."


translate pt_br play_pockets_122874da:


    "...mas {b}não{/b} é uma foto que você reconhece."


translate pt_br play_pockets_22b5aa5b:


    you "Mas que porra..? E-Eu tirei..?"


translate pt_br play_pockets_5f369989:


    "{size=-10}você não tirou essa foto.{/size}"


translate pt_br play_pockets_63fc373e:


    "Você olha para o gato por cima do ombro..."


translate pt_br play_pockets_a20cefa7_5:


    "..."


translate pt_br play_pockets_6d6c3c7a:


    "...mas o gato está apenas olhando para você."


translate pt_br play_pockets_9cad6637:


    cat "Miauuu..."


translate pt_br play_pockets_f0c613db:


    "Ele mia triste, como se estivesse implorando para você voltar."


translate pt_br play_pockets_dae0ec55_2:


    you "..."


translate pt_br play_pockets_10090c2b:


    you "Bom... Acho que posso ficar mais um pouco..."


translate pt_br play_pockets_c44e377e:


    cat "Miauu!" with hpunch


translate pt_br play_pockets_a43f8b59:


    you "Mas o que fazer agora.."


translate pt_br play_pockets_16879ce5:


    cat "Miau?"


translate pt_br phoneHome_dae0ec55:


    you "..."


translate pt_br phoneHome_b31d124d:


    "Você ignora o gato e sai do beco com pressa, sem olhar para trás."


translate pt_br phoneHome_b0f8881c:


    you "Ufa..."


translate pt_br phoneHome_474b3625:


    you "Isso foi estranho..."


translate pt_br phoneHome_48a233a3:


    "Você já está bem longe, quando-"


translate pt_br phoneHome_1919fb1f:


    "*BZZT*!" with hpunch


translate pt_br phoneHome_8a8661d4:


    you "..! De novo não..."


translate pt_br phoneHome_d472fea1:


    "Você olha relutante para a nova mensagem e..."


translate pt_br phoneHome_f6b2a9a9:


    phoneText "{b}--nn me ignoraaaa ;_;--{/b}"


translate pt_br phoneHome_8dabefc6:


    ".."


translate pt_br phoneHome_a20cefa7:


    "..."


translate pt_br phoneHome_e1c95b67:


    "Assustado... você decide simplesmente ir para casa."


translate pt_br phoneHome_1919fb1f_1:


    "*BZZT*!" with hpunch


translate pt_br phoneHome_934d45d4:


    phoneText "{b}--eu sei q vc ta vendo isso--{/b}"


translate pt_br phoneHome_1919fb1f_2:


    "*BZZT*!" with hpunch


translate pt_br phoneHome_f089ea18:


    phoneText "{b}--volta--{/b}"


translate pt_br phoneHome_dae0ec55_1:


    you "..."


translate pt_br phoneHome_1919fb1f_3:


    "*BZZT*!" with hpunch


translate pt_br phoneHome_f089ea18_1:


    phoneText "{b}--volta--{/b}"


translate pt_br phoneHome_1919fb1f_4:


    "*BZZT*!" with hpunch


translate pt_br phoneHome_f089ea18_2:


    phoneText "{b}--volta--{/b}"


translate pt_br phoneHome_1919fb1f_5:


    "*BZZT*!" with hpunch


translate pt_br phoneHome_f089ea18_3:


    phoneText "{b}--volta--{/b}"


translate pt_br phoneHome_1919fb1f_6:


    "*BZZT*!" with hpunch


translate pt_br phoneHome_f089ea18_4:


    phoneText "{b}--volta--{/b}"


translate pt_br phoneHome_1919fb1f_7:


    "*BZZT*!" with hpunch


translate pt_br phoneHome_d4d2616a:


    "*BZZT*! *BZZT*!" with hpunch


translate pt_br phoneHome_65ea3a0a:


    phoneText "{b}--volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta --{/b}"


translate pt_br phoneHome_dae0ec55_2:


    you "..."


translate pt_br phoneHome_99f007c0:


    "{size=-8}*bzzt*...{/size}"


translate pt_br phoneHome_4b8a63af:


    phoneText "{b}--posso ver vc--{/b}"


translate pt_br phoneHome_99f007c0_1:


    "{size=-8}*bzzt*...{/size}"


translate pt_br phoneHome_42283d6e:


    phoneText "{b}--posso SEMPRE ver vc--{/b}"


translate pt_br phoneHome_36feac05:


    phoneText "{b}--VC N PODE SE ESCONDER--{/b}"


translate pt_br phoneHome_4f8f387e:


    phoneText "{b}--eu sempre vou achar vccccc OwO--{/b}"


translate pt_br phoneHome_dae0ec55_3:


    you "..."


translate pt_br phoneHome_6ba80fd4:


    "Seus olhos se movem ansiosamente... {i}certos{/i} de que você está sendo seguido."


translate pt_br phoneHome_8dabefc6_1:


    ".."


translate pt_br phoneHome_a20cefa7_1:


    "..."


translate pt_br phoneHome_f89b839f:


    "{size=-8}Mas não há nada ali.{/size}"


translate pt_br phoneHome_dae0ec55_4:


    you "..."


translate pt_br phoneHome_8dabefc6_2:


    ".."


translate pt_br phoneHome_a20cefa7_2:


    "..."


translate pt_br phoneHome_e6e0bd68:


    "Você finalmente chega em casa, mas se sente abalado demais para que o alívio te acalme."


translate pt_br phoneHome_86f767b7:


    "Você corre para o banheiro, entra e bate a porta"


translate pt_br phoneHome_5489dbe4:


    you "Tá tudo bem..."


translate pt_br phoneHome_1d1ef86b:


    you "Isso não é real..."


translate pt_br phoneHome_cb8665e3:


    "É só um sonho ruim..."


translate pt_br phoneHome_88b66f2a:


    "Tá tudo... bem..."


translate pt_br phoneHome_a20cefa7_3:


    "..."


translate pt_br phoneHome_fa440177:


    "Você tateia no escuro para ligar a torneira da pia e joga água fria no rosto..."


translate pt_br phoneHome_274213b7:


    "...na esperança de acalmar sua mente... {w}e parar com as alucinações."


translate pt_br phoneHome_ba425576:


    "{size=-5}...porque não passa disso, né?{/size}"


translate pt_br phoneHome_03f60dc4:


    "{size=-8}...Alucinações?{/size}"


translate pt_br phoneHome_a20cefa7_4:


    "..."


translate pt_br phoneHome_366ae109:


    "Você realmente está se arrependendo de ter saído de casa hoje."


translate pt_br phoneHome_207ad5fd:


    "Você deve ter se sobrecarregado de trabalho mais do que imaginava..."


translate pt_br phoneHome_d200e00e:


    "É... Deve ter sid-"


translate pt_br phoneHome_05b04601:


    "{b}*BZZT*!{/b}" with hpunch


translate pt_br phoneHome_8ca8510a:


    you "!!!" with vpunch


translate pt_br phoneHome_d4eb578f:


    "Você salta ao ouvir seu celular te notificando mais uma mensagem recebida."


translate pt_br phoneHome_dae0ec55_5:


    you "..."


translate pt_br checkPhone_8fa7a50f:


    "Com as mãos tremendo, você olha para o seu celular..."


translate pt_br checkPhone_2bd17ff9:


    phoneText "{b}--oI AMigO--{/b}"


translate pt_br checkPhone_8ca8510a:


    you "!!!" with vpunch


translate pt_br checkPhone_af7e27d2:


    you "O qu... O quê...?"


translate pt_br checkPhone_db4a3473:


    "Você se vira, assustado, e instintivamente salta para trás..."


translate pt_br checkPhone_a20cefa7:


    "..."


translate pt_br checkPhone_0f5de544:


    "Você..."


translate pt_br checkPhone_8b35204f:


    "Você {i}escorrega...{/i}"


translate pt_br checkPhone_22c24f7e:


    "...batendo a parte de trás da cabeça no espelho do banheiro."


translate pt_br checkPhone_2168405d:


    "Você não sente a dor na hora, seus olhos se movem freneticamente pelo cômodo."


translate pt_br checkPhone_8dabefc6:


    ".."


translate pt_br checkPhone_a20cefa7_1:


    "..."


translate pt_br checkPhone_7af4a8ac:


    "Não..."


translate pt_br checkPhone_a9f7a5de:


    "Não tem nada aqui."


translate pt_br checkPhone_bd69546a:


    "Absolutamente nada..."


translate pt_br checkPhone_a20cefa7_2:


    "..."


translate pt_br checkPhone_f887a3f9:


    "...Você se sente zonzo."


translate pt_br checkPhone_74fa22f3:


    "Atordoado, você sente a parte de trás da sua cabeça e examina sua mão."


translate pt_br checkPhone_8dabefc6_1:


    ".."


translate pt_br checkPhone_a20cefa7_3:


    "..."


translate pt_br checkPhone_9eca284d:


    "Você não consegue ver muita coisa..."


translate pt_br checkPhone_a20cefa7_4:


    "..."


translate pt_br checkPhone_e5477b1e:


    "Mas parece morno…"


translate pt_br checkPhone_fb2e25e6:


    "...e {i}úmido.{/i}"


translate pt_br checkPhone_8e7eed80:


    "O cheiro de cobre preenche o ar..."


translate pt_br checkPhone_c953e0ca:


    "Sentindo muita tontura, você cai sobre o piso do banheiro."


translate pt_br checkPhone_bf69ea4a:


    you "Soc..orro..."


translate pt_br checkPhone_72ca9f5f:


    "Você alcança o celular para chamar uma ambulância..."


translate pt_br checkPhone_8dabefc6_2:


    ".."


translate pt_br checkPhone_a20cefa7_5:


    "..."


translate pt_br checkPhone_842f2398:


    "...A bateria acabou."


translate pt_br checkPhone_8dabefc6_3:


    ".."


translate pt_br checkPhone_a20cefa7_6:


    "..."


translate pt_br checkPhone_a5333c46:


    "Final 30: Fotogênico"


translate pt_br ignorePhone_05b04601:


    "{b}*BZZT*!{/b}" with hpunch


translate pt_br ignorePhone_45e226d6:


    "{b}*BZZT*! *BZZT*! *BZZT*! {/b}" with hpunch


translate pt_br ignorePhone_3e5256b6:


    "{size=+20}{b}*BZZT*!{/b}{/size}" with hpunch


translate pt_br ignorePhone_43511216:


    "Seu celular vibra insistentemente, de novo e de novo..."


translate pt_br ignorePhone_a20cefa7:


    "..."


translate pt_br ignorePhone_6741af6f:


    "...mas você simplesmente não consegue olhar."


translate pt_br ignorePhone_97d37cc5:


    "Você mantém os olhos bem fechados. Seus dedos se agarram firmemente à pia."


translate pt_br ignorePhone_9e64b774:


    "Na sua mente, você implora para quem... ou {i}o que{/i} quer que esteja fazendo isso parar logo..."


translate pt_br ignorePhone_702b5575:


    "Por favor... Por favor..."


translate pt_br ignorePhone_6a348634:


    you "Por favor... Me tira logo desse sofrimento...."


translate pt_br ignorePhone_dcdacf88:


    "Você murmura isso baixinho. Você... não quer dizer isso {i}de verdade{/i}."


translate pt_br ignorePhone_6ce1cb34:


    "Você {i}não quer.{/i}"


translate pt_br ignorePhone_a20cefa7_1:


    "..."


translate pt_br ignorePhone_7bc58a93:


    "Mas, enquanto que as palavras tomam forma nos cantos mais sombrios da sua mente..."


translate pt_br ignorePhone_58827019:


    "...o celular {i}imediatamente{/i} para de vibrar."


translate pt_br ignorePhone_e2a45fdf:


    "Você pensaria que isso lhe traria um alívio..."


translate pt_br ignorePhone_a20cefa7_2:


    "..."


translate pt_br ignorePhone_ae9f462d:


    "...mas você só sente um horror se instalando pesado no seu estômago."


translate pt_br ignorePhone_698fca08:


    "Você pode sentir olhos em você..."


translate pt_br ignorePhone_19e3c7ae:


    "Você pode sentir sopros de ar na sua nuca... {w}úmidos, profundos e {b}lentos{/b}..."


translate pt_br ignorePhone_0f7f3730:


    "Você respira fundo e abre os olhos..."


translate pt_br ignorePhone_d6fac14d:


    "Você olha..."


translate pt_br ignorePhone_0f5c8741:


    "...para o espelho."


translate pt_br ignorePhone_8dabefc6:


    ".."


translate pt_br ignorePhone_a20cefa7_3:


    "..."


translate pt_br ignorePhone_97d7e1ff:


    "...Nada."


translate pt_br ignorePhone_7688b87e:


    "Você espia pelo banheiro."


translate pt_br ignorePhone_8dabefc6_1:


    ".."


translate pt_br ignorePhone_a20cefa7_4:


    "..."


translate pt_br ignorePhone_d39ba71d:


    "...Ainda nada. {w}Nada mesmo..."


translate pt_br ignorePhone_fa14a2fd:


    "Mas você sabe. Você {i}sabe{/i} que algo está ali..."


translate pt_br ignorePhone_3a16261e:


    "Esperando ser descoberto..."


translate pt_br ignorePhone_9080b186:


    "Que você aceite o fato de sua existência."


translate pt_br ignorePhone_195993dc:


    "Somente {i}então{/i} ele se dignará a te dar paz.."


translate pt_br ignorePhone_0d88251d:


    "...te libertar de uma vida de insegurança constante..."


translate pt_br ignorePhone_98aa90d7:


    "...de temer sua própria imagem... {w}seu próprio reflexo."


translate pt_br ignorePhone_0a31632a:


    "Você pode sentir sua paciência, ilimitada e antiga."


translate pt_br ignorePhone_7d6512f3:


    "Você não pode vencê-lo no cansaço."


translate pt_br ignorePhone_f8fa2106:


    "Sua vida se esgotará muito antes que ele se enjoe de você."


translate pt_br ignorePhone_42b896f8:


    "Então..."


translate pt_br ignorePhone_a20cefa7_5:


    "..."


translate pt_br ignorePhone_dec216e1:


    "Você fecha os olhos..."


translate pt_br ignorePhone_8dabefc6_2:


    ".."


translate pt_br ignorePhone_a20cefa7_6:


    "..."


translate pt_br ignorePhone_3275149d:


    "...e aceita."


translate pt_br ignorePhone_632d1a35:


    you "!!!" with hpunch


translate pt_br ignorePhone_dae0ec55:


    you "..."


translate pt_br ignorePhone_902a5fbf:


    "Enquanto sua cabeça é separada do seu pescoço, você se sente em paz... {w}grato por, pelo menos..."


translate pt_br ignorePhone_e515cfae:


    "...nunca ter que ver {color=#FF0000}isso.{/color}"


translate pt_br ignorePhone_faca898b:


    "O que quer que {color=#FF0000}isso{/color} fosse.."


translate pt_br ignorePhone_8dabefc6_3:


    ".."


translate pt_br ignorePhone_a20cefa7_7:


    "..."


translate pt_br ignorePhone_3d7f79a0:


    "Final 31: Perdendo a cabeça"


translate pt_br play_lookAround_fe95c45e:


    "Você olha ao redor..."


translate pt_br play_lookAround_26d8fe49:


    "...mas não há nada no beco que pareça interessante o suficiente para o gato brincar."


translate pt_br play_lookAround_d230d6d0:


    "Então..."


translate pt_br play_lookAround_8895ca7b:


    you "Que tal... um jogo?"


translate pt_br play_lookAround_16879ce5:


    cat "Miau?"


translate pt_br play_lookAround_09d74134:


    "Você escolhe uma brincadeira que conhece desde a infância..."


translate pt_br play_lookAround_6a840dc3:


    "Batata Quente... {w}um clássico."


translate pt_br play_lookAround_fb2631f7:


    "Ensinar um gato a jogar pode ser um tanto desafiador..."


translate pt_br play_lookAround_fcf103dd:


    "...mas você tem a sensação de que os instintos naturais de caça do felino vão ajudar."


translate pt_br play_lookAround_ef9d4eaf:


    "Você caminha até a entrada do beco, com o gato miando para você."


translate pt_br play_lookAround_4367a7aa:


    cat "Miau! Miauuu!"


translate pt_br play_lookAround_cfb6ac60:


    you "Não se preocupe, eu não vou a lugar nenhum~"


translate pt_br play_lookAround_3d7739d9:


    "Você exagera nos movimentos, cobrindo os olhos com as mãos... e se vira."


translate pt_br play_lookAround_79b5cf51:


    you "Um... {w}Dois... {w}Três... {w}.{w}.{w}."


translate pt_br play_lookAround_1b42e081:


    you "...Queimou!" with hpunch


translate pt_br play_lookAround_93fd1982:


    "Você se vira rapidamente."


translate pt_br play_lookAround_b4e52671:


    "O gato não saiu da caixa, inclinando a cabeça para você, confuso e curioso."


translate pt_br play_lookAround_7c7b7c3d:


    "Talvez o conceito seja muito avançado para um gato, afinal..."


translate pt_br play_lookAround_e64afe7e:


    "Tudo bem. Você vai pensar em outra coisa para fazer."


translate pt_br playRedLight_ddbe32ac:


    "Você tenta de novo."


translate pt_br playRedLight_3c3c3328:


    "Dessa vez, você vai um pouco mais devagar."


translate pt_br playRedLight_e64b19d2:


    you "Um..."


translate pt_br playRedLight_a20cefa7:


    "..."


translate pt_br playRedLight_382ca646:


    you "Dooois~"


translate pt_br playRedLight_a20cefa7_1:


    "..."


translate pt_br playRedLight_68231842:


    you "Trêeeees~"


translate pt_br playRedLight_8dabefc6:


    ".."


translate pt_br playRedLight_a20cefa7_2:


    "..."


translate pt_br playRedLight_652686fc:


    you "QUEIMOU~!" with hpunch


translate pt_br playRedLight_5f5eef33:


    "Dessa vez, quando você se vira..."


translate pt_br playRedLight_6319ec5c:


    "...o gato está fora da caixa."


translate pt_br playRedLight_ab6d5659:


    cat "!!!" with hpunch


translate pt_br playRedLight_20c4e0a4:


    "O gato congela sob o seu olhar, como se pensasse que você não pode vê-lo se ele não se mexer."


translate pt_br playRedLight_13bef835:


    you "{i}Tão fofo~{/i}"


translate pt_br playRedLight_0743b011:


    "Satisfeito que o gato está pegando o jeito da brincadeira, você se vira de novo... acelerando o ritmo."


translate pt_br playRedLight_488ec393:


    you "Um... Dois... Três..."


translate pt_br playRedLight_30030125:


    you "Queimou!" with hpunch


translate pt_br playRedLight_65781c81:


    "Você se vira..."


translate pt_br playRedLight_d6257afb:


    "O gato está a alguns passos da caixa agora, espiando por trás de uma lixeira..."


translate pt_br playRedLight_74164412:


    "...com os olhos fixos... {w}{i}intensamente{/i} em você."


translate pt_br playRedLight_a20cefa7_3:


    "..."


translate pt_br playRedLight_c450b224:


    "Bom... {w}pelo menos está se divertindo?"


translate pt_br playRedLight_a20cefa7_4:


    "..."


translate pt_br playRedLight_5a29d90a:


    "Você se vira de novo..."


translate pt_br playRedLight_a20cefa7_5:


    "..."


translate pt_br playRedLight_e3ca830a:


    "...e sente um arrepio repentino percorrer sua espinha de cima a baixo."


translate pt_br playRedLight_90b68c87:


    you "..?"


translate pt_br playRedLight_0c09560a:


    "Você se sente meio ridículo... {w}mas acaba contando um {i}pouco{/i} mais rápido desta vez..."


translate pt_br playRedLight_7f66eaea:


    you "Um, dois, três, queimou!" with hpunch


translate pt_br playRedLight_79eb9703:


    "...se virando bem rápido após dizer \"queimou!\""


translate pt_br playRedLight_a20cefa7_6:


    "..."


translate pt_br playRedLight_3f788947:


    "Você... olha para o gato."


translate pt_br playRedLight_18019ca8:


    "Está na metade do caminho do beco, mais perto de você agora, mas..."


translate pt_br playRedLight_a20cefa7_7:


    "..."


translate pt_br playRedLight_5812c142:


    "...é como se a perspectiva do que você está vendo estivesse {b}errada{/b} de alguma forma."


translate pt_br playRedLight_325acab7:


    "O gato não parece um pouco... {w}{i}maior{/i}..?"


translate pt_br playRedLight_4390a056:


    "Suas pupilas são como fendas agora."


translate pt_br playRedLight_7f0ac95c:


    cat "..."


translate pt_br playRedLight_dae0ec55:


    you "..."


translate pt_br playRedLight_973413d4:


    "Algo..."


translate pt_br playRedLight_2aad8b65:


    "{size=-5}Algo não está certo.{/size}"


translate pt_br playRedLight_4f37bfcc:


    cat "Reowrrr..."


translate pt_br playRedLight_84627845:


    "O gato mia para você novamente, mas soa muito mais {b}grave{/b} do que antes."


translate pt_br playRedLight_cee07e8b:


    "Está agachado... como se estivesse prestes a saltar..."


translate pt_br playRedLight_133b6978:


    "Sua respiração tremula um pouco enquanto seu coração acelera."


translate pt_br playRedLight_e43c0e50:


    "Seu pé instintivamente recua-"


translate pt_br playRedLight_1948cb48:


    cat "{size=+20}{b}REAAWWWRRR!{/b}{/size}" with hpunch


translate pt_br playRedLight_8ca8510a:


    you "!!!" with vpunch


translate pt_br playRedLight_4f55a03f:


    "Você congela imediatamente."


translate pt_br playRedLight_0e14e06c:


    "O gato parece..."


translate pt_br playRedLight_a34925d6:


    "...{b}impaciente{/b}."


translate pt_br playRedLight_8dbd85ab:


    "Ele... Ele quer continuar brincando?"


translate pt_br playRedLight_9897df30:


    "{size=-5}Mas...{/size}"


translate pt_br playRedLight_dae0ec55_1:


    you "..."


translate pt_br playRedLight_8ed89f65:


    "Você engole seco e se vira, {w}contando rápido e se virando novamente enquanto ofega..."


translate pt_br playRedLight_41759c18:


    you "{size=-5}U-Um-dois-três-queimou!!{/size}"


translate pt_br playRedLight_3aae9beb:


    "{size=+35}{b}CRASH!!{/b}{/size}" with vpunch


translate pt_br playRedLight_632d1a35:


    you "!!!" with hpunch


translate pt_br playRedLight_6022342a:


    "O chão treme enquanto você se vira de volta..."


translate pt_br playRedLight_100dd9e8:


    "...se deparando com uma longa superfície de pelo preto."


translate pt_br playRedLight_e2847060:


    "Você olha lentamente para cima..."


translate pt_br playRedLight_435dd3ca:


    "E para cima..."


translate pt_br playRedLight_c9db0979:


    "E para {i}cima{/i}..."


translate pt_br playRedLight_a20cefa7_8:


    "..."


translate pt_br playRedLight_40543d82:


    "...para ver uma figura gigantesca e sombria olhando para baixo, curvada sobre você."


translate pt_br playRedLight_caf41941:


    "Presas pingando saliva..."


translate pt_br playRedLight_26619c65:


    "Garras cravadas nas paredes de concreto do beco..."


translate pt_br playRedLight_70fb954c:


    "Seus olhos brilhantes não piscam enquanto olham para você... {w}o gato está esperando sua próxima jogada."


translate pt_br playRedLight_c97b388a:


    "Mas está tão {b}perto{/b}... {w}Se você se virar {i}{b}agora{/b}...{/i}"


translate pt_br playRedLight_dae0ec55_2:


    you "..."


translate pt_br playRedLight_0f5de544:


    "Você..."


translate pt_br playRedLight_9fd59da9:


    "{size=-10}você não quer mais brincar{/size}"


translate pt_br play_gameRun_632d1a35:


    you "!!!" with hpunch


translate pt_br play_gameRun_08ea5e28:


    "Você nem termina de se virar antes que as garras agarrem seu tórax..."


translate pt_br play_gameRun_65b129bb:


    "...cravando e perfurando a carne macia do seu abdômen facilmente."


translate pt_br play_gameRun_fbb16dfe:


    "Enquanto você é levantado, vê as mandíbulas se abrindo acima de você, pingando saliva..."


translate pt_br play_gameRun_8515e08c:


    "...e não consegue evitar de pensar que devia haver outra maneira de sair dessa."


translate pt_br play_gameRun_cacea3a1:


    "Mas arrependimentos inúteis são bem típicos de você..."


translate pt_br play_gameRun_55ef6376:


    "{size=-5}...não são?{/size}"


translate pt_br play_gameRun_a20cefa7:


    "..."


translate pt_br play_gameRun_479119e0:


    "Final 32: Medroso"


translate pt_br play_backUp_50e0caa3:


    "Com os olhos fixos no gigante que se ergue sobre você..."


translate pt_br play_backUp_1f17c6e2:


    "...você dá um passo para trás."


translate pt_br play_backUp_f2f2471a:


    who "Não."


translate pt_br play_backUp_d36f2d70:


    who "Isso é {b}trapaça{/b}."


translate pt_br runBackUp_93206a37:


    who "O que você está fazendo?"


translate pt_br runBackUp_0a8c0018:


    who "{size=+15}{b}PARE!{/b}{/size}" with hpunch


translate pt_br runBackUp_5110274f:


    who "{size=+25}{b}VOCÊ VAI QUEBRAR TUD-{/b}{/size}{w=0.5}{nw}" with hpunch


translate pt_br backedUp_895b7892:


    "O gato te \ {b}e n c a r a {/b} \ enquanto você mantém contato visual e volta..."


translate pt_br backedUp_4050e13d:


    "Você dá um passo pra trÁs..."


translate pt_br backedUp_ea56939f:


    "E PaRa tRás..."


translate pt_br backedUp_d13e6e4f:


    "E cOnfoRme VOcê DÁ mais uM paSSO PrA ForA dO bECo..."


translate pt_br backedUp_8dabefc6:


    ".."


translate pt_br backedUp_a20cefa7:


    "..."


translate pt_br backedUp_dae0ec55:


    you "..."


translate pt_br backedUp_8dabefc6_1:


    ".."


translate pt_br backedUp_a20cefa7_1:


    "..."


translate pt_br backedUp_05374f43:


    "ERRO."


translate pt_br backedUp_05374f43_1:


    "ERRO."


translate pt_br backedUp_05374f43_2:


    "ERRO."


translate pt_br backedUp_05374f43_3:


    "ERRO."


translate pt_br backedUp_dc5c1f8b:


    "ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO."


translate pt_br backedUp_8dabefc6_2:


    ".."


translate pt_br backedUp_a20cefa7_2:


    "..."


translate pt_br backedUp_9ff185ae:


    "O mundo fora do beco parece estar... {w}{i}quebrado.{/i}"


translate pt_br backedUp_f8eca25b:


    "{size=-8}O que exatamente você {b}fez?{/b}{/size}"


translate pt_br backedUp_a20cefa7_3:


    "..."


translate pt_br backedUp_da5037e5:


    "Final 33: {b}eRRo{/b} EnCoNtRaDo"


translate pt_br play_buyToy_17b6ceba:


    "Depois de ficar nesse beco, completamente sozinho, por sabe-se lá quanto tempo..."


translate pt_br play_buyToy_dc10009e:


    "...você acha que seu amigo peludo merece algo {b}especial{/b}."


translate pt_br play_buyToy_c0eeee5a:


    you "Já volto, tá?"


translate pt_br play_buyToy_16879ce5:


    cat "Miau?"


translate pt_br play_buyToy_29937c3a:


    "Você sai rapidamente do beco e corre até o pet shop mais próximo."


translate pt_br play_buyToy_ec2f406b:


    "Você examina todos os diferentes brinquedos para gatos."


translate pt_br play_buyToy_bf05eeff:


    "São tantos para escolher... de pelúcia, coloridos e com cheiro de catnip..."


translate pt_br play_buyToy_bf0874e3:


    "Mas..."


translate pt_br play_buyToy_e86004a8:


    "Você percebe que a maioria dos brinquedos não são feitos para o gato brincar sozinho."


translate pt_br play_buyToy_57b2fbb2:


    "Você não pode ficar no beco brincando {i}para sempre...{/i}"


translate pt_br play_buyToy_9b14289c:


    "E também não pode arrumar {i}outro{/i} gato para fazer companhia..."


translate pt_br play_buyToy_a20cefa7:


    "..."


translate pt_br play_buyToy_5c68eec6:


    "\"Outro...\""


translate pt_br play_buyToy_0fdaeb98:


    you "{i}{size=+8}É isso!{/size}{/i}" with vpunch


translate pt_br play_buyToy_ce5d2ac5:


    "Você sabe exatamente o que comprar agora!"


translate pt_br play_buyToy_72c661ba:


    "Depois de uma busca rápida e bem-sucedida pela loja..."


translate pt_br play_buyToy_c96d5702:


    "...você faz sua compra e corre de volta para o beco... {w}ansioso para mostrar o que encontrou."


translate pt_br play_buyToy_d120113b:


    you "Tô de volta~!"


translate pt_br play_buyToy_ec1974d4:


    cat "Miau!" with hpunch


translate pt_br play_buyToy_755cfe9c:


    "O beco parece ainda mais sombrio depois de passar um tempo diretamente sob a luz do sol..."


translate pt_br play_buyToy_0f6e5e68:


    "Isso faz você se sentir ainda mais orgulhoso do seu presente."


translate pt_br play_buyToy_84f515b2:


    "Você corre até o gato e vasculha a sacola plástica da loja."


translate pt_br play_buyToy_50f51005:


    you "Trouxe uma coisa pra você~"


translate pt_br play_buyToy_16879ce5_1:


    cat "Miau?"


translate pt_br play_buyToy_94919086:


    "O gato se levanta, curioso com o conteúdo da sacola."


translate pt_br play_buyToy_8dabefc6:


    ".."


translate pt_br play_buyToy_a20cefa7_1:


    "..."


translate pt_br play_buyToy_c8e2fc6b:


    "Você tira seu presente para o gato..."


translate pt_br play_buyToy_e5e73efe:


    you "{size=+5}TCHARAM~!{/size}" with hpunch


translate pt_br play_buyToy_6003bca0:


    "É um gatinho de pelúcia."


translate pt_br play_buyToy_4f8666f2:


    "O boneco de pelúcia tem uma cor laranja clara com listras marrons, {w}fazendo-o parecer um gato tigrado."


translate pt_br play_buyToy_b5de0f8d:


    "O pelo sintético é macio, mas não de um jeito artificial..."


translate pt_br play_buyToy_54c1b109:


    "...e os olhos grandes têm cor verde pálido, mais discretos do que você esperaria para um brinquedo."


translate pt_br play_buyToy_053e2879:


    "Não há como negar que é apenas um boneco de pelúcia, mas os detalhes cuidadosos ainda o tornam quase..."


translate pt_br play_buyToy_55022625:


    "...{b}misterioso{/b} em relação à coisa real."


translate pt_br play_buyToy_a20cefa7_2:


    "..."


translate pt_br play_buyToy_1b1eee42:


    "O que o torna {i}perfeito.{/i}"


translate pt_br play_buyToy_c1f68b0f:


    "Um companheiro para o gato, {w}e um que você pode bancar."


translate pt_br play_buyToy_6b205f71:


    "Só vantagem."


translate pt_br play_buyToy_16879ce5_2:


    cat "Miau?"


translate pt_br play_buyToy_2d9feb3d:


    you "E não é só isso!"


translate pt_br play_buyToy_54cca3c7:


    "Você aperta a pelúcia e-"


translate pt_br play_buyToy_b4578bdf:


    catDoll "{i}miiaauu{/i}"


translate pt_br play_buyToy_7f0ac95c:


    cat "..."


translate pt_br play_buyToy_0e14e06c:


    "O gato parece..."


translate pt_br play_buyToy_335f91cb:


    "...indiferente."


translate pt_br play_buyToy_f297b97b:


    you "{i}Hum.{/i}"


translate pt_br play_buyToy_750dec0e:


    "Bem. {w}{i}Você{/i} acha fofo..."


translate pt_br play_buyToy_c7218d6f:


    "Parece que sua compra não foi tão bem-sucedida assim."


translate pt_br play_buyToy_fd1a09e7:


    "Sem opções e sem dinheiro, {w}você, sem graça, coloca a pelúcia na caixa, ao lado do gato."


translate pt_br play_buyToy_0c88972c:


    "Você se levanta e se vira para sair."


translate pt_br play_buyToy_82edeab8:


    "Está a alguns passos de distância quando ouve um miado eletrônico atrás de você."


translate pt_br play_buyToy_b4578bdf_1:


    catDoll "{i}miiaauu{/i}"


translate pt_br play_buyToy_c90675bd:


    you "Hã?"


translate pt_br play_buyToy_0776796a:


    "Você se vira e vê o boneco de pelúcia no chão ao lado da caixa."


translate pt_br play_buyToy_d1cca908:


    "O gato está te observando atentamente, com o olhar fixo."


translate pt_br pickUpDoll_82161d60:


    "Você suspira e vai pegar o boneco..."


translate pt_br pickUpDoll_2aa568f9:


    you "Você só {i}quer{/i} um pouco de atenção, não é?"


translate pt_br pickUpDoll_022b9bff:


    cat "Miau! Miauu!"


translate pt_br pickUpDoll_89a6495c:


    "Você pega o boneco do gato, dando uma olhada..."


translate pt_br pickUpDoll_8dabefc6:


    ".."


translate pt_br pickUpDoll_a20cefa7:


    "..."


translate pt_br pickUpDoll_704e0eb5:


    "Ele parece um pouco... diferente."


translate pt_br pickUpDoll_479c3431:


    you "!!" with vpunch


translate pt_br pickUpDoll_e22dd6c2:


    "Ele acabou de..."


translate pt_br pickUpDoll_23c671a1:


    "{size=-8}...{b}olhar{/b} para você?{/size}"


translate pt_br pickUpDoll_b4578bdf:


    catDoll "{i}miiaauu{/i}"


translate pt_br pickUpDoll_a20cefa7_1:


    "..."


translate pt_br pickUpDoll_69d038c5:


    catDoll "{i}{b}m i i a a u u...{/b}{/i}{w=0.8}{nw}"


translate pt_br pickUpDoll_bd45ae33:


    catDoll "{i}{b}m i i a a u u-au...{/b}{/i}{w=0.8}{nw}"


translate pt_br pickUpDoll_8606d94b:


    catDoll "{i}{b}m i i a a u u-au-au...{/b}{/i}{w=0.8}{nw}"


translate pt_br pickUpDoll_f88ef7f7:


    catDoll "{i}{b}m i i a a u u-au-au-au...{/b}{/i}{w=0.8}{nw}"


translate pt_br pickUpDoll_3b489aee:


    catDoll "{i}{b}m i i a a u u-au-au-au-au...{/b}{/i}"


translate pt_br pickUpDoll_12a250d7:


    "{size=+20}{b}{i}CHOMP!!{/i}{/b}{/size}" with hpunch


translate pt_br pickUpDoll_8ca8510a:


    you "!!!" with vpunch


translate pt_br pickUpDoll_6e0cdb4a:


    "A pelúcia, de alguma forma, abre a boca costurada antes de morder seu pulso!"


translate pt_br pickUpDoll_9275ba69:


    you "{b}AI!!{/b} P-PARA!" with vpunch


translate pt_br pickUpDoll_4afb1a12:


    "Você tenta jogá-lo para longe, mas sua mordida é muito forte. Enquanto isso, ele suga seu sangue, voraz e frenético."


translate pt_br pickUpDoll_05c892b0:


    "Você bate a pelúcia contra as paredes de concreto do beco..."


translate pt_br pickUpDoll_6530086c:


    "Tenta rasgar seu tecido resistente..."


translate pt_br pickUpDoll_354ced13:


    "Mas, por mais que tente, não consegue feri-la ou fazê-la parar..."


translate pt_br pickUpDoll_ed657fd0:


    "Afinal, é apenas um brinquedo."


translate pt_br pickUpDoll_d9df7f92:


    "Eventualmente, você começa a se sentir sem forças... {w}O suficiente para cair de joelhos, derrotado."


translate pt_br pickUpDoll_ae5955fe:


    "O boneco de pelúcia está bebendo mais calmo agora..."


translate pt_br pickUpDoll_3458d0b1:


    "...como se sua agressão anterior tivesse sido apenas uma reação ao seu desespero."


translate pt_br pickUpDoll_a20cefa7_2:


    "..."


translate pt_br pickUpDoll_e5b804f8:


    "Ele parece satisfeito por você não estar mais lutando."


translate pt_br pickUpDoll_8dabefc6_1:


    ".."


translate pt_br pickUpDoll_a20cefa7_3:


    "..."


translate pt_br pickUpDoll_17adc77a:


    "Por um segundo você pensa ter desmaiado..."


translate pt_br pickUpDoll_cb31072e:


    "...porque quando volta a si, ainda está sentado com os olhos fechados."


translate pt_br pickUpDoll_0f5de544:


    "Você..."


translate pt_br pickUpDoll_79beda1e:


    "Você se sente tão fraco..."


translate pt_br pickUpDoll_8c840e9e:


    "Você precisa usar toda a sua força apenas para abrir os olhos, e quando consegue..."


translate pt_br pickUpDoll_40d9ca73:


    "..?"


translate pt_br pickUpDoll_35a7a74d:


    "...você vê um... {w}gatinho?"


translate pt_br pickUpDoll_47bd6cb5:


    "Seu pelo é um tom familiar laranja claro com listras marrons..."


translate pt_br pickUpDoll_a20cefa7_4:


    "..."


translate pt_br pickUpDoll_b3f7547c:


    "Ele está lambendo seu pulso..."


translate pt_br pickUpDoll_d587e6e7:


    "O gatinho levanta a cabeça e olha para você com seus penetrantes olhos verde-pálido..."


translate pt_br pickUpDoll_07d3bffa:


    kitten "Miiiiau!"


translate pt_br pickUpDoll_e1a39f3b:


    "Ele mia para você com um tom agudo e estridente..."


translate pt_br pickUpDoll_5c40811b:


    "...a boca coberta de sangue."


translate pt_br pickUpDoll_dae0ec55:


    you "..."


translate pt_br pickUpDoll_d40d5f1c:


    "Seria absolutamente adorável... {w}se você não estivesse prestes a morrer por perda de sangue..."


translate pt_br pickUpDoll_90071059:


    "O gato aparece na sua vista e pega o filhote."


translate pt_br pickUpDoll_3f40ce34:


    "Ele lhe lança um olhar indecifrável..."


translate pt_br pickUpDoll_ca09ce4e:


    "...antes de se afastar."


translate pt_br pickUpDoll_461d72a5:


    "O gato leva o filhote de volta para a caixa e começa a limpá-lo com cuidado."


translate pt_br pickUpDoll_19878d53:


    kitten "Miiiaauu..."


translate pt_br pickUpDoll_67107e6c:


    cat "Purr..."


translate pt_br pickUpDoll_dae0ec55_1:


    you "..."


translate pt_br pickUpDoll_fb698b9d:


    "Você desequilibra e percebe que não consegue se manter de pé antes de cair no chão."


translate pt_br pickUpDoll_d573f842:


    "Pelo visto, no fim das contas..."


translate pt_br pickUpDoll_d8af5247:


    "...você conseguiu arranjar um companheiro para o gato, afinal."


translate pt_br pickUpDoll_a20cefa7_5:


    "..."


translate pt_br pickUpDoll_51267a7a:


    "Final 34: Brinquedo vivo"


translate pt_br leaveDoll_7f0ac95c:


    cat "..."


translate pt_br leaveDoll_dae0ec55:


    you "..."


translate pt_br leaveDoll_9e098551:


    "{size=-10}Monstrinho ingrato.{/size}"


translate pt_br leaveDoll_f34f5817:


    "Você expira, irritado."


translate pt_br leaveDoll_c6883583:


    you "De nada, {i}{b}viu?{/b}{/i}..."


translate pt_br leaveDoll_10532c8a:


    "Balançando a cabeça, você se vira para ir embora mais uma vez-"


translate pt_br leaveDoll_56ebb028:


    you "!!!"


translate pt_br leaveDoll_5ef96487:


    you "{b}AHH!{/b}" with vpunch


translate pt_br leaveDoll_1542f023:


    "...quando uma dor aguda atravessa seu braço."


translate pt_br leaveDoll_d75c3479:


    you "{b}{size=+10}GAHH!!{/size}{/b}" with vpunch


translate pt_br leaveDoll_41de37fd:


    "Gritando de dor, você agarra o braço, fazendo ele-"


translate pt_br leaveDoll_632d1a35:


    you "!!!" with hpunch


translate pt_br leaveDoll_47103633:


    "{size=-5}...cair.{/size}"


translate pt_br leaveDoll_f7c10c20:


    "{size=-8}Seu braço simplesmente {i}cai.{/i}{/size}"


translate pt_br leaveDoll_145d5b9e:


    "Você encara, em choque, o seu membro amputado no chão."


translate pt_br leaveDoll_cb3b97dc:


    "Juntando coragem..."


translate pt_br leaveDoll_3461876b:


    "...você se vira para olhar onde seu braço costumava estar ligado ao resto do corpo, apenas para ver..."


translate pt_br leaveDoll_b8178942:


    you "..!?"


translate pt_br leaveDoll_4579d27c:


    "Não é sangue..? É..."


translate pt_br leaveDoll_6cca42de:


    "É {i}{b}algodão?!{/b}{/i}"


translate pt_br leaveDoll_9e6ab9f6:


    "Você encosta no toco e percebe que não dói..."


translate pt_br leaveDoll_a20cefa7:


    "..."


translate pt_br leaveDoll_5cf9ed70:


    "Isso é..."


translate pt_br leaveDoll_a20cefa7_1:


    "..."


translate pt_br leaveDoll_0c436653:


    "{size=-8}...até que a mesma coisa acontece com seu outro braço.{/size}"


translate pt_br leaveDoll_b61a60d7:


    you "{b}{size=+10}AAAAHHH!!{/size}{/b}" with vpunch


translate pt_br leaveDoll_cd0981ae:


    you "{b}{size=+20}{i}GAAAHHH!!!{/i}{/size}{/b}" with vpunch


translate pt_br leaveDoll_8ca8510a:


    you "!!!" with vpunch


translate pt_br leaveDoll_658780db:


    you "AHH!!" with vpunch


translate pt_br leaveDoll_43d120d4:


    "Você cai quando ambas as pernas sucumbem ao mesmo destino sem sentido..."


translate pt_br leaveDoll_75cd7bfe:


    "...gritando pela agonia que vai e vem como se nunca tivesse acontecido..."


translate pt_br leaveDoll_4461f216:


    "...como se você não estivesse atualmente deitado no chão sujo de um beco..."


translate pt_br leaveDoll_5ca04004:


    "{b}...sem membros{/b}."


translate pt_br leaveDoll_c03a3d82:


    "{size=-8}O que diabos está acontecendo..?{/size}"


translate pt_br leaveDoll_78f5a0cd:


    "Você não consegue entender..."


translate pt_br leaveDoll_97f38b80:


    "Não consegue pensar direito..."


translate pt_br leaveDoll_8dabefc6:


    ".."


translate pt_br leaveDoll_a20cefa7_2:


    "..."


translate pt_br leaveDoll_a20cefa7_3:


    "..."


translate pt_br leaveDoll_ef40bdc4:


    "A dor passou..."


translate pt_br leaveDoll_95257a22:


    "...te deixando com uma estranha sensação de vazio no estômago."


translate pt_br leaveDoll_d38ad1a6:


    "Considerando que você ainda {i}tem{/i} um estômago e que não foi substituído por..."


translate pt_br leaveDoll_a20cefa7_4:


    "..."


translate pt_br leaveDoll_8ba140ab:


    "Enquanto você se deita... impotente e ainda em choque, olhando para o céu..."


translate pt_br leaveDoll_70f07f0b:


    "...o rosto do gato aparece em sua linha de visão."


translate pt_br leaveDoll_dae0ec55_1:


    you "..."


translate pt_br leaveDoll_7f0ac95c_1:


    cat "..."


translate pt_br leaveDoll_2453d78c:


    "Ele salta em direção ao seu torso e começa a morder e arranhar seu peito como se você fosse um brinquedo de mastigar."


translate pt_br leaveDoll_af8ce120:


    "Não dói mais..."


translate pt_br leaveDoll_650a397d:


    "Mas você sente que {i}deveria.{/i}"


translate pt_br leaveDoll_360e2c6a:


    "Você... não tem certeza se fica feliz por {i}{b}não doer{/b}{/i}..."


translate pt_br leaveDoll_a20cefa7_5:


    "..."


translate pt_br leaveDoll_9b7b97b5:


    "Eventualmente, você sente o gato {i}puxar{/i} algo de dentro de você..."


translate pt_br leaveDoll_af048f08:


    "...um bonequinho, que parece muito, muito familiar."


translate pt_br leaveDoll_230dc578:


    "É difícil afirmar, mas... esse boneco é..."


translate pt_br leaveDoll_eceefbf1:


    "É {i}você{/i}..."


translate pt_br leaveDoll_31f42f2f:


    "{size=-8}...não é?{/size}"


translate pt_br leaveDoll_e99f1253:


    "O gato pula de você e volta para a caixa com seu prêmio."


translate pt_br leaveDoll_4397d1db:


    "Pelo menos, é o que você {i}acha{/i}..."


translate pt_br leaveDoll_32485deb:


    "Está tudo... {w}{size=-5}escuro demais...{/size} {w}{size=-8}para saber...{/size}"


translate pt_br leaveDoll_8dabefc6_1:


    ".."


translate pt_br leaveDoll_a20cefa7_6:


    "..."


translate pt_br leaveDoll_233e66b3:


    "...Você acorda e descobre que não consegue se mexer nem um centímetro."


translate pt_br leaveDoll_816001ad:


    "Você não consegue olhar à sua volta."


translate pt_br leaveDoll_bb663b42:


    "Nem ao menos respirar."


translate pt_br leaveDoll_6665f0ba:


    "Embora nenhuma dessas constatações pareça ser... um {i}problema?{/i}"


translate pt_br leaveDoll_cac600dc:


    "Tudo o que você consegue ver é a face de um gato familiar enroscado em você, ronronando enquanto dorme."


translate pt_br leaveDoll_b53c4107:


    cat "Purr... Purrr..."


translate pt_br leaveDoll_aae0b1be:


    "Por alguma razão, isso não te incomoda."


translate pt_br leaveDoll_2f662c10:


    "Você não sabe por que sente que deveria."


translate pt_br leaveDoll_a8aca17f:


    "Você tenta se agarrar a pensamentos na sua mente, que parecem memórias de outra vida..."


translate pt_br leaveDoll_8e65e29b:


    "Outro tempo..."


translate pt_br leaveDoll_f93d2a1b:


    "Outro {i}você{/i}..."


translate pt_br leaveDoll_b846ccd9:


    "...mas os pensamentos escapam como sonhos esquecidos."


translate pt_br leaveDoll_8dabefc6_2:


    ".."


translate pt_br leaveDoll_a20cefa7_7:


    "..."


translate pt_br leaveDoll_2521d867:


    "Ah, ok."


translate pt_br leaveDoll_6ff54d13:


    "Tá tudo bem, né?"


translate pt_br leaveDoll_dbcfd29d:


    "{size=-5}Você é só um \ {b}b o n e c o{/b}, afinal...{/size}"


translate pt_br leaveDoll_f17d3908:


    "E o papel de um boneco não é ter {i}pensamentos{/i} bobos ou {i}lembrar{/i} de coisas sem importância..."


translate pt_br leaveDoll_ad9a2f7f:


    "...mas sim ser uma {i}companhia.{/i}"


translate pt_br leaveDoll_8d3133d1:


    cat "Purrr..."


translate pt_br leaveDoll_35fc12aa:


    "E, a julgar pelo ronronar satisfeito do gato..."


translate pt_br leaveDoll_55c51d80:


    "...você parece estar cumprindo o seu papel perfeitamente."


translate pt_br leaveDoll_8efdd0d0:


    "Você é preenchido com uma sensação de orgulho avassaladora por isso."


translate pt_br leaveDoll_8dbe9dfc:


    "E assim, você {i}também{/i}... {w}se sente contente."


translate pt_br leaveDoll_8dabefc6_3:


    ".."


translate pt_br leaveDoll_a20cefa7_8:


    "..."


translate pt_br leaveDoll_bac39afa:


    "Final 35: Bonequinho"

translate pt_br strings:


    old "Leave cat"
    new "Deixar o gato"


    old "?????"
    new "?????"


    old "{b}You are ready...{/b}"
    new "{b}Você está pronto...{/b}"


    old "{color=#FF0000}{b}K I L L{/b}{/color}  cat.."
    new "{color=#FF0000}{b}M A T A R{/b}{/color}  o gato.."


    old "Ignore"
    new "Ignorar"


    old "Turn back"
    new "Se virar"


    old "I think I'll..."
    new "Acho que..."


    old "Go watch a movie"
    new "Vou assistir um filme"


    old "Go to the carnival"
    new "Vou ao festival"


    old "Go to dog park"
    new "Vou ao parque para cachorros"


    old "Go to the old theater."
    new "Ir ao cinema antigo."


    old "Go to the new cinema."
    new "Ir ao cinema novo."


    old "Move to another spot."
    new "Mudar para outro lugar."


    old "Confront the stranger."
    new "Confrontar o estranho."


    old "Leave the theater."
    new "Sair do cinema."


    old "{size=-8}Don't look behind you. Don't look behind you. Don't look behind you. Don't look behind you.{/size}"
    new "{size=-8}Não olhe para trás. Não olhe para trás. Não olhe para trás. Não olhe para trás.{/size}"


    old "{b}{color=#FF0000}{s}Don't{/s}{/color} look behind you...{/b}"
    new "{b}{color=#FF0000}{s}Não{/s}{/color} olhe para trás...{/b}"


    old "Try to leave the theater."
    new "Tentar sair da sala."


    old "Try to blend in with the crowd."
    new "Tentar se misturar à multidão."


    old "Do something else."
    new "Caçar outra coisa pra fazer."


    old "Enter the maze."
    new "Entrar no labirinto."


    old "Leave the park."
    new "Sair do parque."


    old "Kick the puppy."
    new "Chutar o filhote."


    old "Kill the puppy."
    new "Matar o filhote."


    old "Eat the puppy."
    new "Devorar o filhote."


    old "Pick up the puppy."
    new "Segurar o filhote."


    old "{size=+5}DROP IT!{/size}"
    new "{size=+5}SOLTA!{/size}"


    old "{size=-5}Hold on!{/size}"
    new "{size=-5}Calma aí!{/size}"


    old "LEAVE THE PARK."
    new "SAIR DO PARQUE."


    old "Stay at the park..."
    new "Ficar no parque..."


    old "{size=+40}{b}LEAVE! LEAVE! {color=#FF0000}LEAVE!{/color}{/b}{/size}"
    new "{size=+40}{b}VÁ EMBORA! VÁ EMBORA! {color=#FF0000}VÁ EMBORA!{/color}{/b}{/size}"


    old "{size=-6}THROW!{/size}"
    new "{size=-6}JOGA!{/size}"


    old "LEAVE."
    new "VÁ EMBORA."


    old "Pet dog."
    new "Acariciar o cachorro."


    old "{size=+5}{color=#FF0000}l e av e...{/color}{/size}"
    new "{size=+5}{color=#FF0000}v á  em b o ra...{/color}{/size}"


    old "{size=-5}pet the {b}d{/b}oG.{/size}"
    new "{size=-5}acariciar o {b}c{/b}aChoRro.{/size}"


    old "Leave the park?"
    new "Ir embora do parque?"


    old "Stay?"
    new "Ficar?"


    old "Leave?"
    new "Ir embora?"


    old "Leave and... go home..?"
    new "Sair e... ir para casa..?"


    old "I... I think I'll..."
    new "Eu... eu acho que..."


    old "G o  WAtc h  A  mo vIe"
    new "VOu  AsSis Tir  uM  F iL me"


    old "G o  To tHe cArn iVa l"
    new "V Ou  Ao fEst iVa l"


    old "gO  t o DOG pAr k"
    new "vOU  a o  pAr Que pAr a  CACHORROS"


    old "Go home..."
    new "Vou para casa..."


    old "G o tO {b}old theater.{/b}"
    new "V ou aO {b}cinema antigo.{/b}"


    old "go t o {b}new cinema.{/b}"
    new "vou  a o {b}cinema novo.{/b}"


    old ".ezam eht retnE"
    new ".otniribal on rartnE"


    old "{size=-8}{b}p u p p y.{/b}{/size}"
    new "{size=-8}{b}c a c h o r r i n h o.{/b}{/size}"


    old "Check pockets"
    new "Olhar os bolsos"


    old "Look around the area"
    new "Dar uma olhada ao redor"


    old "{color=#FF0000}Blood...{/color}"
    new "{color=#FF0000}Sangue...{/color}"


    old "Beg for forgiveness."
    new "Implorar por perdão."


    old "Go inside."
    new "Entrar em casa."


    old "Spare the mouse."
    new "Poupar o rato."


    old "Spare the mouse..."
    new "Poupar o rato..."


    old "{i}Spare the mouse.{/i}"
    new "{i}Poupar o rato.{/i}"


    old "{b}{i}Spare the mouse.{/i}{/b}"
    new "{b}{i}Poupar o rato.{/i}{/b}"


    old "SpaRe tHe {color=#FF0000}{b}mouse{/b}{/color}."
    new "PouPaR O {color=#FF0000}{b}rato{/b}{/color}."


    old "Feed mouse to cat."
    new "Dar o rato ao gato."


    old "{color=#FF0000}{b}Feed mouse to cat.{/b}{/color}"
    new "{color=#FF0000}{b}Dar o rato ao gato.{/b}{/color}"


    old "Stop the cat."
    new "Impedir o gato."


    old "Let cat feed."
    new "Deixar o gato se alimentar."


    old "Check pockets."
    new "Checar os bolsos."


    old "Look around the area."
    new "Olhar em volta."


    old "Buy a toy"
    new "Comprar um brinquedo."


    old "Hang out and do something else?"
    new "Ficar por aqui e fazer outra coisa?"


    old "Get out of the alley."
    new "Sair do beco."


    old "Check phone..."
    new "Olhar o celular..."


    old "Ignore phone..."
    new "Ignorar o celular..."


    old "Try something else?"
    new "Tentar outra coisa?"


    old "Keep playing?"
    new "Continuar brincando?"


    old "Run..."
    new "Fugir..."


    old "Back up..."
    new "Voltar..."


    old "Run {size=-10}restoreBACKUP.exe{/size}"
    new "Rodar {size=-10}VOLTARsave.exe{/size}"


    old "Begin restoration: _ _ _ _  _ _{#1st_game}"
    new "Comece a restauração: _ _ _ _ _ _"


    old "Begin restoration: B _ _ _  _ _"
    new "Comece a restauração: V _ _ _ _ _"


    old "Begin restoration: B A _ _  _ _"
    new "Comece a restauração: V O _ _ _ _"


    old "Begin restoration: B A C _  _ _"
    new "Comece a restauração: V O L _ _ _"


    old "Begin restoration: B A C K  _ _"
    new "Comece a restauração: V O L T _ _"


    old "Begin restoration: B A C K  U _"
    new "Comece a restauração: V O L T A _"


    old "Restoration Complete: B A C K  U P"
    new "Restauração concluída: V O L T A R"


    old "{b}B A C K  U P{/b}"
    new "{b}V O L T A R  S A V E{/b}"


    old "gO HOmE..."
    new "iR PAra CAsA..."


    old "Pick up plushie."
    new "Pegar a pelúcia. "


    old "Leave."
    new "Sair."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
