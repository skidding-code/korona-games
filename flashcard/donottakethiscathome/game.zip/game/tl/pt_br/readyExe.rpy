


translate pt_br end_Hint_71219ec6:


    "O que você deve fazer com um gato que tem sido {i}muito…{/i}"


translate pt_br end_Hint_8794b742:


    "{i}muito…{/i}"


translate pt_br end_Hint_ba6b8484:


    "{i}{size=+10}muito…{/size}{/i}"


translate pt_br end_Hint_7cf748e5:


    "{color=#FF0000}{b}l e v a d o . . ?{/b}{/color}"


translate pt_br end_Hint2_8d9f4bf5:


    "É algo que ele {color=#FF0000}merece.{/color}"


translate pt_br end_Hint2_22b30d96:


    "Algo... {w}{color=#FF0000}{b}definitivo…{/b}{/color}"


translate pt_br end_Hint3_829c3289:


    "Algo que ele esteve fazendo com você esse tempo todo."


translate pt_br end_Hint3_bd62e827:


    "...Vez após vez, {i}{b}sem{/b}{/i} parar."


translate pt_br end_Hint4_40d9ca73:


    "..?"


translate pt_br end_Hint4_2ace7158:


    "O ato de tirar uma vida..?"


translate pt_br end_Hint4_a3784eb7:


    "{alpha=0.1}matar{/alpha}"


translate pt_br end_Hint5_a3784eb7:


    "{alpha=0.1}matar{/alpha}"


translate pt_br end_Hint5_cc680146:


    "{alpha=0.3}matar{/alpha}"


translate pt_br end_Hint5_e0c70f7b:


    "{alpha=0.5}{size=+5}matar{/size}{/alpha}"


translate pt_br end_Hint5_f209d4a5:


    "{alpha=0.7}{size=+10}matar{/size}{/alpha}"


translate pt_br end_Hint5_4190fec2:


    "{size=+20}{color=#FF0000}{b}matar{/b}{/color}{/size}"

translate pt_br strings:
    old "Begin restoration: _ _ _ _  _ _{#2nd_game}"
    new "Comece a restauração: _ _ _ _ _"

    old "Begin restoration: K _ _ _  _ _"
    new "Comece a restauração: M _ _ _ _"

    old "Begin restoration: K I _ _  _ _"
    new "Comece a restauração: M A _ _ _"

    old "Begin restoration: K I L _  _ _"
    new "Comece a restauração: M A T _ _"

    old "Begin restoration: K I L L  _ _"
    new "Comece a restauração: M A T A _"

    old "Begin restoration: K I L L  I _"
    new "Restauração Completa: M A T A R"

    old "Restoration Complete: K I L L  I T"
    new "Restauração Completa: M A T A R"


    old "Hint?"
    new "Dica?"


    old "Ok, got it."
    new "Beleza, entendi."


    old "Need another hint."
    new "Preciso de outra dica."


    old "Gonna need another hint."
    new "Vou precisar de outra dica."


    old "Still not following..."
    new "Ainda não peguei…"


    old "Okay, one more hint..."
    new "Tá, só mais uma dica…"


    old "..?"
    new "..?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
