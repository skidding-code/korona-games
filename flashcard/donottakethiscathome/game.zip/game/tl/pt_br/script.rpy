


translate pt_br afterLanguage_9ea2f78c:


    " "


translate pt_br afterLanguage_9ea2f78c_1:


    " "


translate pt_br mainGame_a20cefa7:


    "..."


translate pt_br mainGame_fb0939d1:


    "Você se divertiu, não é?"


translate pt_br mainGame_5a1fba27:


    "Sim... {w}{i}Eu{/i} também~"


translate pt_br mainGame_a20cefa7_1:


    "..."


translate pt_br mainGame_b3e12ea5:


    "Mas..."


translate pt_br mainGame_8f9c4d0d:


    "Tudo que é bom precisa chegar ao fim..."


translate pt_br mainGame_d6f62ed1:


    "...E acredito que você esteja {b}pronto.{/b}"


translate pt_br mainGameStart_8dabefc6:


    ".."


translate pt_br mainGameStart_a20cefa7:


    "..."


translate pt_br mainGameStart_2f052c40:


    "Você está caminhando..."


translate pt_br mainGameStart_da373e99:


    "Certo. É claro."


translate pt_br mainGameStart_45f04c4f:


    "É a primeira vez em um bom tempo que te deu vontade de sair..."


translate pt_br mainGameStart_a20cefa7_1:


    "..."


translate pt_br mainGameStart_7039fb77:


    "E você..."


translate pt_br mainGameStart_4c74d5a4:


    "...na verdade, está feliz por ter saído."


translate pt_br mainGameStart_78cf1fa7:


    "tempo bom hoje"


translate pt_br mainGameStart_5ec9f3bf:


    "essa coisa boa"


translate pt_br mainGameStart_f21d0208:


    "talvez boa sorte também"


translate pt_br mainGameStart_57725082:


    "sim sorte"


translate pt_br mainGameStart_df511821:


    "{w=0.6}sorte {w=0.6}sorte {w=0.6}sorte {w=0.6}sorte {w=0.6}{nw}"


translate pt_br mainGameStart_a3f9f101:


    "sorte sorte sorte sorte {w=0.6}sorte {w=0.6}sorte {w=0.6}sorte {w=0.6}sorte {w=0.6}{nw}"


translate pt_br mainGameStart_db26c555:


    "sorte sorte sorte sorte sorte sorte sorte sorte {w=0.3}sorte {w=0.3}sorte {w=0.3}sorte {w=0.3}sorte {w=0.6}{nw}"


translate pt_br mainGameStart_9ea2f78c:


    " "


translate pt_br mainGameStart_8ca8510a:


    you "!!!" with vpunch


translate pt_br mainGameStart_dae0ec55:


    you "..."


translate pt_br mainGameStart_c7b678f0:


    "O tempo está absolutamente {i}perfeito{/i} hoje."


translate pt_br mainGameStart_dadb738e:


    "É um bom sinal, né?"


translate pt_br mainGameStart_a0ad31e8:


    "Talvez sua sorte finalmente esteja começando a mudar."


translate pt_br mainGameStart_c7b678f0_1:


    "O tempo está absolutamente {i}perfeito{/i} hoje."


translate pt_br mainGameStart_dadb738e_1:


    "É um bom sinal, né?"


translate pt_br mainGameStart_a0ad31e8_1:


    "Talvez sua sorte finalmente esteja começando a mudar."


translate pt_br mainGameStart_c8a18d3b:


    "Você se permite sentir empolgado com cautela pelas possibilidades de onde você poderia ir ou o que poderia fazer..."


translate pt_br mainGameStart_3967ef01:


    "...Talvez até {i}quem{/i} você poderia encontrar."


translate pt_br mainGameStart_1f1bf179:


    "Você está tão imerso em seus pensamentos que quase não percebe."


translate pt_br mainGameStart_22b1ba98:


    who "{size=-5}{alpha=0.4}Miau...{/alpha}{/size}"


translate pt_br mainGameStart_d83b2afc:


    you "{i}Hã? O que foi isso?{/i}"


translate pt_br mainGameStart_38cc5198:


    "Com a curiosidade guiando seus passos, você segue o som até a entrada de um beco solitário."


translate pt_br mainGameStart_741a7cdd:


    "A luz do sol só consegue alcançar, {i}com dificuldade{/i}, o espaço entre os altos edifícios de cada um dos lados."


translate pt_br mainGameStart_d1586eaa:


    "Você entra timidamente no beco e segue, com o cascalho solto e o entulho espalhado no chão amortecendo seus passos."


translate pt_br mainGameStart_a46fe60b:


    who "Miau! Miau!"


translate pt_br mainGameStart_1b77a27b:


    "Finalmente você tem visão da fonte do som na luz quente, quase etérea, do beco..."


translate pt_br mainGameStart_1b5c33fc:


    "No fim do beco..."


translate pt_br mainGameStart_f6400e85:


    "...em uma caixa grande de papelão..."


translate pt_br mainGameStart_8dabefc6_1:


    ".."


translate pt_br mainGameStart_a20cefa7_2:


    "..."


translate pt_br mainGameStart_69a9648a:


    "...tem um gato."


translate pt_br mainGameStart_605589a2:


    you "Hã. Acho que isso era… óbvio..?"


translate pt_br mainGameStart_e5fab8a0:


    cat "Miau!"


translate pt_br mainGameStart_fc6b31f2:


    "É um gato com uma aparência interessante. Seus lindos olhos amarelos brilham como ouro entre o mar negro de sua pelagem preta."


translate pt_br mainGameStart_3b9482ac:


    "Ele coloca as patas da frente na borda da caixa e olha para você."


translate pt_br mainGameStart_085f82bc:


    cat "Miau..."


translate pt_br mainGameStart_632d1a35:


    you "!!!" with hpunch


translate pt_br mainGameStart_242bb4ce:


    you "{i}T-{w}Tão..!{/i}"


translate pt_br mainGameStart_dae0ec55_1:


    you "..."


translate pt_br mainGameStart_90b68c87:


    you "..?"


translate pt_br mainGameStart_ea0ef047:


    you "Você parece tão..."


translate pt_br mainGameStart_8dabefc6_2:


    ".."


translate pt_br mainGameStart_ab627e54:


    "...{i}familiar{/i}."


translate pt_br mainGameStart_c06dcd96:


    "...Né?"


translate pt_br mainGameStart_e5fab8a0_1:


    cat "Miau!"


translate pt_br mainGameStart_a20cefa7_3:


    "..."


translate pt_br mainGameStart_23175e48:


    "Por outro lado, {i}é{/i} um gato. Afinal, não há muitas formas diferentes para um gato preto normal se parecer."


translate pt_br mainGameStart_a20cefa7_4:


    "..."


translate pt_br mainGameStart_849caf29:


    "Mas {i}esse{/i} aqui é uma fofura, com certeza."


translate pt_br mainGameStart_ff38a381:


    "Olhe..."


translate pt_br mainGameStart_480ec193:


    "Ele não está te encarando fixamente ou mostrando os dentes por você ter chegado tão perto, como outros gatos de rua já fizeram."


translate pt_br mainGameStart_1d08389c:


    "Está apenas sentado ali pacientemente..."


translate pt_br mainGameStart_85f1774e:


    "Esperando você fazer alguma coisa..."


translate pt_br mainChoice1_230edd2e:


    "Infelizmente, por mais fofo que o gato seja..."


translate pt_br mainChoice1_a20cefa7:


    "..."


translate pt_br mainChoice1_3313542d:


    "{size=-10}...você {b}nunca{/b} levaria essa {color=#FF0000}{b}coisa{/b}{/color} para casa.{/size}"


translate pt_br mainChoice1_8dabefc6:


    ".."


translate pt_br mainChoice1_a20cefa7_1:


    "..."


translate pt_br mainChoice1_ab96ac00:


    "...você só {i}não pode{/i} levá-lo para casa com você."


translate pt_br mainChoice1_e10d4d87:


    "Você é um adulto responsável."


translate pt_br mainChoice1_085f82bc:


    cat "Miau..."


translate pt_br mainChoice1_9c8908c5:


    "V-Você {i}é!{/i}"


translate pt_br mainChoice1_473c0e80:


    "Com aluguel e contas para pagar! Sem contar que você também precisa comprar comida para sobreviver!"


translate pt_br mainChoice1_6783211d:


    "Não tem como {i}você{/i} cuidar de um gato a longo prazo, né?"


translate pt_br mainChoice1_8d3712f3:


    "Você mal pode arcar com essa saidinha no seu dia de folga..."


translate pt_br mainChoice1_e5fab8a0:


    cat "Miau!"


translate pt_br mainChoice1_dae0ec55:


    you "..."


translate pt_br mainChoice1_af5ee6df:


    "O que fazer..."


translate pt_br mainChoice2_7f0ac95c:


    cat "..."


translate pt_br mainChoice2_dae0ec55:


    you "..."


translate pt_br mainChoice2_085f82bc:


    cat "Miau..."


translate pt_br mainChoice2_dae0ec55_1:


    you "..."


translate pt_br mainChoice2_549c54ff:


    you "Bem... Por que não?"


translate pt_br mainChoice2_9979a58c:


    "Né?"


translate pt_br mainChoice2_e5fab8a0:


    cat "Miau!"


translate pt_br mainChoice2_c97c6224:


    "Você mal estende os braços antes que o gato, ansioso, salte neles e escale até os seus ombros."


translate pt_br mainChoice2_6dcf309e:


    "Ele esfrega a cabeça na lateral da sua, acariciando-a."


translate pt_br mainChoice2_cc63b22e:


    cat "Purr... Purr... Purr..."


translate pt_br mainChoice2_dae0ec55_2:


    you "..."


translate pt_br mainChoice2_8de35a3a:


    you "Hehe..."


translate pt_br mainChoice2_b7f6e266:


    "Você não consegue deixar de sorrir com o entusiasmo do gato."


translate pt_br mainChoice2_c18c153e:


    you "Vamos sair daqui, tá?"


translate pt_br mainChoice2_67107e6c:


    cat "Purr..."


translate pt_br mainChoice2_0c4dd6d6:


    "No caminho de volta, você considera por um instante comprar ração para o gato..."


translate pt_br mainChoice2_8dabefc6:


    ".."


translate pt_br mainChoice2_a20cefa7:


    "..."


translate pt_br mainChoice2_ba9adcaf:


    "{size=-5}Mas isso seria perda de tempo.{/size}"


translate pt_br mainChoice2_40d9ca73:


    "..?"


translate pt_br mainChoice2_45eb50c5:


    "Você ignora a sensação estranha e segue em frente."


translate pt_br mainChoice2_df101305:


    "Você vive em um apartamento humilde."


translate pt_br mainChoice2_247ad3ce:


    "Um quarto. Um banheiro."


translate pt_br mainChoice2_2d3f71e5:


    "Apenas {i}você{/i} vivendo sozinho nele..."


translate pt_br mainChoice2_f380a402:


    "Então, é estranho ter outro ser vivo aí dentro depois de tanto tempo."


translate pt_br mainChoice2_8b0c916e:


    "Mesmo que {i}seja{/i} só um gato."


translate pt_br mainChoice2_1c9ee7fd:


    "Depois de trancar a porta e colocar o gato no chão, você espera que ele saia andando e explorando o novo ambiente."


translate pt_br mainChoice2_a20cefa7_1:


    "..."


translate pt_br mainChoice2_480ae195:


    "Mas ele apenas fica sentado e olha para você com expectativa..."

translate pt_br strings:
    old "This game is not suitable for children or the easily disturbed.\n\nIt includes depictions of horror elements, human/animal violence and death,\nabuse/abusive relationship(s), disturbing images, loud noises, flashing images/lights and more.\nIndividuals suffering from anxiety, depression or certain fears/phobias may not have a safe experience playing this game.\n\nFor full list of content/trigger warnings go to 'About' section in the game's main menu."
    new "Este jogo não é adequado para crianças ou para pessoas sensíveis. \n\nInclui representações de elementos de horror, violência animal/humana e morte,\nabuso/relacionamento(s) abusivo(s), imagens perturbadoras, ruídos altos, imagens/luzes piscando e mais.\nIndivíduos que sofrem de ansiedade, depressão ou certos medos/fobias podem não ter uma experiência segura ao jogar este jogo.\n\nPara a lista completa de avisos de conteúdo/gatilho, vá à seção 'Sobre' no menu principal do jogo."

    old "Please take care of yourself."
    new "Por favor, cuide-se."

    old "\\ "
    new "\\ "


    old "Take cat home!"
    new "Levar o gato para casa!"


    old "Do not take cat home..."
    new "Não levar o gato para casa..."

    old "You"
    new "Você"

    old "Cat"
    new "Gato"

    old "Cat #2"
    new "Gato #2"




    old "Text"
    new "Texto"

    old "Cat on screen"
    new "Gato na tela"

    old "Audience"
    new "Público"

    old "Dog"
    new "Cachorro"

    old "Cat Doll"
    new "Boneca Gato"

    old "Kitten"
    new "Gatinho"

    old "I T"
    new "I S S O"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
