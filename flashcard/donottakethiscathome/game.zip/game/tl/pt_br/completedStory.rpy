


translate pt_br hereAgain_8644fdbf:


    who "brinque comigo..." nointeract


translate pt_br hereAgain_6f50b679:


    who "..."


translate pt_br hereAgain_a11fa0b8:


    who "então suma."


translate pt_br hereAgain_6f50b679_1:


    who "..."


translate pt_br hereAgain_17114041:


    who "de verdade?"


translate pt_br hereAgain_88bc4e2a:


    who "você vai abandonar essa conclusão patética..."


translate pt_br hereAgain_92534b16:


    who "...e brincar mais um pouco comigo?"


translate pt_br hereAgain_78091749:


    who "Não prometa se não estiver falando sério." nointeract


translate pt_br hereAgain_6f50b679_2:


    who "..."


translate pt_br hereAgain_a11fa0b8_1:


    who "então suma."


translate pt_br hereAgain_84de3be0:


    who "...bom."


translate pt_br hereAgain_a5457a87:


    who "Muito bom."


translate pt_br hereAgain_281311fe:


    who "Me encontre..."


translate pt_br hereAgain_9ea2f78c:


    " "

translate pt_br strings:


    old "no. never again."
    new "não. nunca mais."


    old "yes..."
    new "sim..."


    old "no..."
    new "não..."


    old "yes."
    new "sim."

    old "D{alpha=0.0}O NOT BETRAY ME AGAIN.{/alpha}"
    new "N{alpha=0.0}ÃO ME TRAIA DE NOVO.{/alpha}"

    old "DO{alpha=0.0} NOT BETRAY ME AGAIN.{/alpha}"
    new "NÃ{alpha=0.0}O ME TRAIA DE NOVO.{/alpha}"

    old "DO {alpha=0.0}NOT BETRAY ME AGAIN.{/alpha}"
    new "NÃO{alpha=0.0} ME TRAIA DE NOVO.{/alpha}"

    old "DO N{alpha=0.0}OT BETRAY ME AGAIN.{/alpha}"
    new "NÃO {alpha=0.0}ME TRAIA DE NOVO.{/alpha}"

    old "DO NO{alpha=0.0}T BETRAY ME AGAIN.{/alpha}"
    new "NÃO M{alpha=0.0}E TRAIA DE NOVO.{/alpha}"

    old "DO NOT{alpha=0.0} BETRAY ME AGAIN.{/alpha}"
    new "NÃO ME{alpha=0.0} TRAIA DE NOVO.{/alpha}"

    old "DO NOT {alpha=0.0}BETRAY ME AGAIN.{/alpha}"
    new "NÃO ME {alpha=0.0}TRAIA DE NOVO.{/alpha}"

    old "DO NOT B{alpha=0.0}ETRAY ME AGAIN.{/alpha}"
    new "NÃO ME T{alpha=0.0}RAIA DE NOVO.{/alpha}"

    old "DO NOT BE{alpha=0.0}TRAY ME AGAIN.{/alpha}"
    new "NÃO ME TR{alpha=0.0}AIA DE NOVO.{/alpha}"

    old "DO NOT BET{alpha=0.0}RAY ME AGAIN.{/alpha}"
    new "NÃO ME TRA{alpha=0.0}IA DE NOVO.{/alpha}"

    old "DO NOT BETR{alpha=0.0}AY ME AGAIN.{/alpha}"
    new "NÃO ME TRAI{alpha=0.0}A DE NOVO.{/alpha}"

    old "DO NOT BETRA{alpha=0.0}Y ME AGAIN.{/alpha}"
    new "NÃO ME TRAIA{alpha=0.0} DE NOVO.{/alpha}"

    old "DO NOT BETRAY{alpha=0.0} ME AGAIN.{/alpha}"
    new "NÃO ME TRAIA {alpha=0.0}DE NOVO.{/alpha}"

    old "DO NOT BETRAY {alpha=0.0}ME AGAIN.{/alpha}"
    new "NÃO ME TRAIA D{alpha=0.0}E NOVO.{/alpha}"

    old "DO NOT BETRAY M{alpha=0.0}E AGAIN.{/alpha}"
    new "NÃO ME TRAIA DE{alpha=0.0} NOVO.{/alpha}"

    old "DO NOT BETRAY ME{alpha=0.0} AGAIN.{/alpha}"
    new "NÃO ME TRAIA DE {alpha=0.0}NOVO.{/alpha}"

    old "DO NOT BETRAY ME {alpha=0.0}AGAIN.{/alpha}"
    new "NÃO ME TRAIA DE N{alpha=0.0}OVO.{/alpha}"

    old "DO NOT BETRAY ME A{alpha=0.0}GAIN.{/alpha}"
    new "NÃO ME TRAIA DE NO{alpha=0.0}VO.{/alpha}"

    old "DO NOT BETRAY ME AG{alpha=0.0}AIN.{/alpha}"
    new "NÃO ME TRAIA DE NOV{alpha=0.0}O.{/alpha}"

    old "DO NOT BETRAY ME AGA{alpha=0.0}IN.{/alpha}"
    new "NÃO ME TRAIA DE NOVO{alpha=0.0}.{/alpha}"

    old "DO NOT BETRAY ME AGAI{alpha=0.0}N.{/alpha}"
    new "NÃO ME TRAIA DE NOVO."

    old "DO NOT BETRAY ME AGAIN{alpha=0.0}.{/alpha}"
    new "NÃO ME TRAIA DE NOVO."

    old "DO NOT BETRAY ME AGAIN."
    new "NÃO ME TRAIA DE NOVO."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
