


translate pt_br atHome_start_dc8d0895:


    "Tipo o quê?"


translate pt_br atHome_start_dc8d0895_1:


    "Tipo o quê?"


translate pt_br cleanHome_a2afa525:


    "Você decide que, mesmo sendo seu dia de folga, isso não quer dizer que você deva ser {i}completamente{/i} improdutivo."


translate pt_br cleanHome_d5bf1ac2:


    "Você sabe que tem um convidado e tudo mais, mas não deveria adiar suas tarefas."


translate pt_br cleanHome_82116c0b:


    "Melhor terminar logo enquanto está no clima pra isso..."


translate pt_br cleanHome_38aeb1c1:


    "Então, por agora, você se veste, arregaça as mangas e começa a limpar o apartamento."


translate pt_br cleanHome_8dabefc6:


    ".."


translate pt_br cleanHome_a20cefa7:


    "..."


translate pt_br cleanHome_0ef3b42c:


    "Pelo menos..."


translate pt_br cleanHome_be509105:


    "...você {i}tenta{/i}?"


translate pt_br cleanHome_251a3003:


    "Você varre a sala..."


translate pt_br cleanHome_801add69:


    "Você limpa o balcão da cozinha..."


translate pt_br cleanHome_0f5de544:


    "Você..."


translate pt_br cleanHome_94b91bfc:


    "Tá, você não arruma a cama, mas quem é que faz isso afinal?"


translate pt_br cleanHome_a20cefa7_1:


    "..."


translate pt_br cleanHome_b3e12ea5:


    "Ainda assim..."


translate pt_br cleanHome_e3226b50:


    "Você nota que, não importa quanto limpe..."


translate pt_br cleanHome_fe5c443f:


    "...você continua encontrando mais bagunça do que quando começou."


translate pt_br cleanHome_dae0ec55:


    you "..."


translate pt_br cleanHome_6cf4e540:


    "Você espia o gato."


translate pt_br cleanHome_9e899f4f:


    "Você suspeita que ele possa ser o culpado por trás desse mistério..."


translate pt_br cleanHome_ef50fc2a:


    "Mas toda vez que você corre para checar ou pegá-lo no pulo..."


translate pt_br cleanHome_78b6d9cf:


    cat "Purr.. Purr.."


translate pt_br cleanHome_e12dcff9:


    "...Você sempre o encontra cochilando na sala."


translate pt_br cleanHome_78b6d9cf_1:


    cat "Purr.. Purr.."


translate pt_br cleanHome_dae0ec55_1:


    you "..."


translate pt_br cleanHome_70e6e0c9:


    "Você continua limpando, mas o gato..."


translate pt_br cleanHome_350e9976:


    "...ou {i}alguma coisa{/i}..."


translate pt_br cleanHome_3333a159:


    "...continua deixando cada vez mais bagunça pelo caminho."


translate pt_br keepCleaning_f8527730:


    "Você continua limpando, mas há cada vez mais bagunça..."


translate pt_br keepCleaning_2eaedbe8:


    "E mais..."


translate pt_br keepCleaning_a20cefa7:


    "..."


translate pt_br keepCleaning_d9897097:


    "E {i}mais{/i}..."


translate pt_br keepCleaning_8fe73cbe:


    "Quando você finalmente para e olha ao seu redor..."


translate pt_br keepCleaning_8dabefc6:


    ".."


translate pt_br keepCleaning_a20cefa7_1:


    "..."


translate pt_br keepCleaning_a20cefa7_2:


    "..."


translate pt_br keepCleaning_df223326:


    "...você nem reconhece mais sua casa."


translate pt_br keepCleaning_d37d2b14:


    "Há pilhas de lixo por toda parte. Você {i}tem{/i} mesmo tantas coisas assim?"


translate pt_br keepCleaning_f12f1103:


    "Você não se lembra de ter comprado ou ganhado a maior parte disso."


translate pt_br keepCleaning_6b45c41b:


    "As pilhas se erguem sobre você."


translate pt_br keepCleaning_1b4957f6:


    "Você se sente claustrofóbico."


translate pt_br keepCleaning_7c04f542:


    "O fedor de lixo é insuportável, apesar de suas mãos estarem doloridas de tanto líquido de limpeza que você tem usado."


translate pt_br keepCleaning_9e56909e:


    "Seus olhos ainda ardem por causa do alvejante."


translate pt_br keepCleaning_1f4f5647:


    "Você precisa de ar."


translate pt_br keepCleaning_47312e78:


    "Você precisa sair daqui."


translate pt_br keepCleaning_a46102ae:


    "Crack!" with hpunch


translate pt_br keepCleaning_08ca5ed4:


    "Você ouve um barulho e vê uma xícara de chá, que com certeza não é sua, quebrada no chão."


translate pt_br keepCleaning_2ee0c458:


    "Você olha para cima e vê o gato sentado em uma pilha bem instável de louças e utensílios de cozinha."


translate pt_br keepCleaning_dde8fd86:


    "Ele empurra cuidadosamente outra xícara de chá da pilha, fazendo-a despencar no chão..."


translate pt_br keepCleaning_f68c64ac:


    "...mas você nem pisca quando ela se despedaça."


translate pt_br keepCleaning_4cb92d86:


    "Em vez disso..."


translate pt_br keepCleaning_cd64e084:


    you "Heh..."


translate pt_br keepCleaning_bc45b6ba:


    "Você começa a rir."


translate pt_br keepCleaning_0931d500:


    you "Hehehe!"


translate pt_br keepCleaning_d7e774f2:


    "De repente, você está gargalhando. É tão hilário..."


translate pt_br keepCleaning_852190f9:


    you "HAHAHA!" with hpunch


translate pt_br keepCleaning_a2a51a94:


    "...que você começa a lacrimejar."


translate pt_br keepCleaning_3e62584c:


    you "Eu {i}sabia{/i} foi você! {i}Você{/i} fez isso, não foi?"


translate pt_br keepCleaning_f6110b17:


    "Você pega o maior pedaço de cerâmica das xícaras quebradas..."


translate pt_br keepCleaning_ffcea493:


    you "{size=+5}{b}{i}NÃO{/i}{/b} FOI?!{/size}" with hpunch


translate pt_br keepCleaning_bcb59dd1:


    "...e joga no gato."


translate pt_br keepCleaning_d9053550:


    "O gato desvia pulando da pilha."


translate pt_br keepCleaning_89623c0d:


    "A pilha... balança."


translate pt_br keepCleaning_6ba05e33:


    "E balança..."


translate pt_br keepCleaning_8dabefc6_1:


    ".."


translate pt_br keepCleaning_a20cefa7_3:


    "..."


translate pt_br keepCleaning_03fd754d:


    "...Está caindo."


translate pt_br keepCleaning_28b3ac41:


    you "!!"


translate pt_br keepCleaning_b1a6c334:


    "...Está caindo na sua direç--{w=0.8}{nw}"


translate pt_br keepCleaning_180588a5:


    "{size=+25}{b}{i}CRASH!!{/i}{/b}{/size}" with vpunch


translate pt_br keepCleaning_8dabefc6_2:


    ".."


translate pt_br keepCleaning_a20cefa7_4:


    "..."


translate pt_br keepCleaning_77a402e9:


    "...Você não consegue se mexer."


translate pt_br keepCleaning_23a3bbe5:


    "Você está..."


translate pt_br keepCleaning_19c2b1c0:


    "Você está soterrado."


translate pt_br keepCleaning_1600c9a3:


    "A pilha caiu em cima de você."


translate pt_br keepCleaning_f5935cf0:


    "Cacos de cerâmica fina e talheres afiados estão perfurando sua pele..."


translate pt_br keepCleaning_2e357ce3:


    "Seus {b}órgãos{/b}..."


translate pt_br keepCleaning_9c53ce22:


    "Seus ossos parecem soltos e moles... esmagados sob os pesados utensílios."


translate pt_br keepCleaning_cea9f1b7:


    "Uma poça de líquido morno se forma sob você."


translate pt_br keepCleaning_7c3e10e7:


    "Com o que resta das suas forças..."


translate pt_br keepCleaning_8dd57887:


    "...você ouve as patas do gato se aproximando suavemente de você, se deitando e ronronando sonolento."


translate pt_br keepCleaning_55355e09:


    cat "Purr.. Purr.."


translate pt_br keepCleaning_dae0ec55:


    you "..."


translate pt_br keepCleaning_4914da37:


    "É..."


translate pt_br keepCleaning_8ad69668:


    "Um cochilo parece uma ideia..."


translate pt_br keepCleaning_8a5ba85b:


    "{size=-5}muito...{/size}"


translate pt_br keepCleaning_444906a3:


    "{size=-10}boa...{/size}"


translate pt_br keepCleaning_dae0ec55_1:


    you "..."


translate pt_br keepCleaning_a20cefa7_5:


    "..."


translate pt_br keepCleaning_fdf7d678:


    "Final 1: Uma Fuga (Não Tão) Limpa"


translate pt_br catchCat_2d0b7d8d:


    "Como você espera terminar de limpar se esse diabinho está fazendo tanta bagunça?"


translate pt_br catchCat_bcf6dd4d:


    "Não."


translate pt_br catchCat_eeaa381b:


    "Você {i}sabe{/i} que o gato é o culpado..."


translate pt_br catchCat_f18bba2e:


    "Você pensa em prendê-lo no banheiro, pelo menos até você ter limpado o resto do apartamento..."


translate pt_br catchCat_857162a0:


    "...Mas não parece justo, já que você não tem nenhuma prova disso."


translate pt_br catchCat_23e7b8d0:


    "Você precisa investigar isso mais a fundo."


translate pt_br catchCat_7142699f:


    "Você precisa de provas."


translate pt_br catchCat_5d38d834:


    "Não apenas para o bem da sua sanidade, mas, mais importante, para o bem..."


translate pt_br catchCat_d81de3ab:


    "...da {b}{i}limpeza!{/i}{/b}" with hpunch


translate pt_br catchCat_302a1096:


    "Você começa a limpar de novo e dá uma espiada por trás de você, vendo apenas vislumbres de uma pata aqui ou um rabo ali..."


translate pt_br catchCat_66dd8df3:


    "Mas, como antes, quando você corre de volta para a sala, o gato ainda está dormindo."


translate pt_br catchCat_7c813d85:


    you "{i}Beleza, quer brincar, gato?{/i}"


translate pt_br catchCat_1df4b1f2:


    you "{i}Então vamos brincar{/i}..."


translate pt_br catchCat_5264ec6b:


    "Desta vez, você decide armar uma armadilha – uma que seu amigo felino não poderá resistir."


translate pt_br catchCat_e6ab25a3:


    "Você ataca o balcão da ilha da cozinha e o deixa nos {b}{i}trinques{/i}{/b}."


translate pt_br catchCat_f8c31f4c:


    "Está {i}brilhando{/i} assim que você termina."


translate pt_br catchCat_ece57ede:


    "Está tão limpo..."


translate pt_br catchCat_737ad384:


    "...que você daria uma voadora em qualquer um que simplesmente {b}{i}pensasse{/i}{/b} em comer nele."


translate pt_br catchCat_965246c3:


    "A armadilha perfeita para o seu pequeno sabotador da limpeza."


translate pt_br catchCat_caf7a734:


    "Você assobia inocentemente enquanto sai do cômodo e se esconde atrás da esquina da entrada do corredor."


translate pt_br catchCat_66b634bf:


    "Do ângulo em que você está, tem uma visão perfeita do gato e do balcão da ilha."


translate pt_br catchCat_12e1a084:


    "Impossível não pegar o culpado com a boca na botija agora."


translate pt_br catchCat_c456968c:


    "Se realmente não for o gato, talvez você lhe dê um petisco como um pedido de desculpas pelas suspeitas?"


translate pt_br catchCat_0197e62d:


    "Mas enquanto você pensa se deve passar no supermercado para comprar um pouco de peixe... o gato começa a..."


translate pt_br catchCat_8f5e83db:


    "...mudar?"


translate pt_br catchCat_80e45c97:


    "Suas costas, que estavam subindo e descendo uniformemente pela respiração momentos atrás..."


translate pt_br catchCat_abeaf9eb:


    "...agora estão se ondulando em pequenos tremores, como uma onda agitada em um mar negro."


translate pt_br catchCat_451b684a:


    "Está tremendo..."


translate pt_br catchCat_4da3e6b9:


    "Está borbulhando..."


translate pt_br catchCat_91204d86:


    "Está inchando..."


translate pt_br catchCat_51fdb3a7:


    "Está {b}{i}inchando--{/i}{/b}{w=0.3}{nw}"


translate pt_br catchCat_7b893834:


    "{b}{size=+15}PLOP!{/size}{/b}" with vpunch


translate pt_br catchCat_90b68c87:


    you "..?"


translate pt_br catchCat_78ae5d65:


    you "..?!" with hpunch


translate pt_br catchCat_13a4394e:


    you "{i}Mas... que {b}porra{/b}..?{/i}"


translate pt_br catchCat_0673262a:


    "Seu queixo cai em descrença ao ver {b}outro gato{/b} explodir para fora do felino que você havia levado para casa, que ainda, {i}ainda{/i}, estava dormindo."


translate pt_br catchCat_dae0ec55:


    you "..."


translate pt_br catchCat_23a3bbe5:


    "Você está..."


translate pt_br catchCat_3b3dcfd1:


    "Você tem certeza {i}absoluta{/i} de que não é assim que gatos dão à luz."


translate pt_br catchCat_200e4ba1:


    "Mas, mais importante..."


translate pt_br catchCat_c1255ce3:


    "Você observa o gato número 2 se sacudir antes de pular em cima do balcão..."


translate pt_br catchCat_0f4a0748:


    "...revirando-se em cima dele e deixando pelos e sujeira para trás."


translate pt_br catchCat_7f180865:


    you "{i}Hm. Provavelmente deveria ter dado um banho nele mais cedo{/i}..."


translate pt_br catchCat_cc415aaf:


    "Você sente que sua mente está demorando a processar a realidade da descoberta que acabou de fazer..."


translate pt_br catchCat_5624fa4d:


    "...mas você parece incapaz de pensar além de observações menores."


translate pt_br catchCat_b4139f5d:


    "Por exemplo..."


translate pt_br catchCat_c841f0ba:


    "Embora os como e porquês do que você está testemunhando lhe escapem..."


translate pt_br catchCat_7d96eba3:


    "...a pergunta mais pertinente que surge é: se o gato original ainda está dormindo..."


translate pt_br catchCat_8301e7ce:


    "...e o gato clonado está ocupado fazendo {i}mais uma{/i} bagunça..."


translate pt_br catchCat_8dabefc6:


    ".."


translate pt_br catchCat_a20cefa7:


    "..."


translate pt_br catchCat_031168fd:


    "{size=-8}...então onde estão todos os {b}outros{/b} clones?{/size}"


translate pt_br catchCat_8ca8510a:


    you "!!!" with vpunch


translate pt_br catchCat_9107a91b:


    "De repente, os dois gatos olham diretamente para você em perfeita sincronia."


translate pt_br catchCat_7f0ac95c:


    cat "..."


translate pt_br catchCat_2849e452:


    cat2 "..."


translate pt_br catchCat_dae0ec55_1:


    you "..."


translate pt_br catchCat_5b9cf052:


    "Seus olhos prendem você no lugar com sua intensidade..."


translate pt_br catchCat_a20cefa7_1:


    "..."


translate pt_br catchCat_bf0874e3:


    "Mas..."


translate pt_br catchCat_77335cac:


    "Você percebe, com a familiar sensação aterradora de estar sendo observado por trás..."


translate pt_br catchCat_7fe62e1d:


    "...que eles não são os {i}únicos{/i} olhando para você."


translate pt_br catchCat_2da9a525:


    "Você se vira lentamente..."


translate pt_br catchCat_479c3431:


    you "!!" with vpunch


translate pt_br catchCat_d6b508aa:


    "Empilhados no corredor atrás de você, do chão ao teto..."


translate pt_br catchCat_8434b31c:


    "...está uma parede viva, respirando e {i}se contorcendo{/i}, feita de gatos..."


translate pt_br catchCat_2df33dd1:


    "...de {i}{b}clones{/b}{/i}..."


translate pt_br catchCat_6a0c9ea0:


    "...todos empilhados uns sobre os outros."


translate pt_br catchCat_a9d5e578:


    "Os olhos dourados e brilhantes de cada gato na parede ondulante de puro pelo preto..."


translate pt_br catchCat_34b528c2:


    "Cada olho..."


translate pt_br catchCat_dff87f71:


    "...está fixo em você."


translate pt_br catchCat_dae0ec55_2:


    you "..."


translate pt_br catchCat_5a6e3687:


    "Por medo e uma necessidade desesperada de se afastar desse borrão na realidade e na ordem natural..."


translate pt_br catchCat_9a5f0b90:


    "...você dá um único passo para trás."


translate pt_br catchCat_8dabefc6_1:


    ".."


translate pt_br catchCat_a20cefa7_2:


    "..."


translate pt_br catchCat_4d3e0545:


    "..E em resposta."


translate pt_br catchCat_3d2d7818:


    "A parede simplesmente..."


translate pt_br catchCat_3c6ffc63:


    "...{b}se desfaz{/b}."


translate pt_br catchCat_a3a8c547:


    "...os gatos todos correndo sobre você."


translate pt_br catchCat_a7561dac:


    "Isso seria meio..."


translate pt_br catchCat_f46b477d:


    "...fofo?"


translate pt_br catchCat_5af96194:


    "...Se suas patas macias não escondessem garras tão afiadas quanto facas."


translate pt_br catchCat_7ae94986:


    "Você tenta se proteger... {w}mas há tantos deles."


translate pt_br catchCat_cfcc4899:


    "O sangue vaza constantemente dos seus arranhões..."


translate pt_br catchCat_9d23ba22:


    "Você se sente tonto..."


translate pt_br catchCat_f52affb8:


    "Com a pouca força que lhe resta..."


translate pt_br catchCat_f55aea98:


    "...você vira a cabeça e observa enquanto os gatos rasgam o carpete e o estofado..."


translate pt_br catchCat_9d8db959:


    "...derrubam vasos, pratos e luminárias..."


translate pt_br catchCat_1a299f19:


    "...arranham as paredes..."


translate pt_br catchCat_6f71224c:


    "Vai levar uma eternidade para limpar tudo isso, você pensa."


translate pt_br catchCat_d44174fd:


    "Talvez você enfrente tudo isso de novo mais tarde..."


translate pt_br catchCat_9ca1c0cc:


    "...logo depois de você..."


translate pt_br catchCat_a6bf102e:


    "{size=-5}...tirar um..{/size}"


translate pt_br catchCat_cac82399:


    "{size=-8}...cochilo...{/size}"


translate pt_br catchCat_dae0ec55_3:


    you "..."


translate pt_br catchCat_54aa11a1:


    "Com uma inspiração irritada..."


translate pt_br catchCat_a20cefa7_3:


    "..."


translate pt_br catchCat_3f89c6a6:


    "...você dá seu último suspiro."


translate pt_br catchCat_a20cefa7_4:


    "..."


translate pt_br catchCat_6956a6b4:


    "Final 2: Problema Em Dobro"


translate pt_br watchTV_7a132060:


    "Você não está cansado o suficiente para cochilar, mas está com preguiça demais para começar qualquer uma das suas tarefas."


translate pt_br watchTV_59ecac21:


    "Então você decide assistir a um filme."


translate pt_br watchTV_e6b3f86f:


    "Você veste seu pijama favorito, faz pipoca com uma quantidade obscena de manteiga e vai até sua poltrona..."


translate pt_br watchTV_addc29e1:


    "...só para descobrir que o gato já está cochilando nela."


translate pt_br watchTV_c4045cbc:


    "Você franze um pouco a testa, pensativo."


translate pt_br watchTV_4f7364cd:


    "Seu sofá não está no melhor ângulo para uma experiência ideal de assistir TV, e você não está afim de movê-lo e ter que colocá-lo de volta depois."


translate pt_br watchTV_d1311036:


    "As únicas opções que restam são sentar no chão..."


translate pt_br watchTV_ac7e9daa:


    "...ou tirar o gato e reivindicar seu trono."


translate pt_br sitOnFloor_f258c8af:


    "Você decide sentar no chão. Afinal, o gato é um convidado, e você se orgulha pelo menos de ser um bom anfitrião."


translate pt_br sitOnFloor_94fced8c:


    "Bem... Pelo menos você se orgulharia disso caso já tivesse tido algum convidado antes."


translate pt_br sitOnFloor_59924bfd:


    "Você pega um cobertor e algumas almofadas e faz um ninho confortável na frente da poltrona."


translate pt_br sitOnFloor_c9c06a2d:


    "Coloca um filme aleatório da sua coleção e percebe na hora que é um dos seus filmes de terror favoritos."


translate pt_br sitOnFloor_178f4f3c:


    "Você já o viu algumas vezes, mas ele nunca deixa de fazer seu coração disparar."


translate pt_br sitOnFloor_af009a23:


    "Depois de alguns minutos, você já está envolvido, se reconectando com a história e os personagens."


translate pt_br sitOnFloor_5c1e198e:


    "Os sustos ainda demoram um pouco para aparecer, mas..."


translate pt_br sitOnFloor_b30c491a:


    "...por algum motivo, você sente que algo está te observando por trás."


translate pt_br sitOnFloor_84c7ae7d:


    "Você sabe que provavelmente não é nada, mas se sente obrigado a checar mesmo assim."


translate pt_br sitOnFloor_06fb4a58:


    "Você espia por cima do seu ombro..."


translate pt_br sitOnFloor_ac50ef1c:


    you "{size=+5}AAH!{/size}" with vpunch


translate pt_br sitOnFloor_81f1b73f:


    "...só para levar um susto, fazendo algumas pipocas caírem da tigela que está no seu colo."


translate pt_br sitOnFloor_1f13af02:


    "O gato está acordado e olhando bem para você."


translate pt_br sitOnFloor_7f0ac95c:


    cat "..."


translate pt_br sitOnFloor_143b81e3:


    you "*Suspiro*"


translate pt_br sitOnFloor_eea23dd1:


    "Você respira fundo, se recuperando do seu coração quase ter saído pela boca e imediatamente se sente um idiota."


translate pt_br sitOnFloor_dfcad786:


    "Era só o gato, é claro. Estava tão quieto que você havia esquecido que estava bem atrás de você..."


translate pt_br sitOnFloor_f37d47cd:


    "...mesmo sendo a razão pela qual você está sentado no chão pra começo de conversa."


translate pt_br sitOnFloor_50a15250:


    "Você pega o controle remoto com a mão trêmula, pretendendo voltar algumas partes que perdeu."


translate pt_br sitOnFloor_236c0e1e:


    "No entanto, assim que você aperta o botão de retroceder..."


translate pt_br sitOnFloor_8dabefc6:


    ".."


translate pt_br sitOnFloor_a20cefa7:


    "..."


translate pt_br sitOnFloor_493f0953:


    "...a TV desliga."


translate pt_br sitOnFloor_90b68c87:


    you "..?"


translate pt_br sitOnFloor_70a6570e:


    "Você pisca, confuso."


translate pt_br sitOnFloor_78747100:


    "Nada mais desligou. A luz fraca da cozinha ainda estava acesa..."


translate pt_br sitOnFloor_af8a226c:


    "O relógio digital ainda piscava... e..."


translate pt_br sitOnFloor_78037d5b:


    "...o aparelho de DVD ainda estava retrocedendo..."


translate pt_br sitOnFloor_3fa5f761:


    "Claramente, a energia não caiu... Então, por que...?"


translate pt_br sitOnFloor_6a84e27a:


    "Um frio percorre sua espinha ao ver o reflexo do gato na tela escura da TV."


translate pt_br sitOnFloor_a74decef:


    "Ele ainda está..."


translate pt_br sitOnFloor_29346eda:


    "...te olhando?"


translate pt_br sitOnFloor_68f3d642:


    you "{i}Gatos encaram, idiota. É meio que a pira deles...{/i}"


translate pt_br sitOnFloor_97996fab:


    "...né?"


translate pt_br sitOnFloor_c6dea0bf:


    "E você é novo na vida dele. É claro que ele vai te observar de perto para ver se você é confiável."


translate pt_br sitOnFloor_22126792:


    "Você liga a TV de novo, enquanto se tranquiliza mentalmente."


translate pt_br sitOnFloor_8dabefc6_1:


    ".."


translate pt_br sitOnFloor_40d9ca73:


    "..?"


translate pt_br sitOnFloor_67aaa788:


    "O quê?"


translate pt_br sitOnFloor_4be706f4:


    "A TV está ligada, mas... o filme não está passando na tela."


translate pt_br sitOnFloor_90b93b6a:


    "É..."


translate pt_br sitOnFloor_20572e6e:


    "!!"


translate pt_br sitOnFloor_0034943b:


    "É você..?"


translate pt_br sitOnFloor_06079290:


    "Você se vê franzindo a testa na tela enquanto sente sua sobrancelha contrair junto."


translate pt_br sitOnFloor_bc0619d3:


    "É como uma filmagem sua em tempo real, como se estivesse sendo gravado..."


translate pt_br sitOnFloor_b084c950:


    "Você sente a sensação familiar de sua mente se concentrando em pequenos detalhes para evitar a visão mais ampla da sua situação atual."


translate pt_br sitOnFloor_907a81a6:


    "Evitando as perguntas de como isso está acontecendo... de quem ou o que está fazendo isso..."


translate pt_br sitOnFloor_4bda7300:


    "...e por quê."


translate pt_br sitOnFloor_ac593ae3:


    "De repente, sua versão espelhada sorri e acena para você. Por conta própria."


translate pt_br sitOnFloor_98f42958:


    "Você não acena de volta, atordoado demais para se mover."


translate pt_br sitOnFloor_a20cefa7_1:


    "..."


translate pt_br sitOnFloor_49b81530:


    "No entanto, o {b}você{/b} na tela não parece se importar."


translate pt_br sitOnFloor_470fca2a:


    "Então, ele se levanta..."


translate pt_br sitOnFloor_46677075:


    "Ele sai do enquadramento..."


translate pt_br sitOnFloor_a20cefa7_2:


    "..."


translate pt_br sitOnFloor_98a9232f:


    "E-"


translate pt_br sitOnFloor_2b614492:


    you "{b}{i}AAHHH!!{/i}{/b}" with vpunch


translate pt_br sitOnFloor_57aec916:


    "Um grito aterrorizado escapa da sua boca antes que você consiga pensar em abafar."


translate pt_br sitOnFloor_8112b810:


    "Na tela... na cadeira..."


translate pt_br sitOnFloor_73ca6c0a:


    "...está o gato."


translate pt_br sitOnFloor_a20cefa7_3:


    "..."


translate pt_br sitOnFloor_8432e062:


    "Mas tem algo... {b}errado{/b}."


translate pt_br sitOnFloor_c0555fb1:


    "Ele se tornou uma grande massa inchada de pelo preto..."


translate pt_br sitOnFloor_133f90fc:


    "Ele pulsa de forma irregular, enquanto suas respirações são lentas, quase metódicas."


translate pt_br sitOnFloor_be8a773e:


    "Sua boca é uma entrada escancarada para um abismo negro, exibindo um conjunto de dentes que parecem muito, {i}muito{/i} {b}afiados{/b}."


translate pt_br sitOnFloor_7a6698ae:


    "Olhos brilhantes estão espalhados por todo o seu corpo..."


translate pt_br sitOnFloor_8dabefc6_2:


    ".."


translate pt_br sitOnFloor_a20cefa7_4:


    "..."


translate pt_br sitOnFloor_bc239af5:


    "{size=-5}Ele... ainda está {b}olhando{/b} para você...{/size}"


translate pt_br sitOnFloor_cbbe5c23:


    "Ele nem sequer reconhece sua versão na tela enquanto retorna ao enquadramento e acaricia {b}isso{/b} quase carinhosamente."


translate pt_br sitOnFloor_f64ee9d8:


    "Então..."


translate pt_br sitOnFloor_acb34839:


    "O {b}você{/b} de dentro da TV toca uma das presas do \"gato\"..."


translate pt_br sitOnFloor_479c3431:


    you "!!" with vpunch


translate pt_br sitOnFloor_2718a9f1:


    "Você se encolhe ao sentir uma dor aguda e repentina na palma da mão."


translate pt_br sitOnFloor_78150384:


    "Olha para baixo e, com certeza..."


translate pt_br sitOnFloor_9b18421a:


    "...sua mão está sangrando."


translate pt_br sitOnFloor_ba0ef687:


    "Você nunca teve medo de ver sangue, mas..."


translate pt_br sitOnFloor_1d340c8b:


    "...por algum motivo, a visão dele escorrendo de você te faz arrepiar de cima a baixo."


translate pt_br sitOnFloor_7c7dcbc3:


    "Um pensamento... claro e {i}terrível{/i} passa pela sua cabeça..."


translate pt_br sitOnFloor_2061faa4:


    "Não é {i}apenas{/i} o gato mutante {b}dentro{/b} da TV que está te observando..."


translate pt_br sitOnFloor_75079696:


    "{size=-5}...é?{/size}"


translate pt_br sitOnFloor_91f03785:


    "{size=-10}Não olha para trás... Não olha para trás... Não olha para trás... Não olha para trás... Não olha para trás... Não olha para trás... {/size}"


translate pt_br sitOnFloor_e1698794:


    "Você observa, impotente, enquanto sua versão da tela sorri e acena com a cabeça para você, quase como se quisesse te {i}encorajar{/i}..."


translate pt_br sitOnFloor_ceaf9390:


    "Ele fica em pé diante das mandíbulas escancaradas do gato..."


translate pt_br sitOnFloor_a76a9c6a:


    "Olha para as profundezas escuras..."


translate pt_br sitOnFloor_5cdba61f:


    "...e, enquanto a concepção horripilante do que está prestes a acontecer te atormenta..."


translate pt_br sitOnFloor_82ccfc29:


    "...e a inquietante curiosidade sobre o que ele vê olhando de volta daquele abismo profundo se apodera de você..."


translate pt_br sitOnFloor_8dabefc6_3:


    ".."


translate pt_br sitOnFloor_a20cefa7_5:


    "..."


translate pt_br sitOnFloor_91fe1774:


    "...ele se joga lá {i}dentro{/i}."


translate pt_br sitOnFloor_8dabefc6_4:


    ".."


translate pt_br sitOnFloor_a20cefa7_6:


    "..."


translate pt_br sitOnFloor_d88e36d3:


    "A escuridão subitamente se torna uma presença em toda a sua volta."


translate pt_br sitOnFloor_c6d24f52:


    "Pressionando, te segurando..."


translate pt_br sitOnFloor_a6895774:


    "...e, ainda assim, você se sente de alguma forma... sem peso."


translate pt_br sitOnFloor_d861ceaf:


    "Você não sabe dizer se está caindo, mas não parece que está deitado ou em pé também."


translate pt_br sitOnFloor_156d0dbf:


    "Você sente calor..."


translate pt_br sitOnFloor_3a06e0dd:


    "Você sente frio..."


translate pt_br sitOnFloor_bcd3d129:


    "Você sente tudo..."


translate pt_br sitOnFloor_2b49bb86:


    "Você sente nada..."


translate pt_br sitOnFloor_a20cefa7_7:


    "..."


translate pt_br sitOnFloor_1ef9b933:


    "Você não sente {b}nada.{/b}"


translate pt_br sitOnFloor_a20cefa7_8:


    "..."


translate pt_br sitOnFloor_e8846d70:


    "Final 3: O Mal Interior"


translate pt_br sitInChair_b3119c57:


    "Você arruma a postura."


translate pt_br sitInChair_0a269556:


    you "Desculpa, gatinho. Mas esse lugar é meu."


translate pt_br sitInChair_f57f352f:


    "Você pega o gato e o coloca no chão."


translate pt_br sitInChair_12dc27c4:


    cat "Miaau!!" with hpunch


translate pt_br sitInChair_3a47415e:


    "Ele está claramente chateado com você. Quando você tenta fazer um carinho como pedido de desculpas, ele evita a sua mão e foge."


translate pt_br sitInChair_590b209f:


    "Você dá de ombros e coloca um filme aleatório antes de se aconchegar na sua cadeira."


translate pt_br sitInChair_761b0c81:


    "É algum filme de terror que você adora criticar do início ao fim."


translate pt_br sitInChair_c1831989:


    "Nada além de uma sequência interminável de sustos sem sentido."


translate pt_br sitInChair_02d4fb14:


    "Os roteiristas não sabiam o que significava a palavra \"sutil\"?"


translate pt_br sitInChair_0420a8db:


    "{size=+15}{b}CRASH!{/b}{/size}" with vpunch


translate pt_br sitInChair_28b3ac41:


    you "!!"


translate pt_br sitInChair_a9188f84:


    you "O que foi isso?! Foi no banheiro..?"


translate pt_br sitInChair_f3f4fb49:


    "O gato deve ter entrado no armário de remédios ou derrubado alguma coisa."


translate pt_br sitInChair_d150cda1:


    "Acalmando seu coração acelerado com uma respiração profunda, você pausa o filme e se levanta para investigar."


translate pt_br sitInChair_ec1974d4:


    cat "Miau!" with hpunch


translate pt_br sitInChair_fc460430:


    you "Ei!" with vpunch


translate pt_br sitInChair_4f08c65a:


    "O gato corre entre suas pernas vindo do corredor."


translate pt_br sitInChair_071d97e8:


    you "Fugir da cena só te faz parecer mais culpado, sabia?"


translate pt_br sitInChair_c4cc6ce8:


    "Você está ainda mais relutante em ver o estrago agora. Você só quer relaxar e assistir seu filme de terror ruim..."


translate pt_br sitInChair_eb15eef1:


    "Você entra no banheiro e acende a luz."


translate pt_br sitInChair_2a6c7408:


    "Como você suspeitava, todas as coisas do seu armário de remédios estão espalhadas pelo piso."


translate pt_br sitInChair_8b19c490:


    "Você suspira. Pelo menos nada parece quebrado ou danificado."


translate pt_br sitInChair_dc4e84a5:


    "Você se agacha para recolher tudo."


translate pt_br sitInChair_84499443:


    "{size=-8}bam...{/size}"


translate pt_br sitInChair_90b68c87:


    you "..?"


translate pt_br sitInChair_3c037f7a:


    "A porta... fechou? Você a bateu quando agachou ou..?"


translate pt_br sitInChair_a20cefa7:


    "..."


translate pt_br sitInChair_4f5638e2:


    "B-Bom... Pelo menos assim o gato não pode entrar pra fazer mais bagunça-"


translate pt_br sitInChair_40d9ca73:


    "..?"


translate pt_br sitInChair_cdedc7c0:


    "As luzes?"


translate pt_br sitInChair_2bfd08b2:


    "Você não acabou de trocar as lâmpadas? Elas não estavam com defeito, estavam?"


translate pt_br sitInChair_f920211f:


    "Você nunca se lembra de guardar os recibos para situações como essa."


translate pt_br sitInChair_0249ee11:


    "E duvida que vá conseguir reembolso..."


translate pt_br sitInChair_a20cefa7_1:


    "..."


translate pt_br sitInChair_dae0ec55:


    you "..."


translate pt_br sitInChair_3a64e1bd:


    "Você se levanta."


translate pt_br sitInChair_c3acc1e2:


    "Após se esticar, aliviando a dor na coluna por ter agachado, você abre o armário de remédios."


translate pt_br sitInChair_29a4c348:


    "Cuidadosamente, você coloca tudo de volta em seu devido lugar, certificando-se de que nada está faltando."


translate pt_br sitInChair_3cbf6fbc:


    "Você fecha a porta do armário--{w=0.60}{nw}"


translate pt_br sitInChair_24c68cb1:


    you "{size=+30}AAAAAHHH!!{/size}" with vpunch


translate pt_br sitInChair_77935352:


    "Você salta para trás, batendo contra a parede e cobrindo a boca."


translate pt_br sitInChair_51841170:


    "Você olha para o espelho da porta do armário de remédios e vê..."


translate pt_br sitInChair_8dabefc6:


    ".."


translate pt_br sitInChair_a20cefa7_2:


    "..."


translate pt_br sitInChair_e9a3c807:


    "...nada."


translate pt_br sitInChair_3a9199d1:


    "Nada?"


translate pt_br sitInChair_dc92f804:


    you "Mas... Mas que porra..? Alguma coisa... Tinha alguma coisa..."


translate pt_br sitInChair_312bb316:


    "Você sabe que viu algo agora há pouco."


translate pt_br sitInChair_963cfd9b:


    "Você {i}sabe{/i} que viu."


translate pt_br sitInChair_9979a58c:


    "Certo?"


translate pt_br movieBathroomJumpscare1_2144dee4:


    "É, com certeza. Você não vai ficar para--{w=0.4}{nw}"


translate pt_br movieBathroomJumpscare1_9998cb84:


    you "{size=+35}{b}AAAAAAAAHHHHH!!{/b}{/size}" with hpunch


translate pt_br movieBathroomJumpscare1_9a70f959:


    "Você corre para fora do banheiro e bate a porta com força sem olhar."


translate pt_br movieBathroomJumpscare1_4482999d:


    "Você entra no corredor e-"


translate pt_br movieBathroomJumpscare1_8105eadd:


    you "Não..."


translate pt_br movieBathroomJumpscare1_b3556bea:


    you "Não não não não não!!" with hpunch


translate pt_br movieBathroomJumpscare1_40feb4d7:


    "Você se protege usando os braços e..."


translate pt_br movieBathroomJumpscare1_8dabefc6:


    ".."


translate pt_br movieBathroomJumpscare1_a20cefa7:


    "..."


translate pt_br movieBathroomJumpscare1_e9a3c807:


    "...nada."


translate pt_br movieBathroomJumpscare1_4b236e0a:


    "Nada. De novo."


translate pt_br movieBathroomJumpscare1_7af0a5e1:


    "Você espia através dos dedos e vê..."


translate pt_br movieBathroomJumpscare1_9949aa1e:


    "...apenas o seu corredor de sempre."


translate pt_br movieBathroomJumpscare1_0f5de544:


    "Você..."


translate pt_br movieBathroomJumpscare1_6c66c891:


    "Você não se sente muito bem."


translate pt_br movieBathroomJumpscare1_a20cefa7_1:


    "..."


translate pt_br movieBathroomJumpscare1_63883ba3:


    "Precisa se sentar."


translate pt_br movieBathroomJumpscare1_3d95bb71:


    "Você segue cuidadosamente de volta para a sala escura..."


translate pt_br movieBathroomJumpscare1_20b300df:


    "...tentando não sobrecarregar seus sentidos mais do que já fez."


translate pt_br movieBathroomJumpscare1_394dfa11:


    "Talvez você devesse assistir algo um pouco mais tranquilo..."


translate pt_br movieBathroomJumpscare1_038385fd:


    "...ou simplesmente ir se deitar?"


translate pt_br movieBathroomJumpscare1_2f6db9fa:


    "Você não sabe."


translate pt_br movieBathroomJumpscare1_6866aca7:


    "Está meio difícil de pensar..."


translate pt_br movieBathroomJumpscare1_d42b8f2e:


    "Você só... precisa se {b}sentar.{/b}"


translate pt_br movieBathroomJumpscare1_5ec868b4:


    "Cambaleando para frente, você alcança sua poltrona..."


translate pt_br movieBathroomJumpscare1_2cdad339:


    "{color=#FF0000}Mas-{/color}"


translate pt_br movieBathroomJumpscare1_a110fb02:


    you "{size=+15}!!!!!{/size}" with vpunch


translate pt_br movieBathroomJumpscare1_8dabefc6_1:


    ".."


translate pt_br movieBathroomJumpscare1_a20cefa7_2:


    "..."


translate pt_br movieBathroomJumpscare1_a4cfcb7e:


    "Não é nada."


translate pt_br movieBathroomJumpscare1_d10408f3:


    "Absolutamente nada."


translate pt_br movieBathroomJumpscare1_650a1380:


    "Só o gato... sentado na sua poltrona de novo. Olhando para você com curiosidade."


translate pt_br movieBathroomJumpscare1_16879ce5:


    cat "Miau?"


translate pt_br movieBathroomJumpscare1_8dabefc6_2:


    ".."


translate pt_br movieBathroomJumpscare1_8dabefc6_3:


    "..."


translate pt_br movieBathroomJumpscare1_a20cefa7_3:


    "..."


translate pt_br movieBathroomJumpscare1_30fe06e7:


    "...mas isso é o suficiente."


translate pt_br movieBathroomJumpscare1_b8391155:


    "Seu coração disparou tão intensamente, numa mistura de medo e ansiedade..."


translate pt_br movieBathroomJumpscare1_ee49c0d1:


    "...que ele simplesmente parou."


translate pt_br movieBathroomJumpscare1_217ef2ff:


    "Seus olhos rolam para trás."


translate pt_br movieBathroomJumpscare1_ab3f5fb1:


    "Você sente que está caindo para trás."


translate pt_br movieBathroomJumpscare1_8dabefc6_4:


    ".."


translate pt_br movieBathroomJumpscare1_a20cefa7_4:


    "..."


translate pt_br movieBathroomJumpscare1_43180df7:


    "...Você morre antes mesmo de tocar o chão."


translate pt_br movieBathroomJumpscare1_a20cefa7_5:


    "..."


translate pt_br movieBathroomJumpscare1_15eac906:


    "Final 4--{w=0.3}{nw}"


translate pt_br movieBathroomJumpscare1_a20cefa7_6:


    "..."


translate pt_br movieBathroomJumpscare1_ca055f36:


    "Final 4: Bem \"Sutil\""


translate pt_br napAlone_8f615c2b:


    "Você está um pouco cansado dos acontecimentos do dia."


translate pt_br napAlone_dcbf1da5:


    "Tomar decisões que mudam sua vida, como se comprometer com a responsabilidade de cuidar de outro ser vivo..."


translate pt_br napAlone_d9c98972:


    "...realmente te esgota."


translate pt_br napAlone_4505fdc0:


    "Você definitivamente poderia tirar um cochilo."


translate pt_br napAlone_c3e294a3:


    "Você vai para o seu quarto e coloca seu pijama, antes de decidir pegar um copo d'água na cozinha."


translate pt_br napAlone_0fed84ed:


    "Você volta para o seu quarto, pronto para o tão esperado cochilo..."


translate pt_br napAlone_ec1974d4:


    cat "Miau!" with hpunch


translate pt_br napAlone_fc460430:


    you "Ei!" with vpunch


translate pt_br napAlone_a5249354:


    "...mas o gato passa correndo por você pela porta aberta e pula no meio da cama."


translate pt_br napAlone_919b944d:


    "Ele toma seu tempo, amassando os lençóis com as patinhas antes de se acomodar e fechar os olhos."


translate pt_br napAlone_cc63b22e:


    cat "Purr... Purr... Purr..."


translate pt_br napAlone_dae0ec55:


    you "..."


translate pt_br napAlone_13af021f:


    you "{i}Rapaz, isso foi rápido...{/i}"


translate pt_br napAlone_5068475e:


    "Você franze a testa, pensativo."


translate pt_br napAlone_3bd08dfd:


    "Agora que isso passou pela sua cabeça, você se pega querendo {i}muito{/i} tirar uma soneca na sua própria cama."


translate pt_br napAlone_661e2716:


    "De jeito nenhum você vai se contentar em dormir no sofá. {i}Com certeza{/i} não na poltrona..."


translate pt_br napAlone_91480ce3:


    "O que significa que você deve..."


translate pt_br napMenu_dae0ec55:


    you "..."


translate pt_br napMenu_b4e0a60e:


    "Talvez você possa tentar cochilar {i}mais tarde...{/i}"


translate pt_br napMenu_f2c5d8d3:


    "Você decide fazer outra coisa com o seu tempo."


translate pt_br napMoveCat_c4777c85:


    "Você dá um empurrãozinho no gato, tentando fazê-lo se mover por conta própria."


translate pt_br napMoveCat_8dabefc6:


    ".."


translate pt_br napMoveCat_a20cefa7:


    "..."


translate pt_br napMoveCat_01382361:


    "Ele não se mexe nem um centímetro."


translate pt_br napMoveCat2_60058abd:


    "Você empurra um pouquinho mais forte desta vez."


translate pt_br napMoveCat2_3af2f912:


    cat "Miaau..."


translate pt_br napMoveCat2_dae0ec55:


    you "..."


translate pt_br napMoveCat2_35168c1b:


    "O gato parece irritado com você..."


translate pt_br napMoveCat2_7f0ac95c:


    cat "..."


translate pt_br napMoveCat3_a5040b05:


    "O gato abre um de seus olhos amarelos e arrasta o olhar para você."


translate pt_br napMoveCat3_f07f0105:


    cat "{b}Miaaaau...{/b}"


translate pt_br napMoveCat3_38a2a096:


    you "..!" with vpunch


translate pt_br napMoveCat3_24137500:


    "A miado dele está um pouco... mais grave? Do que antes?"


translate pt_br napMoveCat3_a20cefa7:


    "..."


translate pt_br napMoveCat3_7f0ac95c:


    cat "..."


translate pt_br napMoveCat4_98c26b25:


    "Você avança. {w}Pronto para empurrar o gato com toda a sua força--{w=1.5}{nw}"


translate pt_br napMoveCat4_87d1e4e3:


    "{size=+25}CRASH!{/size}" with vpunch


translate pt_br napMoveCat4_35bc070f:


    you "{size=+10}GAH!{/size}" with hpunch


translate pt_br napMoveCat4_267670c2:


    "Você é arremessado para trás por uma força invisível e bate na cômoda, antes de cair no chão."


translate pt_br napMoveCat4_e16be8b8:


    you "Unhh..."


translate pt_br napMoveCat4_f2025eea:


    "Sem ar, você olha para cima atordoado..."


translate pt_br napMoveCat4_8ca8510a:


    you "!!!" with vpunch


translate pt_br napMoveCat4_0f5de544:


    "Você..."


translate pt_br napMoveCat4_c335fc02:


    "Você não consegue compreender bem o que está vendo."


translate pt_br napMoveCat4_1edf14ea:


    "Um vento forte em espiral se levantou, jogando objetos por toda parte..."


translate pt_br napMoveCat4_2e084285:


    "...como se um mini furacão tivesse se formado em seu quarto."


translate pt_br napMoveCat4_d7c2d390:


    "E bem no centro disso tudo..."


translate pt_br napMoveCat4_73ca6c0a:


    "...está o gato."


translate pt_br napMoveCat4_b37f5c41:


    "Pairando no ar acima da cama..."


translate pt_br napMoveCat4_f02e91e8:


    "Seus olhos abertos, brilhando como lava derretida..."


translate pt_br napMoveCat4_3e04d2ff:


    cat "Miauuuu..."


translate pt_br napMoveCat4_c2cbf478:


    cat "{size=+5}Miauuuu...{/size}" with vpunch


translate pt_br napMoveCat4_c64e3fd2:


    cat "{size=+10}{b}M i a u u u u...!{/b}{/size}" with vpunch


translate pt_br napMoveCat4_28b3ac41:


    you "!!"


translate pt_br napMoveCat4_3db840b4:


    "Você assiste enquanto um vórtice se abre no centro da sua cama..."


translate pt_br napMoveCat4_9c4942bc:


    "...e entra em pânico quando o vento em espiral se transforma em um {i}vácuo.{/i}"


translate pt_br napMoveCat4_4351a428:


    "{b}Arrastando{/b} você em direção à cama..."


translate pt_br napMoveCat4_67c9c705:


    you "Ghh!" with hpunch


translate pt_br napMoveCat4_410731bd:


    "Suas unhas prendem e se {b}{i}quebram{/i}{/b} enquanto você tenta desesperadamente se segurar no carpete... {w}as tábuas do chão..."


translate pt_br napMoveCat4_20ed66fb:


    "...toda e {i}qualquer{/i} mobília ao seu alcance..."


translate pt_br napMoveCat4_c8ef0095:


    "...seus dedos ensanguentados escorregam desajeitadamente em cada superfície..."


translate pt_br napMoveCat4_8dabefc6:


    ".."


translate pt_br napMoveCat4_a20cefa7:


    "..."


translate pt_br napMoveCat4_fe111813:


    "...mas não há nada que você possa fazer."


translate pt_br napMoveCat4_92ab24b3:


    "Quando você toca o vórtice... seu corpo começa a..."


translate pt_br napMoveCat4_cb8978e7:


    "...{i}desintegrar.{/i}"


translate pt_br napMoveCat4_70bd56a0:


    "Minúsculas partículas do seu corpo se separando e flutuando para o nada..."


translate pt_br napMoveCat4_9d7d7459:


    "A última coisa que você vê é o gato caindo agilmente na cama e amassando os seus lençóis..."


translate pt_br napMoveCat4_3bbf7816:


    "...antes de se enroscar e voltar a dormir."


translate pt_br napMoveCat4_67107e6c:


    cat "Purr..."


translate pt_br napMoveCat4_a20cefa7_1:


    "..."


translate pt_br napMoveCat4_575b36ec:


    "Final 5: Não Mia Corde"


translate pt_br napTogether_4e7a8b32:


    "Qual o problema em dividir a cama, certo?"


translate pt_br napTogether_426f3adb:


    "Afinal, vocês dois tiveram um longo dia."


translate pt_br napTogether_a3583f06:


    "Você tenta deitar com cuidado para não incomodar o gato, mas ele imediatamente se aproxima e se enrosca em você de qualquer maneira."


translate pt_br napTogether_cc63b22e:


    cat "Purr... Purr... Purr..."


translate pt_br napTogether_0ff74098:


    "Você sorri."


translate pt_br napTogether_416e2125:


    you "Sonhe com os anjos..."


translate pt_br napTogether_8dabefc6:


    ".."


translate pt_br napTogether_a20cefa7:


    "..."


translate pt_br napTogether_40d9ca73:


    "..?"


translate pt_br napTogether_37d6d699:


    you "Mmph..?"


translate pt_br napTogether_80a5c3e8:


    "Você sente que dormiu por um bom tempo."


translate pt_br napTogether_40d9ca73_1:


    "..?"


translate pt_br napTogether_1a1908b3:


    "Também sente um peso quente nas costas..."


translate pt_br napTogether_f1efd4f0:


    "Mas você não vê o-{w=0.6}{nw}"


translate pt_br napTogether_57f9ada2:


    cat "Purr... Purr... Purr..."


translate pt_br napTogether_28052c77:


    "...Ah. Mistério resolvido, então."


translate pt_br napTogether_3ab0f315:


    "Você se sente... confortável..?"


translate pt_br napTogether_6a292af6:


    "Você pensa em se levantar..."


translate pt_br napTogether_5bdd7954:


    "...mas assim que essa ideia passa pela sua cabeça, sua mente se enche com um ruído e um senso profundo de..."


translate pt_br napTogether_ef2259f2:


    "...desaprovação?"


translate pt_br napTogether_dae0ec55:


    you "..."


translate pt_br napTogether_0ef6194c:


    you "{i}Então, ainda não? Ok...{/i}"


translate pt_br napTogether_614a2e6c:


    "O gato, incomodado com suas tentativas de se mexer, amassa suas costas dolorosamente antes de se acomodar novamente e voltar a dormir."


translate pt_br napTogether_2145b389:


    "Você também volta a adormecer."


translate pt_br napTogether_8dabefc6_1:


    ".."


translate pt_br napTogether_a20cefa7_1:


    "..."


translate pt_br napTogether_a20cefa7_2:


    "..."


translate pt_br napTogether_3e8cc2f1:


    "Está de noite."


translate pt_br napTogether_b5717b9e:


    "Você quer se levantar."


translate pt_br napTogether_d13d6302:


    you "Nnnh!" with vpunch


translate pt_br napTogether_45f5f5bd:


    "As garras se cravam em suas costas, como um aviso."


translate pt_br napTogether_dae0ec55_1:


    you "..."


translate pt_br napTogether_4c13fdd1:


    "...Amanhã então, certo?"


translate pt_br napTogether_55355e09:


    cat "Purr... Purr..."


translate pt_br napTogether_dae0ec55_2:


    you "..."


translate pt_br napTogether_8dabefc6_2:


    ".."


translate pt_br napTogether_a20cefa7_3:


    "..."


translate pt_br napTogether_e1a3bb11:


    "...Já é de manhã. Você vai se atrasar para o trabalho..."


translate pt_br napTogether_ccb83206:


    "...mas o gato não se mexe."


translate pt_br napTogether_6faab910:


    "Desta vez, você nem tenta se levantar."


translate pt_br napTogether_da0c099f:


    "Apenas fecha os olhos e volta a dormir."


translate pt_br napTogether_8dabefc6_3:


    ".."


translate pt_br napTogether_a20cefa7_4:


    "..."


translate pt_br napTogether_90b93b6a:


    "É..."


translate pt_br napTogether_a20cefa7_5:


    "..."


translate pt_br napTogether_7e35a8e3:


    "Já faz um dia..."


translate pt_br napTogether_a20cefa7_6:


    "..."


translate pt_br napTogether_432cfea9:


    "...desde que você começou a se perder nos últimos {b}vários{/b} dias..."


translate pt_br napTogether_b3d9c927:


    "...Ou foram semanas?"


translate pt_br napTogether_a20cefa7_7:


    "..."


translate pt_br napTogether_8a135021:


    "{size=-8}Ou mais...?{/size}"


translate pt_br napTogether_a20cefa7_8:


    "..."


translate pt_br napTogether_4c91bf15:


    "Você não tem certeza."


translate pt_br napTogether_dae0ec55_3:


    you "..."


translate pt_br napTogether_421780e5:


    "Você está com fome."


translate pt_br napTogether_f631369d:


    "Você não sabe por quanto tempo esteve deitado."


translate pt_br napTogether_097a8871:


    "Você sente as costas doloridas, mas também o estômago, os braços, o rosto..."


translate pt_br napTogether_d6e6ac76:


    "Todo lugar..."


translate pt_br napTogether_6ebedf14:


    "Você não consegue se lembrar da sua última refeição... {w}Da última vez que bebeu algo..."


translate pt_br napTogether_151a082b:


    "Você esteve dormindo todo esse tempo..."


translate pt_br napTogether_5255f5a0:


    "...mas se sente {b}exausto{/b}. Mais cansado do que jamais se lembra de ter ficado."


translate pt_br napTogether_e3a05912:


    "É como se uma mão gigante estivesse {i}pressionando{/i} você contra a cama."


translate pt_br napTogether_0fa6935c:


    "Você não consegue se lembrar da última vez que sequer considerou se mover..."


translate pt_br napTogether_4c459194:


    "Mas, de alguma forma, você sabe..."


translate pt_br napTogether_2c153c83:


    "{size=-8}......que precisa voltar a dormir {b}de qualquer jeito{/b}.{/size}"


translate pt_br napTogether_f31145ff:


    "Tudo vai ficar bem se você só voltar a dormir."


translate pt_br napTogether_8dabefc6_4:


    ".."


translate pt_br napTogether_a20cefa7_9:


    "..."


translate pt_br napTogether_b59d962a:


    "..?" with vpunch


translate pt_br napTogether_e82e813a:


    "Você pensa estar alucinando quando o gato finalmente se mexe..."


translate pt_br napTogether_085f82bc:


    cat "Miau..."


translate pt_br napTogether_c3e31538:


    "Ele se estica preguiçosamente antes de pular das suas costas."


translate pt_br napTogether_2f0da195:


    "Você ouve suas patinhas passando pela porta do seu quarto ainda aberta, seus passos desaparecendo pelo corredor."


translate pt_br napTogether_8dabefc6_5:


    ".."


translate pt_br napTogether_a20cefa7_10:


    "..."


translate pt_br napTogether_c45998b5:


    "Você não abre os olhos."


translate pt_br napTogether_9e3127bc:


    "Você não {i}se move.{/i}"


translate pt_br napTogether_a20cefa7_11:


    "..."


translate pt_br napTogether_40b03495:


    "Você tem medo de não se lembrar {b}como.{/b}"


translate pt_br napTogether_7362ca19:


    "Tem medo de que o ruído volte se você tentar..."


translate pt_br napTogether_a20cefa7_12:


    "..."


translate pt_br napTogether_3c068b44:


    "Mas eventualmente você {i}tenta{/i}."


translate pt_br napTogether_cedc9e87:


    "Você tenta se apoiar no braço."


translate pt_br napTogether_9728d600:


    "Ele está mais fino do que você já o viu..."


translate pt_br napTogether_7accebe2:


    "Mais fino do que você acha que deveria ser {i}possível-{/i}"


translate pt_br napTogether_f877cb8f:


    "{size=+10}CRACK!{/size}" with vpunch


translate pt_br napTogether_dae0ec55_4:


    you "..."


translate pt_br napTogether_bf2e0dee:


    "O braço se quebra sob o peso do seu corpo e se desfaz em pó sobre os lençóis."


translate pt_br napTogether_a20cefa7_13:


    "..."


translate pt_br napTogether_205af2fa:


    "Não dói nem um pouco..."


translate pt_br napTogether_72a91789:


    "Como se até seus nervos tivessem secado e se tornado tão inúteis quanto..."


translate pt_br napTogether_e7fd628a:


    "...bem, tão inútil quanto você se sente, {i}de maneira geral.{/i}"


translate pt_br napTogether_afc8d8b5:


    "{size=-8}Há quanto {b}tempo{/b} você está deitado nessa cama..?{/size}"


translate pt_br napTogether_a20cefa7_14:


    "..."


translate pt_br napTogether_ac9494ba:


    "Você não tem muito tempo para pensar nisso."


translate pt_br napTogether_ea722524:


    "Sua tentativa frustrada de se sentar faz com que você despenque do lado da cama como um boneco de pano..."


translate pt_br napTogether_39ee23ef:


    "{size=+5}CRACK!{/size}" with vpunch


translate pt_br napTogether_f877cb8f_1:


    "{size=+10}CRACK!{/size}" with vpunch


translate pt_br napTogether_047fc669:


    "{size=+25}CRACK!{/size}" with vpunch


translate pt_br napTogether_1407836e:


    "Mas você pensa que está mais para um boneco de {i}cerâmica{/i}..."


translate pt_br napTogether_394bdc78:


    "...pois seu corpo se despedaça {i}instantâneamente{/i} ao cair no chão."


translate pt_br napTogether_d48b6485:


    "Sua cabeça rola em direção à porta..."


translate pt_br napTogether_118dceca:


    "...fazendo você observar o restante dos seus membros espalhados se quebrarem..."


translate pt_br napTogether_fdee14d8:


    "...e {i}se desfazerem{/i}..."


translate pt_br napTogether_77f0a0e9:


    "...transformando-se em {b}entulho{/b} à medida que sua consciência começa a se dissipar."


translate pt_br napTogether_1d86a44d:


    "O gato então aparece... cutucando e tocando os restos dos seus membros quebradiços."


translate pt_br napTogether_59882995:


    "\"Gatinho mau.\" {w}Você tenta dizer..."


translate pt_br napTogether_a20cefa7_15:


    "..."


translate pt_br napTogether_c7e0166e:


    "Mas você pensa que sua mandíbula pode já ter se quebrado."


translate pt_br napTogether_58a56e4d:


    "Quase como se sentisse sua atenção, o gato caminha até você..."


translate pt_br napTogether_ebb54fa1:


    "Bem... pelo menos até sua {i}cabeça{/i}..."


translate pt_br napTogether_3639e1f8:


    "...e você observa, nos seus últimos segundos de consciência, enquanto ele se deita, se enroscando ao seu redor."


translate pt_br napTogether_55355e09_1:


    cat "Purr... Purr..."


translate pt_br napTogether_8dabefc6_6:


    ".."


translate pt_br napTogether_a20cefa7_16:


    "..."


translate pt_br napTogether_807ca19c:


    "É quentinho."


translate pt_br napTogether_a20cefa7_17:


    "..."


translate pt_br napTogether_221cbb22:


    "Bom..."


translate pt_br napTogether_a20cefa7_18:


    "..."


translate pt_br napTogether_ba93f838:


    "{size=-8}Talvez outro cochilo não fizesse mal...{/size}"


translate pt_br napTogether_8dabefc6_7:


    ".."


translate pt_br napTogether_a20cefa7_19:


    "..."


translate pt_br napTogether_f7b8427a:


    "Final 6: Só Um Cochilo"


translate pt_br petCat_52bd3edf:


    "Não é todo dia que você tem acesso a um bichinho fofo e peludo."


translate pt_br petCat_f910595b:


    "O que mais você poderia fazer além de fazer carinho nele até se sentir satisfeito?"


translate pt_br petCat_59866bfa:


    "Você se senta no chão da sala e estala a língua para chamar o gato."


translate pt_br petCat_9542a4b9:


    cat "Mrrp!!" with hpunch


translate pt_br petCat_59da5396:


    "O gato corre até você, subindo no seu colo imediatamente."


translate pt_br petCat_c59a408d:


    you "Pobrezinho~ Só quer um pouco de atenção, não é?"


translate pt_br petCat_e5fab8a0:


    cat "Miau!"


translate pt_br petCat_cef992d7:


    you "Hehe, tá bom, tá bom!"


translate pt_br petCat_99ba38b9:


    "Você o acaricia com cuidado. {w}Coça atrás da orelha. {w}Esfrega em baixo do queixo. {w}Desliza a mão suavemente pelas costas."


translate pt_br petCat_cc63b22e:


    cat "Purr... Purr... Purr..."


translate pt_br petCat_4d2c742f:


    you "Heh, tá gostando?"


translate pt_br petCat_67107e6c:


    cat "Purr..."


translate pt_br petCat_79e12018:


    "Você continua acariciando o gato no seu colo, aproveitando esse momento juntos..."


translate pt_br petCat_f5145a26:


    "...mas o gato começa a ficar inquieto depois de um tempo."


translate pt_br keepPetting_a20cefa7:


    "..."


translate pt_br keepPetting_e01ca199:


    "Você não está pronto para parar."


translate pt_br keepPetting_7107d5ed:


    "Você se sente tão {i}calmo{/i}... Essa ação repetitiva acalma sua mente sobrecarregada..."


translate pt_br keepPetting_8dabefc6:


    ".."


translate pt_br keepPetting_a20cefa7_1:


    "..."


translate pt_br keepPetting_afeb9142:


    "Você continua fazendo carinho."


translate pt_br keepPetting_3af2f912:


    cat "Miau..."


translate pt_br keepPetting_a3f235fe:


    "O gato se afasta da sua próxima tentativa de fazer carinho na cabeça."


translate pt_br keepPetting_1e8aea73:


    "Está tentando sair do seu colo."


translate pt_br keepPetting2_972c75fa:


    "Quando você faz um carinho em baixo do queixo do gato, ele morde seus dedos."


translate pt_br keepPetting2_ae0c2b21:


    "Você pode estar sangrando, mas, na verdade, mal dói."


translate pt_br keepPetting2_b3d3cd04:


    "Mais um aviso do que qualquer outra coisa."


translate pt_br keepPetting2_ceceaf01:


    cat "Miaau!" with hpunch


translate pt_br keepPetting2_746fba6a:


    "O gato se debate em seus braços."


translate pt_br keepPetting2_59092dab:


    "Está te observando atentamente."


translate pt_br keepPetting2_dae0ec55:


    you "..."


translate pt_br keepPetting3_8dabefc6:


    ".."


translate pt_br keepPetting3_a20cefa7:


    "..."


translate pt_br keepPetting3_1ffa03f8:


    "Você continua fazendo carinho no gato-"


translate pt_br keepPetting3_df1f0434:


    cat "{b}{size=+5}MIAAU!{/size}{/b}" with hpunch


translate pt_br keepPetting3_d51d0b13:


    "{size=+15}{b}CHOMP!{/b}{/size}" with vpunch


translate pt_br keepPetting3_28b3ac41:


    you "!!"


translate pt_br keepPetting3_a20cefa7_1:


    "..."


translate pt_br keepPetting3_a513413e:


    "..!"


translate pt_br keepPetting3_f5b70ae2:


    "O gato..."


translate pt_br keepPetting3_439e3871:


    "...morde seu dedo e o arranca {b}fora{/b}."


translate pt_br keepPetting3_dae0ec55:


    you "..."


translate pt_br keepPetting3_62c0c671:


    "Dói..."


translate pt_br keepPetting3_505e1acd:


    "Você {i}definitivamente{/i} está sangrando agora..."


translate pt_br keepPetting3_bf0874e3:


    "Mas..."


translate pt_br keepPetting3_a20cefa7_2:


    "..."


translate pt_br keepPetting3_a4bb9dbd:


    "...por alguma razão..."


translate pt_br keepPetting3_a20cefa7_3:


    "..."


translate pt_br keepPetting3_92e28b8f:


    "{size=-8}...você simplesmente não consegue {b}parar.{/b}{/size}"


translate pt_br keepPetting3_0ecc6b91:


    "Você não sabe o que é..."


translate pt_br keepPetting3_f43d701c:


    "Seu pelo é muito mais {b}{i}macio{/i}{/b} do que você imaginava..."


translate pt_br keepPetting3_99249dc1:


    "É de se pensar que ele brilharia sob a luz fraca da sala, mas..."


translate pt_br keepPetting3_4b10ed10:


    "...é como se a escuridão do pelo preto do gato estivesse {i}absorvendo{/i} toda a iluminação ao redor dele..."


translate pt_br keepPetting3_d09fbed4:


    "...tornando-o completamente {i}nulo.{/i}"


translate pt_br keepPetting3_21d4057c:


    "Você é atraído para ele. {w}Como se, de alguma forma, estivesse segurando um profundo e sombrio {b}abyss{/b} bem no seu colo."


translate pt_br keepPetting3_8c8267dd:


    cat "Purr... Purr..."


translate pt_br keepPetting3_2ba9ab53:


    "Parece mais calmo agora, mastigando seu dedo arrancado."


translate pt_br keepPetting3_03d25c7d:


    "O toco entre o polegar e o dedo médio está sangrando..."


translate pt_br keepPetting3_a20cefa7_4:


    "..."


translate pt_br keepPetting3_396fb77c:


    "...mas você continua acariciando."


translate pt_br keepPetting3_c18819d8:


    "Você não quer que seu sangue manche o pelo dele, mas o gato parece não se importar mais."


translate pt_br keepPetting3_8dabefc6_1:


    ".."


translate pt_br keepPetting3_a20cefa7_5:


    "..."


translate pt_br keepPetting3_4d9e273d:


    "O tempo passa. {w}Já está escuro lá fora."


translate pt_br keepPetting3_7ff6d061:


    "Por mais macio que seja o pelo, sua palma começou a ficar áspera e úmida com a fricção constante dos carinhos."


translate pt_br keepPetting3_a20cefa7_6:


    "..."


translate pt_br keepPetting3_005a0a26:


    "{size=-7}Surge um pensamento vago de que talvez já tenha sido o suficiente.{/size}"


translate pt_br keepPetting3_0d6d2a66:


    "Você começa a levantar a mão do gato..."


translate pt_br keepPetting3_0f665b3a:


    "...quando, num piscar de olhos--{w=0.5}{nw}"


translate pt_br keepPetting3_8ca8510a:


    you "!!!" with vpunch


translate pt_br keepPetting3_8dabefc6_2:


    ".."


translate pt_br keepPetting3_a20cefa7_7:


    "..."


translate pt_br keepPetting3_8dabefc6_3:


    ".."


translate pt_br keepPetting3_a20cefa7_8:


    "..."


translate pt_br keepPetting3_cb08e821:


    "...sua {b}mão{/b} inteira é separada do seu pulso."


translate pt_br keepPetting3_28e9e838:


    "Ela cai no seu colo, ao lado do gato."


translate pt_br keepPetting3_9ab57abe:


    "As garras da pata dianteira direita do gato brilham com um líquido carmesim."


translate pt_br keepPetting3_c40b465b:


    "Você não sente nada na hora, mas seu corpo se tenciona..."


translate pt_br keepPetting3_f432849a:


    "...antecipando a dor enquanto observa, atônito, o gato lamber a palma ensanguentada da sua mão decepada."


translate pt_br keepPetting3_e5fab8a0:


    cat "Miau!"


translate pt_br keepPetting3_4a4e0688:


    you "H-hah..! Isso... dói..."


translate pt_br keepPetting3_3476012a:


    "Dói muito, {i}muito{/i} mesmo.."


translate pt_br keepPetting3_a268e071:


    "Então... {w}o gato te olha e você... {w}se sente forçado..."


translate pt_br keepPetting3_a20cefa7_9:


    "..."


translate pt_br keepPetting3_c070fd95:


    "{size=-8}...a continuar {b}acariciando.{/b}{/size}"


translate pt_br keepPetting3_6bbf2111:


    "Você está relutante... mas também com medo do que acontecerá se não atender ao chamado."


translate pt_br keepPetting3_a3553d39:


    "O que você perderá da {i}próxima vez{/i} se tentar resistir novamente?"


translate pt_br keepPetting3_a20cefa7_10:


    "..."


translate pt_br keepPetting3_0b8e27c7:


    "Você se machucou por insistir em acariciar antes..."


translate pt_br keepPetting3_2f39be7c:


    "...e agora foi ferido por tentar parar?"


translate pt_br keepPetting3_85303526:


    "...Isso desafia toda a lógica, mas é isso que te assusta."


translate pt_br keepPetting3_9d61d6e2:


    "Não há como argumentar com caprichos tão volúveis..."


translate pt_br keepPetting3_3feec0d7:


    "Você tenta, hesitante, levantar sua mão {b}{i}não ferida{/i}{/b} para acariciar o gato..."


translate pt_br keepPetting3_e419ea53:


    "...mas ele se enrijece, com os olhos dourados brilhando perigosamente."


translate pt_br keepPetting3_8dabefc6_4:


    ".."


translate pt_br keepPetting3_a20cefa7_11:


    "..."


translate pt_br keepPetting3_221cbb22:


    "Bom..."


translate pt_br keepPetting3_a20cefa7_12:


    "..."


translate pt_br keepPetting3_7d2ae1e5:


    "{size=-10}Tá bom então.{/size}"


translate pt_br keepPetting3_fa304b76:


    "Você levanta seu braço sem mão ensanguentado e retoma o carinho da melhor maneira possível."


translate pt_br keepPetting3_57f9ada2:


    cat "Purr... Purr... Purr..."


translate pt_br keepPetting3_dae0ec55_1:


    you "..."


translate pt_br keepPetting3_b9a42afa:


    "Você faz carinho..."


translate pt_br keepPetting3_70d03ba5:


    "...e sangra."


translate pt_br keepPetting3_b9a42afa_1:


    "Você faz carinho..."


translate pt_br keepPetting3_70d03ba5_1:


    "...e sangra."


translate pt_br keepPetting3_b9a42afa_2:


    "Você faz carinho..."


translate pt_br keepPetting3_70d03ba5_2:


    "...e sangra."


translate pt_br keepPetting3_15f14ac5:


    "Você faz carinho e..."


translate pt_br keepPetting3_a20cefa7_13:


    "..."


translate pt_br keepPetting3_73e94448:


    "...você..."


translate pt_br keepPetting3_dae0ec55_2:


    you "..."


translate pt_br keepPetting3_a20cefa7_14:


    "..."


translate pt_br keepPetting3_31baff1c:


    "Final 7: Limites Pessoais"


translate pt_br feedHome_87825912:


    "O gato parece estar com fome, então você decide alimentá-lo."


translate pt_br feedHome_e8e76bb4:


    "Você se arrepende de não ter parado para comer antes, pois não tem muito em casa. Afinal, o dia de compras no supermercado é amanhã..."


translate pt_br feedHome_5c57afc5:


    "Você vai até a cozinha e estala a língua, fazendo com que o gato te siga."


translate pt_br feedHome_393fa72b:


    "Ele salta agilmente para o balcão da cozinha e observa enquanto você procura opções de refeição."


translate pt_br feedHome_a873ea07:


    you "Hmm, vejamos..."


translate pt_br feedHome_72d43a37:


    "Você encontra algumas coisas que já esperava:"


translate pt_br feedHome_aa2b7420:


    "Uma lata de atum na despensa..."


translate pt_br feedHome_8b7aae08:


    "Um pouco de bolo de carne na geladeira..."


translate pt_br feedHome_cb64e404:


    "E..."


translate pt_br feedHome_40d9ca73:


    "..?"


translate pt_br feedHome_8e2c51bf:


    you "Hã? O que é {i}isso{/i}..?"


translate pt_br feedHome_af12342d:


    "Você percebe que há um tapuer bem fechado na prateleira de baixo da geladeira."


translate pt_br feedHome_8dabefc6:


    ".."


translate pt_br feedHome_a20cefa7:


    "..."


translate pt_br feedHome_24225f61:


    "Você {b}não faz ideia{/b} do que seja."


translate pt_br feedHome_36681b88:


    "Um odor fétido está vazando do recipiente..."


translate pt_br feedHome_ea57ce22:


    "O que quer que esteja dentro {i}não pode{/i} ser seguro para consumo humano..."


translate pt_br feedHome_022b9bff:


    cat "Miau! Miauu!"


translate pt_br feedHome_f909cf5f:


    you "Ãhn..."


translate pt_br feedHome_a20cefa7_1:


    "..."


translate pt_br feedHome_1350b083:


    "...mas o {i}gato{/i} parece estar empolgado. Praticamente {i}salivando{/i} por causa disso..."


translate pt_br feedHome_dae0ec55:


    you "..."


translate pt_br feedHome_24b8e350:


    "Ainda assim, {i}você{/i} é o responsável aqui."


translate pt_br feedHome_2e4a58b3:


    "{i}Você{/i} é quem precisa decidir o que é melhor para alimentar um gato faminto."


translate pt_br feedHome_cf9ca97b:


    "Então, você vai alimentá-lo com..."


translate pt_br feedHomeMenu_f4bfafde:


    you "Eh, não estou com muita fome agora..."


translate pt_br feedHomeMenu_8b418ade:


    "Você decide deixar a comida de lado e fazer outra coisa."


translate pt_br feedTuna_d786e656:


    you "Gatos gostam de peixe, né?"


translate pt_br feedTuna_96364a0d:


    "Você dá de ombros e tira o atum para o gato e o bolo de carne para você."


translate pt_br feedTuna_1712c85a:


    "Você coloca o recipiente francamente {i}sinistro{/i} de volta na geladeira."


translate pt_br feedTuna_1a9c9560:


    "O gato parece um pouco desapontado."


translate pt_br feedTuna_a1a28824:


    "Dureza."


translate pt_br feedTuna_ee9eb500:


    "Você vai precisar se desfazer daquela coisa estranha... {b}{i}seja lá o que for{/i}{/b} mais tarde."


translate pt_br feedTuna_e074c087:


    "Você abre a lata de atum e coloca em um pratinho. Coloca o prato na bancada da cozinha ao lado do gato."


translate pt_br feedTuna_a1f2544f:


    "Você não acha que deveria incentivá-lo a comer ali em cima..."


translate pt_br feedTuna_a98d3823:


    "...mas você acha que isso compensará por não o ter alimentado com aquela gosma tóxica que ele queria."


translate pt_br feedTuna_16879ce5:


    cat "Miau?"


translate pt_br feedTuna_6769c6cb:


    "O gato parece achar o atum..."


translate pt_br feedTuna_164d6921:


    "...aceitável."


translate pt_br feedTuna_6aad42ef:


    "Você acha que é o suficiente."


translate pt_br feedTuna_3b189997:


    you "Bom apetite, gatinho."


translate pt_br feedTuna_085f82bc:


    cat "Miau..."


translate pt_br feedTuna_38b50666:


    "Enquanto o gato aproveita a sua refeição, você vai aquecendo o bolo de carne no micro-ondas."


translate pt_br feedTuna_c294db5c:


    "Enquanto ajusta o tempo, você ouve-"


translate pt_br feedTuna_2699cbe6:


    cat "{size=-7}*soluço*...{/size}"


translate pt_br feedTuna_5d06f92b:


    you "Hm?"


translate pt_br feedTuna_70f82d13:


    "Você se vira e vê que o prato está completamente vazio."


translate pt_br feedTuna_14924412:


    you "Opa, isso foi rápido... Você precisa se controlar-"


translate pt_br feedTuna_5c31b794:


    cat "*soluço*..." with hpunch


translate pt_br feedTuna_829d2012:


    cat "*soluço*... *soluço*..." with hpunch


translate pt_br feedTuna_75a36584:


    cat "{size=+5}*SOLUÇO*{/size}" with hpunch


translate pt_br feedTuna_0e9b573c:


    you "!?"


translate pt_br feedTuna_b52ace45:


    you "Mas que..?"


translate pt_br feedTuna_8871fae2:


    "Você observa, perplexo, enquanto o gato continua soluçando, fazendo..."


translate pt_br feedTuna_56982b7d:


    "...pequenas bolhas flutuarem da boca dele..?"


translate pt_br feedTuna_8dabefc6:


    ".."


translate pt_br feedTuna_a20cefa7:


    "..."


translate pt_br feedTuna_f0657274:


    "Beleza."


translate pt_br feedTuna_a4c0df6c:


    "Tudo bem."


translate pt_br feedTuna_6dfd9fc3:


    "Você pode... Você pode processar isso. Não algo {i}completamente{/i} fora de cogitação, certo?"


translate pt_br feedTuna_a20cefa7_1:


    "..."


translate pt_br feedTuna_ff5f4bbc:


    "Certo."


translate pt_br feedTuna_d1b6b37d:


    "Melhor não pensar muito sobre isso."


translate pt_br feedTuna_3e1feb83:


    "Em pouco tempo, o quarto está cheio de bolhas flutuando."


translate pt_br feedTuna_20d20ae4:


    cat "s.. s... {size=-5}*soluço*{/size}..."


translate pt_br feedTuna_544efc67:


    "O gato solta uma última bolhinha antes de bocejar e se deitar ali mesmo no balcão."


translate pt_br feedTuna_cc63b22e:


    cat "Purr... Purr... Purr..."


translate pt_br feedTuna_13093fc6:


    you "Bem... Que bom que você gostou..."


translate pt_br feedTuna_2c4ee3ec:


    "As bolhas não saíram do quarto nem estouraram. Elas parecem ser bastante resistentes..."


translate pt_br feedTuna_40d9ca73:


    "..?"


translate pt_br feedTuna_5a83a2b4:


    "Espera... O que..?"


translate pt_br feedTuna_112822b7:


    you "O que é aquilo..?"


translate pt_br feedTuna_f0eb37c9:


    "À medida que uma das bolhas flutua mais perto de você..."


translate pt_br feedTuna_b6cf5b97:


    "...você vê que, na verdade, há algo dentro dela."


translate pt_br feedTuna_7a06a1b0:


    "Um pequeno... e {i}peludo{/i}..."


translate pt_br feedTuna_40d9ca73_1:


    "..?"


translate pt_br feedTuna_4208ab4d:


    "...peixe?"


translate pt_br feedTuna_dae0ec55:


    you "..."


translate pt_br feedTuna_a99e5490:


    you "Isso tá ficando cada vez mais estranho..."


translate pt_br feedTuna_b3e12ea5:


    "Ainda assim..."


translate pt_br feedTuna_f2728bdd:


    "Você não consegue deixar de se maravilhar com o milagre impossível à sua frente..."


translate pt_br feedTuna_8d18fd6d:


    "Você levanta uma mão..."


translate pt_br feedTuna_a20cefa7_2:


    "..."


translate pt_br feedTuna_09b77d88:


    "Estende um dedo em direção a uma bolha..."


translate pt_br feedTuna_69d6aee8:


    "...Pressiona cuidadosamente contra a superfície-"


translate pt_br feedTuna_8ca8510a:


    you "!!!" with vpunch


translate pt_br feedTuna_b9de8c3d:


    "O peixinho dentro ataca, ferozmente cravando dentes minúsculos em seu dedo."


translate pt_br feedTuna_ba997575:


    "Inicialmente não dói tanto, mas então..."


translate pt_br feedTuna_2da11494:


    you "AHH! A-Ai! O que..?" with vpunch


translate pt_br feedTuna_c7a75804:


    "A dor começa a subir do seu dedo para o resto da mão..."


translate pt_br feedTuna_77c0c910:


    "Passando pelo pulso..."


translate pt_br feedTuna_06c8ab12:


    "Poderia ser... algum tipo de {b}veneno{/b}..?"


translate pt_br feedTuna_32fa58b5:


    "Você balança o braço na tentativa de fazer o peixe soltar, mas..."


translate pt_br feedTuna_8ca8510a_1:


    you "!!!" with vpunch


translate pt_br feedTuna_321fb0c5:


    you "{size=+15}{b}{i}GAH!{/i}{/b}{/size}" with hpunch


translate pt_br feedTuna_af541737:


    "...você acaba batendo o braço em várias das bolhas flutuando ao redor."


translate pt_br feedTuna_48cade3b:


    "Mais peixinhos famintos se agarram à sua pele..."


translate pt_br feedTuna_d89404a4:


    "Você tropeça para trás devido à dor e a uma súbita tontura, te fazendo esbarrar em mais bolhas..."


translate pt_br feedTuna_6ae60f96:


    "...mais peixes cravam os dentes em suas costas."


translate pt_br feedTuna_4cf68681:


    you "Ghh..! Uhnn..."


translate pt_br feedTuna_62c0c671:


    "Dói..."


translate pt_br feedTuna_33314499:


    "Você está ficando tonto..."


translate pt_br feedTuna_4a51b22e:


    "Você tem que... sair..."


translate pt_br feedTuna_246f5c25:


    "Você tenta, delirante, cambalear para fora da cozinha..."


translate pt_br feedTuna_eec393f2:


    "...mas o quarto inteiro está {i}cheio{/i} de bolhas mortais."


translate pt_br feedTuna_aa72ff49:


    "Quando você desaba no chão, está absolutamente coberto de peixinhos raivosos e {b}famintos{/b}..."


translate pt_br feedTuna_39a7b474:


    "Suas pernas... {w}Seu tronco... {w}Seus braços... {w}Seu {i}rosto{/i}..."


translate pt_br feedTuna_8dabefc6_1:


    ".."


translate pt_br feedTuna_a20cefa7_3:


    "..."


translate pt_br feedTuna_9b33ef77:


    "...A dor é {b}insuportável.{/b}"


translate pt_br feedTuna_74c927c6:


    "Você pode sentir isso em sua pele, nos seus dentes, nos seus olhos, no seu cabelo e..."


translate pt_br feedTuna_ee1fb69a:


    "...e é tão {i}desgastante{/i} que você não consegue nem sentir seu corpo se contorcendo."


translate pt_br feedTuna_514dcaf6:


    "...Ou chorando."


translate pt_br feedTuna_01f15502:


    "Você não desmaia."


translate pt_br feedTuna_ca0edb73:


    "Seus olhos ainda estão se revirando quando você solta o seu último suspiro."


translate pt_br feedTuna_8dabefc6_2:


    ".."


translate pt_br feedTuna_a20cefa7_4:


    "..."


translate pt_br feedTuna_b311580a:


    "Final 8: Peixe Fora D'Água"


translate pt_br feedMeatloaf_38761e59:


    "Você sente de que o gato não vai ficar muito impressionado com qualquer coisa que saia de uma lata."


translate pt_br feedMeatloaf_b3808f59:


    "E você com certeza {i}não{/i} vai alimentá-lo com aquela coisa tóxica que parece um lodo..."


translate pt_br feedMeatloaf_4217e4a0:


    "Então está decidido..."


translate pt_br feedMeatloaf_6b525050:


    "Um sanduíche de atum para você e as sobras de bolo de carne para o seu convidado felino."


translate pt_br feedMeatloaf_47300799:


    "Você ignora os miados decepcionados do gato enquanto coloca o estranho recipiente de volta na geladeira, para descartá-lo depois."


translate pt_br feedMeatloaf_f17edea9:


    "Você esquenta o bolo de carne no micro-ondas."


translate pt_br feedMeatloaf_8dabefc6:


    ".."


translate pt_br feedMeatloaf_a20cefa7:


    "..."


translate pt_br feedMeatloaf_6a13ca1e:


    "{size=+5}{i}BIP! BIP! BIP! BIP!{/i}{/size}" with hpunch


translate pt_br feedMeatloaf_187e6671:


    "Você coloca o bolo de carne agora quente em um pratinho ao lado do gato no balcão."


translate pt_br feedMeatloaf_a1f2544f:


    "Você não acha que deveria incentivá-lo a comer ali em cima..."


translate pt_br feedMeatloaf_a98d3823:


    "...mas você acha que isso compensará por não o ter alimentado com aquela gosma tóxica que ele queria."


translate pt_br feedMeatloaf_16879ce5:


    cat "Miau?"


translate pt_br feedMeatloaf_6f042a3e:


    "O gato parece achar o bolo de carne..."


translate pt_br feedMeatloaf_c595ac61:


    "...interessante."


translate pt_br feedMeatloaf_5291b869:


    "Já serve."


translate pt_br feedMeatloaf_3b189997:


    you "Bom apetite, gatinho."


translate pt_br feedMeatloaf_085f82bc:


    cat "Miau..."


translate pt_br feedMeatloaf_e2cec0db:


    "Enquanto o gato devora sua refeição, você começa a procurar por um pão para seu sanduíche de atum."


translate pt_br feedMeatloaf_abbef2a5:


    "Você está tão distraído na busca que mal ouve-"


translate pt_br feedMeatloaf_92aab58b:


    "{size=-10}*splat*{/size}"


translate pt_br feedMeatloaf_5d06f92b:


    you "Hm?"


translate pt_br feedMeatloaf_c6afd330:


    "Você se vira e vê que o bolo de carne tem marcas de apenas uma, {i}talvez{/i} duas mordidas..."


translate pt_br feedMeatloaf_e41d47bd:


    "Mas, mais alarmante..."


translate pt_br feedMeatloaf_074c7320:


    "Parece ter um rastro vermelho de..."


translate pt_br feedMeatloaf_a20cefa7_1:


    "..."


translate pt_br feedMeatloaf_8dea9007:


    "...{i}algo{/i}"


translate pt_br feedMeatloaf_a38b893d:


    "...levando de onde o gato estava sentado..."


translate pt_br feedMeatloaf_c0b392d7:


    "...e caindo da borda do balcão em direção à sala de estar."


translate pt_br feedMeatloaf_bebfdc57:


    you "{i}Isso...{/i}"


translate pt_br feedMeatloaf_8de83a4b:


    you "{i}{size=-5}Isso é sangue..?{/size}{/i}"


translate pt_br feedMeatloaf_a406bb9a:


    who "*gurgle*... *gurgle*... *grk*... Uhhnn..."


translate pt_br feedMeatloaf_479c3431:


    you "!!" with vpunch


translate pt_br feedMeatloaf_29b1ab2e:


    "Você pula de sousto por causa do som estranho vindo de algum canto."


translate pt_br feedMeatloaf_d5fe7a57:


    "Mais ao fundo do seu apartamento."


translate pt_br feedMeatloaf_a20cefa7_2:


    "..."


translate pt_br feedMeatloaf_b94adebc:


    "Você... tenta acalmar seus nervos."


translate pt_br feedMeatloaf_4ef1545a:


    "Respirando fundo, você contorna o balcão e caminha em direção à sala-"


translate pt_br feedMeatloaf_9a14f254:


    "*Splat*..."


translate pt_br feedMeatloaf_90b68c87:


    you "..?"


translate pt_br feedMeatloaf_8ca8510a:


    you "!!!" with vpunch


translate pt_br feedMeatloaf_56add764:


    "Você pisou em algo quente e úmido..."


translate pt_br feedMeatloaf_e7fb65f3:


    "...e {color=#FF0000}vermelho.{/color}"


translate pt_br feedMeatloaf_6aee484c:


    "Você resiste ao impulso de vomitar e tira o pé da trilha de..."


translate pt_br feedMeatloaf_aa46a15a:


    "De..."


translate pt_br feedMeatloaf_a20cefa7_3:


    "..."


translate pt_br feedMeatloaf_cb348c3a:


    "Você segue a trilha até a sala de estar e vê que ela vai em direção ao corredor."


translate pt_br feedMeatloaf_2f827865:


    who "{size=+5}*gurgle*... *grk*... *kurrgh*... Uhhhgh...{/size}"


translate pt_br feedMeatloaf_dae0ec55:


    you "..."


translate pt_br feedMeatloaf_98bfcf24:


    "Está ficando mais alto."


translate pt_br feedMeatloaf_e71a3743:


    "Está {i}definitivamente{/i} no corredor."


translate pt_br feedMeatloaf_8dabefc6_1:


    ".."


translate pt_br feedMeatloaf_a20cefa7_4:


    "..."


translate pt_br feedMeatloaf_1853155d:


    "Você sente como se pudesse ouvir seu próprio coração batendo."


translate pt_br feedMeatloaf_a20cefa7_5:


    "..."


translate pt_br feedMeatloaf_de85b765:


    "Você torce para que o que quer que esteja no corredor {i}não possa{/i}."


translate pt_br feedMeatloaf_e0863d49:


    "Seu corpo treme enquanto você dá mais um passo à frente."


translate pt_br feedMeatloaf_a20cefa7_6:


    "..."


translate pt_br feedMeatloaf_28a75bbb:


    "...E mais um."


translate pt_br feedMeatloaf_a20cefa7_7:


    "..."


translate pt_br feedMeatloaf_28a75bbb_1:


    "...E mais um."


translate pt_br feedMeatloaf_a20cefa7_8:


    "..."


translate pt_br feedMeatloaf_8ffd6bf2:


    "...E {i}{b}mais um.{/b}{/i}"


translate pt_br feedMeatloaf_dae0ec55_1:


    you "..."


translate pt_br feedMeatloaf_3b66688a:


    "Você espia..."


translate pt_br feedMeatloaf_e4196020:


    "por trás do canto..."


translate pt_br feedMeatloaf_8dabefc6_2:


    ".."


translate pt_br feedMeatloaf_a20cefa7_9:


    "..."


translate pt_br feedMeatloaf_40d9ca73:


    "..?"


translate pt_br feedMeatloaf_9850f53c:


    "Nada."


translate pt_br feedMeatloaf_4367dae0:


    "Não há nada lá."


translate pt_br feedMeatloaf_74be92cd:


    you "O que..?"


translate pt_br feedMeatloaf_dc6f132f:


    "Você avança mais pelo corredor e vê que a trilha se estende até o final dele."


translate pt_br feedMeatloaf_b35a0aab:


    "Mas não há nada lá..."


translate pt_br feedMeatloaf_a20cefa7_10:


    "..."


translate pt_br feedMeatloaf_b02be747:


    "Você não... sente alívio, exatamente. Mas pelo menos-"


translate pt_br feedMeatloaf_d22643f9:


    "{size=-10}*plop*{/size}"


translate pt_br feedMeatloaf_28b3ac41:


    you "!!"


translate pt_br feedMeatloaf_887daca8:


    "Você sente algo quente e molhado pingar na sua bochecha."


translate pt_br feedMeatloaf_e8998afe:


    "Algo... {i}muito{/i} quente..."


translate pt_br feedMeatloaf_a56c59b7:


    "Você passa a mão trêmula sobre isso e a tira para ver seus dedos cobertos... de {color=#FF0000}alguma coisa-{/color}"


translate pt_br feedMeatloaf_60bcdd54:


    who "{size=+15}*gurgle*... *gurgle*...{/size}"


translate pt_br feedMeatloaf_ded5babf:


    who "{size=+25}MIAooUuhgh!!{/size}" with hpunch


translate pt_br feedMeatloaf_dae0ec55_2:


    you "..."


translate pt_br feedMeatloaf_81bc8fbe:


    "Você olha para cima."


translate pt_br feedMeatloaf_415d7b3f:


    "E vê o que só pode ser descrito como..."


translate pt_br feedMeatloaf_bb123be3:


    "...{b}carne{/b}."


translate pt_br feedMeatloaf_c009ecbe:


    "O teto inteiro do corredor está coberto por uma camada espessa, ondulante,retorcida e pulsante de {b}carne{/b}..."


translate pt_br feedMeatloaf_eb3595a3:


    "...no meio, há um único olho brilhante, girando freneticamente em todas as direções..."


translate pt_br feedMeatloaf_8dabefc6_3:


    ".."


translate pt_br feedMeatloaf_a20cefa7_11:


    "..."


translate pt_br feedMeatloaf_f82e914d:


    "...até seu olhar pousar diretamente em você."


translate pt_br feedMeatloaf_dc6af6ff:


    you "{size=-8}Ah... ah..!{/size}"


translate pt_br feedMeatloaf_ca526b52:


    "Você tenta dar um passo para trás, desesperado para fugir do corredor..."


translate pt_br feedMeatloaf_6d8938bf:


    "Fugir dessa {b}coisa{/b}..."


translate pt_br feedMeatloaf_b3f43ac7:


    "Mas-"


translate pt_br feedMeatloaf_56ebb028:


    you "!!!"


translate pt_br feedMeatloaf_20d52c76:


    "Antes que você possa sequer gritar, tentáculos de carne disparam e te agarram."


translate pt_br feedMeatloaf_2982ba17:


    you "{size=+15}NNNÃOO!!{/size}" with hpunch


translate pt_br feedMeatloaf_3137a039:


    you "{size=+25}{i}ME SOLTA!!{/i}{/size}" with hpunch


translate pt_br feedMeatloaf_f3b9e9bf:


    "Eles te levantam."


translate pt_br feedMeatloaf_435dd3ca:


    "E levantam..."


translate pt_br feedMeatloaf_25c927be:


    "...até um par de mandíbulas que se abrem lentamente."


translate pt_br feedMeatloaf_b2782038:


    "...E então-"


translate pt_br feedMeatloaf_82893c2b:


    "{b}{size=+30}CHOMP!!{/size}{/b}" with vpunch


translate pt_br feedMeatloaf_8dabefc6_4:


    ".."


translate pt_br feedMeatloaf_a20cefa7_12:


    "..."


translate pt_br feedMeatloaf_34c3a0cf:


    "Final 9: Sobras"


translate pt_br feedMysteryFood_dae0ec55:


    you "..."


translate pt_br feedMysteryFood_e19f8a1e:


    you "{i}Será que isso uma boa ideia?{/i}"


translate pt_br feedMysteryFood_36cb4eaa:


    cat "Miau! Miauuuu!" with hpunch


translate pt_br feedMysteryFood_dae0ec55_1:


    you "..."


translate pt_br feedMysteryFood_c3369009:


    you "Uhg... Tá bom, se você faz questão..?"


translate pt_br feedMysteryFood_36a3d8dc:


    "Você abre o recipiente e..."


translate pt_br feedMysteryFood_f5cdd629:


    you "UGH! Hrk..!" with hpunch


translate pt_br feedMysteryFood_7b89e96c:


    "Você quase não consegue evitar de vomitar."


translate pt_br feedMysteryFood_4f6fda05:


    "Mas foi {b}por pouco.{/b}"


translate pt_br feedMysteryFood_bfa15d09:


    "O fedor é {b}{i}insuportável.{/i}{/b}"


translate pt_br feedMysteryFood_df33334e:


    you "*cof*! *gulp*..."


translate pt_br feedMysteryFood_ec1974d4:


    cat "Miau!" with hpunch


translate pt_br feedMysteryFood_d652c8bc:


    you "É, é... C-Calma aí um segundinho..."


translate pt_br feedMysteryFood_dae0ec55_2:


    you "..."


translate pt_br feedMysteryFood_fd67a9c4:


    "Você arrisca olhar para o conteúdo do recipiente, mas..."


translate pt_br feedMysteryFood_40d9ca73:


    "..?"


translate pt_br feedMysteryFood_7fb4ab6c:


    "Você honestamente não consegue entender o que era para estar {i}vendo{/i}."


translate pt_br feedMysteryFood_0d3260cd:


    "Está tudo apenas... {w}{b}amontoado{/b}."


translate pt_br feedMysteryFood_d0e4106b:


    "O que exatamente compõe esse \"tudo\" é um mistério que você está {i}mais{/i} do que feliz em deixar sem solução."


translate pt_br feedMysteryFood_e5b4174b:


    "Formas diferentes... {w}Tamanhos diferentes... {w}{i}Texturas{/i} diferentes..."


translate pt_br feedMysteryFood_a20cefa7:


    "..."


translate pt_br feedMysteryFood_1f632afd:


    "Mas a cor não..."


translate pt_br feedMysteryFood_0499b762:


    "{i}Tudo{/i} tem a mesma cor..."


translate pt_br feedMysteryFood_e5aaee76:


    "O tom de cinza mais {b}desgraçado{/b} que você já viu..."


translate pt_br feedMysteryFood_abfd3e68:


    "...com uma nauseante camada {i}úmida{/i} e {b}verde{/b} por cima..."


translate pt_br feedMysteryFood_6251ddbe:


    you "Hrk..."


translate pt_br feedMysteryFood_eebacd3d:


    you "Eu... Eu deveria {i}esquentar{/i} isso ou..?"


translate pt_br feedMysteryFood_6c91135f:


    "Você realmente não sabe como servir."


translate pt_br feedMysteryFood_6dadf976:


    "Qualquer talher ou prato que tocar nisso vai ser jogado fora {i}imediatamente.{/i}"


translate pt_br feedMysteryFood_a1ab8862:


    "{b}Sem{/b} exceções."


translate pt_br feedMysteryFood_ce04a664:


    "Suas mãos vão ser esfregadas com água e sabão até não aguentar mais depois disso..."


translate pt_br feedMysteryFood_1c5ca3cc:


    "Você decide não colocar essa porcaria no micro-ondas."


translate pt_br feedMysteryFood_e60b4396:


    "Você duvida que iria cheirar ou ter um gosto melhor depois de esquentar."


translate pt_br feedMysteryFood_00b711bd:


    "Não querendo mais segurar isso, você balança a cabeça e praticamente joga o recipiente ao lado do gato no balcão."


translate pt_br feedMysteryFood_4303c63e:


    cat "{size=+5}MIAU!!{/size}" with hpunch


translate pt_br feedMysteryFood_dd9d08f5:


    "O gato voa entusiasmado para a gosma aparentemente tóxica, cheirando-a como se estivesse saboreando o aroma."


translate pt_br feedMysteryFood_7692df1d:


    "Você se vira para a geladeira e a fecha."


translate pt_br feedMysteryFood_a20cefa7_1:


    "..."


translate pt_br feedMysteryFood_6895d8e7:


    "Você perdeu o apetite."


translate pt_br feedMysteryFood_7f974e2b:


    "Está prestes a ir ao banheiro lavar as mãos pelas próximas horas quando..."


translate pt_br feedMysteryFood_767bfdd5:


    cat "*munch*!"


translate pt_br feedMysteryFood_b82c7bcd:


    "{size=-5}*crunch*!{/size}" with vpunch


translate pt_br feedMysteryFood_8ca8510a:


    you "!!!" with vpunch


translate pt_br feedMysteryFood_9b89e7c0:


    you "AI!!" with hpunch


translate pt_br feedMysteryFood_529cb8ee:


    "Uma dor aguda no pé faz você tropeçar."


translate pt_br feedMysteryFood_d7056fb1:


    "Você se apoia na pia da cozinha e olha para baixo, vendo que a ponta da sua meia está..."


translate pt_br feedMysteryFood_2d02d511:


    "{color=#FF0000}...vermelha.{/color}"


translate pt_br feedMysteryFood_645b7424:


    "..?!"


translate pt_br feedMysteryFood_5b076aa4:


    "E o vermelho está lentamente se espalhando para o resto da sua meia."


translate pt_br feedMysteryFood_54172303:


    "Você está {b}{i}sangrando?{/i}{/b}"


translate pt_br feedMysteryFood_eaef5df7:


    "Você rapidamente se inclina e tira a meia para ver o estrago."


translate pt_br feedMysteryFood_a20cefa7_2:


    "..."


translate pt_br feedMysteryFood_632d1a35:


    you "!!!" with hpunch


translate pt_br feedMysteryFood_a20cefa7_3:


    "..."


translate pt_br feedMysteryFood_40b6614a:


    "Seu dedo do meio..."


translate pt_br feedMysteryFood_9342fc41:


    "...{b}sumiu.{/b}"


translate pt_br feedMysteryFood_9117d01a:


    "Simplesmente {i}sumiu{/i}... {w}Há apenas um toco no lugar... {w}vazando sangue no chão."


translate pt_br feedMysteryFood_6558b781:


    you "Ah... Ah..."


translate pt_br feedMysteryFood_f42c7e0f:


    "Você recua desajeitado, como se pudesse se afastar do que estava vendo. A trilha de sangue simplesmente acompanha seus movimentos."


translate pt_br feedMysteryFood_b3c55428:


    "1-9-0..."


translate pt_br feedMysteryFood_a20cefa7_4:


    "..."


translate pt_br feedMysteryFood_5355e62d:


    "Você precisa... ligar para o 1-9-0..."


translate pt_br feedMysteryFood_a378dc9c:


    you "C-Celular... Cadê o-"


translate pt_br feedMysteryFood_33af87d5:


    you "{b}!!!{/b}" with vpunch


translate pt_br feedMysteryFood_40d95a03:


    you "*COF!* *COF!* {b}*COF!*{/b}" with vpunch


translate pt_br feedMysteryFood_8dabefc6:


    ".."


translate pt_br feedMysteryFood_a20cefa7_5:


    "..."


translate pt_br feedMysteryFood_cb722153:


    you "*gurgle* O... Ouê..."


translate pt_br feedMysteryFood_78617435:


    "A sua..."


translate pt_br feedMysteryFood_6e8b8ede:


    "A sua {i}língua{/i}...!"


translate pt_br feedMysteryFood_067d0202:


    you "Ouê... {w}aoonn...nnn?!"


translate pt_br feedMysteryFood_dea300f2:


    you "{i}O que tá acontecendo comigo..?!{/i}"


translate pt_br feedMysteryFood_2f81467a:


    cat "*munch*... *munch*... *munch*..."


translate pt_br feedMysteryFood_a20cefa7_6:


    "..."


translate pt_br feedMysteryFood_db9cba4a:


    "Você lentamente olha para o lado e vê o gato ainda comendo."


translate pt_br feedMysteryFood_f044b2af:


    "Completamente indiferente ao seu sofrimento."


translate pt_br feedMysteryFood_2f81467a_1:


    cat "*munch*... *munch*... *munch*..."


translate pt_br feedMysteryFood_a0ae4816:


    "Sem sequer tentar impedir o sangue de escorrer de sua boca..."


translate pt_br feedMysteryFood_3b0a657b:


    "...você continua observando, atordoado, enquanto o gato mastiga feliz um pedaço asqueroso de..."


translate pt_br feedMysteryFood_40d9ca73_1:


    "..?"


translate pt_br feedMysteryFood_e81efaa7:


    "Espera..."


translate pt_br feedMysteryFood_dde83c31:


    "Isso é..."


translate pt_br feedMysteryFood_90087fb1:


    "Você olha mais de perto para a comida misteriosa na boca do gato."


translate pt_br feedMysteryFood_433e4a84:


    "Parece vagamente familiar..."


translate pt_br feedMysteryFood_ed0337aa:


    "Está... {w}parecendo... {w}uma..."


translate pt_br feedMysteryFood_55d4f761:


    "{size=-10}...língua?{/size}"


translate pt_br feedMysteryFood_ed5ea61e:


    you "Ah..."


translate pt_br feedMysteryFood_4f325bce:


    cat "*munch*... *gulp*..."


translate pt_br feedMysteryFood_0e994b53:


    cat "Miauuu!" with hpunch


translate pt_br feedMysteryFood_0ffcdb7b:


    "Antes que você consiga pensar em fazer algo para parar o gato, ele novamente enfia a cara no recipiente..."


translate pt_br feedMysteryFood_1ccdd916:


    "...e morde um pedaço que parece ser um--{w=1.5}{nw}"


translate pt_br feedMysteryFood_60602550:


    you "{size=+10}AAHHH!!{/size}" with vpunch


translate pt_br feedMysteryFood_b2b51942:


    you "GHH..!!" with vpunch


translate pt_br feedMysteryFood_d6477e05:


    "Você desaba no chão, com a mão no peito."


translate pt_br feedMysteryFood_4ba5d8f7:


    "Você se contorce no piso manchado de sangue, chorando..."


translate pt_br feedMysteryFood_f422db3b:


    "Algo... {w}Algo {i}dentro{/i} de você..."


translate pt_br feedMysteryFood_d69064ca:


    you "Blurgh!!" with vpunch


translate pt_br feedMysteryFood_668a5876:


    "Sangue jorra de dentro de você..."


translate pt_br feedMysteryFood_2c70abae:


    "O que quer que tenha sido... {w}parecia importante..."


translate pt_br feedMysteryFood_a20cefa7_7:


    "..."


translate pt_br feedMysteryFood_0b43b634:


    "...e agora provavelmente também sumiu."


translate pt_br feedMysteryFood_a20cefa7_8:


    "..."


translate pt_br feedMysteryFood_62c0c671:


    "Dói..."


translate pt_br feedMysteryFood_30734567:


    "Dói {i}tanto...{/i}"


translate pt_br feedMysteryFood_5aa5bc57:


    you "P... PaA... Pu... aavor..."


translate pt_br feedMysteryFood_211a3f4c:


    "Você tenta, sem forças, alcançar o gato no balcão acima de você..."


translate pt_br feedMysteryFood_84b8f508:


    "Sua visão começa a embaçar. Pelo esforço... Pela dor... Pelas lágrimas... Pelo-"


translate pt_br feedMysteryFood_822363a9:


    you "UUHHgh!!" with vpunch


translate pt_br feedMysteryFood_a20cefa7_9:


    "..."


translate pt_br feedMysteryFood_cc9a5909:


    "!!!"


translate pt_br feedMysteryFood_0858d46d:


    you "Uhhnn..."


translate pt_br feedMysteryFood_8dabefc6_1:


    ".."


translate pt_br feedMysteryFood_a20cefa7_10:


    "..."


translate pt_br feedMysteryFood_75d1a549:


    "Seus olhos..."


translate pt_br feedMysteryFood_15ada053:


    "Seus {b}{i}olhos{/i}{/b}..!"


translate pt_br feedMysteryFood_a20cefa7_11:


    "..."


translate pt_br feedMysteryFood_bd9ff9f5:


    "Você, fraco, cai no chão."


translate pt_br feedMysteryFood_ac841cd1:


    "Você está sangrando por todo o lugar... {w}{i}de{/i} todo lugar..."


translate pt_br feedMysteryFood_e55d866a:


    "Seu pé... Sua boca... Suas entranhas... Onde ficavam seus olhos..."


translate pt_br feedMysteryFood_a20cefa7_12:


    "..."


translate pt_br feedMysteryFood_8ecf8642:


    "Você tembém pode sentir sua {i}vida{/i} esvaindo..."


translate pt_br feedMysteryFood_a20cefa7_13:


    "..."


translate pt_br feedMysteryFood_caccfbd8:


    "Tá tudo bem..."


translate pt_br feedMysteryFood_e46ce5d0:


    "Se isso significa não sentir a dor de perder mais uma parte de você, então..."


translate pt_br feedMysteryFood_8dabefc6_2:


    ".."


translate pt_br feedMysteryFood_a20cefa7_14:


    "..."


translate pt_br feedMysteryFood_69d0c3bc:


    "Tomara que o gato esteja ocupado comendo seus olhos..."


translate pt_br feedMysteryFood_1a12115a:


    "...e {i}te{/i} dê tempo... {w}{alpha=0.5}para...{/alpha} {w}{alpha=0.3}para...{/alpha}"


translate pt_br feedMysteryFood_dae0ec55_3:


    you "..."


translate pt_br feedMysteryFood_8dabefc6_3:


    ".."


translate pt_br feedMysteryFood_a20cefa7_15:


    "..."


translate pt_br feedMysteryFood_71436a3d:


    "Final 10: \"Você é o que você come...\""


translate pt_br playHome_8b57cab4:


    cat "Miauuu?"


translate pt_br playHome_e1260fe5:


    "O coitadinho devia estar entediado de ficar só sentado naquela caixa velha o dia todo..."


translate pt_br playHome_aa8c252a:


    "Só assistindo a multidão passar por ele..."


translate pt_br playHome_84679d02:


    "{i}Ignorando-o{/i}..."


translate pt_br playHome_a20cefa7:


    "..."


translate pt_br playHome_d87c1b74:


    "Já que está em casa, você não pode deixá-lo sozinho!"


translate pt_br playHome_af11a585:


    "Um pouco de socialização com outras espécies não vai te matar, certo?"


translate pt_br playHome_085f82bc:


    cat "Miau..."


translate pt_br playHome_3b415eb0:


    you "Awn... Você só quer um pouco de atenção, não é? Quer brincar?"


translate pt_br playHome_ec1974d4:


    cat "Miau!" with hpunch


translate pt_br playHome_cbd9fef6:


    you "Hehe, beleza então!"


translate pt_br playHome_30cd7cf3:


    "Mas, brincar de quê?"


translate pt_br playYarn_dd1cf4bc:


    "Se todos os filmes e desenhos com gatos que você assistiu desde a infância estiverem certos..."


translate pt_br playYarn_e8f945eb:


    "...então você pode deduzir com quase {i}absoluta{/i} certeza..."


translate pt_br playYarn_cf283aac:


    "...que os gatos realmente {b}amam{/b} lã."


translate pt_br playYarn_a20cefa7:


    "..."


translate pt_br playYarn_83c46a64:


    "...Provavelmente."


translate pt_br playYarn_f53e5eed:


    "Você desenterra algumas de uma caixa velha no armário do corredor, cheia de quinquilharias de vários hobbies abandonados."


translate pt_br playYarn_9882b599:


    "Você considera simplesmente entregar a bola de lã vermelha brilhante para o gato e supervisionar de longe..."


translate pt_br playYarn_447f557d:


    "...mas isso acabaria com a ideia de brincar {i}juntos{/i}, não é?"


translate pt_br playYarn_0c8da5b7:


    "Você corta um bom pedaço de linha da bola de lã e volta para a sala de estar."


translate pt_br playYarn_143b5340:


    "O gato está descansando no chão."


translate pt_br playYarn_b46f2b82:


    "Ele não está dormindo, mas quando ele olha para cima, vendo você entrar na sala, você sente que ele poderia cochilar ali mesmo."


translate pt_br playYarn_e2043592:


    "Você vai dar um jeito nisso~"


translate pt_br playYarn_1f142b99:


    "Você dá uma risadinha, confiante com sua surpresa..."


translate pt_br playYarn_5a92a679:


    "...e deixa o pedaço de lã pendurado logo acima do chão, preso entre o polegar e o indicador."


translate pt_br playYarn_7f0ac95c:


    cat "..."


translate pt_br playYarn_e4612ec1:


    you "..!"


translate pt_br playYarn_7f0ac95c_1:


    cat "..."


translate pt_br playYarn_082fc8f9:


    "A mudança repentina no comportamento do gato faz seu coração começar a bater um pouco mais rápido."


translate pt_br playYarn_47f12df9:


    "A postura dele mal mudou."


translate pt_br playYarn_693f240f:


    "Apenas uma inclinação sutil da cabeça e das orelhas..."


translate pt_br playYarn_c99bf353:


    "Uma leve tensão nos ombros..."


translate pt_br playYarn_e3dd092d:


    "Um olhar cortante ao focar na lã pendurada a um centímetro do chão."


translate pt_br playYarn_bc8cebd1:


    "O gato ainda poderia se passar por quase... relaxado."


translate pt_br playYarn_c57d0fe0:


    "Calmo."


translate pt_br playYarn_09c01095:


    "E ainda assim, o ar está denso com sua ânsia de se lançar à frente..."


translate pt_br playYarn_9d4bad95:


    "...esperando o momento certo para atacar."


translate pt_br playYarn_dae0ec55:


    you "..."


translate pt_br playYarn_ea936df6:


    "Você sente que acabou de testemunhar o despertar do predador perfeito."


translate pt_br playYarn_c0a501b2:


    "Você... quase teme o que vai acontecer assim que fizer o primeiro movimento..."


translate pt_br playYarn_7f0ac95c_2:


    cat "..."


translate pt_br playYarn_dae0ec55_1:


    you "..."


translate pt_br playYarn_a046cf90:


    "...Mas {i}será{/i} só {i}você{/i} quem fará o primeiro movimento."


translate pt_br playYarn_75c8055f:


    "Você respira fundo..."


translate pt_br playYarn_7f0ac95c_3:


    cat "..."


translate pt_br playYarn_6b7d4985:


    "Relaxa os ombros..."


translate pt_br playYarn_7f0ac95c_4:


    cat "..."


translate pt_br playYarn_cb64e404:


    "E..."


translate pt_br playYarn_a20cefa7_1:


    "..."


translate pt_br playYarn_eaa3eb7d:


    cat "{b}MIAU!!{/b}" with hpunch


translate pt_br playYarn_80bfc06c:


    you "Vapt~!"


translate pt_br playYarn_ece07a96:


    "O gato saltou assim que você balançou a lã."


translate pt_br playYarn_1ec8f382:


    "Mas você é mais rápido."


translate pt_br playYarn_f1e3bd8f:


    "Ele erra completamente ao você girar o pulso, fazendo a lã sair do seu alcance como uma cobra assustada."


translate pt_br playYarn_0a015919:


    "Tendo exagerado ao pousar por causa da sua ânsia, o gato tropeça e olha em volta como se estivesse chocado com seu ataque fracassado."


translate pt_br playYarn_6c8a9bcc:


    "Você generosamente estala a língua para ajudá-lo a se reorientar. O gato vira a cabeça ao ouvir o som."


translate pt_br playYarn_9111e7f0:


    "Você fica um pouco surpreso com a intensidade do seu olhar na lã."


translate pt_br playYarn_dc3f454b:


    "Mas você persiste."


translate pt_br playYarn_0d970e5b:


    "Você mexe na lã novamente, o encorajando... {w}e sim, talvez provocando {i}um pouco{/i}."


translate pt_br playYarn_28d461a7:


    "Desta vez, o gato antecipa o movimento de subida da lã e salta para alcançá-la..."


translate pt_br playYarn_1e32b6e1:


    "Mas você já está um passo à frente, manipulando a lã para dançar graciosamente fora de alcance mais uma vez."


translate pt_br playYarn_ceceaf01:


    cat "Miau!" with hpunch


translate pt_br playYarn_046c475d:


    you "Hehe, vambora. Você consegue~"


translate pt_br playYarn_00cf3674:


    "É um pouco condescendente, mas você não consegue evitar."


translate pt_br playYarn_defd1036:


    "Por algum motivo, é um pouco satisfatório colocar o gato em seu lugar."


translate pt_br playYarn_74d03aa0:


    cat "Miaau! Miaau!"


translate pt_br playYarn_9f124326:


    "Pelo menos parece estar se divertindo?"


translate pt_br playYarn_79f40d3e:


    "Você {i}espera{/i} que sim..."


translate pt_br playYarn_a20cefa7_2:


    "..."


translate pt_br playYarn_5d2e14ac:


    "Você continua."


translate pt_br playYarn_82c37b27:


    cat "Miaau!{w=0.7}{nw}" with vpunch


translate pt_br playYarn_c2d58782:


    cat "{size=+5}Miaau!!{/size}{w=0.7}{nw}" with vpunch


translate pt_br playYarn_ddbf4218:


    cat "{size=+10}Miaau!!!{/size}{w=0.7}{nw}" with vpunch


translate pt_br playYarn_238eca43:


    "Os movimentos do gato começaram a ficar mais... agressivos."


translate pt_br playYarn_b85635f2:


    "Deve estar ficando frustrado."


translate pt_br playYarn_15e0cfc4:


    "Você poderia {i}jurar{/i} que na última vez quase atacou seu olho, pulou tão alto e de forma imprevisível..."


translate pt_br playYarn_b6240bec:


    "Você tem mantido a lã em constante movimento, com medo de desacelerar."


translate pt_br playYarn_7c40740c:


    "Seu pulso está começando a ficar cansado..."


translate pt_br playYarn_f8a8c5e7:


    "Mas o gato não parece estar perdendo energia alguma."


translate pt_br playYarn_abbf9704:


    "É como se..."


translate pt_br playYarn_f401f029:


    "...estivesse ficando cada vez mais rápido."


translate pt_br playYarn_9416f814:


    cat "{b}Miaau!{/b}" with vpunch


translate pt_br playYarn_f2676f04:


    "*Vush*"


translate pt_br playYarn_d1bee282:


    cat "{size=+5}{b}Miaau!{/b}{/size}" with vpunch


translate pt_br playYarn_f2676f04_1:


    "*Vush*"


translate pt_br playYarn_06cf9fb4:


    cat "{size=+10}{b}Miaau!{/b}{/size}" with vpunch


translate pt_br playYarn_6c59984d:


    "*Vush*-"


translate pt_br playYarn_0174bdad:


    you "Nhh!"


translate pt_br playYarn_363b732f:


    "Seu pulso finalmente começa a doer agudamente..."


translate pt_br playYarn_91e83780:


    "...fazendo você perder o controle do movimento da lã enquanto a ponta dela toca levemente seu estômago-"


translate pt_br playYarn_9e69e751:


    "{size=+25}{i}SLASH!!!{/i}{/size}" with hpunch


translate pt_br playYarn_88a29bc2:


    you "..!!! GHH!!" with vpunch


translate pt_br playYarn_fa719f0e:


    "A dor rasga sua barriga..."


translate pt_br playYarn_9d6f51b9:


    "...{i}dentro{/i} da sua barriga."


translate pt_br playYarn_0670ea4a:


    you "B-Blurgh!" with vpunch


translate pt_br playYarn_3fa6ed31:


    "Sangue derrama da sua boca..."


translate pt_br playYarn_93c8a750:


    "Atordoado, você olha para baixo e vê o vermelho aumentando lentamente na parte de baixo da sua camisa... ao redor dos rasgos no tecido..."


translate pt_br playYarn_28f0d5c3:


    you "*cof* *cof*-"


translate pt_br playYarn_b11bba49:


    "{size=+10}{b}PLOP!{/b}{/size}" with vpunch


translate pt_br playYarn_56ebb028:


    you "!!!"


translate pt_br playYarn_cfd9f7c0:


    you "A-Ah..!"


translate pt_br playYarn_a3378925:


    "Você assiste enquanto longas e grossas linhas de..."


translate pt_br playYarn_083f1354:


    "{i}...alguma coisa...{/i}"


translate pt_br playYarn_c9be29f0:


    "...despejam-se debaixo da sua camisa, em um monte de sangue no chão aos seus pés."


translate pt_br playYarn_36f9ea20:


    "Uma única linha vermelha ainda se prende a você... {w}{i}conectando{/i} você a toda aquela... {b}bagunça{/b}."


translate pt_br playYarn_98fb658f:


    "Esses... {w}Esses são seus...?"


translate pt_br playYarn_afbea56b:


    "Você desmorona no chão e cai de lado."


translate pt_br playYarn_101de09f:


    "Sua visão ficou embaçada..."


translate pt_br playYarn_bf0874e3:


    "Mas..."


translate pt_br playYarn_a49bee6a:


    "...você consegue distinguir a forma de algo pequeno e de um preto profundo se aproximando e conferindo seus..."


translate pt_br playYarn_a5942a18:


    "{size=-10}Meu Deus, são seus {i}intestinos{/i}...{/size}"


translate pt_br playYarn_59d3b133:


    "...antes de começar a rolar, animado, na massa de suas entranhas ensanguentadas ao seu lado."


translate pt_br playYarn_5e84b463:


    cat "Miau! Miau!"


translate pt_br playYarn_a0096ee8:


    "Escuridão recai sobre você..."


translate pt_br playYarn_e5fab8a0:


    cat "Miau!"


translate pt_br playYarn_dae0ec55_2:


    you "..."


translate pt_br playYarn_99e0e8b8:


    "O gato... {w}parece feliz."


translate pt_br playYarn_6d107ba2:


    "Ilogicamente, você se pergunta onde foi parar a lã, mas... {w}não há porque se preocupar com isso."


translate pt_br playYarn_2773433b:


    "O gato parece satisfeito com a segunda melhor opção."


translate pt_br playYarn_a20cefa7_3:


    "..."


translate pt_br playYarn_472f27e0:


    "Final 11: Fim da Linha"


translate pt_br playLaser_fb5ad6dc:


    "Gatos são criaturas curiosas por natureza..."


translate pt_br playLaser_c4ace2d3:


    "Eles também são caçadores natos... De certa forma."


translate pt_br playLaser_80e551db:


    "Por que não passar tempo fazendo o gato caçar algo que ele nunca vai entender direito?"


translate pt_br playLaser_a20cefa7:


    "..."


translate pt_br playLaser_75f82259:


    "Pensando bem, isso soa um pouco maldoso..."


translate pt_br playLaser_914e4419:


    "Mas não é como se o gato fosse perceber, de qualquer forma."


translate pt_br playLaser_1a75f885:


    "\"A ignorância é uma benção\", é o que dizem, pelo menos."


translate pt_br playLaser_9007c0d7:


    "Então você desenterra seu laser velho dos tempos amaldiçoados de apresentações em grupo na escola."


translate pt_br playLaser_c3d8ff06:


    "Você o liga e vê que mesmo após todo esse tempo, a bateria ainda funciona."


translate pt_br playLaser_9c176f96:


    "Você se diverte um pouco mirando o laser em um espelho pendurado na sala, fazendo-o refletir no vidro..."


translate pt_br playLaser_679296d6:


    "...E fazendo um ponto vermelho aparecer no seu joelho."


translate pt_br playLaser_751f71d9:


    cat "...Miau?"


translate pt_br playLaser_ebec2255:


    "O gato cuidadosamente se aproxima, parando a cada poucos passos para lançar um olhar desconfiado em sua direção."


translate pt_br playLaser_1f6e99f2:


    "Quando ele finalmente chega perto, pressiona suavemente a patinha no seu joelho..."


translate pt_br playLaser_7afb7281:


    "...como se estivesse tentando pegar o pontinho vermelho, como se fosse possível."


translate pt_br playLaser_6e2311a9:


    you "Hm!" with vpunch


translate pt_br playLaser_e7427e1b:


    "Você consegue segurar um riso. Não que isso importe muito."


translate pt_br playLaser_51f4c068:


    "O gato não está nem prestando atenção em você, totalmente focado na luz que agora está em sua pata."


translate pt_br playLaser_c6366437:


    you "Hehe~"


translate pt_br playLaser_a1c9ebec:


    "Você move a luz para um pouco acima do seu joelho."


translate pt_br playLaser_bdf0b7fa:


    "O gato reage na hora, tentando prender o ponto de luz..."


translate pt_br playLaser_1e13c86f:


    "...mas no segundo seguinte, você já o moveu para o chão."


translate pt_br playLaser_e51a55ad:


    "O gato acompanha bruscamente, tentando um ataque mais enérgico quando você move o ponto vermelho......"


translate pt_br playLaser_27fb2bef:


    "Aqui..."


translate pt_br playLaser_99bbe8fa:


    "Ali..."


translate pt_br playLaser_c2405716:


    "E ali..."


translate pt_br playLaser_a4dbb992:


    "Perto do..."


translate pt_br playLaser_7b4b553d:


    "Em cima {i}do{/i} sofá..."


translate pt_br playLaser_555c0370:


    cat "Miaau! Miaau!!" with hpunch


translate pt_br playLaser_0931d500:


    you "Hehehe!"


translate pt_br playLaser_33d860e3:


    "O gato pode estar te ignorando, mas, com certeza, você está se divertindo."


translate pt_br playLaser_98b699aa:


    "Já faz um bom tempo que você não ri tanto assim."


translate pt_br playLaser_a20cefa7_1:


    "..."


translate pt_br playLaser_2ca4176f:


    "Na verdade, você ri {i}tanto{/i}..."


translate pt_br playLaser_0f656f12:


    "...que acidentamente coloca o ponto vermelho sobre o abajur ao lado do sofá."


translate pt_br playLaser_a4314429:


    cat "{size=+10}Miaau!{/size}" with hpunch


translate pt_br playLaser_c80ec7e6:


    "Na pressa de pegar a luz, o gato pula no abajur, e os dois vão ao chão."


translate pt_br playLaser_c9873f7d:


    "{size=+20}CRASH!!{/size}" with vpunch


translate pt_br playLaser_2cb154e5:


    you "*Gasp* Meu Deus!"


translate pt_br playLaser_4cd0c099:


    "O gato está sentado no meio dos cacos quebrados do que um dia foi o abajur..."


translate pt_br playLaser_4e66e4b9:


    "...costas curvadas, a cabeça se virando para lá e para cá, como se estivesse em pânico."


translate pt_br playLaser_68f4b17b:


    "Você rapidamente desliga o laser e corre até ele."


translate pt_br playLaser_d789f24b:


    you "Me desculpa! V-Você tá bem? Se machucou?"


translate pt_br playLaser_d4abd66b:


    "Você se abaixa para pegar o gato e ver se ele se machucou, quando-"


translate pt_br playLaser_8fdc8cf1:


    cat "{size=+5}MIAAUU!!{/size}" with vpunch


translate pt_br playLaser_ec457ab1:


    "{size=+20}{i}SLASH!{/i}{/size}" with hpunch


translate pt_br playLaser_327933f5:


    you "AI! Ei!"


translate pt_br playLaser_a708b99f:


    "O gato te ataca, com as garras estendidas."


translate pt_br playLaser_da2387c2:


    "Ele recua e se contorce, girando freneticamente em várias direções, como se estivesse procurando por algo..."


translate pt_br playLaser_663f6b23:


    "...ou {i}esperando{/i} que algo apareça."


translate pt_br playLaser_290f624d:


    you "Ai, caralho... Isso machuca, sabia?"


translate pt_br playLaser_38b4ee56:


    "Você segura a mão arranhada próxima ao peito."


translate pt_br playLaser_eee45712:


    "Está sangrando, mas não está tão ruim. É mais irritação que tudo, mas..."


translate pt_br playLaser_e78aaa6d:


    cat "Miaauu!{w=0.75}{nw}" with hpunch


translate pt_br playLaser_1bb5166d:


    cat "Miaauu! Miaauu!{w=1}{nw}" with hpunch


translate pt_br playLaser_ab09fb6c:


    "...imediatamente sua irritação começa a dar lugar à preocupação."


translate pt_br playLaser_e92b7d98:


    cat "{i}MIAAUU!{/i}" with vpunch


translate pt_br playLaser_539c898a:


    "Você observa em choque, enquanto o gato começa a correr pela sala, rasgando o carpete, o sofá, sua poltrona..."


translate pt_br playLaser_f45e7675:


    "Você quer pará-lo, mas está com medo de se enfiar no meio do seu surto."


translate pt_br playLaser_8920b0ca:


    "Você pensa em ligar para um veterinário para saber como acalmar ele, mas por algum motivo..."


translate pt_br playLaser_a20cefa7_2:


    "..."


translate pt_br playLaser_12cd3024:


    "{size=-10}...você sente que não é uma boa ideia.{/size}"


translate pt_br playLaser_a20cefa7_3:


    "..."


translate pt_br playLaser_5fb40629:


    you "O que aconteceu com você...? Será que...?"


translate pt_br playLaser_38a2a096:


    you "..!" with vpunch


translate pt_br playLaser_d478bf3d:


    "Uma ideia passa pela sua cabeça. Ou melhor, uma epifania?"


translate pt_br playLaser_688dec48:


    "Você segura o laser, cuidadosamente apontando-o para o chão no meio da sala..."


translate pt_br playLaser_3ab47bcb:


    "Pensando... {w}{i}esperando{/i}... {w}que o gato pudesse se acalmar caso encontrasse o que estava procurando..."


translate pt_br playLaser_74fa8018:


    "...você liga o laser."


translate pt_br playLaser_ab6d5659:


    cat "!!!" with hpunch


translate pt_br playLaser_8dabefc6:


    ".."


translate pt_br playLaser_a20cefa7_4:


    "..."


translate pt_br playLaser_10394fe2:


    "A reação do gato é {b}imediata.{/b}"


translate pt_br playLaser_e362f7cd:


    cat "Miaauu!" with hpunch


translate pt_br playLaser_d6063309:


    cat "{size=+15}MIAAUU!! {/size}" with hpunch


translate pt_br playLaser_e47b681a:


    cat "{size=+25}{b}MROOARRR!!!{/b}{/size}" with hpunch


translate pt_br playLaser_56ebb028:


    you "!!!"


translate pt_br playLaser_a20cefa7_5:


    "..."


translate pt_br playLaser_02bcbf4d:


    "{size=-8}...Você fudeu tudo.{/size}"


translate pt_br playLaser_ff446bcf:


    "Em questão de segundos, você vê o gato avistar o ponto vermelho do alto da poltrona destroçada..."


translate pt_br playLaser_bcb1443f:


    "...dar um salto muito alto no ar..."


translate pt_br playLaser_ce89eeea:


    "...{i}{b}mudar{/b}{/i} no ar..."


translate pt_br playLaser_b7ce2ec0:


    "{size=+35}{b}CRASH!!{/b}{/size}{w=0.2}{nw}" with hpunch


translate pt_br playLaser_3aae9beb:


    "{size=+35}{b}CRASH!!{/b}{/size}" with vpunch


translate pt_br playLaser_56ebb028_1:


    you "!!!"


translate pt_br playLaser_cd394c54:


    "...e desabar sobre o ponto no chão, com um peso e força que faz {i}tremer{/i} todo o apartamento."


translate pt_br playLaser_41d12d34:


    "Talvez até o prédio inteiro."


translate pt_br playLaser_f7f341a9:


    "Você se pergunta, atordoado, como nenhum dos outros moradores correu para reclamar do barulho..."


translate pt_br playLaser_a1efdf2a:


    "Mas, enquanto você encara a cena à sua frente..."


translate pt_br playLaser_189e50c9:


    "O gato de alguma forma {i}cresceu{/i}..."


translate pt_br playLaser_0d1c6dcc:


    "...os olhos saltados e brilhando... {w}a cauda chicoteando... {w}os dentes crescidos, à mostra e alarmantemente cobertos por uma espuma borbulhante..."


translate pt_br playLaser_b78125ff:


    "Suas garras gigantes rasgam e destroem o carpete, os azulejos do chão e vão ainda {b}mais fundo{/b}..."


translate pt_br playLaser_29b85512:


    "...tentando vorazmente alcançar o ponto vermelho."


translate pt_br playLaser_3917623e:


    "Suas mãos estão tremendo."


translate pt_br playLaser_a225310b:


    "Você não sabe o que fazer. Se sente encurralado. Precisa se afastar."


translate pt_br playLaser_82568cc9:


    "...Precisa se afastar {i}disso{/i}."


translate pt_br playLaser_28b3ac41:


    you "!!"


translate pt_br playLaser_94047747:


    "Você lentamente recua em direção à porta."


translate pt_br playLaser_76076a2d:


    "A luz se move com você."


translate pt_br playLaser_f2573342:


    cat "{size=+10}!!!{/size}" with hpunch


translate pt_br playLaser_56ebb028_2:


    you "!!!"


translate pt_br playLaser_4d205848:


    "Instintivamente você mexe a luz, de um lado para o outro, enquanto o gato corre atrás dela..."


translate pt_br playLaser_cb465f82:


    "{size=+30}{b}CRASH!!{/b}{/size}" with vpunch


translate pt_br playLaser_69d96002:


    you "{i}Rápido demais...{/i}"


translate pt_br playLaser_195b9941:


    "...esmagando a TV... partindo o sofá ao meio..."


translate pt_br playLaser_17efb246:


    "{size=+30}{b}CRASH!!{/b}{/size}{w=0.2}{nw}" with vpunch


translate pt_br playLaser_5fdd654f:


    "{size=+30}{b}CRASH!! CRASH!!{/b}{/size}" with vpunch


translate pt_br playLaser_adef04a7:


    you "{i}Rápido demais...{/i}"


translate pt_br playLaser_555778c7:


    "...atravessando a parede, indo para corredor."


translate pt_br playLaser_3aae9beb_1:


    "{size=+35}{b}CRASH!!{/b}{/size}" with vpunch


translate pt_br playLaser_28b3ac41_1:


    you "!!"


translate pt_br playLaser_7984bc3e:


    "Uma chance!"


translate pt_br playLaser_67119f3b:


    "Você se vira, decidido a sair pela porta e nunca mais voltar..."


translate pt_br playLaser_a741a67f:


    "...mas, na pressa, você {b}esquece{/b} de algo."


translate pt_br playLaser_4dfa2f4a:


    "Você esquece de {i}vários{/i} algos."


translate pt_br playLaser_3ef81c43:


    "Você esquece o laser, segurando-o como se fosse um recurso vital..."


translate pt_br playLaser_e94069c8:


    cat "!!!"


translate pt_br playLaser_6d278a4f:


    "Se esquece do espelho, ainda milagrosamente pendurado na parede ao lado do corredor..."


translate pt_br playLaser_aa8d0cf9:


    "...com o laser refletindo nele..."


translate pt_br playLaser_e6c0f1f9:


    "...projetando um pequeno ponto vermelho brilhante..."


translate pt_br playLaser_a20cefa7_6:


    "..."


translate pt_br playLaser_69603a8b:


    "...atrás da sua cabeça..."


translate pt_br playLaser_7f0ac95c:


    cat "..."


translate pt_br playLaser_80207668:


    "E assim que você alcança a porta......"


translate pt_br playLaser_9b41848f:


    cat "{b}*RUGIDO*{/b}"


translate pt_br playLaser_a20cefa7_7:


    "..."


translate pt_br playLaser_35fdb28d:


    "...você esqueceu que está trancada."


translate pt_br playLaser_8dabefc6_1:


    ".."


translate pt_br playLaser_a20cefa7_8:


    "..."


translate pt_br playLaser_8b4b67e6:


    "Você nem tem a chance de se virar antes que o gato salte do outro lado da sala em sua direção."


translate pt_br playLaser_dae0ec55:


    you "..."


translate pt_br playLaser_f57c18d4:


    "Você é dilacerado antes mesmo de conseguir piscar."


translate pt_br playLaser_a20cefa7_9:


    "..."


translate pt_br playLaser_fa28c27c:


    "Final 12: Alvo"


translate pt_br playHideSeek_4bd0d419:


    you "Que tal esconde-esconde..?"


translate pt_br playHideSeek_16879ce5:


    cat "Miau?"


translate pt_br playHideSeek_dae0ec55:


    you "..."


translate pt_br playHideSeek_7f0ac95c:


    cat "..."


translate pt_br playHideSeek_501b5875:


    "Você... não tem muita certeza de como isso vai funcionar."


translate pt_br playHideSeek_2dd47eb6:


    "Será que um gato conseguiria entender o conceito de um {i}jogo...{/i} {w}ainda mais um com regras, como esconde-esconde?"


translate pt_br playHideSeek_990e7450:


    you "Hmm... Aqui, ó..."


translate pt_br playHideSeek_d9b6c5b2:


    "Você pega o gato e coloca ele virado, longe de você, antes de se esconder atrás da poltrona."


translate pt_br playHideSeek_0b37453e:


    "Você tem quase certeza de que o gato deve ter se virado e olhado enquanto você se escondia... {w}por estar confuso, ou outro motivo..."


translate pt_br playHideSeek_16879ce5_1:


    cat "Miau?"


translate pt_br playHideSeek_caa03df3:


    "De qualquer forma, depois de um momento, o gato cuidadosamente te espia pela poltrona, com os olhos curiosos."


translate pt_br playHideSeek_bfd68843:


    "Você sorri e o pega no colo, segurando-o à sua frente."


translate pt_br playHideSeek_bf4f65f9:


    you "Você me achou! Você ganhou!!"


translate pt_br playHideSeek_321f01a1:


    cat "Miau! Miau!" with hpunch


translate pt_br playHideSeek_3b87374e:


    "O gato parece confuso, mas contente com sua empolgação."


translate pt_br playHideSeek_ef6ad04d:


    "Dessa vez, você o coloca na poltrona para que ele não veja seu esconderijo tão facilmente."


translate pt_br playHideSeek_1f14505c:


    "Você corre até a cozinha, escondendo-se atrás do balcão."


translate pt_br playHideSeek_dd4584c0:


    "Demora um pouco mais dessa vez para o gato te encontrar."


translate pt_br playHideSeek_8fa4c58e:


    "Dessa vez, quando encontra, ele te assusta pulando de cima do balcão direto no seu colo."


translate pt_br playHideSeek_fc460430:


    you "Ei!" with vpunch


translate pt_br playHideSeek_fbbaa7ef:


    cat "Miau! Miaau!" with hpunch


translate pt_br playHideSeek_5afcd17c:


    you "Você me achou de novo!"


translate pt_br playHideSeek_b003a621:


    cat "Miau!"


translate pt_br playHideSeek_fc37ae68:


    you "Hehe, tá, tá, você ganhou!"


translate pt_br playHideSeek_044aa542:


    "Você o recompensa esfregando atrás de sua orelha e abaixo do queixo, fazendo-o se inclinar na sua mão."


translate pt_br playHideSeek_78b6d9cf:


    cat "Purr.. Purr.."


translate pt_br playHideSeek_6e23df72:


    you "Hehe~ Tá bom, que tal você tentar agora?"


translate pt_br playHideSeek_16879ce5_2:


    cat "Miau?"


translate pt_br playHideSeek_4b3553e2:


    "Você vai até o meio da sala e fica lá parado..."


translate pt_br playHideSeek_ab912efe:


    "...com o gato te seguindo, logo atrás."


translate pt_br playHideSeek_13e57d68:


    "Você faz um showzinho cobrindo os olhos e se virando."


translate pt_br playHideSeek_3d4baad1:


    you "Ok~"


translate pt_br playHideSeek_d05e788f:


    you "5... 4... 3... 2... 1... Vai!"


translate pt_br playHideSeek_43176d29:


    "Você se vira e vê que o gato sumiu."


translate pt_br playHideSeek_a96ff075:


    you "Hmm, você pega o jeito rápido..."


translate pt_br playHideSeek_659c41b9:


    "Não há muitos lugares no seu apartamento para que alguém do seu tamanho possa se esconder..."


translate pt_br playHideSeek_138bf664:


    "...mas, sem polegares opositores necessários para abrir as portas fechadas do corredor, o gato também terá seus limites."


translate pt_br playHideSeek_46edf521:


    "É justo."


translate pt_br playHideSeek_e97341d6:


    you "Beleza, agora onde procurar~"


translate pt_br seekLivingRoom_b174d0b4:


    "Você olha atrás do sofá e da poltrona... {w}Depois embaixo da mesa de centro..."


translate pt_br seekLivingRoom_a20cefa7:


    "..."


translate pt_br seekLivingRoom_3f311f83:


    "Nada. A sala é bem simples quando se trata de mobília, afinal."


translate pt_br seekKitchen_8e951d9b:


    "Você espia ao redor do balcão... {w}Pega uma cadeira e dá uma olhada em cima da geladeira..."


translate pt_br seekKitchen_b35ddd37:


    "Você até abre os armários baixos, só para garantir que o gato não tenha conseguido se enfiar lá dentro..."


translate pt_br seekKitchen_a20cefa7:


    "..."


translate pt_br seekKitchen_67b7b559:


    "Nada. Você decide que é até melhor assim."


translate pt_br seekKitchen_6e50a758:


    "A cozinha é para preparar comida, não para brincadeiras."


translate pt_br seekHallway_7248db28:


    "Você olha pelos cantos em direção ao corredor..."


translate pt_br seekHallway_a20cefa7:


    "..."


translate pt_br seekHallway_a20cefa7_1:


    "..."


translate pt_br seekHallway_4e973a05:


    "Nada. Você não tem certeza do que estava esperando."


translate pt_br seekHallway_957bcdee:


    "Com todas as portas fechadas..."


translate pt_br seekHallway_148b7481:


    "Não há onde se esconder no corredor"


translate pt_br seekingDone_2b449ce4:


    "Você não consegue achar o gato em lugar algum..."


translate pt_br seekingDone_e2a5632e:


    "Você começa a ficar um pouco preocupado ao ouvir um som bem baixinho vindo do... corredor..?"


translate pt_br seekingDone_dc5e6416:


    "Você vai até o corredor e ouve de novo."


translate pt_br seekingDone_8dabefc6:


    ".."


translate pt_br seekingDone_a20cefa7:


    "..."


translate pt_br seekingDone_d5aac1e5:


    "{size=-5}*scratch* *scratch*{/size}"


translate pt_br seekingDone_90425976:


    "Parece ter vindo do... seu quarto... mas..."


translate pt_br seekingDone_4902eb0a:


    "Você caminha pelo corredor até seu quarto e abre a porta com cuidado-"


translate pt_br seekingDone_ec1974d4:


    cat "Miau!" with hpunch


translate pt_br seekingDone_e74ed2e1:


    you "Gah!" with vpunch


translate pt_br seekingDone_a479bdf3:


    "O gato sai em passinhos rápidos e corre ao redor das suas pernas, miando insistentemente."


translate pt_br seekingDone_5e84b463:


    cat "Miau! Miau!"


translate pt_br seekingDone_5e30cc7e:


    "Ele parece.... {w}decepcionado com você, de alguma forma? {w}Talvez com suas habilidades de caça aparentemente medíocres..."


translate pt_br seekingDone_bf0874e3:


    "Mas..."


translate pt_br seekingDone_edd5757f:


    "Você o pega nos braços e olha para a porta do seu quarto."


translate pt_br seekingDone_ba8a4d17:


    you "Como você... entrou no meu quarto?"


translate pt_br seekingDone_e5fab8a0:


    cat "Miau!"


translate pt_br seekingDone_dae0ec55:


    you "..."


translate pt_br seekingDone_93d1adf7:


    "Você... {w}Você {i}sabe{/i} que a porta estava fechada."


translate pt_br seekingDone_31c44218:


    "{size=-5}Né..?{/size}"


translate pt_br seekingDone_be5113cc:


    "O gato se solta dos seus braços e corre para fora do corredor."


translate pt_br seekingDone_dae0ec55_1:


    you "..."


translate pt_br seekingDone_c00c8735:


    "Você o segue e encontra ele sentado bem no meio da sala."


translate pt_br seekingDone_e5fab8a0_1:


    cat "Miau!"


translate pt_br seekingDone_e131e1c8:


    "Assim que vê você, ele rapidamente se vira de costas."


translate pt_br seekingDone_63775626:


    "Acho que agora é a vez dele de procurar, não é?"


translate pt_br seekingDone_cc17d7e1:


    "Você está prestes a agradá-lo se escondendo atrás do balcão novamente, quando-"


translate pt_br seekingDone_28b3ac41:


    you "!!"


translate pt_br seekingDone_0cea138b:


    "As luzes... Será que a energia acabou?"


translate pt_br seekingDone_1a77e248:


    you "Droga..."


translate pt_br seekingDone_5c8a1500:


    "Enquanto espera que seus olhos se ajustem à escuridão..."


translate pt_br seekingDone_88a23747:


    "...você percebe que o gato não se mexeu nem um centímetro."


translate pt_br seekingDone_3bb63b1d:


    "Ficou assustado?"


translate pt_br seekingDone_60b30750:


    you "Ei, você tá-"


translate pt_br seekingDone_b48bd826:


    "*Badum* *Badum* *Badum*"


translate pt_br seekingDone_40d9ca73:


    "..?"


translate pt_br seekingDone_67aaa788:


    "O quê?"


translate pt_br seekingDone_8e3bedbd:


    "Por algum motivo..."


translate pt_br seekingDone_ecdba21d:


    "...seu coração começa a bater mais rápido."


translate pt_br seekingDone_0f5de544:


    "Você..."


translate pt_br seekingDone_ae699357:


    "Você pensa em ir até o gato..."


translate pt_br seekingDone_26358dc1:


    "Mas, ao fazer isso..."


translate pt_br seekingDone_bcc0f247:


    "...a ideia faz você sentir..."


translate pt_br seekingDone_84220bdf:


    you ".."


translate pt_br seekingDone_dae0ec55_2:


    you "..."


translate pt_br seekingDone_796928f5:


    "...Você sente que sua vida está em perigo."


translate pt_br seekingDone_8dabefc6_1:


    ".."


translate pt_br seekingDone_a20cefa7_1:


    "..."


translate pt_br seekingDone_c73db94c:


    "Você precisa se esconder."


translate pt_br seekingDone_e42d7264:


    "{b}Agora.{/b}"


translate pt_br time_out_a20cefa7:


    "..."


translate pt_br time_out_ff2c9b51:


    "Você falhou."


translate pt_br time_out_a20cefa7_1:


    "..."


translate pt_br time_out_d4b5152a:


    "Tentar novamente?"


translate pt_br hidingArmchair_dfc43610:


    "Não, é muito perto. Ele te encontraria imediatamente."


translate pt_br hidingKitchen_9e1fc511:


    "Você já se escondeu lá antes e ele te encontrou quase instantaneamente. Não vai funcionar."


translate pt_br hidingHall_6093fc0a:


    "Apenas... No corredor?"


translate pt_br hidingHall_3fe08047:


    "{size=-5}{b}Não há onde se {i}esconder{/i} no corredor.{/b}{/size}"


translate pt_br hidingHallCloset_35447e61:


    "Você entra silenciosamente para dentro do armário do corredor..."


translate pt_br hidingHallCloset_a20cefa7:


    "..."


translate pt_br hidingHallCloset_632d1a35:


    you "!!!" with hpunch


translate pt_br hidingHallCloset_3d6395df:


    "A porta não fecha porque uma caixa pesada a está bloqueando depois de você entrar."


translate pt_br hidingHallCloset_50bac2df:


    "Se você tentar tirá-la do caminho, o gato pode ouvir."


translate pt_br hidingHallCloset_19a963ab:


    "Isso é, se ele já não tiver te ouvido."


translate pt_br hidingHallCloset_a067a470:


    "Isso não vai funcionar. Você precisa se esconder em outro lugar."


translate pt_br hidingHallCloset_0c125b36:


    "Rápido!"


translate pt_br hidingBathroom_ee79f861:


    "Você corre silenciosamente até o banheiro e-"


translate pt_br hidingBathroom_823cbce9:


    "*clink!* *clink!* *clink!*" with hpunch


translate pt_br hidingBathroom_24bdca17:


    you "{i}O quê?! Por que a porta está {b}trancada?!{/b}{/i}"


translate pt_br hidingBathroom_96a60aa2:


    "Você congela ao perceber quanto barulho fez mexendo na maçaneta e prende a respiração."


translate pt_br hidingBathroom_5650ad03:


    "Ouvindo..."


translate pt_br hidingBathroom_dae0ec55:


    you "..."


translate pt_br hidingBathroom_1e37664c:


    "O silêncio vindo da sala parece mais pesado do que antes. Mais inquieto."


translate pt_br hidingBathroom_0df09957:


    "Mesmo se algum milagre abrisse a porta agora, ele saberia exatamente onde você está. Não adianta."


translate pt_br hidingBedroom_1ff5c45d:


    "Você corre silenciosamente para o quarto, fechando a porta atrás de você com cuidado."


translate pt_br hidingBedroom_8fc59726:


    "O único lugar para se esconder no seu quarto é o seu armário."


translate pt_br hideAndSeekEnd_7a6998e3:


    "Você tranca a porta o mais silenciosamente possível antes de pular para dentro armário e fechá-lo."


translate pt_br hideAndSeekEnd_04f7409b:


    "Assim que você se protege dentro do armário..."


translate pt_br hideAndSeekEnd_2aeed70c:


    "...há uma súbita mudança em todo o apartamento."


translate pt_br hideAndSeekEnd_7dfa20bb:


    "Como se algo pudesse sentir que você está mais pronto do que nunca..."


translate pt_br hideAndSeekEnd_8d5830fc:


    "Como se pudesse sentir..."


translate pt_br hideAndSeekEnd_18e07b28:


    "...que você está pronto para ser caçado."


translate pt_br hideAndSeekEnd_c4340c4a:


    "Um horrível arrepio percorre sua espinha ao perceber que é isso que essa brincadeira se tornou."


translate pt_br hideAndSeekEnd_dec1d69c:


    "Isso não é mais uma simples brincadeira de esconde-esconde."


translate pt_br hideAndSeekEnd_db025406:


    "É ser {i}caçado{/i} por um predador... como presa."


translate pt_br hideAndSeekEnd_90116c90:


    "Nunca..."


translate pt_br hideAndSeekEnd_008b199b:


    "{size=-10}Nunca importou onde você escolheu se esconder, importou?{/size}"


translate pt_br hideAndSeekEnd_e993f131:


    "{size=+15}*BAM!!*{/size}" with hpunch


translate pt_br hideAndSeekEnd_8ca8510a:


    you "!!!" with vpunch


translate pt_br hideAndSeekEnd_006cf29b:


    "Como se estivesse respondendo a sua pergunta, você ouve uma batida forte na porta do quarto."


translate pt_br hideAndSeekEnd_1d63d4b0:


    "Você {i}mal{/i} consegue segurar um som de susto diante do barulho."


translate pt_br hideAndSeekEnd_3523c074:


    "{size=+20}*BAM!! BAM!!*{/size}" with hpunch


translate pt_br hideAndSeekEnd_981dfd0d:


    "Seu coração dispara novamente, dificultando respirar em silêncio. Dificultando respirar em geral..."


translate pt_br hideAndSeekEnd_f29fbbed:


    "{size=+25}*BAM!! BAM!! BAM!!*{/size}" with hpunch


translate pt_br hideAndSeekEnd_4331beee:


    "Lágrimas enchem seus olhos enquanto você cobre a boca ofegante com as mãos trêmulas."


translate pt_br hideAndSeekEnd_bc2b365b:


    "Ele sabe."


translate pt_br hideAndSeekEnd_aa5ace4f:


    "Ele {i}{b}sabe{/b}{/i}."


translate pt_br hideAndSeekEnd_7507be91:


    "Chorando com as mãos sobre a boca, tentando abafar os sons sufocados que escapam de você..."


translate pt_br hideAndSeekEnd_30c5f04c:


    "...você desliza pela parede no fundo do armário até cair em um monte de roupas."


translate pt_br hideAndSeekEnd_a785ec8d:


    "{size=+30}*BAM!! BAM!! BAM!! BAM!! BAM!! BAM!! BAM!!*{/size}" with vpunch


translate pt_br hideAndSeekEnd_64e5c3aa:


    "{size=+35}{i}{b}*CRACK!! CRASH!!*{/b}{/i}{/size}" with hpunch


translate pt_br hideAndSeekEnd_510fa47c:


    "Você se encolhe bruscamente ao som da porta sendo arrancada das dobradiças... {w}seguido por um estrondo alto contra a parede do outro lado do quarto..."


translate pt_br hideAndSeekEnd_d11501ae:


    "Como se a porta tivesse sido {b}explodida{/b}..."


translate pt_br hideAndSeekEnd_8dabefc6:


    ".."


translate pt_br hideAndSeekEnd_a20cefa7:


    "..."


translate pt_br hideAndSeekEnd_0adc35ae:


    "O silêncio que se segue... é quase insuportável."


translate pt_br hideAndSeekEnd_40c73218:


    "Você... Você não consegue..."


translate pt_br hideAndSeekEnd_a822f67c:


    you "{size=-8}*soluço*{/size}" with vpunch


translate pt_br hideAndSeekEnd_48cca663:


    "Um único soluço escapa pelo seu nariz."


translate pt_br hideAndSeekEnd_a20cefa7_1:


    "..."


translate pt_br hideAndSeekEnd_a56b7772:


    "Você aperta os olhos, derrotado, consciente do quão alto soou na quietude do quarto."


translate pt_br hideAndSeekEnd_944d62b1:


    "De qualquer forma, não há muito sentido em tentar esconder isso agora, não é?"


translate pt_br hideAndSeekEnd_54d98921:


    "Instintivamente, você junta o resto da sua energia para ouvir os passos..."


translate pt_br hideAndSeekEnd_f054e4f2:


    "...mesmo enquanto se desliga emocionalmente."


translate pt_br hideAndSeekEnd_ba5567da:


    "Mas você não ouve nada."


translate pt_br hideAndSeekEnd_97d7e1ff:


    "...Nada."


translate pt_br hideAndSeekEnd_b1eedee3:


    "... {w}...Nada."


translate pt_br hideAndSeekEnd_f64ee9d8:


    "Então..."


translate pt_br hideAndSeekEnd_a20cefa7_2:


    "..."


translate pt_br hideAndSeekEnd_1ae26af9:


    "{size=-10}*Shhhheeee*{/size}"


translate pt_br hideAndSeekEnd_56ebb028:


    you "!!!"


translate pt_br hideAndSeekEnd_973413d4:


    "Algo..."


translate pt_br hideAndSeekEnd_cc2670ce:


    "...abre a porta do armário."


translate pt_br hideAndSeekEnd_d3ef84de:


    "Você se encolhe."


translate pt_br hideAndSeekEnd_37dac42d:


    "Joelhos levantados... {w}Costas curvadas para frente... {w}Cabeça baixa... {w}Boca coberta... {w}Olhos tão apertados que chegam a doer."


translate pt_br hideAndSeekEnd_169ad8da:


    "Você não quer olhar."


translate pt_br hideAndSeekEnd_9be26059:


    "Você não quer {i}{b}olhar{/b}{/i}."


translate pt_br hideAndSeekEnd_9288147d:


    "Mas é isso que ele está esperando."


translate pt_br hideAndSeekEnd_b4897419:


    "Não vai acabar com você sem esse último ato de crueldade."


translate pt_br hideAndSeekEnd_38e8ce5b:


    "De fazer você {b}olhar{/b} para ele, antes de tomar sua vida."


translate pt_br hideAndSeekEnd_f6781194:


    "Tão... {i}tão{/i} cruel."


translate pt_br hideAndSeekEnd_3964a50d:


    "Você só quer que isso acabe..."


translate pt_br hideAndSeekEnd_42b896f8:


    "Então..."


translate pt_br hideAndSeekEnd_8dabefc6_1:


    ".."


translate pt_br hideAndSeekEnd_a20cefa7_3:


    "..."


translate pt_br hideAndSeekEnd_07ae2bce:


    "...você abre os olhos."


translate pt_br hideAndSeekEnd_05f9ce7c:


    "Você vê... {w}{i}alguma coisa...{/i} {w}encarando você da escuridão além da porta do armário."


translate pt_br hideAndSeekEnd_532712c0:


    "Ele parece..."


translate pt_br hideAndSeekEnd_a20cefa7_4:


    "..."


translate pt_br hideAndSeekEnd_c5599256:


    "...decepcionado."


translate pt_br hideAndSeekEnd_e501a69b:


    "No momento antes de você dar seu último suspiro, quase considera se desculpar por ser uma presa tão indigna."


translate pt_br hideAndSeekEnd_fdce8679:


    "Pelo visto suas habilidades de esconder eram tão medíocres quanto as suas habilidades de caça."


translate pt_br hideAndSeekEnd_8dabefc6_2:


    ".."


translate pt_br hideAndSeekEnd_a20cefa7_5:


    "..."


translate pt_br hideAndSeekEnd_bebf47e2:


    "Final 13: Presa Decepcionante"


translate pt_br hidingGetOut_d6bdd900:


    "Você está no meio do caminho até a porta da frente, quando-{w=0.75}{nw}"


translate pt_br hidingGetOut_8ca8510a:


    you "!!!" with vpunch


translate pt_br hidingGetOut_dec8c6c7:


    "Você olha para a porta e vê vários trincos a mais do que {i}sabe{/i} que tem."


translate pt_br hidingGetOut_3df65a5c:


    "Você dá uma espiada no gato. Ele não está olhando para você, mas..."


translate pt_br hidingGetOut_5b6ca7ca:


    "...Você sente uma onda de decepção quase transbordar dele para você."


translate pt_br hidingGetOut_298892a1:


    "Parece quase..."


translate pt_br hidingGetOut_050be7e5:


    "...como um aviso."


translate pt_br hidingGetOut_dae0ec55:


    you "..."


translate pt_br hidingGetOut_b0ee1743:


    "Você se afasta da porta, e a sensação lentamente se dissipa, permitindo que você respire novamente."


translate pt_br hidingGetOut_d9de9905:


    "Não tem saída então."


translate pt_br hidingGetOut_c73db94c:


    "Você precisa se esconder."


translate pt_br hidingSitOnCouch_a20cefa7:


    "..."


translate pt_br hidingSitOnCouch_e26ed14e:


    "Tá de sacanagem?"


translate pt_br hidingSitOnCouch_85ef84c7:


    "Você tem a impressão de que o gato não vai gostar da sua falta de empenho, e de qualquer forma..."


translate pt_br hidingSitOnCouch_aa165348:


    "{size=-8}...nem {b}fudendo{/b} você vai chegar mais perto dele.{/size}"


translate pt_br hidingSitOnCouch_8d4b014b:


    "Pare de enrolar e encontre um lugar para se esconder."


translate pt_br cleanCat_1f0122ea:


    "Reparando bem..."


translate pt_br cleanCat_73bbf6e8:


    "...você percebe que o gato não está muito limpo."


translate pt_br cleanCat_2dad982f:


    "O que não é surpresa, já que, até você trazê-lo para casa, ele estava em uma caixa velha e suja..."


translate pt_br cleanCat_3e60fb93:


    "...em um beco cheio de lixo espalhado... {w}por sabe-se lá quanto tempo..."


translate pt_br cleanCat_b2b50516:


    "Você já ouviu dizer que gatos conseguem se limpar sozinhos..."


translate pt_br cleanCat_8a02a14f:


    "...mas talvez essa seja uma daquelas vezes em que um pouco de ajuda humana não faria mal?"


translate pt_br cleanCat_e97a3dc8:


    "Você vai até o banheiro e arruma tudo, tentando se lembrar de como dar banho em um gato."


translate pt_br cleanCat_e263c12b:


    "Você definitivamente não é nenhum especialista, mas acha que a melhor maneira de limpar um gato seria..."


translate pt_br cleanQuick_78d7a181:


    "Gatos não gostam de água, você pensa..."


translate pt_br cleanQuick_4e407771:


    "Então, o ideal seria um banho rápido, certo?"


translate pt_br cleanQuick_7f064cd9:


    "Você decide fazer tudo de uma vez, enchendo a banheira com água morna e espumante."


translate pt_br cleanQuick_c39a4c6e:


    "Um mergulho rápido aqui, uma esfregada ali, depois enxaguar e secar."


translate pt_br cleanQuick_9e8e5dea:


    "O gato nem vai entender o que aconteceu antes de tudo terminar."


translate pt_br cleanQuick_71d98443:


    "Você abre a porta e estala a língua, chamando o gato para entrar."


translate pt_br cleanQuick_85ffbc84:


    "Ele rapidamente corre para dentro, curioso com o novo ambiente acessível."


translate pt_br cleanQuick_03c62019:


    "Você fecha a porta para evitar que ele fuja e bagunce o apartamento..."


translate pt_br cleanQuick_9f0ef82a:


    "Respirando fundo, você arregaça as mangas."


translate pt_br cleanQuick_f62bf066:


    "Levanta o gato e o leva até a banheira."


translate pt_br cleanQuick_4b2a2198:


    "Seu plano começa a ser comprometido quando o gato começa a se debater nos seus braços."


translate pt_br cleanQuick_83e9b6c8:


    "Você provavelmente deveria tê-lo segurado de forma que ele não visse a água?"


translate pt_br cleanQuick_1422090a:


    you "Ai! Ai, ei!"


translate pt_br cleanQuick_26e1e230:


    "Ele arranha seus braços. {w}Você já esperava que ele não fosse gostar da água..."


translate pt_br cleanQuick_5f15c75c:


    "...mas não imaginava que ficaria {i}tão{/i} furioso."


translate pt_br cleanQuick_2b5c1bb2:


    "Ainda assim, por mais irritado que ele fique por um tempo... {w}você sabe que isso é para o bem dele."


translate pt_br cleanQuick_5bf8a6d7:


    "Você se assusta com um arranhão profundo no seu bíceps..."


translate pt_br cleanQuick_b7d98ebe:


    "...fazendo você largar o gato na banheira."


translate pt_br cleanQuick_0e4fefa1:


    cat "{size=+10}MIIAAAAAUUU!!!{/size}" with hpunch


translate pt_br cleanQuick_53f96c50:


    "{size=+20}{b}SPLASH!!{/b}{/size}" with vpunch


translate pt_br cleanQuick_4ab5e1b8:


    you "!! Merda! Gatinho?!"


translate pt_br cleanQuick_a20cefa7:


    "..."


translate pt_br cleanQuick_9755cc74:


    "O gato não emerge chiando e miando como você pensou que faria."


translate pt_br cleanQuick_56ebb028:


    you "!!!"


translate pt_br cleanQuick_d3c199bb:


    "Você corre até a banheira e enfia os braços na superfície espumosa, procurando pelo gato."


translate pt_br cleanQuick_28c52c35:


    "E se ele bateu a cabeça e desmaiou?! Ele pode se afogar!"


translate pt_br cleanQuick_8dabefc6:


    ".."


translate pt_br cleanQuick_a20cefa7_1:


    "..."


translate pt_br cleanQuick_da164869:


    "Mas você não encontra o gato."


translate pt_br cleanQuick_4cb92d86:


    "Em vez disso..."


translate pt_br cleanQuick_6d15e014:


    you "..?! Mas que..?"


translate pt_br cleanQuick_37bc76a0:


    "...você observa enquanto a água começa a escurecer."


translate pt_br cleanQuick_bbf488b7:


    "A princípio, você acha que é apenas sujeira do gato e sente que sua decisão foi justificada, mas..."


translate pt_br cleanQuick_1cd5e3cc:


    "...a água escurece cada vez mais..."


translate pt_br cleanQuick_0d858457:


    "...até parecer que você encheu a banheira com {i}tinta preta{/i}, em vez de água."


translate pt_br cleanQuick_b024b629:


    " Até as bolhas de sabão agora têm uma tonalidade obsidiana translúcida..."


translate pt_br cleanQuick_5d31ed33:


    you "Isso é..."


translate pt_br cleanQuick_0667ddd5:


    "Alguma coisa... não está certa."


translate pt_br cleanQuick_28ef0d48:


    "Mas assim que você pensa nisso-"


translate pt_br cleanQuick_c27265ab:


    "!!!" with vpunch


translate pt_br cleanQuick_8825e5a8:


    you "O-Opa!"


translate pt_br cleanQuick_8dabefc6_1:


    ".."


translate pt_br cleanQuick_a20cefa7_2:


    "..."


translate pt_br cleanQuick_f51b5d50:


    "Você acabou de..."


translate pt_br cleanQuick_2703b498:


    "Você acabou de sentir algo puxando você debaixo da água."


translate pt_br cleanQuick_04ac177f:


    "Você tenta se afastar... mas seu braço não se mexe."


translate pt_br cleanQuick_1e1011d4:


    "Seja lá o que for, te puxa em direção à água."


translate pt_br cleanQuick_ea4d65f2:


    "Você tenta usar a mão livre para soltar a tampa do ralo..."


translate pt_br cleanQuick_49f8d758:


    "...mas, ao mergulhar o outro braço na água sem pensar..."


translate pt_br cleanQuick_af07684a:


    "...ele {i}também{/i} é agarrado."


translate pt_br cleanQuick_7bc9d3d3:


    "Com as duas mãos imobilizadas, você não consegue encontrar um jeito de se soltar."


translate pt_br cleanQuick_9b4985ab:


    you "S-SOCOR-"


translate pt_br cleanQuick_959e6733:


    "{size=+30}{b}{i}SPLASH!!{/i}{/b}{/size}" with vpunch


translate pt_br cleanQuick_8dabefc6_2:


    ".."


translate pt_br cleanQuick_a20cefa7_3:


    "..."


translate pt_br cleanQuick_9920ee06:


    "Você é arrastado para as águas turvas da banheira."


translate pt_br cleanQuick_d4cb78f0:


    "Você é puxado para baixo..."


translate pt_br cleanQuick_803774b5:


    "E para baixo..."


translate pt_br cleanQuick_292fd1e4:


    "E ainda mais para baixo..."


translate pt_br cleanQuick_effa8a23:


    "Muito mais do que deveria ser possível para a sua banheira..."


translate pt_br cleanQuick_0f5de544:


    "Você..."


translate pt_br cleanQuick_89ffaa13:


    "Você não consegue respirar."


translate pt_br cleanQuick_6ff0ecd8:


    "Você pensa que também não consegue ver, mas..."


translate pt_br cleanQuick_c4107513:


    "...à medida que suspira pela última vez..."


translate pt_br cleanQuick_19e72cc3:


    "...você acha que vê o que está te puxando para baixo."


translate pt_br cleanQuick_3be28426:


    "Algo repousando bem, bem lá no fundo..."


translate pt_br cleanQuick_117208a3:


    "Algo esperando..."


translate pt_br cleanQuick_a20cefa7_4:


    "..."


translate pt_br cleanQuick_3c2769fc:


    "...por {i}você.{/i}"


translate pt_br cleanQuick_a20cefa7_5:


    "..."


translate pt_br cleanQuick_e75202ef:


    "Final 14: Anti-Banho"


translate pt_br cleanCareful_76034b76:


    "Você acha que ser cuidadoso é a melhor opção."


translate pt_br cleanCareful_753310b5:


    "Gatos nem sempre gostam de água, então você duvida que ele vá gostar de uma quantidade exagerada."


translate pt_br cleanCareful_1e17f067:


    "Assim, você pega o gato e o coloca gentilmente na pia, antes de abrir a torneira."


translate pt_br cleanCareful_ec1974d4:


    cat "Miau!" with hpunch


translate pt_br cleanCareful_0e8202cd:


    "O gato fica assustado, mas no fim das contas..."


translate pt_br cleanCareful_0a111937:


    "...não tenta fugir!"


translate pt_br cleanCareful_52edc0ce:


    "Que bom."


translate pt_br cleanCareful_8897c5e8:


    "Você ensaboa as mãos e cuidadosamente alterna entre esfregar e massagear o gato."


translate pt_br cleanCareful_f506c017:


    "Depois de alguns minutos, você enxágua o gato por completo e o envolve em um cobertor, secando-o."


translate pt_br cleanCareful_0d9cd6eb:


    "Então você pega uma escova e cuidadosamente penteia o pelo do gato."


translate pt_br cleanCareful_57f9ada2:


    cat "Purr... Purr... Purr..."


translate pt_br cleanCareful_1d903d7d:


    "O gato parece estar no paraíso enquanto você o escova."


translate pt_br cleanCareful_079980a1:


    "Alguns pelos ficam grudados em você, mas você não... se importa..."


translate pt_br cleanCareful_40d9ca73:


    "..?"


translate pt_br cleanCareful_c3f6a165:


    "Na verdade..."


translate pt_br cleanCareful_c94a020a:


    "...grudou {i}muito{/i} pelo em você."


translate pt_br cleanCareful_65471dfb:


    "Você tenta tirar usando a escova, mas não quer sair."


translate pt_br cleanCareful_5b936bac:


    "Parece que você também vai precisar de um banho..."


translate pt_br cleanCareful_085f82bc:


    cat "Miau..."


translate pt_br cleanCareful_dae0ec55:


    you "..."


translate pt_br cleanCareful_da765a9f:


    "Você tenta ignorar os pelos e terminar rápido com o gato, mas cada vez mais continuam grudando em você."


translate pt_br cleanCareful_ffccba96:


    "Suas mãos, seus braços.."


translate pt_br cleanCareful_711ff096:


    "Antes que perceba, está cobertos de pelos que não saem."


translate pt_br cleanCareful_52386fff:


    "Está tão denso que você tenta simplesmente puxar, mas-"


translate pt_br cleanCareful_c4b43d4e:


    you "Ai! O quê...?"


translate pt_br cleanCareful_22aea2b6:


    "Uma dor aguda atravessa o ponto onde você puxou."


translate pt_br cleanCareful_8ca8510a:


    you "!!!" with vpunch


translate pt_br cleanCareful_197758f7:


    "Olhando mais de perto... {w}você vê que os pelos estão..."


translate pt_br cleanCareful_68e96464:


    "...{i}crescendo{/i}..."


translate pt_br cleanCareful_a20cefa7:


    "..."


translate pt_br cleanCareful_80ea14b2:


    "{size=-5}{b}...crescendo {i}de{/i} você.{/b}{/size}"


translate pt_br cleanCareful_01e37002:


    you "Ah... Ah..!"


translate pt_br cleanCareful_1ce5a910:


    "Você consegue {b}sentir{/b} agora."


translate pt_br cleanCareful_b86f7ef8:


    "Pelo {i}crescendo{/i} de suas costas, seu pescoço..."


translate pt_br cleanCareful_12fc6531:


    "seu rosto..."


translate pt_br cleanCareful_f9ae2b18:


    "seus olhos..."


translate pt_br cleanCareful_3489b447:


    "sua língua..."


translate pt_br cleanCareful_eeaf3b6e:


    "Está crescendo até mesmo dentro da sua {i}garganta-{/i}"


translate pt_br cleanCareful_06b758f9:


    you "*Gasp!* *Cof!* *Cof!*" with vpunch


translate pt_br cleanCareful_8dabefc6:


    ".."


translate pt_br cleanCareful_a20cefa7_1:


    "..."


translate pt_br cleanCareful_1d671d77:


    "Enquanto você cai no cão e começa a sufocar com os pelos que engrossam em seu esôfago..."


translate pt_br cleanCareful_dae75121:


    "...o gato se inclina e começa a lamber o pelo que cresce em sua testa..."


translate pt_br cleanCareful_cb7d4fad:


    "...limpando seus pelos tão cuidadosamente quanto você fez por ele mais cedo."


translate pt_br cleanCareful_b53c4107:


    cat "Purr... Purrr..."


translate pt_br cleanCareful_96b21532:


    "Você pensa que seria até adorável... {w}se não estivesse ficando sem ar."


translate pt_br cleanCareful_ba1d39d4:


    "Ainda assim."


translate pt_br cleanCareful_ebb0a00f:


    "É reconfortante, pelo menos... {w}ser cuidado e mimado de alguma forma."


translate pt_br cleanCareful_c9790759:


    "Mesmo que seja só por mais um breve momento."


translate pt_br cleanCareful_4d45e938:


    "A cuidadosa limpeza do gato é a última coisa que você sente..."


translate pt_br cleanCareful_a20cefa7_2:


    "..."


translate pt_br cleanCareful_2ed36266:


    "...antes de não conseguir mais respirar."


translate pt_br cleanCareful_a20cefa7_3:


    "..."


translate pt_br cleanCareful_dc678fac:


    "Final 15: Amigões Vaidosos"

translate pt_br strings:


    old "Do something alone."
    new "Fazer algo sozinho."


    old "Do something with cat."
    new "Fazer algo com o gato."


    old "Clean apartment"
    new "Limpar o apartamento"


    old "Watch a movie"
    new "Assistir um filme"


    old "Take a nap"
    new "Tirar uma soneca"


    old "On second thought..."
    new "Pensando bem..."


    old "Pet cat"
    new "Acariciar o gato"


    old "Feed cat"
    new "Alimentar o gato"


    old "Play with cat"
    new "Brincar com o gato"


    old "Clean cat"
    new "Limpar o gato"


    old "Keep cleaning"
    new "Continuar limpando"


    old "Catch cat in the act"
    new "Pegar o gato no flagra"


    old "Sit on the floor."
    new "Sentar no chão."


    old "Reclaim your throne."
    new "Reivindicar seu trono."


    old "You saw something."
    new "Você viu algo."


    old "You {i}definitely{/i} saw something"
    new "Você {i}definitivamente{/i} viu algo"


    old "Move the cat."
    new "Tirar o gato."


    old "Sleep next to cat"
    new "Dormir ao lado do gato"


    old "Do something else"
    new "Ir fazer outra coisa"


    old "Move the cat?"
    new "Tirar o gato?"


    old "Keep trying. This is {i}your{/i} bed."
    new "Continuar tentando. Essa cama é {i}sua{/i}."


    old "Again. You WILL sleep in your own bed."
    new "De novo. Você VAI dormir na sua cama."


    old "I don't know. It sounds mad..."
    new "Não sei não. Ele parece bravo..."


    old "{size=-5}Move the cat?{/size}"
    new "{size=-5}Tirar o gato?{/size}"


    old "Move. The. Cat."
    new "Tirar. O. Gato."


    old "Seriously last chance. You {i}really{/i} want to do this?"
    new "Sério, última chance. Você quer fazer isso {i}mesmo{/i}?"


    old "Keep petting"
    new "Continuar acariciando"


    old "Let's do something else..."
    new "Vamos fazer outra coisa..."


    old "Keep petting..."
    new "Continuar acariciando..."


    old "That's enough. Let's do something else."
    new "Já chega. Vamos fazer outra coisa."


    old "...{i}Keep{/i} petting."
    new "...{i}Continuar{/i} acariciando."


    old "{b}Seriously...{/b} Let's do something else."
    new "{b}Sério...{/b} Vamos fazer outra coisa."


    old "Tuna"
    new "Atum"


    old "Meatloaf"
    new "Bolo de carne"


    old "Mystery food"
    new "Comida misteriosa"


    old "Actually, let's eat later."
    new "Na verdade, vamos comer mais tarde."


    old "Let's play with the cat!"
    new "Vamos brincar com o gato!"


    old "Look for some yarn?"
    new "Procurar um pouco de lã?"


    old "I think my laser pointer still works..."
    new "Acho que meu laser ainda funciona..."


    old "Hide and seek: A classic!"
    new "Esconde-esconde: Um clássico!"


    old "Living Room"
    new "Sala"


    old "Kitchen"
    new "Cozinha"


    old "Hallway"
    new "Corredor"


    old "Hide behind the armchair."
    new "Esconder atrás da poltrona."


    old "Hide behind kitchen counter."
    new "Esconder atrás do balcão da cozinha."


    old "Hide in the hall."
    new "Esconder no corredor."


    old "Hide in the hallway closet."
    new "Esconder no armário do corredor."


    old "Hide in the bathroom."
    new "Esconder no banheiro."


    old "Hide in your bedroom..."
    new "Esconder no seu quarto..."


    old "Get out of the apartment."
    new "Sair do apartamento."


    old "Sit on the couch."
    new "Sentar no sofá."


    old "Hide in the closet."
    new "Esconder no armário."


    old "Risk another hiding spot."
    new "Arriscar outro esconderijo."


    old "Quickly"
    new "Rápido"


    old "Carefully"
    new "Com cuidado"

    old "Yes"
    new "Sim"

    old "No"
    new "Não"

    old "Don't look behind you..."
    new "Não olha para trás..."

    old "{alpha=0.2}How disappointing...{/alpha}"
    new "{alpha=0.2}Que decepcionante...{/alpha}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
