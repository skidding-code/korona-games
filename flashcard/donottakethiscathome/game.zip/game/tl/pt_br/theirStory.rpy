


translate pt_br theirLove1_9ea2f78c:


    " "


translate pt_br theirLove1_9ea2f78c_1:


    " "


translate pt_br theirLove1_9ea2f78c_2:


    " "


translate pt_br theirLove1_9ea2f78c_3:


    " "


translate pt_br theirLove1_9ea2f78c_4:


    " "


translate pt_br theirLove1_9ea2f78c_5:


    " "


translate pt_br theirLove1_9ea2f78c_6:


    " "


translate pt_br theirLove1_9ea2f78c_7:


    " "


translate pt_br theirLove1_9ea2f78c_8:


    " "


translate pt_br theirLove1_9ea2f78c_9:


    " "


translate pt_br theirLove1_9ea2f78c_10:


    " "


translate pt_br theirLove1_9ea2f78c_11:


    " "


translate pt_br theirLove1_9ea2f78c_12:


    " "


translate pt_br theirLove1_9ea2f78c_13:


    " "


translate pt_br theirLove1_9ea2f78c_14:


    " "


translate pt_br theirLove1_9ea2f78c_15:


    " "


translate pt_br theirLove1_9ea2f78c_16:


    " "


translate pt_br theirLove1_9ea2f78c_17:


    " "


translate pt_br theirLove1_9ea2f78c_18:


    " "


translate pt_br theirLove1_9ea2f78c_19:


    " "


translate pt_br theirLove2_9ea2f78c:


    " "


translate pt_br theirLove2_9ea2f78c_1:


    " "


translate pt_br theirLove2_9ea2f78c_2:


    " "


translate pt_br theirLove2_9ea2f78c_3:


    " "


translate pt_br theirLove2_9ea2f78c_4:


    " "


translate pt_br theirLove2_9ea2f78c_5:


    " "


translate pt_br theirLove2_9ea2f78c_6:


    " "


translate pt_br theirLove2_9ea2f78c_7:


    " "


translate pt_br theirLove2_9ea2f78c_8:


    " "


translate pt_br theirLove2_9ea2f78c_9:


    " "


translate pt_br theirLove2_9ea2f78c_10:


    " "


translate pt_br theirLove2_9ea2f78c_11:


    " "


translate pt_br theirLove2_9ea2f78c_12:


    " "


translate pt_br theirLove2_9ea2f78c_13:


    " "


translate pt_br theirLove2_9ea2f78c_14:


    " "


translate pt_br theirLove2_9ea2f78c_15:


    " "


translate pt_br theirLove2_9ea2f78c_16:


    " "


translate pt_br theirLove2_9ea2f78c_17:


    " "


translate pt_br theirLove2_9ea2f78c_18:


    " "


translate pt_br theirLove2_9ea2f78c_19:


    " "


translate pt_br theirLove2_9ea2f78c_20:


    " "


translate pt_br theirLove2_9ea2f78c_21:


    " "


translate pt_br theirLove2_9ea2f78c_22:


    " "


translate pt_br theirLove3_9ea2f78c:


    " "


translate pt_br theirLove3_9ea2f78c_1:


    " "


translate pt_br theirLove3_9ea2f78c_2:


    " "


translate pt_br theirLove3_9ea2f78c_3:


    " "


translate pt_br theirLove3_9ea2f78c_4:


    " "


translate pt_br theirLove3_9ea2f78c_5:


    " "


translate pt_br theirLove3_9ea2f78c_6:


    " "


translate pt_br theirLove3_9ea2f78c_7:


    " "


translate pt_br theirLove3_9ea2f78c_8:


    " "


translate pt_br theirLove3_9ea2f78c_9:


    " "


translate pt_br theirLove3_9ea2f78c_10:


    " "


translate pt_br theirLove3_9ea2f78c_11:


    " "


translate pt_br theirLove3_9ea2f78c_12:


    " "


translate pt_br theirLove3_9ea2f78c_13:


    " "


translate pt_br theirLove3_9ea2f78c_14:


    " "


translate pt_br theirLove3_9ea2f78c_15:


    " "


translate pt_br theirLove3_9ea2f78c_16:


    " "


translate pt_br theirLove3_9ea2f78c_17:


    " "


translate pt_br theirLove3_9ea2f78c_18:


    " "


translate pt_br theirLove3_9ea2f78c_19:


    " "

translate pt_br strings:
    old "I'm sorry..."
    new "Sinto muito..."

    old "I'm so sorry..."
    new "Sinto muito mesmo..."

    old "I was just so tired...\n\nOf everything..."
    new "Eu tava tão cansado...\n\nDe tudo..."

    old "Not you... Never you..."
    new "Não de você... Nunca de você..."

    old "But I couldn't be the person you deserve...\n\nCouldn't ever hope to be."
    new "Mas eu não pude ser a pessoa que você merece…\n\nNunca poderia ser."

    old "You were so amazing...\n\nSmart and talented and independent...\n\n\nYou shined..."
    new "Você era tão incrível...\n\nInteligente e talentoso e independente...\n\n\nVocê brilhava..."

    old "But in comparison, I..."
    new "Mas em comparação, eu..."




    old "Dammit..."
    new "Droga..."

    old "So stupid..."
    new "Tão idiota..."

    old "So worthless..."
    new "Tão inútil..."




    old "But when {color=#FF0000}IT{/color} approached me..."
    new "Mas quando {color=#FF0000}ISSO{/color} se aproximou de mim..."

    old "...{color=#FF0000}IT{/color} didn't tell me that {color=#FF0000}IT{/color} wanted me..."
    new "...{color=#FF0000}ISSO{/color} não me contou que {color=#FF0000}ISSO{/color} me queria..."

    old "...{color=#FF0000}IT{/color} {i}{b}needed{/b}{/i} me."
    new "...{color=#FF0000}ISSO{/color} {i}{b}precisava{/b}{/i} de mim."

    old "Maybe that's what I wanted all along."
    new "Acho que era isso que eu sempre quis."

    old "{i}Wanting{/i} could be so fleeting...\n\nBut to be {i}needed?{/i}"
    new "{i}Querer{/i} pode ser tão efêmero...\n\nMas ser {i}necessário?{/i}"

    old "There was nothing I wouldn't give\n\nto have someone tell me that I mattered to them..."
    new "Não havia nada que eu não daria\n\npara ter alguém que me dissesse que eu era importante..."

    old "That {i}they{/i} needed {i}me.{/i}"
    new "{i}Alguém{/i} que precisasse {i}de mim.{/i}"

    old "In the days leading up to my meeting with {color=#FF0000}IT{/color},\n\nI'd been obsessed with a memory..."
    new "Nos dias que antecederam meu encontro com {color=#FF0000}ISSO{/color},\n\neu estive obcecado por uma memória..."

    old "Someone precious to {i}me{/i}...\n\nhad found someone precious to {i}them{/i}."
    new "Alguém precioso para {i}mim{/i}...\n\ntinha encontrado alguém precioso para {i}si{/i}."

    old "My best friend..."
    new "Meu melhor amigo..."

    old "My {i}only{/i} friend..."
    new "Meu {i}único{/i} amigo..."

    old "I was happy for them, {i}{b}truly{/b}{/i}..."
    new "Eu fiquei feliz por eles, {i}{b}de verdade{/b}{/i}..."

    old "...but then I'd been happy for the others too."
    new "...mas eu também já fiquei feliz por outros antes."

    old "They promised it wouldn't happen to me again..."
    new "Eles prometeram que isso não aconteceria comigo de novo..."

    old "That they knew how it felt to be told by someone you cared for...\n\nthat they'd outgrown you and your friendship..."
    new "Que eles entendiam como era ouvir de algúem que você se importa...\n\nque superou você e sua amizade..."

    old "That they'd never, ever do such a thing to me..."
    new "Que eles nunca fariam uma coisa dessas comigo...s"




    old "There's not a moment that passes now\n\nthat I wish I'd risked the pain of their rejection..."
    new "Agora não passa um segundo\n\nsem que eu deseje ter arriscado a dor da rejeição deles..."

    old "and just...\n\n{b}believed{/b} them..."
    new "e ter só...\n\n{b}acreditado{/b} neles..."

    old "...But I didn't."
    new "...Mas eu não acreditei."

    old "I pulled away before they could,\n\ntrying to protect my fragile heart..."
    new "Eu me afastei antes que eles pudessem,\n\ntentando proteger meu coração frágil..."

    old "But it only hurt all the more."
    new "Mas isso só doeu mais."

    old "Selfish as it was...\n\nI'd wanted them to fight harder to keep me around."
    new "Por mais egoísta que seja...\n\nEu queria que eles se esforçassem mais pra me manter por perto."

    old "When {color=#FF0000}IT{/color} appeared before me,\n\n{color=#FF0000}IT{/color} promised to be just {i}that{/i}..."
    new "Quando {color=#FF0000}ISSO{/color} apareceu diante de mim,\n\n{color=#FF0000}ISSO{/color} prometeu ser {i}justamente{/i}..."

    old "A friend that would never, {i}ever{/i} let me go..."
    new "Um amigo que nunca, {i}nunca{/i} me deixaria ir..."

    old "A friend that would never, {i}ever{/i} leave me..."
    new "Um amigo que nunca, {i}nunca{/i} me abandonaria..."




    old "And all I had to do..."
    new "E tudo que eu precisava fazer..."

    old "...was promise the same thing in return."
    new "...era prometer a mesma coisa."

    old "I never believed in unconditional love..."
    new "Eu nunca acreditei em amor incondicional..."

    old "...not even as young as I was on the day that changed my life forever."
    new "...nem mesmo quando era jovem, no dia que mudou minha vida para sempre."

    old "Still...\n\nI always assumed that {b}{i}they{/i}{/b} would come the closest\n\nto granting it to me."
    new "Ainda assim...\n\nEu sempre imaginei que {b}{i}eles{/i}{/b} seriam os mais próximos\n\nde o conceder para mim."

    old "It's what they always say, right?"
    new "É o que sempre dizem, né?"

    old "That a parent's love is unconditional..."
    new "Que o amor dos pais é incondicional..."

    old "The wounds they'd inflicted on my skin and in my heart...\n\nhad long since scarred over the day they dealt the final blow..."
    new "As feridas que eles causaram na minha pele e no coração...\n\njá haviam cicatrizado há tempos no dia em que deram o golpe final..."

    old "And all it took were two little words..."
    new "E tudo que bastou foram duas palavrinhas..."




    old "{alpha=0.2}\"Get out.\"{/alpha}"
    new "{alpha=0.2}\"Vá embora.\"{/alpha}"

    old "The day they finally turned their backs on me...\n\n{b}abandoned{/b} me..."
    new "O dia em que finalmente viraram as costas para mim...\n\nme {b}abandonaram{/b}..."




    old "That was the day {color=#FF0000}IT{/color} found me."
    new "Foi o dia em que {color=#FF0000}ISSO{/color} me encontrou."

    old "{color=#FF0000}IT{/color} offered me an unfathomable kind of love."
    new "{color=#FF0000}ISSO{/color} me ofereceu um tipo de amor incompreensível."

    old "A love that could be limitless...\n\nEndless...\n\nPowerful...\n\nAll-consuming..."
    new "Um amor que poderia ser ilimitado...\n\nEterno...\n\nPoderoso...\n\nDevastador..."

    old "A love unmatched..."
    new "Um amor incomparável..."

    old "A love unlike anything\n\nthat could exist in this world..."
    new "Um amor diferente de tudo\n\nque poderia existir neste mundo..."

    old "But there was one thing that the love {color=#FF0000}IT{/color} offered could {b}{i}never{/i}{/b} be..."
    new "Mas havia uma coisa que o amor que {color=#FF0000}ISSO{/color} ofereceu {b}{i}nunca{/i}{/b} poderia ser..."




    old "...Unconditional."
    new "...Incondicional."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
