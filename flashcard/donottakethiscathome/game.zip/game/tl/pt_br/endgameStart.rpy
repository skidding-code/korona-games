


translate pt_br endCat_6022b618:


    "Sério? Tem certeza?"


translate pt_br endCat_a20cefa7:


    "..."


translate pt_br endCat1_a20cefa7:


    "..."


translate pt_br endCat1_ee69ed58:


    "Uma vez que fizer isso..."


translate pt_br endCat1_5376e166:


    "...você NÃO PODERÁ voltar atrás."


translate pt_br endCat1_8dabefc6:


    ".."


translate pt_br endCat1_a20cefa7_1:


    "..."


translate pt_br endCat2_a20cefa7:


    "..."


translate pt_br endCat2_18858365:


    "Última chance."


translate pt_br endCat2_f66a6910:


    "Você tem certeza {b}absoluta{/b} disso?"


translate pt_br endCat2_a20cefa7_1:


    "..."


translate pt_br endCat2_0a4bf479:


    "...Nós iremos."


translate pt_br endCat2_d56150af:


    "Para sempre e sempre..."


translate pt_br endCatFinal_a20cefa7:


    "..."


translate pt_br endCatFinal_dae0ec55:


    you "..."


translate pt_br endCatFinal_7f0ac95c:


    cat "..."


translate pt_br endCatFinal_8dabefc6:


    ".."


translate pt_br endCatFinal_a20cefa7_1:


    "..."


translate pt_br endCatFinal_0b3e6813:


    "Você mata o gato."


translate pt_br endCatFinal_99b6c530:


    "O seu corpo jaz inérte e sem vida em sua caixa de papelão agora manchada de sangue."


translate pt_br endCatFinal_8dabefc6_1:


    ".."


translate pt_br endCatFinal_a20cefa7_2:


    "..."


translate pt_br endCatMenu_20873599:


    "O que você gostaria de fazer?"


translate pt_br endPockets_5308f154:


    "Não tem porque."


translate pt_br endPockets_edd17d2d:


    "O gato está morto."


translate pt_br endPockets_bcb34bfb:


    "Você enfia a mão nos bolsos mesmo assim..."


translate pt_br endPockets_a89eb7de:


    "Bolso esquerdo..."


translate pt_br endPockets_600502e3:


    "...Linha. {w}Inútil."


translate pt_br endPockets_197df679:


    "Bolso direito..."


translate pt_br endPockets_a20cefa7:


    "..."


translate pt_br endPockets_2bcc0dba:


    "{color=#FF0000}{b}...Chocolate.{/b}{/color}"


translate pt_br endPockets_8eb9bd2b:


    "Você come o chocolate."


translate pt_br endPockets_559496a2:


    "Você está com seu celular."


translate pt_br endPockets_1a0c66b1:


    "Tirar uma foto?"


translate pt_br endPockets_a20cefa7_1:


    "..."


translate pt_br endPockets_c8d556cd:


    "Não tem motivo."


translate pt_br endPockets_edd17d2d_1:


    "O gato está morto."


translate pt_br endLook_2e60e8b3:


    "O que você está procurando?"


translate pt_br endLook_edd17d2d:


    "O gato está morto."


translate pt_br endLook_30561a58:


    "Você olha mesmo assim..."


translate pt_br endLook_2af5fa5c:


    "Você olha para a esquerda e para a direita..."


translate pt_br endLook_e8093ee2:


    "...Nada além de lixo."


translate pt_br endLook_c96ce435:


    "Você olha para cima..."


translate pt_br endLook_52bbc94a:


    "...O sol mal alcança aqui dentro."


translate pt_br endLook_29e137bf:


    "Mas você pode notar que hoje é um belo dia."


translate pt_br endLook_35f3a46a:


    "Você olha para trás..."


translate pt_br endLook_8dabefc6:


    ".."


translate pt_br endLook_a20cefa7:


    "..."


translate pt_br endLook_1dc79289:


    "{size=-10}{b}ninguém viu.{/b}{/size}"


translate pt_br endLook_a4cef966:


    "Você olha bem embaixo de você..."


translate pt_br endLook_8dabefc6_1:


    ".."


translate pt_br endLook_a20cefa7_1:


    "..."


translate pt_br endLook_49dade07:


    "Ah é..."


translate pt_br endLook_edd17d2d_1:


    "O gato está morto."


translate pt_br endLeave_b5a44804:


    "Você acabou por aqui."


translate pt_br endLeave_a40ffd19:


    "Você se vira para sair do beco..."


translate pt_br endLeave_8dabefc6:


    ".."


translate pt_br endLeave_a20cefa7:


    "..."


translate pt_br endLeave_40d9ca73:


    "..?"


translate pt_br endLeave_ec199ff2:


    "Pelo menos... {w}Você {i}tenta{/i}..."


translate pt_br endLeave_74fbacaf:


    "Enquanto está parado na entrada do beco..."


translate pt_br endLeave_d9a60d33:


    "...você vê que não existe nada além dele."


translate pt_br endLeave_16e07799:


    "Só um completo vazio."


translate pt_br endLeave_8ca8510a:


    you "!!!" with vpunch


translate pt_br endLeave_252552a2:


    "Você dá meia volta..."


translate pt_br endLeave_88047473:


    "...e vê que o fundo do beco está envolto em escuridão."


translate pt_br endLeave_d8c18e4f:


    "Você não consegue ver nada."


translate pt_br endLeave2_cfb03abe:


    "{size=-5}Mas não há nada por lá.{/size}"


translate pt_br endLeave3_ca0588d8:


    "Sem opções, você avança em direção à escuridão..."


translate pt_br endLeave3_624b526a:


    "Cada vez..."


translate pt_br endLeave3_a20cefa7:


    "..."


translate pt_br endLeave3_57fba23d:


    "Mais perto..."


translate pt_br endLeave3_6faf07b3:


    "E mais per-{w=0.3}{nw}"


translate pt_br endLeave3_50da432c:


    "{size=+10}{b}SLASH!!{/b}{/size}" with hpunch


translate pt_br endLeave3_632d1a35:


    you "!!!" with hpunch


translate pt_br endLeave3_8dabefc6:


    ".."


translate pt_br endLeave3_a20cefa7_1:


    "..."


translate pt_br endLeave3_23a3bbe5:


    "Você tá..."


translate pt_br endLeave3_13ee741d:


    "Você tá sangr-{w=0.2}{nw}"


translate pt_br endLeave3_ea937b79:


    "{size=+15}{b}{i}SLASH!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch


translate pt_br endLeave3_9a0232ef:


    "{size=+20}{b}{i}SLASH!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch


translate pt_br endLeave3_e1d010df:


    "{size=+25}{b}{i}SLASH!! SLASH!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch


translate pt_br endLeave3_c6e79053:


    "{size=+30}{b}{i}{color=#FF0000}SLASH!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with vpunch


translate pt_br endLeave3_cc9a5909:


    "!!!"


translate pt_br endLeave3_a20cefa7_2:


    "..."


translate pt_br endLeave3_8dabefc6_1:


    ".."


translate pt_br endLeave3_a20cefa7_3:


    "..."


translate pt_br endLeave3_c6478448:


    "Você cai de joelhos..."


translate pt_br endLeave3_c760ebc8:


    "A parte da frente do seu corpo está dilacerada, vazando sangue, tripas e órgãos pelo seu tronco e sobre seu colo."


translate pt_br endLeave3_27a9cba3:


    who "você... {w}nao... {w}sabe..."


translate pt_br endLeave3_cfc77429:


    who "{size=-10}...que gatos têm {b}{color=#FF0000}N O V E{/color}{/b} vidas~?{/size}"


translate pt_br endLeave3_a79a5fec:


    you "Esper-{w=0.3}{nw}"


translate pt_br endLeave3_b363dab3:


    "{size=+30}{b}{i}{color=#FF0000}SLASH!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch


translate pt_br endLeave3_a40c3115:


    "{size=+35}{b}{i}{color=#FF0000}SLASH!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch


translate pt_br endLeave3_13c80e81:


    "{size=+40}{b}{i}{color=#FF0000}S L A S H ! !{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch


translate pt_br endLeave3_8dabefc6_2:


    ".."


translate pt_br endLeave3_a20cefa7_4:


    "..."


translate pt_br endLeave3_66ecbb19:


    "Final 36: Só mais oito"


translate pt_br endLeave3_a20cefa7_5:


    "..."

translate pt_br strings:


    old "Maybe not..."
    new "Talvez não..."

    old "Yes."
    new "Sim."


    old "I've changed my mind, let's go back!"
    new "Mudei de ideia, vamos voltar!"


    old "...Do it."
    new "...Vá em frente."


    old "This is the point of NO return. Are you sure there's nothing else you wish to do?"
    new "Esse é um ponto SEM volta. Tem certeza de que não há mais nada que queira fazer?"


    old "Take me back, I want us to play forever."
    new "Me leve de volta, quero que a gente brinque para sempre."

    old "...and ever."
    new "...e sempre."


    old "{b}{color=#FF0000}k i l l... t h e... c a t...{/color}{/b}"
    new "{b}{color=#FF0000}m a t a r... o... g a t o...{/color}{/b}"


    old "...Check pockets."
    new "...Checar os bolsos."


    old "...Look around the area."
    new "...Olhar em volta da área."


    old "leave."
    new "ir embora."


    old "Leave the alley."
    new "Sair do beco."


    old "Approach the darkness"
    new "Se aproximar da escuridão."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
