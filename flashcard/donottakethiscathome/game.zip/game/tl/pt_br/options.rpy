## == Web Port Build (auto-patched) ==
## Run: renpy.sh launcher web_build <this_folder>



translate pt_br strings:


    old "Do NOT Take This Cat Home"
    new "NÃO Leve Esse Gato Para Casa"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
