


translate ita afterLanguage_9ea2f78c:


    " "


translate ita afterLanguage_9ea2f78c_1:


    " "


translate ita mainGame_a20cefa7:


    "..."


translate ita mainGame_fb0939d1:


    "Ti stai divertendo, non è vero?"


translate ita mainGame_5a1fba27:


    "Sì... Anche {w}{i}io{/i}~"


translate ita mainGame_a20cefa7_1:


    "..."


translate ita mainGame_b3e12ea5:


    "Eppure..."


translate ita mainGame_8f9c4d0d:


    "Tutte le cose belle finiscono prima o poi..."


translate ita mainGame_d6f62ed1:


    "... e penso che tu lo {b}sappia già.{/b}"


translate ita mainGameStart_8dabefc6:


    ".."


translate ita mainGameStart_a20cefa7:


    "..."


translate ita mainGameStart_2f052c40:


    "Stai camminando..."


translate ita mainGameStart_da373e99:


    "Certo. Ovviamente."


translate ita mainGameStart_45f04c4f:


    "Era da un po' di tempo che non ti sentivi così bene da voler uscire..."


translate ita mainGameStart_a20cefa7_1:


    "..."


translate ita mainGameStart_7039fb77:


    "E tu..."


translate ita mainGameStart_4c74d5a4:


    "... sei felice di averlo fatto."


translate ita mainGameStart_78cf1fa7:


    "bel tempo oggi"


translate ita mainGameStart_5ec9f3bf:


    "cosa molto buona"


translate ita mainGameStart_f21d0208:


    "magari oggi anche fortuna"


translate ita mainGameStart_57725082:


    "sì, fortuna"


translate ita mainGameStart_df511821:


    "{w=0.6}fortuna {w=0.6}fortuna {w=0.6}fortuna {w=0.6}fortuna {w=0.6}{nw}"


translate ita mainGameStart_a3f9f101:


    "fortuna fortuna fortuna {w=0.6}fortuna {w=0.6}fortuna {w=0.6}fortuna {w=0.6}fortuna {w=0.6}{nw}"


translate ita mainGameStart_db26c555:


    "fortuna fortuna fortuna fortuna fortuna fortuna {w=0.3}fortuna {w=0.3}fortuna {w=0.3}fortuna {w=0.3}fortuna {w=0.6}{nw}"


translate ita mainGameStart_9ea2f78c:


    " "


translate ita mainGameStart_8ca8510a:


    you "!!!" with vpunch


translate ita mainGameStart_dae0ec55:


    you "..."


translate ita mainGameStart_c7b678f0:


    "Il tempo è assolutamente {i}perfetto{/i} oggi."


translate ita mainGameStart_dadb738e:


    "È un buon segno, giusto?"


translate ita mainGameStart_a0ad31e8:


    "Forse la fortuna sta iniziando a girare dalla tua parte."


translate ita mainGameStart_c7b678f0_1:


    "Il tempo è assolutamente {i}perfetto{/i} oggi."


translate ita mainGameStart_dadb738e_1:


    "È un buon segno, giusto?"


translate ita mainGameStart_a0ad31e8_1:


    "Forse la fortuna sta iniziando a girare dalla tua parte."


translate ita mainGameStart_c8a18d3b:


    "Ti concedi di provare entusiasmo per i posti dove potresti andare, per le attività che potresti fare..."


translate ita mainGameStart_3967ef01:


    "... e per {i}chi{/i} potresti incontrare."


translate ita mainGameStart_1f1bf179:


    "I tuoi pensieri sono talmente profondi che quasi non lo noti."


translate ita mainGameStart_22b1ba98:


    cat "{size=-5}{alpha=0.4}Miao...{/alpha}{/size}"


translate ita mainGameStart_d83b2afc:


    you "{i}Eh? Cosa è stato?{/i}"


translate ita mainGameStart_38cc5198:


    "La curiosità ti spinge a seguire il suono fino all'entrata di un vicolo isolato."


translate ita mainGameStart_741a7cdd:


    "La luce del sole raggiunge {i}a malapena{/i} la strada tra le mura alte dei palazzi."


translate ita mainGameStart_d1586eaa:


    "Ti addentri con cautela nel vicolo mentre la ghiaia e i vari detriti sparsi a terra attutiscono il rumore dei tuoi passi."


translate ita mainGameStart_a46fe60b:


    cat "Miao! Miao!"


translate ita mainGameStart_1b77a27b:


    "Finalmente l'origine del suono si manifesta nella luce calda e quasi eterea del vicolo... "


translate ita mainGameStart_1b5c33fc:


    "Alla fine del vicolo..."


translate ita mainGameStart_f6400e85:


    "... dentro una grande scatola di cartone..."


translate ita mainGameStart_8dabefc6_1:


    ".."


translate ita mainGameStart_a20cefa7_2:


    "..."


translate ita mainGameStart_69a9648a:


    "... c'è un gatto."


translate ita mainGameStart_605589a2:


    you "Uhm. Immagino che fosse abbastanza... ovvio...?"


translate ita mainGameStart_e5fab8a0:


    cat "Miao!"


translate ita mainGameStart_fc6b31f2:


    "È un gatto dall'aspetto curioso. I suoi begli occhi gialli scintillano come oro nell'oscuro mare di pelliccia."


translate ita mainGameStart_3b9482ac:


    "Si appoggia con le zampe anteriori al bordo della scatola e ti osserva."


translate ita mainGameStart_085f82bc:


    cat "Miao..."


translate ita mainGameStart_632d1a35:


    you "!!!" with hpunch


translate ita mainGameStart_242bb4ce:


    you "{i}C-{w}Così...!{/i}"


translate ita mainGameStart_dae0ec55_1:


    you "..."


translate ita mainGameStart_90b68c87:


    you "...?"


translate ita mainGameStart_ea0ef047:


    you "Sei così..."


translate ita mainGameStart_8dabefc6_2:


    ".."


translate ita mainGameStart_ab627e54:


    "... {i}familiare{/i}."


translate ita mainGameStart_c06dcd96:


    "... giusto?"


translate ita mainGameStart_e5fab8a0_1:


    cat "Miao!"


translate ita mainGameStart_a20cefa7_3:


    "..."


translate ita mainGameStart_23175e48:


    "Alla fine, è {i}solo{/i} un gatto. A guardarlo bene è simile a tanti altri gatti neri già visti."


translate ita mainGameStart_a20cefa7_4:


    "..."


translate ita mainGameStart_849caf29:


    "{i}Questo{/i} qui è davvero carino, però."


translate ita mainGameStart_ff38a381:


    "Guardalo..."


translate ita mainGameStart_480ec193:


    "Non sembra infuriato e non ti soffia contro quando ti avvicini, al contrario di altri che hai incontrato."


translate ita mainGameStart_1d08389c:


    "Sta seduto lì con aria paziente..."


translate ita mainGameStart_85f1774e:


    "Aspetta che tu faccia qualcosa..."


translate ita mainChoice1_230edd2e:


    "Purtroppo, per quanto sia carino..."


translate ita mainChoice1_a20cefa7:


    "..."


translate ita mainChoice1_3313542d:


    "{size=-10}... non porteresti {b}mai{/b} questa {color=#FF0000}{b}cosa{/b}{/color} a casa tua.{/size}"


translate ita mainChoice1_8dabefc6:


    ".."


translate ita mainChoice1_a20cefa7_1:


    "..."


translate ita mainChoice1_ab96ac00:


    "... {i}Non puoi{/i} proprio portarlo a casa tua."


translate ita mainChoice1_e10d4d87:


    "Sei maggiorenne e responsabile."


translate ita mainChoice1_085f82bc:


    cat "Miao..."


translate ita mainChoice1_9c8908c5:


    "L-Lo {i}sei!{/i}"


translate ita mainChoice1_473c0e80:


    "Con affitto e bollette da pagare! Per non parlare della spesa!"


translate ita mainChoice1_6783211d:


    "Non avresti {i}nessuna{/i} possibilità di tenere a lungo un gatto, giusto?"


translate ita mainChoice1_8d3712f3:


    "Puoi permetterti a malapena questa uscita nel tuo giorno libero..."


translate ita mainChoice1_e5fab8a0:


    cat "Miao!"


translate ita mainChoice1_dae0ec55:


    you "..."


translate ita mainChoice1_af5ee6df:


    "Che fare..."


translate ita mainChoice2_7f0ac95c:


    cat "..."


translate ita mainChoice2_dae0ec55:


    you "..."


translate ita mainChoice2_085f82bc:


    cat "Miao..."


translate ita mainChoice2_dae0ec55_1:


    you "..."


translate ita mainChoice2_549c54ff:


    you "Beh... Perché no?"


translate ita mainChoice2_9979a58c:


    "Giusto?"


translate ita mainChoice2_e5fab8a0:


    cat "Miao!"


translate ita mainChoice2_c97c6224:


    "Al minimo accenno di movimento, il gatto salta sulle tue braccia per poi arrampicarsi sulle spalle."


translate ita mainChoice2_6dcf309e:


    "Strofina la sua testa contro la tua."


translate ita mainChoice2_cc63b22e:


    cat "Purr... Purr... Purr..."


translate ita mainChoice2_dae0ec55_2:


    you "..."


translate ita mainChoice2_8de35a3a:


    you "Eheh..."


translate ita mainChoice2_b7f6e266:


    "L'entusiasmo del gatto ti fa sorridere."


translate ita mainChoice2_c18c153e:


    you "Andiamo via da questo posto, ok?"


translate ita mainChoice2_67107e6c:


    cat "Purr..."


translate ita mainChoice2_0c4dd6d6:


    "Sulla via di casa, ti chiedi se comprare o meno del cibo per gatti..."


translate ita mainChoice2_8dabefc6:


    ".."


translate ita mainChoice2_a20cefa7:


    "..."


translate ita mainChoice2_ba9adcaf:


    "{size=-5}Ma sarebbe uno spreco di tempo.{/size}"


translate ita mainChoice2_40d9ca73:


    "...?"


translate ita mainChoice2_45eb50c5:


    "Ti scrolli di dosso una strana sensazione e vai avanti."


translate ita mainChoice2_df101305:


    "Vivi in un piccolo appartamento."


translate ita mainChoice2_247ad3ce:


    "Una camera da letto. Un bagno."


translate ita mainChoice2_2d3f71e5:


    "Ci vivi {i}tu{/i}, tu e basta..."


translate ita mainChoice2_f380a402:


    "Quindi ti sembra strano che ci sia un altro essere vivente dopo tanto tempo."


translate ita mainChoice2_8b0c916e:


    "Anche se è {i}soltanto{/i} un gatto."


translate ita mainChoice2_1c9ee7fd:


    "Dopo aver chiuso la porta d'ingresso e aver poggiato il gatto a terra, ti fermi per vedere come esplorerà il nuovo ambiente."


translate ita mainChoice2_a20cefa7_1:


    "..."


translate ita mainChoice2_480ae195:


    "Ma lui rimane seduto lì e ti guarda con aria di attesa..."

translate ita strings:


    old "Take cat home!"
    new "Porta il gatto a casa!"


    old "Do not take cat home..."
    new "Non portare il gatto a casa..."

    old "This game is not suitable for children or the easily disturbed.\n\nIt includes depictions of horror elements, human/animal violence and death,\nabuse/abusive relationship(s), disturbing images, loud noises, flashing images/lights and more.\nIndividuals suffering from anxiety, depression or certain fears/phobias may not have a safe experience playing this game.\n\nFor full list of content/trigger warnings go to 'About' section in the game's main menu."
    new "Questo videogioco non è adatto ai bambini e alle persone facilmente impressionabili. \n\nInclude scene con elementi horror, persone/animali sottoposti a violenza e morte, scene di abuso/relazioni violente, immagini inquietanti, rumori forti, immagini/luci intermittenti e altro. \nLe persone che soffrono d’ansia, di depressione o di certe paure/fobie \npotrebbero avere un’esperienza spiacevole durante il gioco. \n\nPer la lista completa degli avvisi relativi ai contenuti consulta la sezione ‘Informazioni’ nella schermata principale del gioco."

    old "Please take care of yourself."
    new "Prenditi cura della tua salute fisica e mentale."

    old "\\ "
    new "\\ "

    old "Or maybe it was..."
    new "Fortuna o..."

    old "{w=0.6}f{w=0.6}a{w=0.6}t{w=0.6}e{w=0.6}~{w=0.6}?"
    new "{w=0.6}d{w=0.6}e{w=0.6}s{w=0.6}t{w=0.6}i{w=0.6}n{w=0.6}o{w=0.6}~{w=0.6}?"

    old "You"
    new "Tu"

    old "Cat"
    new "Gatto"

    old "Cat #2"
    new "Gatto n.2"

    old "Text"
    new "Messaggio"

    old "Cat on screen"
    new "Gatto sullo schermo"

    old "Audience"
    new "Pubblico"

    old "Dog"
    new "Cane"

    old "Cat Doll"
    new "Gatto di Peluche"

    old "Kitten"
    new "Gattino"

    old "I T"
    new "L U I"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
