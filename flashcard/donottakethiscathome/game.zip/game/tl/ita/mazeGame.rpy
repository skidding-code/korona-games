


translate ita mazeStart_a48e0df5:


    who "Salve, amante dell'avventura~!"


translate ita mazeStart_8ca8510a:


    you "!!!" with vpunch


translate ita mazeStart_95254b2e:


    "Chi ha parl--{w=0.3}{nw}"


translate ita mazeStart_5149a957:


    who "Ti do il benvenuto nel Labirinto di Specchi!"


translate ita mazeStart_75539f95:


    who "Vorresti un consiglio su come attraversare il labirinto?" nointeract


translate ita mazeStart_58e7d283:


    who "Ok, ok! {w}Non c'è bisogno di fare così..."


translate ita mazeStart_1bc7b06c:


    who "Cominciamo allora!"


translate ita mazeStart_1847df9a:


    who "3... {w}2... {w}1..."


translate ita mazeStart_7486d4f4:


    who "{size=+25}{b}VIA!{/b}{/size}" with vpunch


translate ita mazeTutorial_523cd98e:


    "Ancora una volta... {w}Ti do il benvenuto nel Labirinto di Specchi!"


translate ita mazeTutorial_b20052dc:


    "Sembri un po' in difficoltà, ma non preoccuparti!"


translate ita mazeTutorial_39fb6b3b:


    "Sei in {i}buone{/i} mani!"


translate ita mazeTutorial_9985c05f:


    "O per meglio dire..."


translate ita mazeTutorial_0c5f5726:


    "... buone {b}zampe!{/b}"


translate ita mazeTutorial_5fc3dcc7:


    "Vedi quei piccoletti adorabili?"


translate ita mazeTutorial_ff9fc1d5:


    "Faranno del loro meglio per guidarti attraverso il labirinto!"


translate ita mazeTutorial_9043d317:


    "Gentile da parte loro, vero~?"


translate ita mazeTutorial_59691f37:


    "Quando entrerai in una stanza... la luce di emergenza lampeggerà, mostrando i percorsi davanti a te per un secondo."


translate ita mazeTutorial_dcc59543:


    "Oltre a ciò che ti attende alla loro fine."


translate ita mazeTutorial_0d753b90:


    "Quando vedrai questi gentili gattini..."


translate ita mazeTutorial_824e766c:


    "... ti basterà seguirli per raggiungere la stanza successiva!"


translate ita mazeTutorial_96380374:


    "Purtroppo..."


translate ita mazeTutorial_74dfdecc:


    "... non troverai solo loro."


translate ita mazeTutorial_93e0e5fe:


    "Consigliamo {i}caldamente{/i} di trattenersi dal seguire {i}qualsiasi altro{/i} nostro... {w}{b}{i}ospite{/i}{/b}"


translate ita mazeTutorial_22a32adf:


    "Possono essere subdoli, cercare di distrarti... {w}ma sono {b}sempre{/b} ostili."


translate ita mazeTutorial_106eb8ca:


    "Quindi fa' attenzione quando entri nella prossima stanza!"


translate ita mazeTutorial_e361bedb:


    "Ovviamente questo non sarebbe un labirinto di specchi senza specchi!"


translate ita mazeTutorial_7fa0fc05:


    "\"Possono farti del male?\""


translate ita mazeTutorial_1907bcc0:


    "No! Sono solo degli specchi, che sciocchezza!"


translate ita mazeTutorial_c4e8c1f8:


    "Non ti faranno assolutamente nulla~!"


translate ita mazeTutorial_d7a493b8:


    "E tu non puoi fare nulla a loro."


translate ita mazeTutorial_fa242737:


    "Sono solo degli ostacoli che non puoi oltrepassare."


translate ita mazeTutorial_876495c2:


    "Vai a {b}sinistra{/b}, {w}vai {b}avanti{/b}, {w}o vai a {b}destra{/b}!"


translate ita mazeTutorial_4931dda6:


    "La scelta è tua!"


translate ita mazeTutorial_23e939ae:


    "Però..."


translate ita mazeTutorial_15510f8f:


    "Se trovi una stanza senza gattini che ti aiutino..."


translate ita mazeTutorial_d32e4fb5:


    "... e ogni strada porta a uno specchio o a... {w}{color=#FF0000}{b}qualcos'altro...{/b}{/color}"


translate ita mazeTutorial_a78f88cc:


    "Ti consiglio di {b}non muoverti{/b}... {w}e forse tutto si sistemerà da sé!"


translate ita mazeTutorial_4dfacc44:


    "E ora vediamo la tua attrezzatura!"


translate ita mazeTutorial_194e688a:


    "A quella {b}torcia{/b} che hai trovato non resta molta batteria..."


translate ita mazeTutorial_0ba8aaf5:


    "Ti permetterà di dare una {b}breve{/b} occhiata ai dintorni circa cinque volte."


translate ita mazeTutorial_f28a1cba:


    "Perciò cerca di non usarla tutta in una volta!"


translate ita mazeTutorial_7938b891:


    "Puoi tenere traccia dei tuoi progressi nelle {b}stanze{/b} in alto a sinistra..."


translate ita mazeTutorial_519aa538:


    "... e delle tue {b}vite{/b} in alto a destra!"


translate ita mazeTutorial_238bd2a4:


    "Hai tre vite, perciò cerca di evitare gli ospiti meno amichevoli che si nascondono in giro."


translate ita mazeTutorial_69a6fef7:


    "\"Perché solo {b}tre{/b} vite\", chiedi?"


translate ita mazeTutorial_f56b6035:


    "Perché sei fragile e a rischio di traumi"


translate ita mazeTutorial_d3a59e2c:


    "Non ci vorrebbe molto per causarti danni irreparabili..."


translate ita mazeTutorial_a20cefa7:


    "..."


translate ita mazeTutorial_53b3ffb5:


    "E inoltre..."


translate ita mazeTutorial_781b2cf3:


    "... sei un essere umano. Di solito gli umani hanno solo {b}una{/b} vita, giusto?"


translate ita mazeTutorial_91cf105d:


    "Eppure qui, ne avrai tre!"


translate ita mazeTutorial_8dabefc6:


    ".."


translate ita mazeTutorial_a20cefa7_1:


    "..."


translate ita mazeTutorial_00557775:


    "Non pensi che... {w}dovresti mostrare... {w}un po' più di..."


translate ita mazeTutorial_40553271:


    "{b}... g {w=0.2}r {w=0.2}a {w=0.2}t {w=0.2}i {w=0.2}t {w=0.2}u {w=0.2}d {w=0.2}i {w=0.2}n {w=0.2}e {w=0.2}?{/b}"


translate ita mazeTutorial_8dabefc6_1:


    ".."


translate ita mazeTutorial_a20cefa7_2:


    "..."


translate ita mazeTutorial_e4ba3fc6:


    "Il tutorial finisce qui!!!"


translate ita mazeTutorial_c4fbff42:


    "Spero sia stato utile!"


translate ita mazeTutorial_bf623419:


    "Vuoi iniziare il gioco?"


translate ita mazeSettings_02557781:


    who "Hai qualche domanda?~" nointeract


translate ita mazeSettings_1ff6beab:


    "Ok!"


translate ita mazeSettings_a05e1dc4:


    "3... {w}2... {w}1..."


translate ita mazeSettings_e5f078db:


    "{size=+25}{b}VIA!{/b}{/size}" with vpunch


translate ita mazeSettings_909322d8:


    who "La tua richiesta di arrenderti è stata rifiutata!~"


translate ita mazeSettings_74a88101:


    you "Fammi uscire da qui!" with vpunch


translate ita mazeSettings_616c59ce:


    who "Non è permesso gridare nel labirinto!~"


translate ita mazeSettings_0862e669:


    who "Ovvio!"


translate ita mazeSettings_7ee6eac8:


    who "Flash {b}ACCESO!{/b}"


translate ita mazeSettings_0862e669_1:


    who "Ma certo!"


translate ita mazeSettings_4388c99c:


    who "Flash {b}SPENTO!{/b}"


translate ita mazeSettings_b56089a4:


    who "Oh, va bene..."


translate ita mazeSettings_dca85608:


    who "La tua torcia ti darà altre {b}sette{/b} possibilità ora..."


translate ita mazeSettings_412f0fff:


    who "{i}E{/i} il flash durerà più a lungo..."


translate ita mazeSettings_1d4dacaf:


    who "Va meglio adesso~?"


translate ita mazeSettings_6f50b679:


    who "..."


translate ita mazeSettings_6647ecc8:


    who "Ah, è {b}così?{/b}"


translate ita mazeSettings_8dabefc6:


    ".."


translate ita mazeSettings_a20cefa7:


    "..."


translate ita mazeSettings_24c97862:


    who "Ecco... {w}tutto a posto!"


translate ita mazeSettings_95022402:


    you "Aspetta, cosa hai fatto?"


translate ita mazeSettings_6f50b679_1:


    who "..."


translate ita mazeSettings_279d8c4f:


    who "Vedrai~"


translate ita mazeSettings_3ab9acb5:


    who "Ce l'hai fatta!"


translate ita mazeSettings_6bf745f8:


    who "Come desideri!"


translate ita maze1Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze1Menu_76061708_1:


    you "AHI! Non da quella parte!"


translate ita maze1Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze1Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze1Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze2Menu_ef682bac:


    "*CLANG!*"


translate ita maze2Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze2Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze2Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze2Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze2Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze3Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze3Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze3Menu_76061708_1:


    you "AHI! Non da quella parte!"


translate ita maze3Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze3Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze4Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze4Menu_76061708_1:


    you "AHI! Non da quella parte!"


translate ita maze4Menu_76061708_2:


    you "AHI! Non da quella parte!"


translate ita maze4Menu_dc06f641:


    you "Questa stanza sembra strana..."


translate ita maze4Menu_1ad23f1f:


    you "Aspetta..."


translate ita maze4Menu_dae0ec55:


    you "..."


translate ita maze4Menu_e4612ec1:


    you "..!"


translate ita maze4Menu_ceb48012:


    you "Penso ci sia qualcosa di diverso..."


translate ita maze4Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze5Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze5Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze5Menu_76061708_1:


    you "AHI! Non da quella parte!"


translate ita maze5Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze5Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze6Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze6Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze6Menu_76061708_1:


    you "AHI! Non da quella parte!"


translate ita maze6Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze6Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze7Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze7Menu_ef682bac:


    "*CLANG!*"


translate ita maze7Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze7Menu_76061708_1:


    you "AHI! Non da quella parte!"


translate ita maze7Menu_dc06f641:


    you "Questa stanza sembra strana..."


translate ita maze7Menu_1ad23f1f:


    you "Aspetta..."


translate ita maze7Menu_dae0ec55:


    you "..."


translate ita maze7Menu_e4612ec1:


    you "..!"


translate ita maze7Menu_ceb48012:


    you "Penso ci sia qualcosa di diverso..."


translate ita maze7Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze8Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze8Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze8Menu_76061708_1:


    you "AHI! Non da quella parte!"


translate ita maze8Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze8Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze9Menu_ef682bac:


    "*CLANG!*"


translate ita maze9Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze9Menu_ef682bac_1:


    "*CLANG!*"


translate ita maze9Menu_9af1e7a3_1:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze9Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze9Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze9Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze10Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze10Menu_76061708_1:


    you "AHI! Non da quella parte!"


translate ita maze10Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze10Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze10Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze11Menu_ef682bac:


    "*CLANG!*"


translate ita maze11Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze11Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze11Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze11Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze11Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze12Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze12Menu_ef682bac:


    "*CLANG!*"


translate ita maze12Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze12Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze12Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze12Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze13Menu_ef682bac:


    "*CLANG!*"


translate ita maze13Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze13Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze13Menu_ef682bac_1:


    "*CLANG!*"


translate ita maze13Menu_9af1e7a3_1:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze13Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze13Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze14Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze14Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze14Menu_ef682bac:


    "*CLANG!*"


translate ita maze14Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze14Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze14Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze15Menu_ef682bac:


    "*CLANG!*"


translate ita maze15Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze15Menu_ef682bac_1:


    "*CLANG!*"


translate ita maze15Menu_9af1e7a3_1:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze15Menu_ef682bac_2:


    "*CLANG!*"


translate ita maze15Menu_9af1e7a3_2:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze15Menu_dc06f641:


    you "Questa stanza sembra strana..."


translate ita maze15Menu_1ad23f1f:


    you "Aspetta..."


translate ita maze15Menu_dae0ec55:


    you "..."


translate ita maze15Menu_e4612ec1:


    you "..!"


translate ita maze15Menu_ceb48012:


    you "Penso ci sia qualcosa di diverso..."


translate ita maze15Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze16Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze16Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze16Menu_76061708_1:


    you "AHI! Non da quella parte!"


translate ita maze16Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze16Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze17Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze17Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze17Menu_ef682bac:


    "*CLANG!*"


translate ita maze17Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze17Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze17Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze18Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze18Menu_ef682bac:


    "*CLANG!*"


translate ita maze18Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze18Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze18Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze18Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze19Menu_ef682bac:


    "*CLANG!*"


translate ita maze19Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze19Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze19Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze19Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze19Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze20Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze20Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze20Menu_ef682bac:


    "*CLANG!*"


translate ita maze20Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze20Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze20Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze21Menu_ef682bac:


    "*CLANG!*"


translate ita maze21Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze21Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze21Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze21Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze21Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze22Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze22Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze22Menu_76061708_1:


    you "AHI! Non da quella parte!"


translate ita maze22Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze22Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze23Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze23Menu_ef682bac:


    "*CLANG!*"


translate ita maze23Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze23Menu_ef682bac_1:


    "*CLANG!*"


translate ita maze23Menu_9af1e7a3_1:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze23Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze23Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze24Menu_a9f7373b:


    you "Ok, prossima stanza..."


translate ita maze24Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze24Menu_ef682bac:


    "*CLANG!*"


translate ita maze24Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze24Menu_5a213e14:


    you "Credo proprio che questa stanza abbia un'uscita..."


translate ita maze24Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita maze25Menu_76061708:


    you "AHI! Non da quella parte!"


translate ita maze25Menu_76061708_1:


    you "AHI! Non da quella parte!"


translate ita maze25Menu_ef682bac:


    "*CLANG!*"


translate ita maze25Menu_9af1e7a3:


    you "Uno specchio? Non posso passare da qui!"


translate ita maze25Menu_dc06f641:


    you "Questa stanza sembra strana..."


translate ita maze25Menu_1ad23f1f:


    you "Aspetta..."


translate ita maze25Menu_dae0ec55:


    you "..."


translate ita maze25Menu_e4612ec1:


    you "..!"


translate ita maze25Menu_ceb48012:


    you "Penso ci sia qualcosa di diverso..."


translate ita maze25Menu_c3c3f39d:


    "Cacchio... La torcia è scarica..."


translate ita mazeWin_8dabefc6:


    ".."


translate ita mazeWin_a20cefa7:


    "..."


translate ita mazeWin_a513413e:


    "..!"


translate ita mazeWin_0c52a734:


    "La vedi! L'uscita!"


translate ita mazeWin_bb7d045b:


    "Ti metti a correre, ma non appena lo fai..."


translate ita mazeWin_2fa70f34:


    "... lo scenario... {b}cambia{/b}."


translate ita mazeWin_ca8b0a70:


    "Solo lievemente all'inizio..."


translate ita mazeWin_a20cefa7_1:


    "..."


translate ita mazeWin_ee3778a5:


    "... ma ora corri troppo forte per fermarti e vai a sbattere contro il vetro."


translate ita mazeWin_a20cefa7_2:


    "..."


translate ita mazeWin_a513413e_1:


    "...!"


translate ita mazeWin_a5cb5de7:


    "Eppure..."


translate ita mazeWin_1bd92e64:


    "... non finisci proprio {i}dentro{/i} al vetro."


translate ita mazeWin_3c2eb60a:


    "Non ci vai nemmeno a {i}sbattere{/i} contro."


translate ita mazeWin_77c290a9:


    "Semplicemente... ci {w}passi {b}attraverso{/b}."


translate ita mazeWin_c7791603:


    "E dall'altra parte, vedi un vuoto bianco e infinito e..."


translate ita mazeWin_40d9ca73:


    "...?"


translate ita mazeWin_bb6dce2b:


    "... delle tue copie?"


translate ita mazeWin_6f2f53b2:


    "A dozzine."


translate ita mazeWin_f99b0994:


    "{i}Centinaia{/i} di tue copie che vagano in giro..."


translate ita mazeWin_d5c80074:


    "Senza meta..."


translate ita mazeWin_d4aabc08:


    "Senza volto..."


translate ita mazeWin_a20cefa7_3:


    "..."


translate ita mazeWin_2bfa9431:


    "E vuote..."


translate ita mazeWin_8a444783:


    "Così vuote e apatiche, che non si accorgono nemmeno della tua presenza."


translate ita mazeWin_28b3ac41:


    you "!!!"


translate ita mazeWin_b9a65d59:


    "Provi a tornare indietro..."


translate ita mazeWin_a20cefa7_4:


    "..."


translate ita mazeWin_8df49ab6:


    "... ma il vetro non cede."


translate ita mazeWin_e6523116:


    "Oltre il vetro..."


translate ita mazeWin_c3b5585c:


    "... un familiare gatto nero si avvicina e ti guarda."


translate ita mazeWin_6e960518:


    "Pensi che stia miagolando a te..."


translate ita mazeWin_a20cefa7_5:


    "..."


translate ita mazeWin_b1b87e48:


    "... ma non riesci a sentire il suono."


translate ita mazeWin_7f0ac95c:


    cat "..."


translate ita mazeWin_38c1149b:


    "Inclina la testa..."


translate ita mazeWin_e391259c:


    "... e se ne va."


translate ita mazeWin_7d5b08ef:


    "Il vetro diventa nero..."


translate ita mazeWin_ed2c108e:


    "Lo guardi disperatamente mentre scompare del tutto..."


translate ita mazeWin_8dabefc6_1:


    ".."


translate ita mazeWin_a20cefa7_6:


    "..."


translate ita mazeWin_15e0cbf3:


    "Sei in trappola..."


translate ita mazeWin_5bbdfcf4:


    "... con le tue sole copie a farti compagnia."


translate ita mazeWin_a20cefa7_7:


    "..."


translate ita mazeWin_cbc07846:


    "Finale 19: Superi il labirinto :D"


translate ita mazeLose_8dabefc6:


    ".."


translate ita mazeLose_a20cefa7:


    "..."


translate ita mazeLose_f8342e66:


    "All'improvviso..."


translate ita mazeLose_054e707a:


    "Le luci si accendono..."


translate ita mazeLose_539b0333:


    "I tuoi occhi bruciano per la forte luminosità..."


translate ita mazeLose_da4b1c21:


    "Mentre la tua vista si riprende, capisci di avere attorno specchi su specchi..."


translate ita mazeLose_71354367:


    "Le immagini riflesse, grottesche in modi unici..."


translate ita mazeLose_f0156f30:


    "... non sembrano assomigliarti per nulla."


translate ita mazeLose_a20cefa7_1:


    "..."


translate ita mazeLose_b19017ca:


    "Ma sembrano {i}molto{/i}..."


translate ita mazeLose_a20cefa7_2:


    "..."


translate ita mazeLose_515f36c9:


    "... {b}a f f a m a t e.{/b}"


translate ita mazeLose_28b3ac41:


    you "!!!"


translate ita mazeLose_3106400c:


    "Indietreggi. {w}Non sai dove andare. {w}Ma c'è mai stata una via d'uscita?"


translate ita mazeLose_39d54166:


    "Urti uno specchio con la schiena..."


translate ita mazeLose_f38c3a4c:


    "... e senti una mano afferrarti forte una spalla."


translate ita mazeLose_c84580e0:


    "{size=+25}{b}CHOMP!!!{/b}{/size}"


translate ita mazeLose_bbe064f5:


    you "{b}GASP!!!{/b}" with vpunch


translate ita mazeLose_3360de48:


    "Senti un dolore acuto all'altra spalla."


translate ita mazeLose_aa4f8089:


    "Ti distacchi e girandoti vedi un... {i}{b}essere{/b}{/i} sporgersi dallo specchio."


translate ita mazeLose_a1e48554:


    "La sua faccia non ha lineamenti... {w}eccetto una larga bocca spalancata..."


translate ita mazeLose_5244ba66:


    "... macchiata del tuo sangue."


translate ita mazeLose_44a8fb9b:


    "Nel panico, ti guardi attorno, notando che gli specchi sembrano più vicini di prima."


translate ita mazeLose_a01def9f:


    "Il percorso che avevi seguito non si vede già più."


translate ita mazeLose_7f1405b1:


    "Ti circondano... e ogni volta che chiudi gli occhi..."


translate ita mazeLose_986a69fb:


    "... {i}giureresti{/i} di vedere gli specchi sempre più vicini..."


translate ita mazeLose_57fba23d:


    "Più vicini..."


translate ita mazeLose_0650d5b6:


    "... sempre di più."


translate ita mazeLose_7865cabc:


    "Le tue immagini riflesse sembrano ancora più affamate..."


translate ita mazeLose_10364f30:


    "... voraci..."


translate ita mazeLose_becd9a7d:


    "... e fameli--{w=0.3}{nw}"


translate ita mazeLose_8dabefc6_1:


    ".."


translate ita mazeLose_a20cefa7_3:


    "..."


translate ita mazeLose_e1f94697:


    "Finale 20: Non hai superato il labirinto :("

translate ita strings:


    old "Yes, I need help!"
    new "Sì, ho bisogno di aiuto!"


    old "No! I don't even know you!"
    new "No! Non ti conosco nemmeno!"


    old "No, but I have some questions..."
    new "No, ma ho alcune domande..."


    old "{b}{size=+5}I'm ready to play!{/size}{/b}"
    new "{b}{size=+5}Iniziamo il gioco!{/size}{/b}"


    old "Can you let me go?"
    new "Puoi lasciarmi andare?"


    old "Can you turn {b}ON{/b} the flash, please?"
    new "Puoi {b}ACCENDERE{/b} il flash, per favore?"


    old "Can you turn {b}OFF{/b} the flash, please?"
    new "Puoi {b}SPEGNERE{/b} il flash, per favore?"


    old "This game is too hard..."
    new "Questo gioco è troppo difficile..."


    old "Psh! This game's {i}{b}way{/b}{/i} too easy!"
    new "Pff! Questo gioco è {i}{b}davvero{/b}{/i} troppo facile!"


    old "Reset Settings"
    new "Ripristina le impostazioni"


    old "Can you tell me about the maze again?"
    new "Puoi rispiegarmi come funziona il labirinto?"


    old "LEFT"
    new "SINISTRA"


    old "CENTER"
    new "AVANTI"


    old "RIGHT"
    new "DESTRA"


    old "STAY"
    new "NON MUOVERTI"


    old "Flashlight ([flashlight]/[maxLight])"
    new "Torcia ([flashlight]/[maxLight])"

    old "LIVES: [mazeLives]/[maxLives]"
    new "VITE: [mazeLives]/[maxLives]"

    old "Room [roomCounter]/25"
    new "Stanza [roomCounter]/25"

    old "[mazeClock]"
    new "[mazeClock]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
