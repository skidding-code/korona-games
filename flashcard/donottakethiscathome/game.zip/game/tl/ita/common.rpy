

translate ita strings:


    old "Self-voicing disabled."
    new "Lettura del testo disattivata."


    old "Clipboard voicing enabled. "
    new "Abilitazione della voce negli appunti. "


    old "Self-voicing enabled. "
    new "Lettura del testo attivata."


    old "bar"
    new "asta"


    old "selected"
    new "selezionata"


    old "viewport"
    new "vista"


    old "horizontal scroll"
    new "scorrimento orizzontale"


    old "vertical scroll"
    new "scorrimento verticale"


    old "activate"
    new "attivare"


    old "deactivate"
    new "disattivare"


    old "increase"
    new "aumento"


    old "decrease"
    new "diminuire"


    old "Font Override"
    new "Sostituzione carattere"


    old "Default"
    new "Predefinita"


    old "DejaVu Sans"
    new "DejaVu Sans"


    old "Opendyslexic"
    new "Opendyslexic"


    old "Text Size Scaling"
    new "Ridimensionamento della dimensione del testo"


    old "Reset"
    new "Reset"


    old "Line Spacing Scaling"
    new "Scala di interlinea"


    old "Self-Voicing"
    new "Lettura del testo"


    old "Off"
    new "Spenta"


    old "Text-to-speech"
    new "Testo-voce"


    old "Clipboard"
    new "Appunti"


    old "Debug"
    new "Debug"


    old "Self-Voicing Volume Drop"
    new "Riduzione del Volume Della Auto-voce"


    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "Le opzioni di questo menu hanno lo scopo di migliorare l'accessibilità. Potrebbero non funzionare con tutti i giochi e alcune combinazioni di opzioni potrebbero rendere il gioco ingiocabile. Questo non è un problema del gioco o del motore grafico. Per ottenere risultati ottimali quando si cambia il font, cercare di mantenere la dimensione del testo invariata rispetto a quella originale."


    old "{#weekday}Monday"
    new "{#weekday}Lunedì"


    old "{#weekday}Tuesday"
    new "{#weekday}Martedì"


    old "{#weekday}Wednesday"
    new "{#weekday}Mercoledì"


    old "{#weekday}Thursday"
    new "{#weekday}Giovedì"


    old "{#weekday}Friday"
    new "{#weekday}Venerdì"


    old "{#weekday}Saturday"
    new "{#weekday}Sabato"


    old "{#weekday}Sunday"
    new "{#weekday}Domenica"


    old "{#weekday_short}Mon"
    new "{#weekday_short}Lun"


    old "{#weekday_short}Tue"
    new "{#weekday_short}Mar"


    old "{#weekday_short}Wed"
    new "{#weekday_short}Mer"


    old "{#weekday_short}Thu"
    new "{#weekday_short}Gio"


    old "{#weekday_short}Fri"
    new "{#weekday_short}Ven"


    old "{#weekday_short}Sat"
    new "{#weekday_short}Sab"


    old "{#weekday_short}Sun"
    new "{#weekday_short}Dom"


    old "{#month}January"
    new "{#month}Gennaio"


    old "{#month}February"
    new "{#month}Febbraio"


    old "{#month}March"
    new "{#month}Marzo"


    old "{#month}April"
    new "{#month}Aprile"


    old "{#month}May"
    new "{#month}Maggio"


    old "{#month}June"
    new "{#month}Giugno"


    old "{#month}July"
    new "{#month}Luglio"


    old "{#month}August"
    new "{#month}Agosto"


    old "{#month}September"
    new "{#month}Settembre"


    old "{#month}October"
    new "{#month}Ottobre"


    old "{#month}November"
    new "{#month}Novembre"


    old "{#month}December"
    new "{#month}Dicembre"


    old "{#month_short}Jan"
    new "{#month_short}Gen"


    old "{#month_short}Feb"
    new "{#month_short}Feb"


    old "{#month_short}Mar"
    new "{#month_short}Mar"


    old "{#month_short}Apr"
    new "{#month_short}Apr"


    old "{#month_short}May"
    new "{#month_short}Mag"


    old "{#month_short}Jun"
    new "{#month_short}Giu"


    old "{#month_short}Jul"
    new "{#month_short}Lug"


    old "{#month_short}Aug"
    new "{#month_short}Ago"


    old "{#month_short}Sep"
    new "{#month_short}Set"


    old "{#month_short}Oct"
    new "{#month_short}Ott"


    old "{#month_short}Nov"
    new "{#month_short}Nov"


    old "{#month_short}Dec"
    new "{#month_short}Dic"


    old "%b %d, %H:%M"
    new "%b %d, %H:%M"


    old "Save slot %s: [text]"
    new "Salva spazio %s: [text]"


    old "Load slot %s: [text]"
    new "Carico spazio %s: [text]"


    old "Delete slot [text]"
    new "Cancellare spazio [text]"


    old "Pagina del file automatica"
    new ""


    old "File page quick"
    new "Pagina del file veloce"


    old "File page [text]"
    new "Pagina del file [text]"


    old "Next file page."
    new "Pagina del file successivo."


    old "Previous file page."
    new "Pagina del file precedente."


    old "Quick save complete."
    new "Salvataggio rapido completato."


    old "Quick save."
    new "Salvataggio rapido."


    old "Quick load."
    new "Caricamento rapido."


    old "Language [text]"
    new "Lingua [text]"


    old "The interactive director is not enabled here."
    new "Qui il direttore interattivo non è abilitato."


    old "⬆"
    new "⬆"


    old "⬇"
    new "⬇"


    old "Done"
    new "Fatto"


    old "(statement)"
    new "(statement)"


    old "(tag)"
    new "(tag)"


    old "(attributes)"
    new "(attributes)"


    old "(transform)"
    new "(transform)"


    old "(transition)"
    new "(transition)"


    old "(channel)"
    new "(channel)"


    old "(filename)"
    new "(filename)"


    old "Change"
    new "Modifica"


    old "Add"
    new "Aggiungere"


    old "Cancel"
    new "Cancellare"


    old "Remove"
    new "Rimuovere"


    old "Statement:"
    new "Dichiarazione:"


    old "Tag:"
    new "Etichetta:"


    old "Attributes:"
    new "Attributi:"


    old "Transforms:"
    new "trasforma:"


    old "Behind:"
    new "Dietro:"


    old "Transition:"
    new "Transizione:"


    old "Channel:"
    new "Canale:"


    old "Audio Filename:"
    new "Nome file audio:"


    old "Are you sure?"
    new "Confermi?"


    old "Are you sure you want to delete this save?"
    new "Confermi di voler eliminare questo salvataggio?"


    old "Are you sure you want to overwrite your save?"
    new "Confermi di voler sovrascrivere il tuo salvataggio?"


    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Il caricamento comporterà la perdita dei progressi non salvati.\nConfermi di voler procedere?"


    old "Are you sure you want to quit?"
    new "Confermi di voler uscire?"


    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Vuoi davvero tornare al menu principale?\nI progressi non salvati andranno persi."


    old "Are you sure you want to continue where you left off?"
    new "Sei sicuro di voler continuare da dove eri rimasto?"


    old "Are you sure you want to end the replay?"
    new "Sei sicuro di voler terminare la riproduzione?"


    old "Are you sure you want to begin skipping?"
    new "Sei sicuro di voler iniziare a saltare?"


    old "Are you sure you want to skip to the next choice?"
    new "Sei sicuro di voler passare alla scelta successiva?"


    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "Vuoi davvero saltare il dialogo non visto e passare alla scelta successiva?"


    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "Questo salvataggio è stato creato su un dispositivo diverso. I file di salvataggio creati in modo fraudolento possono danneggiare il computer. Ti fidi di chi ha creato questo salvataggio e di chiunque possa aver modificato il file?"


    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "Ti fidi del dispositivo su cui è stato creato il salvataggio?\nRispondi 'Sì' solo se sei l'unica persona che utilizza il dispositivo."


    old "Failed to save screenshot as %s."
    new "Impossibile salvare lo screenshot come %s."


    old "Saved screenshot as %s."
    new "Screenshot salvato come %s."


    old "Skip Mode"
    new "Modalità Salta"


    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Questo programma è stato realizzato con software gratuiti rilasciati sotto diverse licenze, tra le quali la licenza MIT e la GNU Lesser General Public License. Un elenco completo dei software, inclusi i link al codice sorgente completo, è disponibile {a=https://www.renpy.org/l/license}{b}qui{/b}{/a}."


    old "display"
    new "display"


    old "transitions"
    new "transizioni"


    old "skip transitions"
    new "saltare le transizioni"


    old "video sprites"
    new "sprite video"


    old "show empty window"
    new "mostra la finestra vuota"


    old "text speed"
    new "velocità del testo"


    old "joystick"
    new "joystick"


    old "joystick..."
    new "joystick..."


    old "skip"
    new "saltare"


    old "skip unseen [text]"
    new "salta invisibile [text]"


    old "skip unseen text"
    new "salta il testo non visualizzato"


    old "begin skipping"
    new "iniziare a saltare"


    old "after choices"
    new "dopo le scelte"


    old "skip after choices"
    new "saltare dopo le scelte"


    old "auto-forward time"
    new "tempo di avanzamento automatico"


    old "auto-forward"
    new "inoltro automatico"


    old "Auto forward"
    new "Avanzamento automatico"


    old "auto-forward after click"
    new "inoltro automatico dopo il clic"


    old "automatic move"
    new "spostamento automatico"


    old "wait for voice"
    new "aspetta la voce"


    old "voice sustain"
    new "sostegno della voce"


    old "self voicing"
    new "lettura del testo"


    old "self voicing volume drop"
    new "riduzione del volume della auto-voce"


    old "clipboard voicing"
    new "voce degli appunti"


    old "debug voicing"
    new "eseguire il debug della voce"


    old "emphasize audio"
    new "enfatizzare l'audio"


    old "rollback side"
    new "lato di rollback"


    old "gl powersave"
    new "gl powersave"


    old "gl framerate"
    new "gl framerate"


    old "gl tearing"
    new "gl tearing"


    old "font transform"
    new "trasformazione del carattere"


    old "font size"
    new "dimensione del carattere"


    old "font line spacing"
    new "interlinea del carattere"


    old "system cursor"
    new "cursore di sistema"


    old "renderer menu"
    new "menu del renderer"


    old "accessibility menu"
    new "menu di accessibilità"


    old "music volume"
    new "volume della musica"


    old "sound volume"
    new "volume del suono"


    old "voice volume"
    new "volume della voce"


    old "mute music"
    new "musica muta"


    old "mute sound"
    new "suono muto"


    old "mute voice"
    new "voce muta"


    old "mute all"
    new "disattiva tutto"


    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Voce degli appunti abilitata. Premere 'shift+C' per disabilitarla."


    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "L'auto-voce direbbe \"[renpy.display.tts.last]\". Premere 'alt+shift+V' per disattivare."


    old "Self-voicing enabled. Press 'v' to disable."
    new "Lettura del testo attivata. Premere 'v' per disattivare."


    old "Image [index] of [count] locked."
    new "Immagine [index] di [count] bloccata."


    old "prev"
    new "prec"


    old "next"
    new "pros"


    old "slideshow"
    new "presentazione"


    old "return"
    new "ritorno"


    old "Select Gamepad to Calibrate"
    new "Seleziona il gamepad da calibrare"


    old "No Gamepads Available"
    new "Nessun gamepad disponibile"


    old "Calibrating [name] ([i]/[total])"
    new "Calibrazione [name] ([i]/[total])"


    old "Press or move the '[control!s]' [kind]."
    new "Premere o spostare il '[control!s]' [kind]."


    old "Skip (A)"
    new "Salta (A)"


    old "Back (B)"
    new "Indietro (B)"


    old "Open"
    new "Aprire"


    old "Opens the traceback.txt file in a text editor."
    new "Apre il file traceback.txt in un editor di testo."


    old "Copy BBCode"
    new "Copia il BBCode"


    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copia il file traceback.txt negli appunti come BBcode per forum come https://lemmasoft.renai.us/."


    old "Copy Markdown"
    new "Copia Markdown"


    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Copia il file traceback.txt negli appunti come Markdown per Discord."


    old "An exception has occurred."
    new "Si è verificata un'eccezione."


    old "Rollback"
    new "Rollback"


    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Tenta di tornare a un momento precedente, consentendoti di salvare o di scegliere un'opzione diversa."


    old "Ignores the exception, allowing you to continue."
    new "Ignora l'eccezione, consentendoti di continuare."


    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Ignora l'eccezione, consentendo di continuare. Questo spesso causa ulteriori errori."


    old "Reload"
    new "Ricaricare"


    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Ricarica il gioco dal disco, salvando e ripristinando lo stato del gioco se possibile."


    old "Console"
    new "Console"


    old "Opens a console to allow debugging the problem."
    new "Apre una console per consentire il debug del problema."


    old "Quits the game."
    new "Esce dal gioco."


    old "Parsing the script failed."
    new "Analisi dello script non riuscita."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
