


translate ita prologue_start_984bc6cc:


    "La tua giornata non è delle migliori, tanto per cambiare."


translate ita prologue_start_1481783e:


    you "Oh bene..."


translate ita prologue_start_45f04c4f:


    "Era da un po' di tempo che non ti sentivi così bene da voler uscire..."


translate ita prologue_start_8a152280:


    "Ma nel mezzo della passeggiata, comincia a piovere."


translate ita prologue_start_11943181:


    "Tipico. Ma..."


translate ita prologue_start_be9a673a:


    "... forse è un modo per dirti che sarebbe stato meglio rimanere a casa oggi?"


translate ita prologue_start_aba41a33:


    "Già. Puoi sempre riprovare domani... {w}no?"


translate ita prologue_start_f93e972d:


    "Ti volti per tornare a casa quando--"


translate ita prologue_start_a1100951:


    who "{size=-5}{alpha=0.25}Miao...{/alpha}{/size}"


translate ita prologue_start_4d2575f7:


    you "{i}Uh? Cosa è stato...?{/i}"


translate ita prologue_start_6b2b7353:


    "Per strada non c'è quasi nessuno..."


translate ita prologue_start_dd4ef7b8:


    "Ha senso, dato il recente aumento dei casi di persone disperse in questa zona..."


translate ita prologue_start_edacd6a8:


    "Beh, {i}quello{/i} e il tempo..."


translate ita prologue_start_8dabefc6:


    ".."


translate ita prologue_start_a20cefa7:


    "..."


translate ita prologue_start_bf8c3d80:


    "Eppure, nessuno reagisce {i}minimamente{/i} al suono. "


translate ita prologue_start_01f2bb72:


    "La curiosità guida i tuoi passi. Segui il suono fino all'entrata di un vicolo buio e sudicio."


translate ita prologue_start_c0632003:


    "Timidamente entri nel vicolo e fai un passo avanti..."


translate ita prologue_start_ee1644f5:


    "Il suolo bagnato dalla pioggia fa sembrare i tuoi passi più forti e sicuri di quanto tu ti senta."


translate ita prologue_start_a46fe60b:


    who "Miao! Miao!"


translate ita prologue_start_0141658f:


    "Finalmente, la sorgente del suono si rivela nella fredda, tenue luce del vicolo..."


translate ita prologue_start_7845feba:


    "Alla fine del vicolo, dentro una grande scatola di cartone..."


translate ita prologue_start_69a9648a:


    "... c'è un gatto."


translate ita prologue_start_e4ece72d:


    you "Uh. Immagino dovesse essere abbastanza ovvio..."


translate ita prologue_start_fc6b31f2:


    "È un gatto dall'aspetto curioso. I suoi begli occhi gialli scintillano come oro nell'oscuro mare di pelliccia."


translate ita prologue_start_3b9482ac:


    "Si appoggia con le zampe anteriori al bordo della scatola e ti osserva."


translate ita prologue_start_085f82bc:


    cat "Miao..."


translate ita prologue_start_632d1a35:


    you "!!!" with hpunch


translate ita prologue_start_8adec91e:


    you "{i}Che-{w}Che carino...!{/i}"


translate ita prologue_start_443266e6:


    "E lui ne è del tutto {i}consapevole{/i}..."


translate ita prologue_start_51df6142:


    "Non hai mai avuto un'opinione particolare sui gatti prima d'ora..."


translate ita prologue_start_6d340fc5:


    "Ma se sono tutti come questo qui..."


translate ita prologue_start_1074677c:


    "... è scioccante pensare che non abbiano ancora provato a conquistare il mondo."


translate ita prologue_start_1eb5cc4a:


    "Non sarebbe tanto male sottomettersi a un signore supremo dei felini."


translate ita prologue_start_dae0ec55:


    you "..."


translate ita prologue_start_1ca0cd0e:


    "Ti guardi attorno aggrottando le sopracciglia."


translate ita prologue_start_1d578264:


    you "Ma chi è che lascerebbe dei gatti in una semplice scatola di cartone? Gli basterebbe giusto un salto per uscire, no?"


translate ita prologue_start_7f0ac95c:


    cat "..."


translate ita prologue_start_1325c2b8:


    "Il gatto non ti risponde. {w}Ovviamente."


translate ita prologue_start_926d62e7:


    "E non segue neanche il tuo suggerimento di lasciare la scatola."


translate ita prologue_start_c6acd156:


    "Ti sta... fissando?"


translate ita prologue_start_67f65235:


    "Come se stesse aspettando la tua prossima mossa..."


translate ita prologueChoice1_c86cf436:


    "Con un sospiro, fai un passo deciso all'indietro."


translate ita prologueChoice1_e66a2c52:


    "Per quanto sia carino il gatto, non puoi proprio permetterti di adottare un animale di punto in bianco."


translate ita prologueChoice1_76b01b01:


    "Presto dovrai pagare l'affitto e il tuo lavoro non ti fa di certo navigare nell'oro..."


translate ita prologueChoice1_ecf3c1ab:


    "Guardi il gatto scuotendo tristemente la testa."


translate ita prologueChoice1_8199e4d6:


    you "Scusami... Buona fortuna per tutto, ok?"


translate ita prologueChoice1_7f0ac95c:


    cat "..."


translate ita prologueChoice1_4b339222:


    "Ti volti lasciandoti il gatto alle spalle."


translate ita prologueChoice1_93d0f774:


    "La pioggia sta aumentando."


translate ita prologueChoice1_a20cefa7:


    "..."


translate ita prologueChoice1_dd6fc7c7:


    "È ora di tornare a casa."


translate ita prologueChoice2_8dabefc6:


    ".."


translate ita prologueChoice2_a20cefa7:


    "..."


translate ita prologueChoice2_4122aacf:


    you "Sai che c'è...?"


translate ita prologueChoice2_5743aa48:


    "Allunghi le mani nella scatola e sollevi il gatto, tenendolo di fronte a te."


translate ita prologueChoice2_4907ebc0:


    you "... Perché no?"


translate ita prologueChoice2_e5fab8a0:


    cat "Miao!"


translate ita prologueChoice2_3abd7e46:


    you "Sei tutto solo e beh... Direi che siamo nella stessa barca io e te. Quindi..."


translate ita prologueChoice2_7dc50f87:


    "Avvicini il gatto a te."


translate ita prologueChoice2_bf60a3c6:


    "Non avevi notato che stesse tremando finora... ma non appena si stringe a te il suo respiro si fa più tranquillo."


translate ita prologueChoice2_5498dacc:


    you "... Che ne dici se ci facciamo compagnia? Almeno per un po'."


translate ita prologueChoice2_55355e09:


    cat "Purr... Purr..."


translate ita prologueChoice2_d091f8d9:


    "Per \"un po'\" intendi dire una giornata. Domani farai la cosa giusta portandolo a un rifugio per gatti, ma per ora..."


translate ita prologueChoice2_a7af763b:


    you "Ti porto al riparo da questa pioggia, ok?"


translate ita prologueChoice2_085f82bc:


    cat "Miao..."


translate ita prologueChoice2_6139ffca:


    "Ti fermi in un piccolo negozio per animali e prendi del cibo per gatti, poi vai a casa."


translate ita prologueChoice2_df101305:


    "Vivi in un piccolo appartamento."


translate ita prologueChoice2_247ad3ce:


    "Una camera da letto. Un bagno."


translate ita prologueChoice2_2d3f71e5:


    "Ci vivi {i}tu{/i}, tu e basta..."


translate ita prologueChoice2_f380a402:


    "Quindi ti sembra strano che ci sia un altro essere vivente dopo tanto tempo."


translate ita prologueChoice2_8b0c916e:


    "Anche se è {i}soltanto{/i} un gatto."


translate ita prologueChoice2_566e1d7f:


    "Dopo aver chiuso a chiave la porta e aver appoggiato il gatto a terra, lo osservi un po' mentre esplora incuriosito il nuovo ambiente."


translate ita prologueChoice2_fddd40fa:


    "Lasciando il felino a se stesso, ti metti all'opera per preparare la cena a entrambi."


translate ita prologueChoice2_c9d1a483:


    "Tiri fuori la scatoletta di cibo per gatti e la apri dalla linguetta."


translate ita prologueChoice2_e15d0030:


    "Metti un po' di pappa in una ciotola e chiami il gatto facendo schioccare la lingua."


translate ita prologueChoice2_b5c20577:


    "Lui raddrizza le orecchie al tuo richiamo e si avvicina in fretta."


translate ita prologueChoice2_be0440b9:


    "Guarda la ciotola col cibo..."


translate ita prologueChoice2_8dabefc6_1:


    ".."


translate ita prologueChoice2_a20cefa7_1:


    "..."


translate ita prologueChoice2_655f9b6a:


    "... e la ignora completamente."


translate ita prologueChoice2_a5cadf35:


    you "Sembra che tu non abbia fame..."


translate ita prologueChoice2_e322cfa9:


    "Cerchi di non farti infastidire da questa cosa."


translate ita prologueChoice2_ce62169f:


    "Il gatto non sa cosa sia il denaro e non può esserti riconoscente per aver speso i pochi soldi che guadagni."


translate ita prologueChoice2_562ebb7f:


    "È solamente un gatto, dopotutto."


translate ita prologueChoice2_bf6a731d:


    you "Te lo lascio lì... nel caso ti venga fame più tardi, ok?"


translate ita prologueChoice2_369ea70f:


    "Il gatto si struscia contro le tue gambe facendo le fusa."


translate ita prologueChoice2_94dc0c23:


    "Sorridi. Questo è un grazie più che sufficiente."


translate ita prologueChoice2_0bb73e9b:


    "Ti segue in cucina mentre inizi a preparare la cena."


translate ita prologueChoice2_41ce0cbe:


    "Pensi di avere gli ingredienti giusti per farti un tramezzino."


translate ita prologueChoice2_edb918a9:


    "Pane tostato... {w}Maionese e senape spalmati... {w}Tacchino, formaggio e lattuga perfettamente posizionati... {w}Pomodoro tagliato a fette--{w=0.3}{nw}"


translate ita prologueChoice2_dfc857fd:


    you "AHI!" with vpunch


translate ita prologueChoice2_0d62a972:


    "Sussulti ferendoti a un dito mentre tagli il pomodoro."


translate ita prologueChoice2_04d2c1e4:


    you "Che idiota..."


translate ita prologueChoice2_970b6c6e:


    "Ti senti un po' in imbarazzo per la tua sbadataggine. Con un sospiro lasci cadere il coltello sul tagliere."


translate ita prologueChoice2_3047da37:


    "Stai per andare a prendere un cerotto in bagno quando il gatto salta sul bancone."


translate ita prologueChoice2_316203fa:


    "Annusa il coltello e miagola visibilmente nella tua direzione."


translate ita prologueChoice2_eddf2ff6:


    you "Eheh... non preoccuparti, sto bene. È stato solo un--"


translate ita prologueChoice2_ca13fffe:


    you "!!!" with hpunch


translate ita prologueChoice2_e32ed4c0:


    "Ti fermi a guardare il gatto che inizia a..."


translate ita prologueChoice2_40d9ca73:


    "...?"


translate ita prologueChoice2_2f1c2108:


    "... leccare lievemente, ma con {b}entusiasmo{/b} il sangue sul coltello."


translate ita prologueChoice2_fe70304c:


    "Il {i}tuo{/i} sangue."


translate ita prologueChoice2_31324b11:


    "Lo shock è tale che, quando ti riprendi, il coltello è ormai del tutto pulito."


translate ita prologueChoice2_8477717d:


    "Il gatto si è seduto e ti sta guardando."


translate ita prologueChoice2_dae0ec55:


    you "..."


translate ita prologueChoice2_9b097520:


    "Ti {w}senti... un po' male."


translate ita prologueChoice2_23fd2960:


    "Certo, i gatti sono predatori... carnivori, ma questo è stato un po' strano."


translate ita prologueChoice2_01fb927e:


    "No...?"


translate ita prologueChoice2_7de205f2:


    "Certo, non ne saprai tanto sui gatti... ma di sicuro questo non sembra un comportamento comune..."


translate ita prologueChoice2_a20cefa7_2:


    "..."


translate ita prologueChoice2_c65aa055:


    "{size=-5}... No?{/size}"


translate ita prologueChoice2_e5fab8a0_1:


    cat "Miao!"


translate ita prologueChoice2_dae0ec55_1:


    you "..."


translate ita prologueChoice2_252add1f:


    "Comunque... Non ti sembra il caso di abbandonare un povero gatto sotto la pioggia. Non dopo tutto l'impegno che ci hai messo."


translate ita prologueChoice2_94b91a9f:


    "In fondo, domani lo porterai al rifugio. Cosa sarà mai una notte di stranezze?"


translate ita prologueChoice2_e1de2017:


    "Per quanto sia assurdo..."


translate ita prologueChoice2_e8d99b4a:


    "... è solo un gatto."


translate ita prologueChoice2_4141585e:


    "Il resto della serata, purtroppo, è destinato ad andare a rotoli."


translate ita prologueChoice2_a2f3b22c:


    "Anche dopo aver coperto il taglio con un cerotto, il gatto cerca di leccarti la ferita."


translate ita prologueChoice2_d1ec5fd6:


    "Mentre stai mangiando il tramezzino..."


translate ita prologueChoice2_20bbb144:


    "Mentre pulisci la cucina..."


translate ita prologueChoice2_960243fa:


    "Mentre provi a guardare la TV..."


translate ita prologueChoice2_59387313:


    "Lo spingi via delicatamente, ma stai iniziando a preoccuparti per questo strano comportamento."


translate ita prologueChoice2_f35db5a7:


    "E se avesse trovato il sangue di suo gusto e ora ti considerasse cibo? Non sai bene cosa fare nel caso diventi più aggressivo."


translate ita prologueChoice2_851a5259:


    "Continui a pensare al cibo per gatti là nell'angolo..."


translate ita prologueChoice2_f303bb24:


    "... intatto."


translate ita prologueChoice2_e5fab8a0_2:


    cat "Miao!"


translate ita prologueChoice2_5e84b463:


    cat "Miao! Miao!"


translate ita prologueChoice2_699a0b08:


    cat "Miao! Miao! {b}{i}Miao!{/i}{/b}" with hpunch


translate ita prologueChoice2_2d1f6e2d:


    you "Ooh, su avanti! {i}Smettila{/i} ora!"


translate ita prologueChoice2_2a835de7:


    "Lo spingi via un po' più forte adesso, da quanto ti ha fatto irritare."


translate ita prologueChoice2_80296b88:


    "Ti senti immediatamente in colpa, ma prima che tu possa fare altro il gatto ti miagola contro bruscamente per poi sparire dietro l'angolo dell'ingresso."


translate ita prologueChoice2_116e7855:


    "Fai un sospiro profondo."


translate ita prologueChoice2_eb31519a:


    "A questo punto, pensi che potrebbe anche morderti nel sonno."


translate ita prologueChoice2_5cac017b:


    you "{i}Forse un veterinario potrebbe avere qualche idea su come calmarlo...?{/i}"


translate ita prologueChoice2_760ce1f2:


    "È solo una speranza. Non pensi ti rimangano molte altre opzioni, tranne che gettare il gatto di nuovo sotto la pioggia..."


translate ita prologueChoice2_7e95c19a:


    "Dopo aver trovato il numero di un veterinario nelle vicinanze..."


translate ita prologueChoice2_684db044:


    "... prendi il telefono e--{w=1.0}{nw}"


translate ita prologueChoice2_28b3ac41:


    you "!!!"


translate ita prologueChoice2_8ca8510a:


    you "!!!" with vpunch


translate ita prologueChoice2_a66b8231:


    "Le luci si sono..."


translate ita prologueChoice2_f41aa0f8:


    "... spente?"


translate ita prologueChoice2_dec218fc:


    "Bene. Fantastico. La pioggia ha fatto saltare la corrente."


translate ita prologueChoice2_eb2b6f8b:


    "Controlli il telefono e ti accorgi che è scarico."


translate ita prologueChoice2_adcad194:


    "Avevi dimenticato di caricarlo prima di uscire di casa."


translate ita prologueChoice2_b129dbc5:


    "La passeggiata è stata così imprevista che di certo ha sfasato la tua routine quotidiana."


translate ita prologueChoice2_a7869f4a:


    "Prendi una torcia e l'accendi."


translate ita prologueChoice2_8dabefc6_2:


    ".."


translate ita prologueChoice2_a20cefa7_3:


    "..."


translate ita prologueChoice2_eff9b4f7:


    "C'è silenzio."


translate ita prologueChoice2_a3038114:


    "{i}Troppo{/i} silenzio."


translate ita prologueChoice2_f816a0f7:


    "Ha smesso di piovere?"


translate ita prologueChoice2_3e305a49:


    "Ma allora... perché è saltata la corrente?"


translate ita prologueChoice2_a20cefa7_4:


    "..."


translate ita prologueChoice2_b6a58494:


    "Guardi fuori."


translate ita prologueChoice2_0eccd9ec:


    "Il cielo è tutto nero. Che ora è?"


translate ita prologueChoice2_22796bbb:


    "Ti giri per controllare l'orologio..."


translate ita prologueChoice2_479c3431:


    you "!!!" with vpunch


translate ita prologueChoice2_67438124:


    "Il gatto è seduto sull'orologio digitale e ti sta fissando."


translate ita prologueChoice2_cc2a0af7:


    "A pensarci bene, l'orologio non dovrebbe funzionare senza elettricità, eppure i numeri sono accesi..."


translate ita prologueChoice2_8ce74938:


    "... e sono completamente in tilt."


translate ita prologueChoice2_a4473e29:


    "Il gatto ti sta fissando. È immobile. Se non sapessi che è vivo diresti che si tratta di una statua."


translate ita prologueChoice2_1859d2a8:


    "Non trasmette il minimo segno di vitalità."


translate ita prologueChoice2_e2df05b3:


    "Non muove neanche gli occhi. Non sembra nemmeno che respiri. Ma..."


translate ita prologueChoice2_e9e5efea:


    "... i suoi occhi..."


translate ita prologueChoice2_a20cefa7_5:


    "..."


translate ita prologueChoice2_31ac1903:


    "Tutto questo... non è normale."


translate ita prologueChoice2_9804c7b0:


    "Hai paura."


translate ita prologueChoice2_65973cff:


    "Vorresti scappare, ma non vuoi rischiare di perderlo di vista."


translate ita prologueChoice2_9c9d6223:


    "Potresti ancora buttarlo fuori dopotutto..."


translate ita prologueChoice2_bf0874e3:


    "Ma..."


translate ita prologueChoice2_d73fee82:


    "... non appena il pensiero ti sfiora, {w} ti sale un conato di vomito."


translate ita prologueChoice2_f0883f9b:


    "Quegli occhi... I suoi occhi ti inchiodano sul posto."


translate ita prologueChoice2_3a7a79cb:


    "Anche se gli hai puntato contro una torcia..."


translate ita prologueChoice2_f6f81472:


    "Le sue pupille sono dei grandi pozzi circolari--{w=2.0}{nw}"


translate ita prologueChoice2_28b3ac41_1:


    you "!!!"


translate ita prologueChoice2_82828c42:


    "La luce della torcia sfarfalla..."


translate ita prologueChoice2_8dabefc6_3:


    ".."


translate ita prologueChoice2_a20cefa7_6:


    "..."


translate ita prologueChoice2_c6952d96:


    "... e il gatto scompare."


translate ita prologueChoice2_14176a20:


    "La paura ti avvolge subito la mente."


translate ita prologueChoice2_447e9442:


    "Il silenzio opprimente e i battiti impazziti del tuo cuore..."


translate ita prologueChoice2_5f6e3577:


    "... vengono gradualmente coperti dai rumori della stanza in cui ti trovi."


translate ita prologueChoice2_84a95582:


    "Come può funzionare l'orologio senza corrente...?"


translate ita prologueChoice2_2a8eb917:


    "Non sai dire perché la tua mente si concentri su questo al momento..."


translate ita prologueChoice2_e79a1e8f:


    "... ma senti che se avessi una risposta, tutto riacquisterebbe più senso."


translate ita prologueChoice2_741f7e05:


    "E l'ordine verrebbe ristabilito."


translate ita prologueChoice2_a20cefa7_7:


    "..."


translate ita prologueChoice2_30396cff:


    "Ma non trovi risposte."


translate ita prologueChoice2_f028268f:


    "Ti allontani dall'orologio..."


translate ita prologueChoice2_dbe9efe4:


    "... e l'aria sembra subito caricarsi di tensione..."


translate ita prologueChoice2_cc431bef:


    "... come un predatore che si prepara a colpire..."


translate ita prologueChoice2_7331e0b1:


    "... in attesa."


translate ita prologueChoice2_d877d809:


    "In attesa... della tua prossima mossa."


translate ita prologueChoice2_e0dc85ac:


    "Ma tu non osi muoverti. {w}Hai perfino paura di respirare."


translate ita prologueChoice2_a20cefa7_8:


    "..."


translate ita prologueChoice2_ac25f573:


    "Ma non puoi rimanere immobile per sempre... giusto?"


translate ita prologueChoice2_c2f2e565:


    "Qualunque cosa ti stia osservando... si sta già spazientendo."


translate ita prologueChoice2_af10a9a1:


    "La sua bramosia è palpabile."


translate ita prologueChoice2_80a275c9:


    "Non sai come sia possibile... {w}ma puoi sentirla come se ti stesse sussurrando--"


translate ita prologueChoice2_a20cefa7_9:


    "..."


translate ita prologueChoice2_4bca7969:


    "... direttamente all'orecchio."


translate ita prologueChoice2_176e11ae:


    "Direttamente alla tua {i}anima...{/i}"


translate ita prologueChoice2_a20cefa7_10:


    "..."


translate ita prologueChoice2_590cf3c1:


    "Non aspetterà a lungo. Non che tu abbia molta {i}scelta{/i} in merito."


translate ita prologueChoice2_7b913dcf:


    "Non puoi rimanere qui."


translate ita prologueChoice2_55578b69:


    "Devi {i}scappare{/i}."


translate ita prologueChoice2_8f91c31e:


    "Con questo pensiero, un improvviso istinto primordiale si risveglia in te..."


translate ita prologueChoice2_b8f3a2d1:


    "... facendoti scattare con un movimento rapido e improvviso."


translate ita prologueChoice2_9d930911:


    "Senti che devi {i}agire{/i}."


translate ita prologueChoice2_bf0874e3_1:


    "Ma..."


translate ita prologueChoice2_314b731c:


    "... ti senti ancora debole per la paura."


translate ita prologueChoice2_aaefb8e2:


    "Le gambe ti tradiscono e nella fretta cadi a terra."


translate ita prologueChoice2_8ca8510a_1:


    you "!!!" with vpunch


translate ita prologueChoice2_75f6eebc:


    "Improvvisamente, senti un dolore acuto al piede."


translate ita prologueChoice2_741dce68:


    "Pensi subito che possa essersi rotta la caviglia..."


translate ita prologueChoice2_b904d1f8:


    "... ma qualcosa di caldo e {i}bagnato{/i} ti scorre lungo il piede, formando una pozza a terra."


translate ita prologueChoice2_b7ab4763:


    "Scivolando sul pavimento, senti un suono metallico contro le piastrelle... come se qualcosa venisse calciato..."


translate ita prologueChoice2_db2b1596:


    "Col respiro affannoso per la caduta, guardi con stupore l'oggetto che brilla di una strana luce proveniente da fuori..."


translate ita prologueChoice2_05b49e6d:


    "... la luce che entra dalla tua porta d'ingresso, ora {b}aperta{/b}."


translate ita prologueChoice2_b61a396d:


    "Le domande su chi, come, quando e {i}cosa{/i} abbia aperto la porta ti bloccano all'improvviso..."


translate ita prologueChoice2_d4e0cc13:


    "... mentre il tuo cervello identifica finalmente l'oggetto che stai fissando..."


translate ita prologueChoice2_40d9ca73_1:


    "...?"


translate ita prologueChoice2_2e361f97:


    "È il tuo coltello da cucina..."


translate ita prologueChoice2_8546520a:


    "Com'è possibile che sia ancora rosso dal taglio di prima...? Qualcosa non torna."


translate ita prologueChoice2_38a7b342:


    "Non era stato ripulito del tutto dal...?"


translate ita prologueChoice2_dae0ec55_2:


    you "..."


translate ita prologueChoice2_f5f34102:


    "Deglutisci con la gola secca per il dolore al piede."


translate ita prologueChoice2_fe5b649d:


    "Non fai in tempo a chiederti come il coltello sia potuto finire {i}sul pavimento in salotto{/i}..."


translate ita prologueChoice2_21d29f45:


    "... anziché trovarsi sul tagliere in {i}cucina{/i} dove lo avevi lasciato..."


translate ita prologueChoice2_f0b53c63:


    "... che qualcosa nell'ombra attrae il tuo sguardo..."


translate ita prologueChoice2_a20cefa7_11:


    "..."


translate ita prologueChoice2_e77542e3:


    "Ti guarda a sua volta."


translate ita prologueChoice2_10142e0e:


    "Vedi un paio di occhi dorati e scintillanti avvicinarsi. Il gatto emerge dall'ombra, camminando verso la luce che filtra dalla porta."


translate ita prologueChoice2_e5652646:


    "Si muove leggiadro verso il coltello, come se stesse saltellando di gioia..."


translate ita prologueChoice2_70938f8a:


    "... e si china a leccare il sangue che sgocciola dalla lama."


translate ita prologueChoice2_ed5ea61e:


    you "Ah..."


translate ita prologueChoice2_393f5166:


    "I tuoi sensi cominciano a sopraffarti."


translate ita prologueChoice2_2a730601:


    "L'aria fredda che inizia a soffocarti sotto il suo peso..."


translate ita prologueChoice2_1593a3aa:


    "Il suono dei tuoi respiri tremolanti, in disarmonia con i rumori statici che ti perforano le orecchie..."


translate ita prologueChoice2_ed11f665:


    "La secchezza della tua lingua che si espande nella gola..."


translate ita prologueChoice2_34bcc68c:


    "La vista incomprensibile del randagio che hai accolto in casa... che {w}{i}lecca{/i} il coltello da cucina... ripulendolo del tutto..."


translate ita prologueChoice2_b0a9a5c6:


    "L'odore del sangue della ferita al piede..."


translate ita prologueChoice2_40d9ca73_2:


    "...?"


translate ita prologueChoice2_eed16faf:


    "Sangue...?"


translate ita prologueChoice2_7f0ac95c:


    cat "..."


translate ita prologueChoice2_50e9be35:


    "Ti fissa con quegli occhi dorati come in risposta al recente pensiero..."


translate ita prologueChoice2_281091c2:


    "Sangue..."


translate ita prologueChoice2_8ffe853a:


    "La ferita è dolorante..."


translate ita prologueChoice2_9224c60b:


    "Stai perdendo molto sangue dal piede..."


translate ita prologueChoice2_8121a06c:


    "Ti stai dissanguando..."


translate ita prologueChoice2_00bb4f59:


    "Ti stai {b}{i}{color=#FF0000}dissanguando{/color}{/i}{/b}."


translate ita prologueChoice2_2da587a4:


    "Il gatto si muove appena, le sue spalle fremono, come se stesse {i}considerando{/i} l'idea di saltarti addosso..."


translate ita prologueChoice2_a20cefa7_12:


    "..."


translate ita prologueChoice2_3b91b0ca:


    "Ma tu sei già in piedi e fuori dalla porta."


translate ita prologueChoice2_5f801ea2:


    "Corri, o meglio, {i}ti lanci{/i} verso la strada deserta."


translate ita prologueChoice2_ccea669c:


    "Il cielo è nero e sembra sanguinare..."


translate ita prologueChoice2_cfd4e5e1:


    "... ma c'è una strana luce diffusa che dipinge tutto il resto di bianco."


translate ita prologueChoice2_09cf8ffc:


    "Le case, gli alberi, la strada e perfino te..."


translate ita prologueChoice2_e4427836:


    "{i}Ogni cosa{/i}..."


translate ita prologueChoice2_220b03d6:


    "... tranne il tuo sangue."


translate ita prologueChoice2_a7c4df5f:


    "Riesci a malapena a vedere le impronte insanguinate che il tuo piede ferito ha lasciato a ogni passo sul terreno."


translate ita prologueChoice2_62c0c671:


    "Fa male..."


translate ita prologueChoice2_e6f06c3d:


    "Fa {i}male{/i}."


translate ita prologueChoice2_3dd82419:


    "Ma non puoi fermarti. E {i}non{/i} ti fermi."


translate ita prologueChoice2_511a53e8:


    "Non lo fai quando le ombre ti crescono attorno..."


translate ita prologueChoice2_c94026dc:


    "Non lo fai quando ti senti gli occhi addosso..."


translate ita prologueChoice2_11fab02e:


    "E nemmeno quando sulla strada davanti a te si staglia la lunga ombra di {i}qualcosa{/i} alle tue spalle."


translate ita prologueChoice2_24687875:


    "Anche allora... non smetti di correre. Perché..."


translate ita prologueChoice2_d31c0957:


    "Se quello davanti a te è il gatto..."


translate ita prologueChoice2_f64ee9d8:


    "Allora..."


translate ita prologueChoice2_a20cefa7_13:


    "..."


translate ita prologueChoice2_39b2e350:


    "{size=-8}... cosa diavolo c'è dietro di te?{/size}"


translate ita prologueEND1_45eb1440:


    "Finale ?: Qui Gatta Ci Cova"


translate ita prologueEND2_6f50b679:


    who "..."


translate ita prologueEND2_2821b9de:


    who "Uh... {w}Interessante..."


translate ita prologueEND2_c29791ce:


    who "Davvero, davvero... interessante..."


translate ita prologueEND2_a20cefa7:


    "..."


translate ita prologueEND2_b715ae86:


    "Finale 0: L'inizio"

translate ita strings:


    old "Do not take cat home"
    new "Non portare il gatto a casa"


    old "Take cat home"
    new "Porta il gatto a casa"

    old "Let's play~"
    new "Giochiamo~"


    old "Look behind you."
    new "Girati"


    old "Keep running."
    new "Continua a correre"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
