


translate ita encounterCat_a20cefa7:


    "..."


translate ita encounterCat_07879361:


    "Di nuovo qui, eh?"


translate ita encounterCat_310653c5:


    "Hai già raggiunto il risultato migliore a cui potessi aspirare."


translate ita encounterCat_4961a2a7:


    "Cosa speri di ottenere di più?"


translate ita encounterCat_8dabefc6:


    ".."


translate ita encounterCat_a20cefa7_1:


    "..."


translate ita encounterCat_ebdf273c:


    "Non penseresti mai di rompere la promessa di unirti a me..."


translate ita encounterCat_810e5b21:


    "{color=#FF0000}... giusto?{/color}"


translate ita encounterCat_beec6484:


    "Non ho ancora soddisfatto la tua curiosità?"


translate ita encounterCat_a20cefa7_2:


    "..."


translate ita encounterCat_90b68c87:


    you "...?"


translate ita encounterCat_19d97e41:


    you "{i}Dove... {w}Dove sono...?{/i}"


translate ita encounterCat_a20cefa7_3:


    "..."


translate ita encounterCat_3fdc70e9:


    "{alpha=0.4}E così...{/alpha}"


translate ita encounterCat_ef29c92b:


    "{alpha=0.7}Sei qui...{/alpha}"


translate ita encounterCat_5032d21f:


    "... un'altra volta."


translate ita encounterCat_28b3ac41:


    you "!!!"


translate ita encounterCat_5991bb93:


    you "Cos-"


translate ita encounterCat_548c1316:


    you "Chi ha parlato?!?"


translate ita encounterCat_964f0af4:


    you "E {i}\"qui\"{/i} dov'è? {w}Non riesco a {i}vedere{/i} nulla!"


translate ita encounterCat_a20cefa7_4:


    "..."


translate ita encounterCat_f27122fb:


    who "Perché..."


translate ita encounterCat_a995ea3c:


    cat "... \"qui\" è {i}qui,{/i} idiota!"


translate ita encounterCat_56ebb028:


    you "!!!"


translate ita encounterCat_2a440d93:


    you "S... Sei..."


translate ita encounterCat_49e410bc:


    cat "Beh? {w}Ti ricordi di me, stavolta?"


translate ita encounterCat_187ca1e5:


    cat "Non avrei mai pensato che qualcuno si potesse dimenticare di me..."


translate ita encounterCat_cfb7cc33:


    cat "... ma a quanto pare c'è una prima volta per tutto~!"


translate ita encounterCat_dae0ec55:


    you "..."


translate ita encounterCat_48bb4310:


    "La tua memoria ricompone lentamente i frammenti di un ricordo... {w}Un incontro..."


translate ita encounterCat_b4fa62a0:


    you "Un gatto in... {w}in un vicolo..."


translate ita encounterCat_b5914067:


    you "Ti... {w}ho portato a casa con me... {w}non è vero?"


translate ita encounterCat_c46e050e:


    cat "{size=+5}{b}Esatto!{/b}{/size}" with hpunch


translate ita encounterCat_e32fc389:


    cat "Hai fantasticato così a lungo che persino {i}io{/i} mi sono preoccupato! {w}Te lo immagini?"


translate ita encounterCat_42fcd5d4:


    cat "Io stavo solo giocherellando un po' con la mia preda..."


translate ita encounterCat_8cf8606b:


    cat "... e tu hai scelto di ignorarmi per tutta risposta!"


translate ita encounterCat_dc1e93f2:


    cat "Il gioco non è bello se non sei {i}presente{/i}, sai..."


translate ita encounterCat_99f64913:


    you "Io..."


translate ita encounterCat_d26ddf18:


    you "No, {i}non{/i} lo so! Non capisco proprio cosa sta succedendo!"


translate ita encounterCat_10cb6b4e:


    cat "Uhm... Data la tua curiosità, mi sarei aspettato che avessi delle domande..."


translate ita encounterCat_c3e84f44:


    cat "Bene, credo tu mi abbia fatto divertire abbastanza, sarò magnanimo e dissiperò i tuoi dubbi..."


translate ita encounterCat_6a840c3c:


    cat "Molto bene..."


translate ita questionCat_44076b5e:


    cat "Cosa vorresti sapere~?"


translate ita noMoreQuestions_be011780:


    "Davvero?"


translate ita noMoreQuestions_b132aa27:


    "La tua curiosità non è così grande dopotutto..."


translate ita noMoreQuestions_b3e12ea5:


    "Eppure..."


translate ita moreQuestions_e92c7456:


    "Quindi... lo chiederò ancora..."


translate ita moreQuestions_92e00d5e:


    "Sono sicuro che darai la risposta corretta."


translate ita moreQuestions_cc5f9d9d:


    "Ti unirai a me..."


translate ita moreQuestions_560e6e27:


    "... o morirai?"


translate ita moreQuestions_6b3fef84:


    "No?"


translate ita moreQuestions_76297ef4:


    "Beh, in questo caso..."


translate ita questionCat1_c495dba3:


    cat "Uhm... È la prima cosa che mi è venuta in mente, davvero."


translate ita questionCat1_64bab19b:


    cat "Eri a un passo dalla morte..."


translate ita questionCat1_0c0abb1c:


    cat "Ma invece di guardare la tua vita scorrerti davanti agli occhi..."


translate ita questionCat1_fa75ee80:


    cat "... continuavi a rivivere il ricordo del nostro incontro... {w}pensando a scenari in cui riuscivi a sopravvivere."


translate ita questionCat1_e15e92be:


    cat "Bene. {w}Forse {i}ce l'avresti fatta{/i}... ma..."


translate ita questionCat1_c0153aab:


    cat "Non ho resistito a giocare un po' con la tua immaginazione~"


translate ita questionCat1_7b103b48:


    cat "Dopotutto, hai iniziato {i}tu{/i} a ignorarmi all'improvviso."


translate ita questionCat1_e24fd6e6:


    cat "Ormai lo sai quanto io ami le attenzioni~"


translate ita questionCat1_5f80ea18:


    cat "I tuoi piccoli esperimenti mentali erano anche divertenti..."


translate ita questionCat1_315adaa1:


    cat "Ma... se posso permettermi..."


translate ita questionCat1_23467746:


    cat "... devi aver avuto una vita {i}parecchio{/i} noiosa se hai rinunciato al ricordo di preziosi momenti passati..."


translate ita questionCat1_d06d7a92:


    cat "... per poter continuare a fantasticare su un singolo incontro..."


translate ita questionCat1_05c50243:


    cat "... ancora e ancora."


translate ita questionCat1_6de8f265:


    cat "Ho sentito dire che spesso si hanno rimpianti in punto di morte, ma tutto questo è assurdo!"


translate ita questionCat1_a20cefa7:


    "..."


translate ita questionCat1_d4a2484f:


    cat "... Assurdamente {i}intrigante,{/i} ecco cosa!"


translate ita questionCat1_89d17f6f:


    cat "O forse, piuttosto che i rimpianti, ciò che trovavi intrigante ero {i}{b}IO{/b}~?"


translate ita questionCat1_153670a4:


    cat "Dal momento che ti ricordi di me, direi che sei cosciente..."


translate ita questionCat1_f61b0df4:


    cat "Sembra che tu voglia mettere fine a questa farsa... per quanto divertente sia stata."


translate ita questionCat2_78b85363:


    cat "Nella tua testa, imbecille!"


translate ita questionCat2_3b6637ed:


    cat "Le versioni reali di noi stessi sono ferme nel tempo della tua dimensione. Non è passato davvero così tanto."


translate ita questionCat2_cea70401:


    cat "Dopotutto, queste cose tendono a succedere in un batter d'occhio..."


translate ita questionCat2_90ceece1:


    cat "Beh... {w}{i}di solito,{/i} almeno."


translate ita questionCat3_91c433ff:


    cat "Oh, non angosciarti~"


translate ita questionCat3_628a0e7a:


    cat "Non {i}continuo{/i} a ucciderti! Non ti ho ancora ucciso neanche {i}una{/i} volta..."


translate ita questionCat3_d29cd430:


    cat "Erano solo pensieri e idee che ti frullavano per la testa..."


translate ita questionCat3_03a9b169:


    cat "... lo ammetto, è stato divertente."


translate ita questionCat3_faf0ac79:


    cat "Puoi biasimarmi? Mi sarei {i}annoiato{/i} aspettando che tu ti svegliassi senza far nulla."


translate ita questionCat3_444467b1:


    cat "Mmh, sì... ero solo curioso di vedere se lo avresti fatto davvero."


translate ita questionCat3_bbec1b37:


    cat "Devo dire che ci hai proprio dato dentro... {w}Avevi un po' di rabbia repressa?~"


translate ita questionCat3_142ac461:


    cat "Va tutto bene. Lo sai cosa si dice della curiosità, no?"


translate ita questionCat3_9d6e8628:


    cat "È stata una mia scelta. E inoltre..."


translate ita questionCat3_7b530356:


    cat "{color=#FF0000}... Sei di nuovo con me, giusto~?{/color}"


translate ita questionCat4_346e4804:


    cat "...? Che vuoi dire?"


translate ita questionCat4_723b2270:


    cat "Ho parlato con te per tutto il tempo."


translate ita questionCat4_2537f593:


    cat "Per quanto sia intrigante la tua immaginazione, sarebbe fuori controllo senza di me."


translate ita questionCat4_6dea765f:


    "Sono stato io a {b}guidarti{/b} per {i}tutto{/i} il tempo..."


translate ita questionCat4_8ca8510a:


    you "!!!" with vpunch


translate ita questionCat4_a7b878cb:


    "Non mi hai sentito nei tuoi pensieri...?"


translate ita questionCat4_40a8ff0b:


    "Tipo {i}così~?{/i}"


translate ita questionCat4_dae0ec55:


    you "..."


translate ita questionCat4_4ee1bb0a:


    cat "Sono piuttosto potente, sì... ma non a tal punto."


translate ita questionCat4_f6a21734:


    you "{i}E {b}questo{/b} cosa significa...?{/i}"


translate ita questionCat4_6f7f3d7e:


    cat "E poi, cosa ti assicura che io sia un gatto?"


translate ita questionCat4_9f54e05d:


    cat "Il mio aspetto? Dubito di assomigliare a qualsiasi gatto che tu abbia mai visto."


translate ita questionCat4_8e3ec6ea:


    you "Allora che diavolo sei, se non sei un gatto?"


translate ita questionCat4_2373210e:


    cat "Non ho detto che {i}non{/i} sono un gatto, giusto?"


translate ita questionCat4_dae0ec55_1:


    you "..."


translate ita questionCat4_7f0ac95c:


    cat "..."


translate ita questionCat4_0c9311a0:


    cat "Potrei essere un demone... {w}o un dio... {w}o un alieno di un'altra galassia... {w}o un abominio interdimensionale..."


translate ita questionCat4_7338daf3:


    cat "... oppure {i}potrei{/i} davvero essere solo un gatto."


translate ita questionCat4_0239290e:


    cat "Non è {i}così{/i} importante cosa io sia, giusto?"


translate ita questionCat4_1c318240:


    cat "Magari è quello che posso {b}fare{/b} ciò che conta di più, non pensi?"


translate ita questionCat4_a00b7c5d:


    you "Un vero gatto non avrebbe potuto fare tutto questo!"


translate ita questionCat4_5ef345ac:


    cat "Hai proprio una fissazione per l'aspetto, vero...?"


translate ita questionCat4_ec53df3b:


    cat "Hai qualche prova che i gatti {i}non{/i} possiedano poteri come i miei? {w}Ne dubito~"


translate ita questionCat4_89c7e144:


    cat "Comunque, è piuttosto antipatico da parte tua discutere di continuo di {i}cosa{/i} io sia..."


translate ita questionCat4_6ab4c9ee:


    cat "... visto che non mi hai nemmeno chiesto {i}chi{/i} sono o come mi {i}chiamo{/i}!"


translate ita questionCat4_dae0ec55_2:


    you "..."


translate ita questionCat4_976ad5e8:


    you "*sigh* Ok... allora come ti chiam-"


translate ita questionCat4_7494f9b5:


    cat "Beh, non te lo dirò mica {i}{b}adesso!{/b}{/i}"


translate ita questionCat4_bf0f44ce:


    cat "Impara le buone maniere, e forse te lo dirò. {w}Beh..."


translate ita questionCat4_23bc3a7d:


    cat "... nella tua {i}prossima{/i} vita, s'intende."


translate ita questionCat5_0a5f3e64:


    cat "Uhm..."


translate ita questionCat5_9dde11ef:


    cat "Se stiamo parlando dei miei piani originali, beh... è una questione un po' personale, direi."


translate ita questionCat5_dae0ec55:


    you "..."


translate ita questionCat5_b3148994:


    cat "E poi, le cose sono cambiate!"


translate ita questionCat5_c5905ab0:


    cat "In questo istante?"


translate ita questionCat5_ea6e786a:


    cat "Beh, al momento, vorrei divertirmi un altro po' con te. {w}Stare in tua compagnia si è dimostrato interessante finora."


translate ita questionCat5_03ab381b:


    cat "Se avessimo avuto più tempo... {w}e le circostanze fossero state diverse... {w}forse avremmo potuto essere..."


translate ita questionCat5_7f0ac95c:


    cat "..."


translate ita questionCat5_c38e7b98:


    cat "In ogni caso... tutte le cose belle finiscono."


translate ita questionCat5_1029e671:


    cat "Non vuoi passare il poco tempo che ti resta a piangerti addosso e delirare, giusto?"


translate ita questionCat5_d4182ef1:


    cat "C'è da dire però che {w}sono abbastanza {i}affamato{/i} dopo aver aspettato così a lungo che ti svegliassi."


translate ita questionCat5_fd56ebb0:


    cat "A questo punto, non saprei decidermi."


translate ita finalQuestion_1e7e7eba:


    cat "Ho soddisfatto la tua curiosità?"


translate ita finalQuestion_dae0ec55:


    you "..."


translate ita finalQuestion_97e7bd6b:


    you "Ho un'ultima domanda..."


translate ita finalQuestion_36d620f5:


    you "Perché me? Perché chiamare proprio {i}me{/i} tra tutti...?"


translate ita finalQuestion_91cd85d7:


    cat "Io ho solo chiamato {i}qualcuno{/i} perché mi sentisse."


translate ita finalQuestion_aae09cc1:


    cat "Ho chiamato... e tu sei stata la prima persona a trovarmi. {w}Tutto qui."


translate ita finalQuestion_dae0ec55_1:


    you "..."


translate ita finalQuestion_25add7f4:


    cat "... Speravi ci fosse una ragione speciale?"


translate ita finalQuestion_dae0ec55_2:


    you "..."


translate ita finalQuestion_e304cf84:


    cat "... Ho paura che non ci sia."


translate ita finalQuestion_5d037f74:


    cat "Quello che mi piace di te, l'ho scoperto {i}dopo{/i} il nostro primo incontro."


translate ita finalQuestion_9e1cd95d:


    you "Quindi non c'è nessun grande piano dietro tutto questo?"


translate ita finalQuestion_c86c8dcc:


    cat "La ragione è molto meno interessante dei risultati che sono nati dalla nostra interazione."


translate ita finalQuestion_1ff3d913:


    cat "Ho chiamato per soddisfare la mia fame ma, facendo ciò, ho trovato qualcosa di molto più prezioso."


translate ita finalQuestion_8f6f37e7:


    cat "So che qualunque sia l'esito di questa storia..."


translate ita finalQuestion_f1cd85f2:


    cat "... non ti dimenticherò mai."


translate ita finalQuestion_fec1fe3c:


    you "Che intendi?"


translate ita returnOrigin_bf22af67:


    cat "Ti ho preso in simpatia, mortale. Quindi... ti darò un'altra possibilità..."


translate ita returnOrigin_42029590:


    cat "Un'altra possibilità..."


translate ita returnOrigin_479c3431:


    you "!!!" with vpunch


translate ita returnOrigin_8e03588c:


    you "{i}Questo posto è...{/i}"


translate ita returnOrigin_a20cefa7:


    "..."


translate ita returnOrigin_9c3e8dd9:


    "Ti {i}{b}ricordi{/b}{/i} di questo posto..."


translate ita returnOrigin_f1426fe6:


    "Dell'inseguimento..."


translate ita returnOrigin_626dfd4e:


    "Del sentirti una {b}preda{/b}..."


translate ita returnOrigin_c204d717:


    "Della paura..."


translate ita returnOrigin_7591fb3e:


    "{b}Tanta{/b} paura..."


translate ita returnOrigin_642290f0:


    "Quella paura che {i}tanto{/i} mi attirava a te..."


translate ita returnOrigin_eee55388:


    "... Quel bisogno disperato e istintivo di sopravvivere..."


translate ita returnOrigin_f7d54ac5:


    "Ho desiderato tutte queste cose..."


translate ita returnOrigin_738c58c2:


    "Dato che l'origine di queste succulente emozioni sono io..."


translate ita returnOrigin_850be2a3:


    "... vuol dire che tu {b}mi appartieni{/b} \ {i}g i à .{/i} "


translate ita returnOrigin_a20cefa7_1:


    "..."


translate ita returnOrigin_bf0874e3:


    "Ma..."


translate ita returnOrigin_9042cfe9:


    "Ti permetterò di accettare la realtà del tuo fato."


translate ita returnOrigin_186f39f2:


    cat "Mortale..."


translate ita returnOrigin_e8f7c347:


    cat "Unisciti a me..."


translate ita returnOrigin_aca58e0a:


    cat "... o perisci."


translate ita joinCat_cd8ba4c0:


    cat "Splendido."


translate ita joinCat_1ab5bac9:


    cat "Fatti avanti, mortale."


translate ita joinCat_2c7927e3:


    "Ti fai avanti e prendi in braccio il gatto."


translate ita joinCat_e00dae14:


    "Lo stringi a te e allunghi una mano per grattargli la testa."


translate ita joinCat_67107e6c:


    cat "Purr..."


translate ita joinCat_f8342e66:


    "D'un tratto..."


translate ita joinCat_b0821d91:


    you "Che...?"


translate ita joinCat_d401595a:


    "... Cominci a sentire... {w}sonno."


translate ita joinCat_69c0188b:


    "Ma l'improvvisa ondata di fatica non ti fa perdere l'equilibrio o inciampare."


translate ita joinCat_cedc8e66:


    you "Ma che... che... succ...?"


translate ita joinCat_5e8da3e5:


    cat "Shh..."


translate ita joinCat_b474b001:


    cat "Non temere... Non dovrai più preoccuparti di nulla da ora in avanti..."


translate ita joinCat_85b30929:


    cat "Dormi... e fai dolci, dolci sogni... per me..."


translate ita joinCat_dae0ec55:


    you "..."


translate ita joinCat_2f74697b:


    you "... {w}... {w}..."


translate ita joinCat_60daf151:


    cat "... Eccellente."


translate ita joinCat_7a46e73a:


    cat "In questo modo, diventerai presto parte di me..."


translate ita joinCat_8dabefc6:


    ".."


translate ita joinCat_a20cefa7:


    "..."


translate ita joinCat_a110b86c:


    "Finale 37: \ {b}P e r S e m p r e{/b}"


translate ita refuseCat_4599308d:


    cat ".."


translate ita refuseCat_7f0ac95c:


    cat "..."


translate ita refuseCat_1280d577:


    cat "Capisco. Allora non c'è altro da dire."


translate ita refuseCat_dae0ec55:


    you "..."


translate ita refuseCat_401c177b:


    cat "...{w}\"Rassegnandoti al tuo destino...\""


translate ita refuseCat_568bc2ee:


    "... decidi finalmente {w}{b} d i {w} g i r a r t i .{/b}"


translate ita refuseCat_8dabefc6:


    ".."


translate ita refuseCat_a20cefa7:


    "..."


translate ita refuseCat_998be557:


    "... È {i}{b}enorme.{/b}{/i}"


translate ita refuseCat_073f9da6:


    "Informe... e si innalza nell'aria come fumo denso..."


translate ita refuseCat_2e28e1bd:


    "L'entità d'ombra torreggia su di te..."


translate ita refuseCat_9e637eeb:


    "È così alta da sembrare che il cielo l'abbia scaraventata sulla terra... e che stia {i}ancora{/i} precipitando..."


translate ita refuseCat_1d4c6563:


    "È... inspiegabile... come il tuo piccolo mondo sia capace di reggere..."


translate ita refuseCat_1aee61d8:


    "... il peso della {i}realtà{/i} di un'esistenza come questa..."


translate ita refuseCat_57d2ac22:


    "... e come {i}tu{/i} e la tua fragile mente non siate crollati."


translate ita refuseCat_a20cefa7_1:


    "..."


translate ita refuseCat_bedb2983:


    "Fai un passo avanti verso il mostruoso miasma..."


translate ita refuseCat_a20cefa7_2:


    "..."


translate ita refuseCat_b290aff1:


    "... e ti offri a esso."


translate ita refuseCat_8dabefc6_1:


    ".."


translate ita refuseCat_a20cefa7_3:


    "..."


translate ita refuseCat_ce151d3e:


    "{b}{size=+5}o s c u r i t à . . .{/size}{/b}"


translate ita refuseCat_9255f3aa:


    "Intorno a te c'è un'oscurità pura e assoluta..."


translate ita refuseCat_1ecc4a0c:


    "... e improvvisamente hai la sensazione..."


translate ita refuseCat_ba4f1a80:


    "{size=-10}... che ci sia qualcun {b}altro{/b}.{/size}"


translate ita refuseCat_0a4a23c7:


    "Ti sembra di avere appena messo piede in uno spazio insostenibilmente e incredibilmente {i}affollato{/i}..."


translate ita refuseCat_7e162144:


    "Nelle tue orecchie rimbomba il suono di infinite conversazioni..."


translate ita refuseCat_403137b9:


    "Parole, sussurri, {i}urla{/i}... {w}tutto si mescola..."


translate ita refuseCat_bf0874e3:


    "Ma..."


translate ita refuseCat_134c63de:


    "In realtà non vedi e non senti niente o nessuno..."


translate ita refuseCat_93bc4adf:


    "Non c'è nessuno..."


translate ita refuseCat_1a0c257a:


    "Anche se i tuoi sensi ti mentono e cercano di condurti fuori strada..."


translate ita refuseCat_3fa3800d:


    "{size=-8}... non hai mai provato così tanta solitudine.{/size}"


translate ita refuseCat_237125a9:


    who "bugie... {w}bugie... {w}ascolta... {w}ascolta, {i}ti prego{/i}..."


translate ita refuseCat_90b68c87:


    you "...?"


translate ita refuseCat_ba0d7c87:


    you "Qualcuno sta davvero...?"


translate ita refuseCat_955160b2:


    you "Non riesco a vederti..."


translate ita refuseCat_0d7e3dc7:


    you "Dove sei?"


translate ita refuseCat_986b4bb4:


    who "niente... {w}niente è rimasto... {w}da vedere... {w}puoi solo sentire... {w}sentirci..."


translate ita refuseCat_2d7097aa:


    who "ascolta... {w}ti prego..."


translate ita refuseCat_30099ff9:


    you "Siete... Siete intrappolati qui anche voi? In questo posto...?"


translate ita refuseCat_da793f6a:


    who "nessun posto... {w}solo noi... {w}ciò che vedi... {w}senti... {w}provi... {w}siamo {i}noi{/i}..."


translate ita refuseCat_0e4deed6:


    who "noi... {w}e {b}{color=#FF0000}L U I...{/color}{/b}"


translate ita refuseCat_b46126fe:


    who "Siamo vittime... {w}prede... {w}come te... {w}siamo tante... {w}da perdere il conto..."


translate ita refuseCat_5306dd79:


    who "i nostri corpi sono spariti... {w}con il tempo..."


translate ita refuseCat_174a45b9:


    who "la volontà ci ha abbandonati... {w}noi... {w}noi... {w}siamo diventati... {w}quello che vedi... {w}questo \"posto\"..."


translate ita refuseCat_f03c0d18:


    who "ci serve... {w}il tuo aiuto... {w}aiuto..."


translate ita refuseCat_3abb33dd:


    you "Ma... Che posso fare {i}io{/i}...?"


translate ita refuseCat_82878ab6:


    who "{b}{color=#FF0000}L U I{/color}{/b} troppo ingordo... {w}fatto sbaglio... {w}mangiato troppo... {w}ora siamo tanti... {w}forti..."


translate ita refuseCat_70c5c2af:


    who "reso {b}{color=#FF0000}L U I{/color}{/b} forte... {w}ma fatto sbaglio... {w}sbaglio... {w}errore... {w}svista..."


translate ita refuseCat_85afd939:


    who "{i}debolezza{/i}..."


translate ita refuseCat_5d0fa6b9:


    you "Allora perché non siete scappati?"


translate ita refuseCat_88e7cfa8:


    who "qui a lungo... {w}troppo a lungo... {w}uno... {w}siamo tutt'uno... {w}con {b}{color=#FF0000}L U I...{/color}{/b}"


translate ita refuseCat_1eaa7cb8:


    who "corpi perduti... {w}menti... {w}volontà... {w}noi... {w}tutto corrotto... {w}nessun corpo... {w}non c'è scampo..."


translate ita refuseCat_c9b4decc:


    who "anche tu... {w}tu... {w}noi... {w}{b}{color=#FF0000}L U I...{/color}{/b} {w}uno... {w}tutti noi... {w}ora un tutt'uno..."


translate ita refuseCat_6f50b679:


    who "..."


translate ita refuseCat_028c3ae6:


    who "ma tu... {w}{i}un nuovo{/i}... {w}corpo... {w}vivo..."


translate ita refuseCat_4cfc5eb7:


    who "hai ancora corpo..."


translate ita refuseCat_40326cc1:


    who "una fuga è possibile..."


translate ita refuseCat_dd4998c0:


    who "perché tutt'uno... {w}con {b}{color=#FF0000}L U I...{/color}{/b}"


translate ita refuseCat_b6dc0c49:


    who "anche solo tu... {w}se fuggissi... {w}mente... {w}e corpo..."


translate ita refuseCat_793d75bf:


    who "{b}{color=#FF0000}L U I{/color}{/b} si disferebbe..."


translate ita refuseCat_2bd9b13a:


    who "perderebbe potere... {w}forza... {w}e infine {i}noi{/i}..."


translate ita refuseCat_8e7cd0c9:


    who "noi... {w}in libertà... {w}per sempre... {w}finalmente... {w}fuggire... {w}aiuto..."


translate ita refuseCat_73dce3cc:


    you "Cosa dovrei fare?"


translate ita refuseCat_5e2c21a6:


    who "ricorda {b}{color=#FF0000}L U I{/color}{/b} mente... {w}nascoste nella verità... {w}bugie... {w}bugie..."


translate ita refuseCat_482c36ac:


    who "fuggi... {w}vai avanti... {w}{b}{color=#FF0000}L U I{/color}{/b} mente..."


translate ita refuseCat_bd01a240:


    who "{size=-8}{b}continua...{/b}{/size}"


translate ita refuseCat_dae0ec55_1:


    you "..."


translate ita fakePerish_8dabefc6:


    ".."


translate ita fakePerish_a20cefa7:


    "..."


translate ita fakePerish_0d3bcba3:


    "{size=-10}ignora le loro parole{/size}"


translate ita fakePerish_479c3431:


    you "!!!" with vpunch


translate ita fakePerish_96593730:


    "nel profondo sai che non hai modo di vincere contro qualcosa come {b}{color=#FF0000}L U I...{/color}{/b}"


translate ita fakePerish_9b198811:


    "il gatto..."


translate ita fakePerish_44a490b1:


    "provare sarebbe inconcludente-{w=0.5}{nw}"


translate ita fakePerish_4b851161:


    "assurdo{w=0.15}{nw}"


translate ita fakePerish_0dc07c58:


    "futile{w=0.15}{nw}"


translate ita fakePerish_5028df96:


    "insignificante{w=0.15}{nw}"


translate ita fakePerish_3369598c:


    "senza senso{w=0.15}{nw}"


translate ita fakePerish_527621cb:


    "stupido{w=0.15}{nw}"


translate ita fakePerish_9eed9e56:


    "inutile{w=0.15}{nw}"


translate ita fakePerish_a20cefa7_1:


    "..."


translate ita fakePerish_127944b9:


    "... uno sforzo privo di scopo."


translate ita fakePerish_3e0d2470:


    "la speranza di quelle parole... la loro volontà..."


translate ita fakePerish_0f38a5d5:


    "... sarebbero del tutto sprecate con te."


translate ita fakePerish_69c369af:


    "quindi..."


translate ita fakePerish_05311e61:


    "accetti il tuo destino..."


translate ita fakePerish_bfe65f60:


    "... e scegli di \ {b}m o r i r e.{/b}"


translate ita fakePerish_8dabefc6_1:


    ".."


translate ita fakePerish_a20cefa7_2:


    "..."


translate ita fakePerish_92f9f8f7:


    "non hai la certezza di quanto tempo sia passato, ma le loro patetiche suppliche alla fine si zittiscono."


translate ita fakePerish_2b4577cf:


    "avresti quasi preferito che fossero diventate insulti e minacce..."


translate ita fakePerish_f1634dcc:


    "questo silenzio infinito... è carico di senso di colpa e vergogna..."


translate ita fakePerish_2214de5d:


    "... che persiste anche dopo che il tuo corpo è svanito..."


translate ita fakePerish_4bc243e3:


    "... ed è diventato un tutt'uno..."


translate ita fakePerish_b21d553c:


    "{alpha=0.5}tutt'uno...{/alpha}"


translate ita fakePerish_e1317257:


    "{alpha=0.3}... con me.{/alpha}"


translate ita fakePerish_a20cefa7_3:


    "..."


translate ita fakePerish_5a9b49fc:


    "Finale ???: Morte apparente"


translate ita finalShowdown_8dabefc6:


    ".."


translate ita finalShowdown_a20cefa7:


    "..."


translate ita finalShowdown_dae0ec55:


    you "..."


translate ita finalShowdown_8105eadd:


    you "No..."


translate ita finalShowdown_4d6b47c4:


    you "No, questo... Questo è un altro \"sogno a occhi aperti\"..."


translate ita finalShowdown_ed47dfcc:


    you "... non è vero?"


translate ita finalShowdown_f0fcfbb0:


    cat "!!!"


translate ita finalShowdown_d9b65ba2:


    cat "Sei di nuovo in te? {w}Qui {i}dentro?{/i}"


translate ita finalShowdown_f6c6b67c:


    cat "Ma... come hai...?"


translate ita finalShowdown_dae0ec55_1:


    you "..."


translate ita finalShowdown_685847ec:


    you "Beh..."


translate ita finalShowdown_62715eb3:


    you "Quando sogni lo stesso giorno in continuazione... {w}inizi a notare gli schemi che si ripetono..."


translate ita finalShowdown_7f0ac95c:


    cat "..."


translate ita finalShowdown_16651853:


    you "Senti... {w}Io non sono nulla di speciale."


translate ita finalShowdown_0560b398:


    you "Non ho neanche degli amici."


translate ita finalShowdown_28a71a07:


    you "Non mi piace la folla e nemmeno uscire troppo."


translate ita finalShowdown_ddfefb8c:


    you "E più di ogni altra cosa..."


translate ita finalShowdown_ff3731cf:


    you "... non ho legami."


translate ita finalShowdown_6c53330d:


    you "Persino in casa mia..."


translate ita finalShowdown_0c78bdf6:


    you "Una camera da letto... {w}un bagno... {w}e ci vivo solo {i}io{/i}."


translate ita finalShowdown_ea6f4afe:


    you "Sarebbe più facile dire che non ho nulla da perdere."


translate ita finalShowdown_e7a5aced:


    you "La mia vita è sostanzialmente noiosa."


translate ita finalShowdown_dae0ec55_2:


    you "..."


translate ita finalShowdown_9af744e4:


    you "Ma {i}è{/i}... la {w}{i}{b}mia{/b}{/i}... {w}vita."


translate ita finalShowdown_bccf0c1b:


    you "E se questo è davvero il {i}mio{/i} sogno..."


translate ita finalShowdown_b8c07162:


    you "... allora non sei più tu a prendere le decisioni."


translate ita finalShowdown_7f0ac95c_1:


    cat "..."


translate ita finalShowdown_a20cefa7_1:


    "..."


translate ita finalShowdown_97790092:


    "{size=-8}Non penso tu abbia capito cosa sta accadendo qui.{/size}"


translate ita finalShowdown_55077811:


    you "No, {i}sei tu{/i} che non stai capendo nulla."


translate ita finalShowdown_a513413e:


    "...!"


translate ita finalShowdown_a86ce62e:


    you "{b}Tu{/b} {i}mi{/i} hai chiamato."


translate ita finalShowdown_4a5124d3:


    you "{b}Sei tu{/b} ad avere bisogno di {i}me.{/i}"


translate ita finalShowdown_0833d501:


    you "Sia che tu voglia mangiarmi, uccidermi o rendermi parte di te per sempre, non importa."


translate ita finalShowdown_64ab99ef:


    you "Ho {b}finito{/b} qui."


translate ita finalShowdown_dae0ec55_3:


    you "..."


translate ita finalShowdown_144a76cd:


    you "Me ne vado a {b}casa.{/b}"


translate ita finalShowdown_62708cb5:


    "{size=+15}SCORDATELO, MORTALE!{/size}" with vpunch


translate ita finalShowdown_a20cefa7_2:


    "..."


translate ita finalShowdown_0f5de544:


    "Tu..."


translate ita finalShowdown_944b8194:


    "Tu piccola creatura ingrata..."


translate ita finalShowdown_0476e12b:


    "Ti ho dedicato la mia pazienza... le mie attenzioni... il mio {i}amore...{/i} e ora vuoi semplicemente {i}{b}andartene?{/b}{/i}"


translate ita finalShowdown_c1890fde:


    "Non ero {i}obbligato{/i}, sai? Avrei potuto semplicemente {b}mangiarti{/b} se lo avessi voluto, ma..."


translate ita finalShowdown_111422a8:


    "Ti ho dato tempo per comprendere... accettare ciò che stava succedendo..."


translate ita finalShowdown_6ce15ddb:


    "Ti ho dato una {b}scelta.{/b}"


translate ita finalShowdown_262e06a7:


    "{b}TU.{/b}"


translate ita finalShowdown_e4b6e292:


    "Una nullità esistenziale. NESSUNO avrebbe notato la tua mancanza se ti avessi preso come desideravo."


translate ita finalShowdown_5ec00c47:


    "Sogni di infinite possibilità..."


translate ita finalShowdown_27e84286:


    "Senza doverti mai più preoccupare di conseguenze permanenti... dovute a scelte sbagliate..."


translate ita finalShowdown_94c81802:


    "Un piccolo mondo tutto racchiuso nella tua testa..."


translate ita finalShowdown_4be86aa8:


    "Ti ho offerto tutto questo... Ti ho dato la scelta di unirti a me e avere tutto ciò..."


translate ita finalShowdown_8e138c4d:


    "E tu hai rifiutato."


translate ita finalShowdown_7ab438d2:


    "Dicevi che avresti scelto la morte piuttosto, giusto? \nEppure, stai provando a tornare sui tuoi passi..."


translate ita finalShowdown_ee2480c9:


    "... solo per continuare a rifiutarmi."


translate ita finalShowdown_ec08c7ee:


    "Per rifiutare il mio amore..."


translate ita finalShowdown_380a9730:


    "Quanta incoscienza..."


translate ita finalShowdown_ed1d138e:


    "Quanta ingratitudine..."


translate ita finalShowdown_f5ff6d04:


    "Proprio come chiunque altro, non sai nemmeno cosa vuoi davvero..."


translate ita finalShowdown_08772fff:


    "Un altro mucchio di contraddizioni..."


translate ita finalShowdown_ea286119:


    "Desideri la solitudine, eppure hai paura dell'abbandono..."


translate ita finalShowdown_38a1d032:


    "Hai paura che si dimentichino di te... che nessuno ti desideri... o ti ami..."


translate ita finalShowdown_427c7ef2:


    "Eppure anche se io ti amo e ti desidero..."


translate ita finalShowdown_26d7a1f6:


    "Anche se ho promesso di non dimenticarmi mai di te..."


translate ita finalShowdown_9b5e410c:


    "Anche se {b}io{/b} sono {i}l'unico{/i} che non ti abbandonerebbe mai..."


translate ita finalShowdown_a5b54e8a:


    "TU MI RIPUDI ANCORA."


translate ita finalShowdown_3e31e4a4:


    "Stupida piccola {b}{i}creatura.{/i}{/b}"


translate ita finalShowdown_fe885e9e:


    "Sono {i}stanco{/i} di aspettare."


translate ita finalShowdown_90c94c9e:


    "Non avrai una seconda possibilità. Hai fatto la tua scelta e {b}{i}dovrai{/i}{/b} accettarne le conseguenze."


translate ita finalShowdown_a4585081:


    "Rimarrai qui con il resto di questi ingrati..."


translate ita finalShowdown_9ab7bfe1:


    ".{w=0.7}.{w=0.7}.{w=0.7} p{w=0.7}e{w=0.7}r{w=0.7} {w=0.7}s{w=0.7}e{w=0.7}m{w=0.7}p{w=0.7}r{w=0.7}e{w=0.7}."


translate ita finalShowdown_dae0ec55_4:


    you "..."


translate ita finalShowdown_21096a12:


    you "Lo sai che si può sempre cambiare idea?"


translate ita finalShowdown_240d387e:


    "Ciò non cancella la tua decisione originale. È stata impressa in maniera indelebile nella realtà."


translate ita finalShowdown_985e2f87:


    "Ti consideri così importante da essere {b}esente{/b} dalle conseguenze di tale realtà?"


translate ita finalShowdown_49817c9e:


    you "No... Ma ciò non esclude che io non possa fare del mio meglio per fare la cosa giusta."


translate ita finalShowdown_6346d171:


    you "Sono ancora qui, no? Significa che posso sempre fare altre scelte... Scelte migliori..."


translate ita finalShowdown_a20cefa7_3:


    "..."


translate ita finalShowdown_c6c45632:


    "Mi hai dato tutto di te... {w}{i}Tu{/i} sei già una parte di {b}me{/b}..."


translate ita finalShowdown_f79cd161:


    "Potrebbe essere una patetica piccola delusione..."


translate ita finalShowdown_0e17c1eb:


    "... ma non dimenticarti che {i}sono io{/i} che comando qui, mortale."


translate ita finalShowdown_4d71bde9:


    you "Oh sì, giusto. {w}Quelle \"scelte\" contorte nei miei sogni erano opera tua, non è così?"


translate ita finalShowdown_297c677e:


    who "{alpha=0.3}noi aiutiamo... aiutiamo...{/alpha}"


translate ita finalShowdown_697cd04e:


    who "{alpha=0.5}scappare...{/alpha} fineSogno.exe..."


translate ita finalShowdown_3c44db14:


    "Cosa-"


translate ita finalShowdown_d8c402b1:


    who "I {w=0.3}N {w=0.3}S {w=0.3}I {w=0.3}S {w=0.3}T {w=0.3}I"


translate ita finalShowdown_210d572a:


    "!!!" with hpunch


translate ita finalShowdown_10402de1:


    "Cosa fate, inutili traditori?!?"


translate ita finalShowdown_7daca311:


    "{size=+15}BASTA!{/size}" with hpunch


translate ita finalShowdown_7bbc0a26:


    you "Penso sia arrivato il momento di fare le {i}mie{/i} scelte."


translate ita finalShowdown_c7b05810:


    cat "{size=+35}{b}BAS-!!!{/b}{/size}{w=0.3}{nw}" with hpunch


translate ita whereItBegan_8dabefc6:


    ".."


translate ita whereItBegan_a20cefa7:


    "..."


translate ita whereItBegan_a20cefa7_1:


    "..."


translate ita whereItBegan_355c83da:


    "Sono di nuovo qui..."


translate ita whereItBegan_e91717e2:


    "Dove tutto è iniziato..."


translate ita whereItBegan_939db7b6:


    "Il vicolo..."


translate ita whereItBegan_99fcd215:


    "E nella scatola di cartone... {w}alla fine del vicolo..."


translate ita whereItBegan_8dabefc6_1:


    ".."


translate ita whereItBegan_a20cefa7_2:


    "..."


translate ita whereItBegan_dae0ec55:


    you "..."


translate ita whereItBegan_b0381c02:


    "Eccoti qui..."


translate ita whereItBegan_3064d8e1:


    "Non assomigli per niente al gattino che ho incontrato... {w}beh... {w}sembra secoli fa..."


translate ita whereItBegan_c94b4764:


    "Dopo la fuga e la liberazione delle volontà di tutte le tue vittime..."


translate ita whereItBegan_46986469:


    "... ciò che resta di te è una macchia d'inchiostro nero che mi salta addosso."


translate ita whereItBegan_87df935d:


    cat3 "..."


translate ita whereItBegan_c127cc5c:


    "L'odio infinito che trasuda dal tuo sguardo..."


translate ita whereItBegan_a20cefa7_3:


    "..."


translate ita whereItBegan_083faea7:


    "... non mi spaventa per niente."


translate ita whereItBegan_7e6715dd:


    cat3 "non mi lasciare"


translate ita whereItBegan_5071d7c2:


    cat3 "mi appartieni"


translate ita whereItBegan_8105eadd:


    you "No..."


translate ita whereItBegan_5288c6f4:


    "Non è vero."


translate ita whereItBegan_9a3acbc4:


    cat3 "me li hai portati via"


translate ita whereItBegan_472c0f2d:


    cat3 "erano miei"


translate ita whereItBegan_ba12304a:


    cat3 "e ora non ci sono più"


translate ita whereItBegan_9a3acbc4_1:


    cat3 "me li hai portati via"


translate ita whereItBegan_94d1d734:


    cat3 "mi hai portato via tutto"


translate ita whereItBegan_dae0ec55_1:


    you "..."


translate ita whereItBegan_77bc0354:


    you "Non erano tuoi."


translate ita whereItBegan_f379ba27:


    cat3 "da solo"


translate ita whereItBegan_dae0ec55_2:


    you "..."


translate ita whereItBegan_9d45b838:


    "Non {i}dovevi esserlo{/i} per forza..."


translate ita whereItBegan_85be2ed9:


    "Se ti sentivi solo... {w}potevi semplicemente essere loro amico..."


translate ita whereItBegan_a17d72a6:


    "Ma tu non cercavi amici."


translate ita whereItBegan_8fe47c61:


    "Ti hanno lasciato perché li hai ingannati..."


translate ita whereItBegan_4fe27187:


    "Rapiti..."


translate ita whereItBegan_5f26a1dd:


    "{b}Feriti{/b}..."


translate ita whereItBegan_139aec37:


    "Hai rubato le loro vite... {w}Il loro tempo... {w}E non avranno nulla indietro..."


translate ita whereItBegan_a20cefa7_4:


    "..."


translate ita whereItBegan_7b3789fb:


    "Puoi incolpare solo te stesso."


translate ita whereItBegan_46dd9501:


    cat3 "tu sei impeccabile"


translate ita whereItBegan_60798589:


    you "Non è vero."


translate ita whereItBegan_b18d5776:


    cat3 "lo {i}sei{/i}"


translate ita whereItBegan_1cddd9bb:


    cat3 "non ho bisogno degli altri"


translate ita whereItBegan_057f9031:


    cat3 "solo di te"


translate ita whereItBegan_3f0d14d7:


    cat3 "resta con me"


translate ita whereItBegan_3ee5d6e5:


    you "Non lo farò."


translate ita whereItBegan_51949c19:


    cat3 "posso darti tutto"


translate ita whereItBegan_eeb62c46:


    cat3 "posso essere tutto per te"


translate ita whereItBegan_ff690f3e:


    you "No... Non puoi."


translate ita whereItBegan_1244bbaf:


    "Non potevi {i}prima...{/i}"


translate ita whereItBegan_0c8bb1e9:


    "E sicuramente non puoi {i}ora...{/i}"


translate ita whereItBegan_cb64e404:


    "E..."


translate ita whereItBegan_d38bed87:


    "Anche se tu {i}potessi{/i} darmi tutto ciò che ho sempre desiderato..."


translate ita whereItBegan_a20cefa7_5:


    "..."


translate ita whereItBegan_2dad4a80:


    "Io {b}comunque{/b} non resterei mai."


translate ita whereItBegan_68cdb263:


    cat3 "ti voglio bene"


translate ita whereItBegan_9cf90ed4:


    you "No tu-{w=0.3}{nw}"


translate ita whereItBegan_d49ea8d6:


    cat3 "è {b}così{/b}"


translate ita whereItBegan_dae0ec55_3:


    you "..."


translate ita whereItBegan_258ecaf3:


    cat3 "tanto"


translate ita whereItBegan_68cdb263_1:


    cat3 "ti voglio bene"


translate ita whereItBegan_6cdd727d:


    cat3 "{size=-5}ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene ti voglio bene {/size}"


translate ita whereItBegan_f9bff14e:


    you "{b}{i}Basta.{/i}{/b}"


translate ita whereItBegan_87df935d_1:


    cat3 "..."


translate ita whereItBegan_8753550f:


    you "Forse mi vuoi bene {i}davvero{/i}..."


translate ita whereItBegan_26b2f544:


    you "In qualche strano e contorto modo che non capirò mai..."


translate ita whereItBegan_8d59fc22:


    you "Ma anche se così fosse..."


translate ita whereItBegan_dae0ec55_4:


    you "..."


translate ita whereItBegan_a4a76912:


    you "... Non è abbastanza."


translate ita whereItBegan_87df935d_2:


    cat3 "..."


translate ita whereItBegan_ce7d4730:


    cat3 "per favore"


translate ita whereItBegan_4f636a45:


    cat3 "non andare"


translate ita whereItBegan_5b4c342f:


    cat3 "sarò bravo"


translate ita whereItBegan_dae0ec55_5:


    you "..."


translate ita whereItBegan_97b5d2b0:


    you "Non ti credo."


translate ita whereItBegan_dc4cb259:


    cat3 "lo prometto"


translate ita whereItBegan_dae0ec55_6:


    you "..."


translate ita whereItBegan_e301b7d9:


    you "Non posso fidarmi di te."


translate ita whereItBegan_944f9217:


    cat3 "{size=+10}lo prometto{/size}" with hpunch


translate ita whereItBegan_c8d092d5:


    cat3 "non {b}andartene{/b}"


translate ita whereItBegan_1b817c48:


    cat3 "{size=-5}non lasciarmi da solo{/size}"


translate ita whereItBegan_e81e0eae:


    cat3 "{size=-8}ti prego{/size}"


translate ita whereItBegan_556d4f53:


    cat3 "{size=-8}morirò{/size}"


translate ita whereItBegan_9a0ddf1d:


    cat3 "{size=-8}io {b}morirò{/b} senza di te{/size}"


translate ita whereItBegan_dae0ec55_7:


    you "..."


translate ita whereItBegan_26f6da8b:


    cat3 "..."


translate ita whereItBegan_87df935d_3:


    cat3 "..."


translate ita whereItBegan_e94cd667:


    cat3 "{size=-10}io ti {color=#FF0000}{b}odio{/b}{/color}{/size}"


translate ita whereItBegan_dae0ec55_8:


    you "..."


translate ita whereItBegan_8d18066c:


    you "Ora a {b}{i}questo{/i}{/b}... {w}io {i}posso{/i} crederci."


translate ita whereItBegan_87df935d_4:


    cat3 "..."


translate ita whereItBegan_8dabefc6_2:


    ".."


translate ita whereItBegan_a20cefa7_6:


    "..."


translate ita whereItBegan_bca6c5f8:


    "Non c'è altro da dire."


translate ita whereItBegan_2e1ef17d:


    "Osservo in silenzio il gatto..."


translate ita whereItBegan_53a0111a:


    "... quella {color=#FF0000}{b}cosa{/b}{/color}... {w}svanire nel nulla..."


translate ita whereItBegan_a20cefa7_7:


    "..."


translate ita whereItBegan_dae0ec55_9:


    you "..."


translate ita whereItBegan_0214ad62:


    "{i}Addio...{/i}"


translate ita whereItBegan_d831204f:


    "Dopo un'ultima occhiata al vicolo..."


translate ita whereItBegan_18671b5a:


    "Mi giro..."


translate ita whereItBegan_78e07a96:


    "... e me ne vado."


translate ita whereItBegan_8dabefc6_3:


    ".."


translate ita whereItBegan_a20cefa7_8:


    "..."


translate ita whereItBegan_ebb653f4:


    "Finale 38: NON Portare Questo Gatto a Casa"

translate ita strings:


    old "What do you mean I was \"daydreaming\"?"
    new "In che senso stavo \"fantasticando\"?"


    old "Where are we right now?"
    new "Dove siamo adesso?"


    old "Why do you keep killing me?!"
    new "Perché continui a uccidermi?!?"


    old "You're a cat, how are you talking?"
    new "Sei un gatto, come puoi parlare?"


    old "What do you want?"
    new "Cosa vuoi?"


    old "Nothing, I don't care!"
    new "Niente, non m'importa!"






    old "No..."
    new "No..."


    old "Am I still dreaming?"
    new "Sto ancora sognando?"


    old "You even made me kill {i}you{/i} in the end!"
    new "Mi hai anche costretto a {i}ucciderti{/i} alla fine!"


    old "But you're a {i}cat!{/i} How are you doing this?!"
    new "Ma tu sei un {i}gatto!{/i} Come puoi fare questo?!?"


    old "\"I'll join you...\""
    new "\"Mi unirò a te...\""


    old "\"I'd rather die.\""
    new "\"Preferisco morire.\""


    old "{size=-6}persist...{/size}"
    new "{size=-6}insisti...{/size}"


    old "{b}P E R S I S T{/b}"
    new "{b}I N S I S T I{/b}"


    old "Do not take this cat home."
    new "Non portare questo gatto a casa."


    old "Do {b}NOT{/b} take this cat home."
    new "{b}NON{/b} portare questo gatto a casa."

    old "lies..."
    new "bugie..."

    old "is {i}us{/i}..."
    new "siamo {i}noi{/i}..."

    old "{i}we{/i} are strong..."
    new "{i}noi{/i} siamo forti..."

    old "persist..."
    new "insisti..."

    old "{i}persist...{/i}"
    new "{i}insisti...{/i}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
