


translate ita finalShowdownChase_8dabefc6:


    ".."


translate ita finalShowdownChase_a20cefa7:


    "..."


translate ita finalShowdownChase_28b3ac41:


    you "!!!"


translate ita finalShowdownChase_d780f384:


    you "{i}Sono di nuovo nel vicolo...{/i}"


translate ita finalShowdownChase_f7ab12f7:


    you "{i}Non c'è più... Bene...{/i}"


translate ita finalShowdownChase_06674a63:


    you "{i}Penso che... {w}forse dovrei tornare a casa...{/i}"


translate ita finalShowdownChase_8dabefc6_1:


    ".."


translate ita finalShowdownChase_a20cefa7_1:


    "..."


translate ita finalShowdownChase_d545054f:


    "Io, ehm..."


translate ita finalShowdownChase_0c089aed:


    "... Esco da qui? {w}Fuori dal... {w}vicolo?"


translate ita finalShowdownChase_dae0ec55:


    you "..."


translate ita finalShowdownChase_edaac27f:


    you "{i}Avrò bisogno di un po' di tempo per abituarmi...{/i}"


translate ita finalShowdownChase_c6ca505e:


    "St-sto per uscire dal vicolo, che per fortuna è vuoto."


translate ita finalShowdownChase_a762f582:


    "Sono quasi fuori da qui..."


translate ita finalShowdownChase_c23d8f1d:


    "Quasi a casa-{w=0.5}{nw}"


translate ita finalShowdownChase_f29a87f6:


    "{b}{color=#FF0000}quando \ i m p r o v v i s a m e n t e . . . {/color}{/b}" with hpunch


translate ita finalShowdownChase_479c3431:


    you "!!!" with vpunch


translate ita finalShowdownChase_ba5843f8:


    cat "{size=+15}TUUUU!!!{/size}" with vpunch


translate ita finalShowdownChase_56ebb028:


    you "!!!"


translate ita finalShowdownChase_d9cfa56f:


    cat "{size=+20}NON{/size}{w=0.5}{nw}" with vpunch


translate ita finalShowdownChase_c62afa20:


    cat "{size=+25}FARE{/size}{w=0.5}{nw}" with vpunch


translate ita finalShowdownChase_66fe51fb:


    cat "{size=+30}{b}NEANCHE{/b}{/size}{w=0.5}{nw}" with vpunch


translate ita finalShowdownChase_f73f59ae:


    cat "{size=+35}{b}{i}UNA MOSSA!!!{/i}{/b}{/size}" with vpunch


translate ita gotYou_9ea2f78c:


    " "


translate ita gotYou_9ea2f78c_1:


    " "


translate ita gotYou_9ea2f78c_2:


    " "


translate ita gotYou_9ea2f78c_3:


    " "


translate ita gotYou_9ea2f78c_4:


    " "


translate ita gotYou_9ea2f78c_5:


    " "


translate ita gotYou_9ea2f78c_6:


    " "


translate ita gotYou_9ea2f78c_7:


    " "


translate ita forcedMenu_11e8f724:


    "Dannazione...! Ha annullato la mia scelta!"


translate ita forcedMenu_11da515d:


    "Dove cacchio vado adesso?!?"


translate ita forcedMenu_80dcf355:


    "Ovunque tranne che qui!"


translate ita forcedMenu_80dcf355_1:


    "Ovunque tranne che qui!"


translate ita forcedMenu_80dcf355_2:


    "Ovunque tranne che qui!"


translate ita forcedMenu_479c3431:


    you "!!!" with vpunch


translate ita forcedMenu_bd221748:


    you "È... opera mia...?"


translate ita forcedMenu_7f923745:


    who "matassa sbrogliata... {w}molti noi fuggiti... {w}molti liberi ora..."


translate ita forcedMenu_3c5590a3:


    who "{b}{color=#FF0000}L U I{/color}{/b} perde noi... {w}perde forza..."


translate ita forcedMenu_1c5a04cd:


    who "fuga... {w}ora possibile..."


translate ita forcedMenu_0f670756:


    cat "{size=+25}{b}{i}NOOO!!!{/i}{/b}{/size}" with vpunch


translate ita forcedMenu_2dadc39a:


    cat "{size=+25}{b}{i}TU!!!{/i}{/b}{/size}" with vpunch


translate ita forcedMenu_7e3cb0cc:


    cat "{size=+25}{b}{i}MI!!!{/i}{/b}{/size}" with vpunch


translate ita forcedMenu_3291da01:


    cat "{size=+25}{b}{i}{color=#FF0000}APPARTIENI!!!{/color}{/i}{/b}{/size}" with vpunch


translate ita forcedMenu_32f51c80:


    who "{alpha=0.8}noi andare oltre... {w}noi essere liberi...{/alpha}"


translate ita forcedMenu_c54506c0:


    who "{alpha=0.5}grazie...{/alpha}"


translate ita forcedMenu_63e75705:


    who "{i}{alpha=0.3}grazie...{/alpha}{/i}"


translate ita forcedMenu_6f50b679:


    who "..."


translate ita forcedMenu_dae0ec55:


    you "..."


translate ita forcedMenu_62914fe0:


    you "Grazie anche a voi... di tutto..."


translate ita forcedMenu_dae0ec55_1:


    you "..."


translate ita forcedMenu_0ac72f08:


    you "Non vi dimenticherò..."


translate ita oldTheater5a_b3a0900b:


    you "Cavolo! Un vicolo cieco...!"


translate ita oldTheater5a_0b089920:


    cat "{size=+25}{b}{i}FERMATI!!!{/i}{/b}{/size}" with vpunch


translate ita oldTheater5a_28b3ac41:


    you "!!!"


translate ita oldTheater5c_c52bbb18:


    cat "{size=+15}{b}{i}TORNA QUI!!!{/i}{/b}{/size}" with vpunch


translate ita oldTheater5c_dae0ec55:


    you "..."


translate ita newCinema5a_7e60013d:


    you "Vicolo cieco...? E ora dove va-"


translate ita newCinema5a_2dea9288:


    cat "{size=+25}{b}{i}ECCOTI QUA~!!!{/i}{/b}{/size}" with vpunch


translate ita newCinema5a_28b3ac41:


    you "!!!"


translate ita newCinema5c_c52bbb18:


    cat "{size=+15}{b}{i}TORNA QUI!!!{/i}{/b}{/size}" with vpunch


translate ita newCinema5c_dae0ec55:


    you "..."


translate ita carnival5a_af46df21:


    you "Come faccio a uscire?!?"


translate ita carnival5a_9290bf8e:


    cat "{size=+25}{b}{i}NON PUOI FUGGIRE!!!{/i}{/b}{/size}" with vpunch


translate ita carnival5a_28b3ac41:


    you "!!!"


translate ita carnival5c_c52bbb18:


    cat "{size=+15}{b}{i}TORNA QUI!!!{/i}{/b}{/size}" with vpunch


translate ita carnival5c_dae0ec55:


    you "..."


translate ita dogPark5a_5d305961:


    you "Dannazione! Devo scappare...!"


translate ita dogPark5a_cf455219:


    cat "{size=+25}{b}SEI IN TRAPPOLA {i}ORA!!!{/i}{/b}{/size}" with vpunch


translate ita dogPark5a_28b3ac41:


    you "!!!"


translate ita dogPark5c_c52bbb18:


    cat "{size=+15}{b}{i}TORNA QUI!!!{/i}{/b}{/size}" with vpunch


translate ita dogPark5c_dae0ec55:


    you "..."


translate ita street1_0f670756:


    cat "{size=+25}{b}{i}NOOO!!!{/i}{/b}{/size}" with vpunch


translate ita street3_85039274:


    cat "{size=+25}{b}{i}TORNA DA ME!!!{/i}{/b}{/size}" with vpunch


translate ita street5_3ef5df1c:


    cat "{size=+25}{b}{i}{color=#FF0000}TORNA DA ME!!!{/color}{/i}{/b}{/size}" with vpunch


translate ita apt1_cad1cfa2:


    cat "{size=+25}{b}{i}{color=#FF0000}TI PREGO!!!{/color}{/i}{/b}{/size}" with vpunch


translate ita apt2_8805a939:


    cat "{size=+20}{b}{i}{color=#FF0000}NON LASCIARMI COSÌ!!!{/color}{/i}{/b}{/size}" with vpunch


translate ita apt3_3088931f:


    cat "{size=+15}{b}{i}{color=#FF0000}MORIRÒ SENZA DI TE!!!{/color}{/i}{/b}{/size}" with vpunch


translate ita apt4_d1378a7d:


    cat "{size=+10}{b}{i}{color=#FF0000}MORIRÒ!!!{/color}{/i}{/b}{/size}" with vpunch


translate ita apt5_9f2b0199:


    cat "{size=+5}{b}{i}{color=#FF0000}MORIRÒ!!!{/color}{/i}{/b}{/size}" with vpunch


translate ita apt5_b75195fe:


    cat "ASPETTA...!"


translate ita apt5_3e0cf073:


    cat "{size=-5}Aspetta...{/size}"


translate ita chaseFail_436e4a4f:


    "Devo evitarlo e andare VIA!"

translate ita strings:


    old "GO LEFT!"
    new "VAI A SINISTRA!"


    old "GO BACK!"
    new "TORNA INDIETRO!"


    old "GO RIGHT!"
    new "VAI A DESTRA!"


    old "Go home!!"
    new "Vai a casa!!!"


    old "I've got to escape!"
    new "Devo riuscire a fuggire!"


    old "go WATCH a {b}movie{/b}"
    new "vai a VEDERE un {b}film{/b}"


    old "go {b}to{/b} the CARNIVAL"
    new "vai {b}al{/b} LUNA PARK"


    old "GO to {b}dog{/b} park"
    new "VAI all'area {b}cani{/b}"


    old "They were right... My choice is back!"
    new "Avevano ragione... le mie scelte sono tornate!"


    old "go to old theater."
    new "vai al vecchio cinema"


    old "go to new cinema."
    new "vai al nuovo cinema"


    old "PUSH FORWARD!"
    new "CONTINUA COSÌ!"


    old "Persist?"
    new "Continui?"


    old "Give up?"
    new "Ti arrendi?"

    old "{alpha=1}Don't give in to it...{/alpha}"
    new "{alpha=1}Non dargliela vinta...{/alpha}"

    old "{alpha=0.75}Keep going...{/alpha}"
    new "{alpha=0.75}Stringi i denti...{/alpha}"

    old "{alpha=0.5}{color=#FF0000}IT's{/color} power is fading...{/alpha}"
    new "{alpha=0.5}{color=#FF0000}LUI{/color} sta perdendo il suo potere...{/alpha}"

    old "{alpha=0.25}You're almost there...{/alpha}"
    new "{alpha=0.25}Ci sei quasi...{/alpha}"

    old "{alpha=0.2}You have the strength to escape...{/alpha}"
    new "{alpha=0.2}Hai trovato le forze per scappare...{/alpha}"

    old "{alpha=0.2}At the end of this chaos...{/alpha}"
    new "{alpha=0.2}Quando questo caos finirà...{/alpha}"

    old "{alpha=0.2}You will be okay...{/alpha}"
    new "{alpha=0.2}Ti sentirai finalmente bene...{/alpha}"

    old "{alpha=0.2}We are with you...{/alpha}"
    new "{alpha=0.2}Noi siamo qui con te...{/alpha}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
