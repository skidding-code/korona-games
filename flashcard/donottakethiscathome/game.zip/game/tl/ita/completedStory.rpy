


translate ita hereAgain_8644fdbf:


    who "gioca con me..." nointeract


translate ita hereAgain_6f50b679:


    who "..."


translate ita hereAgain_a11fa0b8:


    who "allora vattene."


translate ita hereAgain_6f50b679_1:


    who "..."


translate ita hereAgain_17114041:


    who "davvero?"


translate ita hereAgain_88bc4e2a:


    who "lascerai perdere questo patetico finale..."


translate ita hereAgain_92534b16:


    who "... e giocherai ancora un po' con me?"


translate ita hereAgain_78091749:


    who "Non prometterlo se non ne hai la certezza." nointeract


translate ita hereAgain_6f50b679_2:


    who "..."


translate ita hereAgain_a11fa0b8_1:


    who "allora vattene."


translate ita hereAgain_84de3be0:


    who "... Bene."


translate ita hereAgain_a5457a87:


    who "Molto bene."


translate ita hereAgain_281311fe:


    who "Trovami..."


translate ita hereAgain_9ea2f78c:


    " "

translate ita strings:


    old "no. never again."
    new "no. mai più."


    old "yes..."
    new "sì..."


    old "no..."
    new "no..."


    old "yes."
    new "sì."

    old "D{alpha=0.0}O NOT BETRAY ME AGAIN.{/alpha}"
    new "N{alpha=0.0}ON TRADIRMI MAI PIÙ.{/alpha}"

    old "DO{alpha=0.0} NOT BETRAY ME AGAIN.{/alpha}"
    new "NO{alpha=0.0}N TRADIRMI MAI PIÙ.{/alpha}"

    old "DO {alpha=0.0}NOT BETRAY ME AGAIN.{/alpha}"
    new "NON{alpha=0.0} TRADIRMI MAI PIÙ.{/alpha}"

    old "DO N{alpha=0.0}OT BETRAY ME AGAIN.{/alpha}"
    new "NON {alpha=0.0}TRADIRMI MAI PIÙ.{/alpha}"

    old "DO NO{alpha=0.0}T BETRAY ME AGAIN.{/alpha}"
    new "NON T{alpha=0.0}RADIRMI MAI PIÙ.{/alpha}"

    old "DO NOT{alpha=0.0} BETRAY ME AGAIN.{/alpha}"
    new "NON TR{alpha=0.0}ADIRMI MAI PIÙ.{/alpha}"

    old "DO NOT {alpha=0.0}BETRAY ME AGAIN.{/alpha}"
    new "NON TRA{alpha=0.0}DIRMI MAI PIÙ.{/alpha}"

    old "DO NOT B{alpha=0.0}ETRAY ME AGAIN.{/alpha}"
    new "NON TRAD{alpha=0.0}IRMI MAI PIÙ.{/alpha}"

    old "DO NOT BE{alpha=0.0}TRAY ME AGAIN.{/alpha}"
    new "NON TRADI{alpha=0.0}RMI MAI PIÙ.{/alpha}"

    old "DO NOT BET{alpha=0.0}RAY ME AGAIN.{/alpha}"
    new "NON TRADIR{alpha=0.0}MI MAI PIÙ.{/alpha}"

    old "DO NOT BETR{alpha=0.0}AY ME AGAIN.{/alpha}"
    new "NON TRADIRM{alpha=0.0}I MAI PIÙ.{/alpha}"

    old "DO NOT BETRA{alpha=0.0}Y ME AGAIN.{/alpha}"
    new "NON TRADIRMI{alpha=0.0} MAI PIÙ.{/alpha}"

    old "DO NOT BETRAY{alpha=0.0} ME AGAIN.{/alpha}"
    new "NON TRADIRMI {alpha=0.0}MAI PIÙ.{/alpha}"

    old "DO NOT BETRAY {alpha=0.0}ME AGAIN.{/alpha}"
    new "NON TRADIRMI M{alpha=0.0}AI PIÙ.{/alpha}"

    old "DO NOT BETRAY M{alpha=0.0}E AGAIN.{/alpha}"
    new "NON TRADIRMI MA{alpha=0.0}I PIÙ.{/alpha}"

    old "DO NOT BETRAY ME{alpha=0.0} AGAIN.{/alpha}"
    new "NON TRADIRMI MAI{alpha=0.0} PIÙ.{/alpha}"

    old "DO NOT BETRAY ME {alpha=0.0}AGAIN.{/alpha}"
    new "NON TRADIRMI MAI {alpha=0.0}PIÙ.{/alpha}"

    old "DO NOT BETRAY ME A{alpha=0.0}GAIN.{/alpha}"
    new "NON TRADIRMI MAI P{alpha=0.0}IÙ.{/alpha}"

    old "DO NOT BETRAY ME AG{alpha=0.0}AIN.{/alpha}"
    new "NON TRADIRMI MAI PI{alpha=0.0}Ù.{/alpha}"

    old "DO NOT BETRAY ME AGA{alpha=0.0}IN.{/alpha}"
    new "NON TRADIRMI MAI PIÙ{alpha=0.0}.{/alpha}"

    old "DO NOT BETRAY ME AGAI{alpha=0.0}N.{/alpha}"
    new "NON TRADIRMI MAI PIÙ."

    old "DO NOT BETRAY ME AGAIN{alpha=0.0}.{/alpha}"
    new "NON TRADIRMI MAI PIÙ."

    old "DO NOT BETRAY ME AGAIN."
    new "NON TRADIRMI MAI PIÙ."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
