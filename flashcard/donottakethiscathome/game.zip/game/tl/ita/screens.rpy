

translate ita strings:


    old "Back"
    new "Vai indietro"


    old "History"
    new "Cronologia"


    old "Skip"
    new "Salta"


    old "Auto"
    new "Auto"


    old "Save"
    new "Salva"


    old "Q.Save"
    new "Salvataggio Veloce"


    old "Q.Load"
    new "Caricamento Veloce"


    old "Prefs"
    new "Preferenze"


    old "..."
    new "..."


    old "Continue"
    new "Continua"


    old "Start"
    new "Inizia"


    old "Load"
    new "Carica"


    old "Preferences"
    new "Preferenze"


    old "End Replay"
    new "Fine Replay"


    old "Main Menu"
    new "Menu Principale"


    old "Endings"
    new "Finali"


    old "???"
    new "???"


    old "About"
    new "Informazioni"


    old "Help"
    new "Aiuto"


    old "Credits"
    new "Ringraziamenti"


    old "Quit"
    new "Esci"


    old "Return"
    new "Torna a Giocare"

    old "\nYou find a cat on your day off. From there, you decide what happens next.\n"
    new "\nTrovi un gatto nel tuo giorno libero. Dopodiché, deciderai tu il da farsi.\n"

    old "...Or {i}do{/i} you?"
    new "... Oppure {i}no{/i}?"

    old "\n{size=+20}Content/Trigger Warnings{/size}"
    new "\n{size=+20}Avviso Relativo ai Contenuti{/size}"


    old "{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n"
    new "{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n"


    old "\nContains {color=#FF0000}spoilers{/color}!\n\n"
    new "\nContiene {color=#FF0000}anticipazioni{/color}!\n\n"


    old "Abuse / abusive relationship(s)"
    new "Abuso / relazioni violente"


    old "Agoraphobia"
    new "Agorafobia"


    old "Amnesia"
    new "Amnesia"


    old "Amputation / Dismemberment"
    new "Amputazioni / Smembramenti"


    old "Animal abuse"
    new "Violenza sugli animali"


    old "Animal death"
    new "Morte di animali"


    old "Animals/monsters eating humans"
    new "Animali/mostri che mangiano esseri umani"


    old "Anxiety / Social Anxiety"
    new "Ansia / Ansia Sociale"


    old "Blood & gore"
    new "Sangue e violenza"


    old "Body horror"
    new "Body horror"


    old "Body injury"
    new "Lesioni corporee"


    old "Cannibalism"
    new "Cannibalismo"


    old "Child abuse (minor mention/hint of)"
    new "Abuso su minori (piccole menzioni/accenni)"


    old "Cosmic horror"
    new "Horror cosmico"


    old "Dead bodies & body parts"
    new "Cadaveri e parti smembrate"


    old "Death / dying"
    new "Morte / decesso"


    old "Decapitation"
    new "Decapitazione"


    old "Depression"
    new "Depressione"


    old "Dissociation"
    new "Dissociazione"


    old "Doll animation"
    new "Bambole animate"


    old "Emotional abuse"
    new "Abuso emotivo"


    old "Entrapment"
    new "Reclusione"


    old "Epilepsy warning - flashing images & lights/static"
    new "Rischio di Epilessia - interferenze/luci e immagini intermittenti"


    old "Glitches"
    new "Glitch"


    old "Hallucinations"
    new "Allucinazioni"


    old "Heart attack"
    new "Infarto"


    old "Intrusive thoughts"
    new "Pensieri intrusivi"


    old "Isolation"
    new "Isolamento"


    old "Kidnapping / abduction"
    new "Rapimento / sequestro"


    old "Loss of vision"
    new "Perdita della vista"


    old "Loud, sudden and/or repeating noises"
    new "Rumori forti, improvvisi e/o ripetitivi"


    old "Manipulation / gaslighting"
    new "Manipolazione / coercizione"


    old "Mental illness"
    new "Malattie mentali"


    old "Mind control"
    new "Controllo della mente"


    old "Murder"
    new "Omicidio"


    old "Paranoia"
    new "Paranoia"


    old "Poison / venom"
    new "Veleno / avvelenamento"


    old "Psychological horror"
    new "Horror psicologico"


    old "Scary / disturbing images & messages"
    new "Messaggi spaventosi / immagini inquietanti"


    old "Scopophobia"
    new "Scopofobia"


    old "Seizure"
    new "Crisi"


    old "Self-harm"
    new "Autolesionismo"


    old "Stalking"
    new "Stalking"


    old "Suicide / Suicidal ideation"
    new "Suicidio / Tendenze suicide"


    old "Tense situations / gameplay"
    new "Situazioni di gioco ansiogene"


    old "Thalassophobia"
    new "Talassofobia"


    old "Timed gameplay"
    new "Gioco a tempo"


    old "Violence"
    new "Violenza"


    old "Vomiting"
    new "Vomito"


    old "\n{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n"
    new "\n{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n"


    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Sviluppato con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"


    old "Endings Found: {color=#fff}[persistent.endCounter] / 40{/color}"
    new "Finali Scoperti: {color=#fff}[persistent.endCounter] / 40{/color}"


    old "Ending 0: It Begins -- {color=#FF0000}Complete{/color}"
    new "Finale 0: L'Inizio -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Something... happened. You {b}think{/b}, anyway. You can't really remember what...{/size}{/i}"
    new "    {i}{size=-3}È successo... qualcosa. Almeno {b}credi{/b}. Non riesci a ricordare cosa...{/size}{/i}"


    old "\nEnding 0: It Begins -- {color=#FF0000}Complete{/color}"
    new "\nFinale 0: L'Inizio -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}The first time you took {color=#FF0000}{b}it{/b}{/color} home.{/size}{/i}"
    new "    {i}{size=-3}La prima volta che hai portato {color=#FF0000}{b}lui{/b}{/color} a casa.{/size}{/i}"


    old "\nEnding 1: A (Not So) Clean Getaway -- {color=#FF0000}Complete{/color}"
    new "\nFinale 1: Un Ingresso (Non Proprio) Pulito -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You tried to clean your apartment but apparently you're not very good at it.{/size}{/i}"
    new "    {i}{size=-3}Hai provato a pulire il tuo appartamento, ma evidentemente non te la sei cavata molto bene.{/size}{/i}"


    old "\nEnding 2: Double Trouble -- {color=#FF0000}Complete{/color}"
    new "\nFinale 2: Doppi Guai -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You found the ones responsible for making a mess of your apartment. Haha, those little pranksters...{/size}{/i}"
    new "    {i}{size=-3}Hai scoperto chi è stato a devastare il tuo appartamento. Ahah, quei piccoli combinaguai...{/size}{/i}"


    old "\nEnding 3: Silent Film -- {color=#FF0000}Complete{/color}"
    new "\nFinale 3: Film Muto -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You let the cat sit in your favorite chair and watched a scary movie together. Just an ordinary movie night.{/size}{/i}"
    new "    {i}{size=-3}Hai lasciato al gatto la tua poltrona preferita per guardare un film di paura insieme. Una serata come tante altre.{/size}{/i}"


    old "\nEnding 4: Real \"Subtle\" -- {color=#FF0000}Complete{/color}"
    new "\nFinale 4: Davvero \"Originale\" -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You took back the chair from the cat and enjoyed some silly, little jumpscares alone.{/size}{/i}"
    new "    {i}{size=-3}Hai reclamato la poltrona dal gatto godendoti dei piccoli e stupidi momenti di paura per conto tuo.{/size}{/i}"


    old "\nEnding 5: Do {i}Nyaa-t{/i} Disturb -- {color=#FF0000}Complete{/color}"
    new "\nFinale 5: Non {i}Miao-lestarmi{/i} -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You shouldn't bother a cat while it's trying to nap...{/size}{/i}"
    new "    {i}{size=-3}Non dovresti disturbare un gatto che prova a dormire...{/size}{/i}"


    old "\nEnding 6: Just A Cat Nap -- {color=#FF0000}Complete{/color}"
    new "\nFinale 6: Un Semplice Pisolino -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Resting's good but you should get up and stretch every now and then... and eat... and {b}drink{/b}...{/size}{/i}"
    new "    {i}{size=-3}Riposarsi fa bene ma dovresti alzarti e muoverti ogni tanto... mangiare... e {b}bere{/b}...{/size}{/i}"


    old "\nEnding 7: Personal Boundaries -- {color=#FF0000}Complete{/color}"
    new "\nFinale 7: Confini Personali -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Knowing how to take \"no\" for an answer is an important life lesson.{/size}{/i}"
    new "    {i}{size=-3}Saper accettare un \"no\" come risposta è un'importante lezione di vita.{/size}{/i}"


    old "\nEnding 8: Fish Out of Water -- {color=#FF0000}Complete{/color}"
    new "\nFinale 8: Un Pesce Fuor d'Acqua -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You fed the cat some tuna. It liked it okay...{/size}{/i}"
    new "    {i}{size=-3}Hai dato del tonno al gatto. Gli è piaciuto...{/size}{/i}"


    old "\nEnding 9: Leftovers -- {color=#FF0000}Complete{/color}"
    new "\nFinale 9: Avanzi -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You fed the cat some leftover meatloaf. It liked it okay...{/size}{/i}"
    new "    {i}{size=-3}Hai dato del polpettone avanzato al gatto. Gli è piaciuto...{/size}{/i}"


    old "\nEnding 10: \"You are what you eat...\" -- {color=#FF0000}Complete{/color}"
    new "\nFinale 10: \"Sei ciò che mangi...\" -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You fed the cat... {b}something{/b}... It really, {b}really{/b} liked it...{/size}{/i}"
    new "    {i}{size=-3}Hai dato al gatto... {b}qualcosa{/b}... da mangiare. Gli è piaciuto {b}davvero{/b} tanto...{/size}{/i}"


    old "\nEnding 11: At The End of Your Rope -- {color=#FF0000}Complete{/color}"
    new "\nFinale 11: Hai Tirato Troppo la Corda -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}What cat doesn't love playing with some yarn?{/size}{/i}"
    new "    {i}{size=-3}A quale gatto non piace giocare con un filo di lana?{/size}{/i}"


    old "\nEnding 12: Targeted -- {color=#FF0000}Complete{/color}"
    new "\nFinale 12: Sotto Tiro -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}The cat loses its mind over a tiny red dot. Hilarious!{/size}{/i}"
    new "    {i}{size=-3}Il gatto impazzisce per un piccolo puntino rosso. Che buffo!{/size}{/i}"


    old "\nEnding 13: Disappointing Prey -- {color=#FF0000}Complete{/color}"
    new "\nFinale 13: Preda Deludente -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You can't run. Apparently you can't hide either.{/size}{/i}"
    new "    {i}{size=-3}Non puoi scappare. E non puoi neanche nasconderti.{/size}{/i}"


    old "\nEnding 14: Bath Hater -- {color=#FF0000}Complete{/color}"
    new "\nFinale 14: Odio Fare il Bagno -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Note to self: DO NOT THROW CATS INTO A BATHTUB FULL OF WATER{/size}{/i}"
    new "    {i}{size=-3}Nota bene: NON BUTTARE MAI UN GATTO IN UNA VASCA PIENA D'ACQUA{/size}{/i}"


    old "\nEnding 15: Self-Care Buddies -- {color=#FF0000}Complete{/color}"
    new "\nFinale 15: A-mici di Toelettatura -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}After you give the cat the full spa treatment, it tries its best to return the favor.{/size}{/i}"
    new "    {i}{size=-3}Dopo aver dato al gatto un trattamento da centro benessere, lui prova a restituirti il favore.{/size}{/i}"


    old "\nEnding 16: Poor Screening Arrangements -- {color=#FF0000}Complete{/color}"
    new "\nFinale 16: Cinema tra A-mici -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You go to the old theater and enjoy a film with an interesting stranger.{/size}{/i}"
    new "    {i}{size=-3}Vai al vecchio cinema per vedere un film con uno sconosciuto interessante.{/size}{/i}"


    old "\nEnding 17: Black Sheep -- {color=#FF0000}Complete{/color}"
    new "\nFinale 17: Pecora Nera -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You weren't a big fan of the movie at the new cinema. The rest of the audience might have opinions about that.{/size}{/i}"
    new "    {i}{size=-3}Vedere i film al nuovo cinema non fa per te. Il resto del pubblico potrebbe avere un'opinione diversa.{/size}{/i}"


    old "\nEnding 18: Happy Birthday -- {color=#FF0000}Complete{/color}"
    new "\nFinale 18: Congratulazioni! È un... gatto -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You have a front-row seat to the touching reunion of multiple siblings at the new cinema.{/size}{/i}"
    new "    {i}{size=-3}Hai un posto in prima fila al nuovo cinema per assistere alla nascita di una cucciolata.{/size}{/i}"


    old "\nEnding 19: You beat the maze :D -- {color=#FF0000}Complete{/color}"
    new "\nFinale 19: Superi il labirinto :D -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Whoa, you beat the maze on {b}hard mode?!{/b/} Holy COW! You're a real gamer, ain't ya?{/size}{/i}"
    new "    {i}{size=-3}Wow, hai superato il labirinto in {b}modalità difficile?!?{/b/} Che FICATA! Giochi da paura, eh?{/size}{/i}"


    old "    {i}{size=-3}Congratulations! You beat the maze.{/size}{/i}"
    new "    {i}{size=-3}Congratulazioni! Hai superato il labirinto.{/size}{/i}"


    old "\nEnding 20: You failed the maze :( -- {color=#FF0000}Complete{/color}"
    new "\nFinale 20: Non hai superato il labirinto :( -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Better luck next time...{/size}{/i}"
    new "    {i}{size=-3}Avrai più fortuna la prossima volta...{/size}{/i}"


    old "\nEnding 21: {color=#FF0000}d o g{/color}  person -- {color=#FF0000}Complete{/color}"
    new "\nFinale 21: Amante dei {color=#FF0000}c a n i{/color} -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}...You had a pleasant day at the  {color=#FF0000}{b}d o g{/b}{/color}  park.{/size}{/i}"
    new "    {i}{size=-3}... Hai passato una bella giornata all'area {color=#FF0000}{b}c a n i{/b}{/color}.{/size}{/i}"


    old "\nEnding 22: Not Alone -- {color=#FF0000}Complete{/color}"
    new "\nFinale 22: In Compagnia -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Isn't it nice to feel heard?{/size}{/i}"
    new "    {i}{size=-3}Non è bello essere ascoltati?{/size}{/i}"


    old "\nEnding 23: Feedback loop -- {color=#FF0000}Complete{/color}"
    new "\nFinale 23: Circolo vizioso -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You try to leave the alley. It doesn't work. You try to leave the alley. It doesn't work. You try to leave the alley. It doesn't{/size}{/i}"
    new "    {i}{size=-3}Provi a uscire dal vicolo. Non ci riesci. Provi a uscire dal vicolo. Non ci riesci. Provi a uscire dal vicolo. Non ci{/size}{/i}"


    old "\nEnding 24: Fishing for pardon -- {color=#FF0000}Complete{/color}"
    new "\nFinale 24: A Pesca di scuse -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Silly you! Chocolate is bad for cats! {s}{color=#FF0000}But you knew that, didn't you?{/color}{/s}{/size}{/i}"
    new "    {i}{size=-3}Che idiota! La cioccolata è tossica per i gatti! {s}{color=#FF0000}Ma lo sapevi già, no?{/color}{/s}{/size}{/i}"


    old "\nEnding 25: Seafood Sacrifice -- {color=#FF0000}Complete{/color}"
    new "\nFinale 25: Offerta di Pesce -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You kindly feed some poor, hungry cats a fish. How nice of you!{/size}{/i}"
    new "    {i}{size=-3}Hai generosamente dato un pesce a dei poveri gatti affamati. Che bel gesto!{/size}{/i}"


    old "\nEnding 26: A life spared -- {color=#FF0000}Complete{/color}"
    new "\nFinale 26: Una vita risparmiata -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You decide not to feed the poor, hungry cat a {s}helpless{/s} mouse. Meanie...{/size}{/i}"
    new "    {i}{size=-3}Privi il povero gatto affamato di un topolino {s}indifeso{/s}. Che cattiveria...{/size}{/i}"


    old "\nEnding 27: Well-Fed -- {color=#FF0000}Complete{/color}"
    new "\nFinale 27: Ben Nutrito -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Cats are supposed to eat mice. Huh, wonder what mice are supposed to eat...{/size}{/i}"
    new "    {i}{size=-3}I gatti mangiano i topi. Uhm, chissà cosa mangeranno i topi allora...{/size}{/i}"


    old "\nEnding 28: Personal care package -- {color=#FF0000}Complete{/color}"
    new "\nFinale 28: Il pranzo è servito -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You share a nice meal with the cat. A bit high in iron though.{/size}{/i}"
    new "    {i}{size=-3}Condividi un pasto assieme al gatto. Ad alto contenuto di ferro, s'intende.{/size}{/i}"


    old "\nEnding 29: All You Can Eat Blood-fey -- {color=#FF0000}Complete{/color}"
    new "\nFinale 29: All You Can Eat al Sangue -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You give the cat an endless supply of food. Generous.{/size}{/i}"
    new "    {i}{size=-3}Dai al gatto un'infinita riserva di cibo. Che generosità.{/size}{/i}"


    old "\nEnding 30: Photo bomber -- {color=#FF0000}Complete{/color}"
    new "\nFinale 30: Photo bomber -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You really nailed your good side in this one!{/size}{/i}"
    new "    {i}{size=-3}In questa foto sei proprio una bomba!{/size}{/i}"


    old "\nEnding 31: Headshot -- {color=#FF0000}Complete{/color}"
    new "\nFinale 31: Colpo di testa -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}It's okay, we all get a little camera shy sometimes.{/size}{/i}"
    new "    {i}{size=-3}È tutto ok, le foto mettono spesso la gente a disagio.{/size}{/i}"


    old "\nEnding 32: Fear Quitter -- {color=#FF0000}Complete{/color}"
    new "\nFinale 32: Codardia Improvvisa -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}\"When the going gets tough, just give up.\" That's how the saying goes, right?{/size}{/i}"
    new "    {i}{size=-3}\"Quando il gioco si fa duro, non chiamatemi.\" Era questo il detto, giusto?{/size}{/i}"


    old "\nEnding 33: {b}eRRoR{/b} \\ FoUnD -- {color=#FF0000}Complete{/color}"
    new "\nFinale 33: {b}eRRoRe{/b} \\ RiLevAtO -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}\"An exception has occurred. Please refrain from going outside of permitted parameters.\"{/size}{/i}"
    new "    {i}{size=-3}\"Rilevata anomalia. Si consiglia di evitare di uscire dai parametri consentiti.\"{/size}{/i}"


    old "\nEnding 34: Living doll -- {color=#FF0000}Complete{/color}"
    new "\nFinale 34: Peluche vivente -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You end up getting the cat a nice companion!{/size}{/i}"
    new "    {i}{size=-3}Hai trovato un'adorabile compagnia per il gatto!{/size}{/i}"


    old "\nEnding 35: Cotton Headed -- {color=#FF0000}Complete{/color}"
    new "\nFinale 35: Imbambolarsi del Tutto -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You're the only friend it needs.{/size}{/i}"
    new "    {i}{size=-3}Ha bisogno solamente della tua amicizia.{/size}{/i}"


    old "\nEnding 36: Eight more left -- {color=#FF0000}Complete{/color}"
    new "\nFinale 36: Ne restano sei -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Well that's {b}one{/b} down... Good luck on the rest.{/size}{/i}"
    new "    {i}{size=-3}Beh, e {b}una{/b} è andata... Buona fortuna per le altre.{/size}{/i}"


    old "\nEnding 37: {b}F o r e v e r{/b} -- {color=#FF0000}Complete{/color}"
    new "\nFinale 37: {b}P e r  S e m p r e{/b} -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You join the cat. Now you'll always be together. At least... until...{/size}{/i}"
    new "    {i}{size=-3}Ti unisci al gatto. Ora starete insieme per sempre. O almeno... fino a quando...{/size}{/i}"


    old "\nEnding 38: Do NOT Take This Cat Home -- {color=#FF0000}Complete{/color}"
    new "\nFinale 38: NON Portare Questo Gatto a Casa -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}Bad kitty.{/size}{/i}"
    new "    {i}{size=-3}Gattino cattivo.{/size}{/i}"


    old "\nEnding N/A: Another day... -- {color=#FF0000}Complete{/color}"
    new "\nFinale N/A: Un altro giorno... -- {color=#FF0000}Completo{/color}"


    old "    {i}{size=-3}You have a nice day off and go home to spend the rest of the evening with your cute, little kitten.{/size}{/i}"
    new "    {i}{size=-3}Passi un bel giorno libero e torni a casa per trascorrere la serata col tuo piccolo e adorabile gattino.{/size}{/i}"


    old "Page {}"
    new "Pagina {}"


    old "Automatic saves"
    new "Salvataggi automatici"


    old "Quick saves"
    new "Salvataggi rapidi"


    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"


    old "empty slot"
    new "nuovo salvataggio"


    old "<"
    new "<"


    old "{#auto_page}A"
    new "{#auto_page}A"


    old "{#quick_page}Q"
    new "{#quick_page}Q"


    old ">"
    new ">"


    old "Display"
    new "Schermo"


    old "Window"
    new "Finestra"


    old "Fullscreen"
    new "Schermo Intero"


    old "Rollback Side"
    new "Funzione Indietro"


    old "Disable"
    new "Disabilita"


    old "Left"
    new "Click a Sinistra"


    old "Right"
    new "Click a Destra"


    old "Unseen Text"
    new "Testo Nascosto"


    old "After Choices"
    new "Dopo le Scelte"


    old "Transitions"
    new "Transizioni"


    old "Language"
    new "Lingua"


    old "Text Speed"
    new "Velocità Testo"


    old "Auto-Forward Time"
    new "Avanzamento Automatico Tempo"


    old "Music Volume"
    new "Volume Musica"


    old "Sound Volume"
    new "Volume Audio"


    old "Test"
    new "Test"


    old "Voice Volume"
    new "Volume Dialogo"


    old "Mute All"
    new "Muta Tutto"


    old "The dialogue history is empty."
    new "La cronologia dei dialoghi è vuota."


    old "Keyboard"
    new "Tastiera"


    old "Mouse"
    new "Mouse"


    old "Gamepad"
    new "Controller"


    old "Enter"
    new "Invio"


    old "Advances dialogue and activates the interface."
    new "Manda avanti il dialogo e attiva l'interfaccia."


    old "Space"
    new "Spazio"


    old "Advances dialogue without selecting choices."
    new "Manda avanti il dialogo senza selezionare le scelte."


    old "Arrow Keys"
    new "Frecce Direzionali"


    old "Navigate the interface."
    new "Esplora l'interfaccia."

    old "*Delete Save"
    new "*Elimina Salvataggio"


    old "Escape"
    new "Esc"


    old "Accesses the game menu."
    new "Accedi al menu di gioco."


    old "Ctrl"
    new "Ctrl"


    old "Skips dialogue while held down."
    new "Tieni premuto per saltare il dialogo."


    old "Tab"
    new "Tab"


    old "Toggles dialogue skipping."
    new "Salta i dialoghi."


    old "Page Up"
    new "Pag Su"


    old "Rolls back to earlier dialogue."
    new "Torna al dialogo precedente."


    old "Page Down"
    new "Pag Giù"


    old "Rolls forward to later dialogue."
    new "Procedi al dialogo successivo."


    old "Hides the user interface."
    new "Nascondi l'interfaccia utente."


    old "Takes a screenshot."
    new "Fai uno screenshot."


    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Attiva/Disattiva la {a=https://www.renpy.org/l/voicing}lettura del testo{/a} assistita."


    old "Select save file with directional pad and press \"delete\" key."
    new "Seleziona il file di salvataggio con pad direzionale e premi il tasto \"cancella\"."


    old "Left Click"
    new "Click Sinistro"


    old "Middle Click"
    new "Click Centrale"


    old "Right Click"
    new "Click Destro"


    old "Mouse Wheel Up\nClick Rollback Side"
    new "Rotella del Mouse Su\nFunzione Indietro"


    old "Mouse Wheel Down"
    new "Rotella del Mouse Giù"


    old "Hover mouse over save file and press \"delete\" key."
    new "Passa il mouse sopra il file di salvataggio e premi il tasto \"cancella\"."


    old "Right Trigger\nA/Bottom Button"
    new "Grilletto Destro\nA/Pulsante in Basso"


    old "Left Trigger\nLeft Shoulder"
    new "Grilletto Sinistro\nDorsale Sinistro"


    old "Right Shoulder"
    new "Dorsale Destro"


    old "D-Pad, Sticks"
    new "Pad Direzionale, Levette"


    old "Start, Guide"
    new "Start, Guida"


    old "Y/Top Button"
    new "Y/Pulsante in Alto"


    old "Calibrate"
    new "Calibra"


    old "Backgrounds &"
    new "Sfondi &"


    old "BG/Art References"
    new "Sfondi/Riferimenti Artistici"


    old "Pexels.com\n"
    new "Pexels.com\n"


    old "Sound Effects"
    new "Effetti Audio"


    old "Pixabay.com\n"
    new "Pixabay.com\n"


    old "Programmed with"
    new "Programmato con"


    old "Ren'Py\n"
    new "Ren'Py\n"

    old "Português-BR Translation"
    new "Traduzione Portoghese-BR"


    old "Italian Translation"
    new "Traduzione Italiana"






    old "And you..."
    new "E a te..."


    old "Thank you for playing!\n"
    new "Grazie per aver giocato!\n"

    old "{size=+40}Do Not Take{/size}"
    new "{size=+40}Non Portare{/size}"

    old "{size=+40}{color=#FF0000}I T {/color} Home{/size}"
    new "{size=+40}{color=#FF0000}L U I {/color} a Casa{/size}"

    old "{size=+40}This Cat Home{/size}"
    new "{size=+40}Questo Gatto a Casa{/size}"


    old "Skipping"
    new "Salta"


    old "Menu"
    new "Menu"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
