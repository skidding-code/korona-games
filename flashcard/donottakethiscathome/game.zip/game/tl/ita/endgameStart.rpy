


translate ita endCat_6022b618:


    "Davvero? È la tua decisione finale?"


translate ita endCat_a20cefa7:


    "..."


translate ita endCat1_a20cefa7:


    "..."


translate ita endCat1_ee69ed58:


    "Una volta fatto..."


translate ita endCat1_5376e166:


    "... NON POTRAI più tornare indietro."


translate ita endCat1_8dabefc6:


    ".."


translate ita endCat1_a20cefa7_1:


    "..."


translate ita endCat2_a20cefa7:


    "..."


translate ita endCat2_18858365:


    "Ultima possibilità."


translate ita endCat2_f66a6910:


    "Ne hai la totale e {b}assoluta{/b} certezza?"


translate ita endCat2_a20cefa7_1:


    "..."


translate ita endCat2_0a4bf479:


    "... Oh, sì che lo faremo."


translate ita endCat2_d56150af:


    "Per sempre..."


translate ita endCatFinal_a20cefa7:


    "..."


translate ita endCatFinal_dae0ec55:


    you "..."


translate ita endCatFinal_7f0ac95c:


    cat "..."


translate ita endCatFinal_8dabefc6:


    ".."


translate ita endCatFinal_a20cefa7_1:


    "..."


translate ita endCatFinal_0b3e6813:


    "Uccidi il gatto."


translate ita endCatFinal_99b6c530:


    "Il suo corpo giace immobile e senza vita nella scatola di cartone insanguinata."


translate ita endCatFinal_8dabefc6_1:


    ".."


translate ita endCatFinal_a20cefa7_2:


    "..."


translate ita endCatMenu_20873599:


    "Cosa hai intenzione di fare?"


translate ita endPockets_5308f154:


    "È inutile."


translate ita endPockets_edd17d2d:


    "Il gatto è morto."


translate ita endPockets_bcb34bfb:


    "Cominci ugualmente a cercare qualcosa nelle tasche..."


translate ita endPockets_a89eb7de:


    "Tasca sinistra..."


translate ita endPockets_600502e3:


    "... Filo. {w}Inutile."


translate ita endPockets_197df679:


    "Tasca destra..."


translate ita endPockets_a20cefa7:


    "..."


translate ita endPockets_2bcc0dba:


    "{color=#FF0000}{b}... Cioccolato.{/b}{/color}"


translate ita endPockets_8eb9bd2b:


    "Mangi il cioccolato."


translate ita endPockets_559496a2:


    "Hai anche il telefono."


translate ita endPockets_1a0c66b1:


    "Vuoi fare una foto?"


translate ita endPockets_a20cefa7_1:


    "..."


translate ita endPockets_c8d556cd:


    "Inutile."


translate ita endPockets_edd17d2d_1:


    "Il gatto è morto."


translate ita endLook_2e60e8b3:


    "Che cosa stai cercando?"


translate ita endLook_edd17d2d:


    "Il gatto è morto."


translate ita endLook_30561a58:


    "Dai comunque un'occhiata..."


translate ita endLook_2af5fa5c:


    "Guardi sia a sinistra che a destra..."


translate ita endLook_e8093ee2:


    "... C'è soltanto immondizia."


translate ita endLook_c96ce435:


    "Guardi in alto..."


translate ita endLook_52bbc94a:


    "... La luce del sole non riesce ad arrivare fino a qui."


translate ita endLook_29e137bf:


    "Ma capisci lo stesso che oggi è una bellissima giornata."


translate ita endLook_35f3a46a:


    "Guardi dietro di te..."


translate ita endLook_8dabefc6:


    ".."


translate ita endLook_a20cefa7:


    "..."


translate ita endLook_1dc79289:


    "{size=-10}{b}nessuno ha visto niente.{/b}{/size}"


translate ita endLook_a4cef966:


    "Guardi in basso davanti a te..."


translate ita endLook_8dabefc6_1:


    ".."


translate ita endLook_a20cefa7_1:


    "..."


translate ita endLook_49dade07:


    "Ah già..."


translate ita endLook_edd17d2d_1:


    "Il gatto è morto."


translate ita endLeave_b5a44804:


    "Non c'è altro da fare qui."


translate ita endLeave_a40ffd19:


    "Ti volti ed esci dal vicolo..."


translate ita endLeave_8dabefc6:


    ".."


translate ita endLeave_a20cefa7:


    "..."


translate ita endLeave_40d9ca73:


    "...?"


translate ita endLeave_ec199ff2:


    "O almeno... {w}Ci {i}provi{/i}..."


translate ita endLeave_74fbacaf:


    "Mentre ti affacci sull'uscita del vicolo..."


translate ita endLeave_d9a60d33:


    "... noti che non esiste più nulla all'esterno."


translate ita endLeave_16e07799:


    "Soltanto un abisso nero e vuoto."


translate ita endLeave_8ca8510a:


    you "!!!" with vpunch


translate ita endLeave_252552a2:


    "Ti volti..."


translate ita endLeave_88047473:


    "... e vedi che la fine del vicolo è stata avvolta dall'oscurità."


translate ita endLeave_d8c18e4f:


    "Non riesci più a vedere nulla."


translate ita endLeave2_cfb03abe:


    "{size=-5}Ma qui non c'è niente.{/size}"


translate ita endLeave3_ca0588d8:


    "Non hai altre opzioni, quindi fai un passo verso l'oscurità..."


translate ita endLeave3_624b526a:


    "E un altro..."


translate ita endLeave3_a20cefa7:


    "..."


translate ita endLeave3_57fba23d:


    "Ti avvicini..."


translate ita endLeave3_6faf07b3:


    "Ancora u-{w=0.3}{nw}"


translate ita endLeave3_50da432c:


    "{size=+10}{b}SLASH!!!{/b}{/size}" with hpunch


translate ita endLeave3_632d1a35:


    you "!!!" with hpunch


translate ita endLeave3_8dabefc6:


    ".."


translate ita endLeave3_a20cefa7_1:


    "..."


translate ita endLeave3_23a3bbe5:


    "Stai..."


translate ita endLeave3_13ee741d:


    "Stai sangui-{w=0.2}{nw}"


translate ita endLeave3_ea937b79:


    "{size=+15}{b}{i}SLASH!!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch


translate ita endLeave3_9a0232ef:


    "{size=+20}{b}{i}SLASH!!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch


translate ita endLeave3_e1d010df:


    "{size=+25}{b}{i}SLASH!!! SLASH!!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch


translate ita endLeave3_c6e79053:


    "{size=+30}{b}{i}{color=#FF0000}SLASH!!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with vpunch


translate ita endLeave3_cc9a5909:


    "!!!"


translate ita endLeave3_a20cefa7_2:


    "..."


translate ita endLeave3_8dabefc6_1:


    ".."


translate ita endLeave3_a20cefa7_3:


    "..."


translate ita endLeave3_c6478448:


    "Cadi in ginocchio..."


translate ita endLeave3_c760ebc8:


    "La parte frontale del tuo corpo è dilaniata. Sangue, budella e organi si riversano sulle tue gambe."


translate ita endLeave3_27a9cba3:


    who "non... lo... {w}sai...{w}"


translate ita endLeave3_cfc77429:


    who "{size=-10}... che i gatti hanno \ {b}{color=#FF0000}S E T T E{/color}{/b} \ vite~?{/size}"


translate ita endLeave3_a79a5fec:


    you "Asp-{w=0.3}{nw}"


translate ita endLeave3_b363dab3:


    "{size=+30}{b}{i}{color=#FF0000}SLASH!!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch


translate ita endLeave3_a40c3115:


    "{size=+35}{b}{i}{color=#FF0000}SLASH!!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch


translate ita endLeave3_13c80e81:


    "{size=+40}{b}{i}{color=#FF0000}S L A S H ! ! !{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch


translate ita endLeave3_8dabefc6_2:


    ".."


translate ita endLeave3_a20cefa7_4:


    "..."


translate ita endLeave3_66ecbb19:


    "Finale 36: Ne restano sei"


translate ita endLeave3_a20cefa7_5:


    "..."

translate ita strings:


    old "Maybe not..."
    new "Forse no..."

    old "Yes."
    new "Sì."


    old "I've changed my mind, let's go back!"
    new "Ho cambiato idea, torniamo indietro!"


    old "...Do it."
    new "... Fallo"


    old "This is the point of NO return. Are you sure there's nothing else you wish to do?"
    new "Questo è il punto di NON ritorno. Non c'è nient'altro che vorresti fare?"


    old "Take me back, I want us to play forever."
    new "Riprendimi con te, voglio che giochiamo per sempre."

    old "...and ever."
    new "... per l'eternità."


    old "{b}{color=#FF0000}k i l l... t h e... c a t...{/color}{/b}"
    new "{b}{color=#FF0000}u c c i d i... i l... g a t t o...{/color}{/b}"


    old "...Check pockets."
    new "... Controlla le tasche"


    old "...Look around the area."
    new "... Osserva l'area attorno a te"


    old "leave."
    new "esci"


    old "Leave the alley."
    new "Esci dal vicolo"


    old "Approach the darkness"
    new "Avvicinati all'oscurità"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
