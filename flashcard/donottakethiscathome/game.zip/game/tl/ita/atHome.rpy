


translate ita atHome_start_dc8d0895:


    "Tipo?"


translate ita atHome_start_dc8d0895_1:


    "Tipo?"


translate ita cleanHome_a2afa525:


    "Decidi che, anche se oggi è il tuo giorno libero, non devi farti {i}vincere{/i} dalla pigrizia."


translate ita cleanHome_d5bf1ac2:


    "Sai di avere ospiti, ma non è proprio il caso di rimandare le faccende domestiche."


translate ita cleanHome_82116c0b:


    "Meglio farle quando sei ancora dell'umore giusto..."


translate ita cleanHome_38aeb1c1:


    "Quindi, per ora, ti vesti, ti rimbocchi le maniche e pulisci l'appartamento."


translate ita cleanHome_8dabefc6:


    ".."


translate ita cleanHome_a20cefa7:


    "..."


translate ita cleanHome_0ef3b42c:


    "O almeno..."


translate ita cleanHome_be509105:


    "... ci {i}provi{/i}?"


translate ita cleanHome_251a3003:


    "Spolveri il salotto..."


translate ita cleanHome_801add69:


    "Lucidi il ripiano della cucina..."


translate ita cleanHome_0f5de544:


    "Rifai..."


translate ita cleanHome_94b91bfc:


    "D'accordo, non rifai il letto ma, d'altronde, chi lo rifà mai?"


translate ita cleanHome_a20cefa7_1:


    "..."


translate ita cleanHome_b3e12ea5:


    "Eppure..."


translate ita cleanHome_e3226b50:


    "Noti che non importa quanto tu pulisca..."


translate ita cleanHome_fe5c443f:


    "... continui a trovare più disordine di quando hai iniziato."


translate ita cleanHome_dae0ec55:


    you "..."


translate ita cleanHome_6cf4e540:


    "Lanci uno sguardo al gatto."


translate ita cleanHome_9e899f4f:


    "Sospetti sia lui il colpevole che si nasconde dietro il mistero..."


translate ita cleanHome_ef50fc2a:


    "Ma ogni volta che tenti di scovarlo con le zampe nel sacco..."


translate ita cleanHome_78b6d9cf:


    cat "Purr... Purr..."


translate ita cleanHome_e12dcff9:


    "... lo trovi sempre che dorme in salotto."


translate ita cleanHome_78b6d9cf_1:


    cat "Purr... Purr..."


translate ita cleanHome_dae0ec55_1:


    you "..."


translate ita cleanHome_70e6e0c9:


    "Riprendi a pulire, ma il gatto..."


translate ita cleanHome_350e9976:


    "... o {i}qualcos'altro{/i}..."


translate ita cleanHome_3333a159:


    "... crea sempre più caos dovunque passi."


translate ita keepCleaning_f8527730:


    "Continui a pulire, ma ce n'è ancora..."


translate ita keepCleaning_2eaedbe8:


    "E ancora..."


translate ita keepCleaning_a20cefa7:


    "..."


translate ita keepCleaning_d9897097:


    "E {i}ancora{/i}..."


translate ita keepCleaning_8fe73cbe:


    "Quando finalmente ti fermi e ti guardi attorno..."


translate ita keepCleaning_8dabefc6:


    ".."


translate ita keepCleaning_a20cefa7_1:


    "..."


translate ita keepCleaning_a20cefa7_2:


    "..."


translate ita keepCleaning_df223326:


    "... casa tua è irriconoscibile."


translate ita keepCleaning_d37d2b14:


    "Ci sono pile di cianfrusaglie ovunque. Ma è {i}tutta{/i} tua questa roba?"


translate ita keepCleaning_f12f1103:


    "Non ricordi di aver mai preso o ricevuto la maggior parte di queste cose."


translate ita keepCleaning_6b45c41b:


    "Le torri di sporco ti sovrastano."


translate ita keepCleaning_1b4957f6:


    "Ti manca l'aria."


translate ita keepCleaning_7c04f542:


    "La puzza di rifiuti è asfissiante, nonostante tu senta le mani infiammate dalla quantità di detergente che hai usato."


translate ita keepCleaning_9e56909e:


    "Ti bruciano ancora gli occhi per la candeggina."


translate ita keepCleaning_1f4f5647:


    "Hai bisogno di aria fresca."


translate ita keepCleaning_47312e78:


    "Devi uscire da qui."


translate ita keepCleaning_a46102ae:


    "Crack!" with hpunch


translate ita keepCleaning_08ca5ed4:


    "Senti un rumore di cocci e vedi una tazza da tè, certamente non tua, frantumarsi a terra."


translate ita keepCleaning_2ee0c458:


    "Guardi in su e vedi il gatto sopra un servizio di porcellana e una pila di elettrodomestici."


translate ita keepCleaning_dde8fd86:


    "Con attenzione, sposta un'altra tazza dalla pila e la spinge a terra..."


translate ita keepCleaning_f68c64ac:


    "... ma non muovi neanche un muscolo mentre si frantuma."


translate ita keepCleaning_4cb92d86:


    "Invece..."


translate ita keepCleaning_cd64e084:


    you "Eh eh..."


translate ita keepCleaning_bc45b6ba:


    "Cominci a sogghignare."


translate ita keepCleaning_0931d500:


    you "Eheheh!"


translate ita keepCleaning_d7e774f2:


    "All'improvviso stai ridendo. È tutto così ridicolo..."


translate ita keepCleaning_852190f9:


    you "AHAHAH!" with hpunch


translate ita keepCleaning_a2a51a94:


    "... che le lacrime cominciano a scorrere sul tuo viso."


translate ita keepCleaning_3e62584c:


    you "Lo {i}sapevo{/i} che eri tu! Sei stato {i}tu{/i}, non è vero?"


translate ita keepCleaning_f6110b17:


    "Tiri su il frammento di ceramica più grande dalle tazze rotte..."


translate ita keepCleaning_ffcea493:


    you "{size=+5}{b}{i}NON È{/i}{/b} VERO?!?{/size}" with hpunch


translate ita keepCleaning_bcb59dd1:


    "... e lo lanci verso il gatto."


translate ita keepCleaning_d9053550:


    "Il gatto lo schiva saltando dalla pila."


translate ita keepCleaning_89623c0d:


    "La pila... oscilla."


translate ita keepCleaning_6ba05e33:


    "Oscilla..."


translate ita keepCleaning_8dabefc6_1:


    ".."


translate ita keepCleaning_a20cefa7_3:


    "..."


translate ita keepCleaning_03fd754d:


    "... Sta crollando."


translate ita keepCleaning_28b3ac41:


    you "!!!"


translate ita keepCleaning_b1a6c334:


    "... Sta crollando sopra di t--{w=0.8}{nw}"


translate ita keepCleaning_180588a5:


    "{size=+25}{b}{i}CRASH!!!{/i}{/b}{/size}" with vpunch


translate ita keepCleaning_8dabefc6_2:


    ".."


translate ita keepCleaning_a20cefa7_4:


    "..."


translate ita keepCleaning_77a402e9:


    "... Non riesci a muoverti."


translate ita keepCleaning_23a3bbe5:


    "I cocci..."


translate ita keepCleaning_19c2b1c0:


    "... ti sommergono."


translate ita keepCleaning_1600c9a3:


    "La pila intera ti è caduta addosso."


translate ita keepCleaning_f5935cf0:


    "Frammenti rotti di raffinate porcellane e utensili appuntiti ti graffiano la pelle..."


translate ita keepCleaning_2e357ce3:


    "I tuoi {b}organi{/b}..."


translate ita keepCleaning_9c53ce22:


    "Senti le ossa dislocate e fragili... schiacciate sotto i pesanti elettrodomestici."


translate ita keepCleaning_cea9f1b7:


    "Un liquido caldo si accumula sotto di te."


translate ita keepCleaning_7c3e10e7:


    "Con le tue ultime forze..."


translate ita keepCleaning_8dd57887:


    "... senti il gatto avvicinarsi, per poi sdraiarsi e fare le fusa con aria assonnata."


translate ita keepCleaning_55355e09:


    cat "Purr... Purr..."


translate ita keepCleaning_dae0ec55:


    you "..."


translate ita keepCleaning_4914da37:


    "In effetti..."


translate ita keepCleaning_8ad69668:


    "Un pisolino..."


translate ita keepCleaning_8a5ba85b:


    "{size=-5}sembra proprio...{/size}"


translate ita keepCleaning_444906a3:


    "{size=-10}una buona idea...{/size}"


translate ita keepCleaning_dae0ec55_1:


    you "..."


translate ita keepCleaning_a20cefa7_5:


    "..."


translate ita keepCleaning_fdf7d678:


    "Finale 1: Un Ingresso (Non Proprio) Pulito"


translate ita catchCat_2d0b7d8d:


    "Come potrai mai finire di pulire tutto mentre questa piccola peste minaccia di fare disastri?"


translate ita catchCat_bcf6dd4d:


    "No."


translate ita catchCat_eeaa381b:


    "Tu {i}sai{/i} che il gatto è il colpevole..."


translate ita catchCat_f18bba2e:


    "Valuti se sia il caso di chiuderlo in bagno, almeno fino a quando non finirai di pulire l'appartamento..."


translate ita catchCat_857162a0:


    "... Ma non sembra comunque giusto senza prove concrete."


translate ita catchCat_23e7b8d0:


    "È necessario indagare ancora."


translate ita catchCat_7142699f:


    "Hai bisogno di prove."


translate ita catchCat_5d38d834:


    "Non solo per la tua sanità mentale, ma proprio in nome..."


translate ita catchCat_d81de3ab:


    "... della {b}{i}pulizia!{/i}{/b}" with hpunch


translate ita catchCat_302a1096:


    "Ricominci a pulire e ogni tanto lanci un'occhiata dietro di te, notando il gatto con la coda dell'occhio..."


translate ita catchCat_66dd8df3:


    "Ma come prima, quando corri in salotto, trovi il gatto ancora addormentato."


translate ita catchCat_7c813d85:


    you "{i}Ok, vuoi giocare con me, gatto?{/i}"


translate ita catchCat_1df4b1f2:


    you "{i}Allora giochiamo{/i}..."


translate ita catchCat_5264ec6b:


    "Questa volta decidi di preparare una trappola a cui il tuo amico felino non potrà resistere."


translate ita catchCat_e6ab25a3:


    "Affronti il bancone della cucina con tanto {b}{i}olio di gomito{/i}{/b}."


translate ita catchCat_f8c31f4c:


    "Una volta finito è {i}scintillante{/i}."


translate ita catchCat_ece57ede:


    "È così pulito..."


translate ita catchCat_737ad384:


    "... che tireresti un calcio a chiunque possa anche solo {b}{i}pensare{/i}{/b} di mangiarci sopra."


translate ita catchCat_965246c3:


    "La trappola perfetta per il tuo piccolo sabotatore di pulizie."


translate ita catchCat_caf7a734:


    "Fischietti in modo innocente mentre esci dalla stanza e ti nascondi dietro l'angolo del salone."


translate ita catchCat_66b634bf:


    "Dal punto in cui ti trovi, hai una vista perfetta del gatto e del bancone della cucina."


translate ita catchCat_12e1a084:


    "Adesso sì che coglierai il colpevole sul fatto."


translate ita catchCat_c456968c:


    "Se invece non si trattasse del gatto, gli darai un premio per scusarti dei tuoi sospetti, magari?"


translate ita catchCat_0197e62d:


    "Ma mentre consideri l'idea di andare al negozio di alimentari per prendere del pesce... il gatto inizia a..."


translate ita catchCat_8f5e83db:


    "... mutare?"


translate ita catchCat_80e45c97:


    "Il suo dorso, che poco prima si alzava e abbassava regolarmente..."


translate ita catchCat_abeaf9eb:


    "... si sta ora increspando con piccoli tremolii simili a onde agitate su un mare nero."


translate ita catchCat_451b684a:


    "Sta sussultando..."


translate ita catchCat_4da3e6b9:


    "Sta ribollendo..."


translate ita catchCat_91204d86:


    "Si sta gonfiando..."


translate ita catchCat_51fdb3a7:


    "Si sta {b}{i}gonfiando--{/i}{/b}{w=0.3}{nw}"


translate ita catchCat_7b893834:


    "{b}{size=+15}POP!{/size}{/b}" with vpunch


translate ita catchCat_90b68c87:


    you "...?"


translate ita catchCat_78ae5d65:


    you "...?!?" with hpunch


translate ita catchCat_13a4394e:


    you "{i}Ma... che {b}diavolo{/b}...?{/i}"


translate ita catchCat_0673262a:


    "Spalanchi la bocca con stupore quando {b}un altro gatto{/b} emerge dal felino che hai portato a casa, mentre lui continua a {i}dormire{/i}."


translate ita catchCat_dae0ec55:


    you "..."


translate ita catchCat_23a3bbe5:


    "Tu hai..."


translate ita catchCat_3b3dcfd1:


    "Hai la {i}quasi{/i} totale certezza che i gatti non nascano così."


translate ita catchCat_200e4ba1:


    "Ma più di ogni altra cosa..."


translate ita catchCat_c1255ce3:


    "Osservi il gatto n.2 scrollarsi se stesso di dosso per poi saltare sul bancone..."


translate ita catchCat_0f4a0748:


    "... rotolandosi, lasciando peli e sporco dappertutto."


translate ita catchCat_7f180865:


    you "{i}Uhm. Forse avrei dovuto fargli un bagno prima{/i}..."


translate ita catchCat_cc415aaf:


    "Hai l'impressione che la tua mente stia rimanendo indietro, davanti a ciò che hai scoperto..."


translate ita catchCat_5624fa4d:


    "... ma sembra che tu non riesca a formulare nulla più che piccole osservazioni."


translate ita catchCat_b4139f5d:


    "Per esempio..."


translate ita catchCat_c841f0ba:


    "Nonostante i come e i perché ti sfuggano..."


translate ita catchCat_7d96eba3:


    "... la domanda più importante che ti ronza in testa è: se il gatto originario sta ancora dormendo..."


translate ita catchCat_8301e7ce:


    "... e il suo clone sta facendo {i}l'ennesimo{/i} disastro..."


translate ita catchCat_8dabefc6:


    ".."


translate ita catchCat_a20cefa7:


    "..."


translate ita catchCat_031168fd:


    "{size=-8}... allora, dove sono tutti gli {b}altri{/b} cloni?{/size}"


translate ita catchCat_8ca8510a:


    you "!!!" with vpunch


translate ita catchCat_9107a91b:


    "All'improvviso, i due gatti cominciano a fissarti all'unisono."


translate ita catchCat_7f0ac95c:


    cat "..."


translate ita catchCat_2849e452:


    cat2 "..."


translate ita catchCat_dae0ec55_1:


    you "..."


translate ita catchCat_5b9cf052:


    "I loro occhi ti inchiodano sul posto con la loro intensità..."


translate ita catchCat_a20cefa7_1:


    "..."


translate ita catchCat_bf0874e3:


    "Ma..."


translate ita catchCat_77335cac:


    "Ti accorgi, preda della familiare e deprimente sensazione che qualcuno ti stia spiando..."


translate ita catchCat_7fe62e1d:


    "... che quelli non sono gli {i}unici{/i} occhi che ti fissano."


translate ita catchCat_2da9a525:


    "Ti volti lentamente..."


translate ita catchCat_479c3431:


    you "!!!" with vpunch


translate ita catchCat_d6b508aa:


    "Nell'ingresso alle tue spalle, così alto da arrivare al soffitto..."


translate ita catchCat_8434b31c:


    "... c'è un muro di gatti vivente, che respira e {i}si contorce{/i}..."


translate ita catchCat_2df33dd1:


    "... formato dai {i}{b}cloni{/b}{/i}..."


translate ita catchCat_6a0c9ea0:


    "... impilati uno sopra l'altro."


translate ita catchCat_a9d5e578:


    "Gli occhi dorati e brillanti di ogni gatto, nel muro di pelliccia nera ondeggiante..."


translate ita catchCat_34b528c2:


    "Ogni singolo occhio..."


translate ita catchCat_dff87f71:


    "... è fisso su di te."


translate ita catchCat_dae0ec55_2:


    you "..."


translate ita catchCat_5a6e3687:


    "Per la paura e il profondo, disperato bisogno di allontanarti da questa mostruosità aberrante..."


translate ita catchCat_9a5f0b90:


    "... compi un singolo passo all'indietro."


translate ita catchCat_8dabefc6_1:


    ".."


translate ita catchCat_a20cefa7_2:


    "..."


translate ita catchCat_4d3e0545:


    "... Per tutta risposta..."


translate ita catchCat_3d2d7818:


    "il muro semplicemente..."


translate ita catchCat_3c6ffc63:


    "... {b}crolla{/b}."


translate ita catchCat_a3a8c547:


    "... Sopra di te senti un fuggi fuggi di gatti."


translate ita catchCat_a7561dac:


    "Sarebbe anche..."


translate ita catchCat_f46b477d:


    "... carino?"


translate ita catchCat_5af96194:


    "... Se soltanto le loro zampette non nascondessero artigli affilati come rasoi."


translate ita catchCat_7ae94986:


    "Provi a difenderti... {w}ma sono semplicemente troppi."


translate ita catchCat_cfcc4899:


    "Il sangue scorre copioso dai graffi..."


translate ita catchCat_9d23ba22:


    "Cominci ad avere le vertigini..."


translate ita catchCat_f52affb8:


    "Con le ultime forze che ti rimangono..."


translate ita catchCat_f55aea98:


    "... volti la testa per vedere i gatti dilaniare tappeto e fodere..."


translate ita catchCat_9d8db959:


    "... spingere a terra vasi, piatti e lampade..."


translate ita catchCat_1a299f19:


    "... graffiare i muri..."


translate ita catchCat_6f71224c:


    "Pensi che ci vorrà un'infinità per pulire tutto questo."


translate ita catchCat_d44174fd:


    "Magari te ne occuperai più tardi..."


translate ita catchCat_9ca1c0cc:


    "... subito dopo..."


translate ita catchCat_a6bf102e:


    "{size=-5}... aver fatto...{/size}"


translate ita catchCat_cac82399:


    "{size=-8}... un riposino...{/size}"


translate ita catchCat_dae0ec55_3:


    you "..."


translate ita catchCat_54aa11a1:


    "Con un sospiro irritato..."


translate ita catchCat_a20cefa7_3:


    "..."


translate ita catchCat_3f89c6a6:


    "... esali il tuo ultimo respiro."


translate ita catchCat_a20cefa7_4:


    "..."


translate ita catchCat_6956a6b4:


    "Finale 2: Doppi Guai"


translate ita watchTV_7a132060:


    "Non senti il bisogno di dormire, ma ti scoccia troppo iniziare le faccende di casa."


translate ita watchTV_59ecac21:


    "Perciò decidi di guardare un film."


translate ita watchTV_e6b3f86f:


    "Indossi il tuo pigiama preferito, prepari dei popcorn con una quantità enorme di burro e ti avvicini alla poltrona..."


translate ita watchTV_addc29e1:


    "... solo per scoprire che il gatto ci sta già dormendo sopra."


translate ita watchTV_c4045cbc:


    "Fai un'espressione corrucciata."


translate ita watchTV_4f7364cd:


    "Il divano non ha l'angolazione giusta per un'ottima e piacevole visione della TV e non hai voglia di spostarlo ora per poi rimetterlo a posto dopo."


translate ita watchTV_d1311036:


    "Le uniche opzioni che ti rimangono sono sederti a terra..."


translate ita watchTV_ac7e9daa:


    "... oppure spostare il gatto reclamando il trono."


translate ita sitOnFloor_f258c8af:


    "Decidi di sederti a terra. Dopotutto, il gatto è un ospite e ti fa piacere, quantomeno, mostrarti accogliente."


translate ita sitOnFloor_94fced8c:


    "Beh... Lo saresti se, prima di adesso, avessi mai avuto ospiti a casa."


translate ita sitOnFloor_59924bfd:


    "Ti armi di copertina e cuscini e costruisci un nido accogliente di fronte alla poltrona."


translate ita sitOnFloor_c9c06a2d:


    "Cominci a guardare un film preso a caso dalla tua collezione e capisci subito che si tratta di uno dei tuoi film horror preferiti."


translate ita sitOnFloor_178f4f3c:


    "Lo hai guardato già diverse volte, ma riesce sempre a farti battere forte il cuore."


translate ita sitOnFloor_af009a23:


    "Bastano pochi minuti per farti coinvolgere di nuovo ed empatizzare con la storia e i personaggi."


translate ita sitOnFloor_5c1e198e:


    "É presto per le scene di paura, ma..."


translate ita sitOnFloor_b30c491a:


    "... per qualche ragione hai la sensazione che qualcuno ti stia osservando da dietro."


translate ita sitOnFloor_84c7ae7d:


    "Sai che probabilmente non è nulla, ma senti di dover controllare comunque."


translate ita sitOnFloor_06fb4a58:


    "Dai un'occhiata dietro di te..."


translate ita sitOnFloor_ac50ef1c:


    you "{size=+5}GASP!{/size}" with vpunch


translate ita sitOnFloor_81f1b73f:


    "... e salti in aria, rovesciandoti un po' di popcorn sulle gambe."


translate ita sitOnFloor_1f13af02:


    "Il gatto è sveglio e ti sta fissando."


translate ita sitOnFloor_7f0ac95c:


    cat "..."


translate ita sitOnFloor_143b81e3:


    you "*SIGH*"


translate ita sitOnFloor_eea23dd1:


    "Fai un respiro profondo, cerchi di calmarti e ti rendi conto di aver avuto una reazione eccessiva."


translate ita sitOnFloor_dfcad786:


    "Era soltanto il gatto, dopotutto. Era così silenzioso che avevi dimenticato fosse dietro di te..."


translate ita sitOnFloor_f37d47cd:


    "... anche se in realtà è la ragione per cui stai guardando la TV dal pavimento."


translate ita sitOnFloor_50a15250:


    "Sollevi il telecomando con mano tremante, con l'intenzione di rivedere le parti perse."


translate ita sitOnFloor_236c0e1e:


    "Tuttavia, non appena premi il pulsante per riavvolgere..."


translate ita sitOnFloor_8dabefc6:


    ".."


translate ita sitOnFloor_a20cefa7:


    "..."


translate ita sitOnFloor_493f0953:


    "... la TV si spegne."


translate ita sitOnFloor_90b68c87:


    you "...?"


translate ita sitOnFloor_70a6570e:


    "La osservi con perplessità."


translate ita sitOnFloor_78747100:


    "Nient'altro si è spento. La luce soffusa della cucina è ancora accesa..."


translate ita sitOnFloor_af8a226c:


    "L'orologio digitale è ancora acceso... e..."


translate ita sitOnFloor_78037d5b:


    "... il registratore sta ancora riavvolgendo il film..."


translate ita sitOnFloor_3fa5f761:


    "L'elettricità è a posto... Quindi perché...?"


translate ita sitOnFloor_6a84e27a:


    "Senti un brivido lungo la schiena mentre osservi il riflesso del gatto sullo schermo nero della TV."


translate ita sitOnFloor_a74decef:


    "Ti sta ancora..."


translate ita sitOnFloor_29346eda:


    "... fissando?"


translate ita sitOnFloor_68f3d642:


    you "{i}I gatti spesso fissano le cose, imbecille. Sono fatti così...{/i}"


translate ita sitOnFloor_97996fab:


    "... giusto?"


translate ita sitOnFloor_c6dea0bf:


    "Inoltre, tu sei una novità per lui. È ovvio che ti osserverà da vicino per capire se può fidarsi di te."


translate ita sitOnFloor_22126792:


    "Mentre calmi i tuoi pensieri, accendi di nuovo la TV."


translate ita sitOnFloor_8dabefc6_1:


    ".."


translate ita sitOnFloor_40d9ca73:


    "...?"


translate ita sitOnFloor_67aaa788:


    "Cosa?"


translate ita sitOnFloor_4be706f4:


    "La TV è accesa, ma... sullo schermo non c'è più il film."


translate ita sitOnFloor_90b93b6a:


    "Invece..."


translate ita sitOnFloor_20572e6e:


    "!!!"


translate ita sitOnFloor_0034943b:


    "Ci sei tu...?"


translate ita sitOnFloor_06079290:


    "Osservi la tua immagine sullo schermo accigliarsi mentre senti la tua fronte fare lo stesso."


translate ita sitOnFloor_bc0619d3:


    "Sembra una ripresa dal vivo, come se una telecamera ti osservasse..."


translate ita sitOnFloor_b084c950:


    "Provi una sensazione familiare, la tua mente si concentra sui piccoli dettagli evitando il quadro generale della situazione."


translate ita sitOnFloor_907a81a6:


    "Evitando le domande su come ciò sia possibile... e chi o cosa stia facendo questo..."


translate ita sitOnFloor_4bda7300:


    "... e perché."


translate ita sitOnFloor_ac593ae3:


    "All'improvviso, la tua immagine ti sorride e ti saluta. Da sola."


translate ita sitOnFloor_98f42958:


    "Non rispondi al saluto, ma rimani immobile per lo shock."


translate ita sitOnFloor_a20cefa7_1:


    "..."


translate ita sitOnFloor_49b81530:


    "La tua {b}copia{/b} sullo schermo non sembra preoccupata."


translate ita sitOnFloor_470fca2a:


    "Si alza..."


translate ita sitOnFloor_46677075:


    "Ed esce dall'inquadratura..."


translate ita sitOnFloor_a20cefa7_2:


    "..."


translate ita sitOnFloor_98a9232f:


    "E-"


translate ita sitOnFloor_2b614492:


    you "{b}{i}AAHHH!!!{/i}{/b}" with vpunch


translate ita sitOnFloor_57aec916:


    "Un urlo terrorizzato esce dalla tua bocca prima che tu possa trattenerlo."


translate ita sitOnFloor_8112b810:


    "Sullo schermo... sulla poltrona..."


translate ita sitOnFloor_73ca6c0a:


    "... c'è il gatto."


translate ita sitOnFloor_a20cefa7_3:


    "..."


translate ita sitOnFloor_8432e062:


    "Ma ha qualcosa di... {b}sbagliato{/b}."


translate ita sitOnFloor_c0555fb1:


    "È diventato una massa rigonfia di pelliccia nera..."


translate ita sitOnFloor_133f90fc:


    "Pulsa fuori tempo rispetto al suo lento, quasi metodico, respiro."


translate ita sitOnFloor_be8a773e:


    "La sua bocca è un'entrata sbadigliante su un nero abisso, incorniciata da denti che sembrano molto, {i}molto{/i} {b}aguzzi{/b}."


translate ita sitOnFloor_7a6698ae:


    "Occhi brillanti spuntano da tutto il suo corpo..."


translate ita sitOnFloor_8dabefc6_2:


    ".."


translate ita sitOnFloor_a20cefa7_4:


    "..."


translate ita sitOnFloor_bc239af5:


    "{size=-5}Ti sta... {b}guardando{/b} ancora...{/size}"


translate ita sitOnFloor_cbbe5c23:


    "Non nota nemmeno la tua copia sullo schermo mentre torna per coccolare {b}se stesso{/b} quasi amorevolmente."


translate ita sitOnFloor_f64ee9d8:


    "Dopodiché..."


translate ita sitOnFloor_acb34839:


    "La {b}tua copia{/b} sullo schermo tocca una delle zanne del \"gatto\"..."


translate ita sitOnFloor_479c3431:


    you "!!!" with vpunch


translate ita sitOnFloor_2718a9f1:


    "Sussulti, mentre senti un dolore improvviso al palmo."


translate ita sitOnFloor_78150384:


    "Guardi in giù e ti accorgi..."


translate ita sitOnFloor_9b18421a:


    "... che la tua mano sta sanguinando."


translate ita sitOnFloor_ba0ef687:


    "Il sangue non ti dà particolare fastidio ma..."


translate ita sitOnFloor_1d340c8b:


    "... per qualche ragione vederlo scorrere ti trasmette un altro brivido lungo la schiena."


translate ita sitOnFloor_7c7dcbc3:


    "Un pensiero... chiaro e {i}terribile{/i} ti balena in testa..."


translate ita sitOnFloor_2061faa4:


    "Il gatto mutante che ti osserva {b}dalla{/b} TV non è {i}l'unico{/i}..."


translate ita sitOnFloor_75079696:


    "{size=-5}... vero?{/size}"


translate ita sitOnFloor_91f03785:


    "{size=-10}Non ti girare... Non ti girare... Non ti girare... Non ti girare... Non ti girare... {/size}"


translate ita sitOnFloor_e1698794:


    "Osservi impotente mentre la tua copia sullo schermo ti sorride e annuisce, quasi {i}incoraggiante{/i}..."


translate ita sitOnFloor_ceaf9390:


    "Sta ferma davanti alle fauci spalancate del gatto..."


translate ita sitOnFloor_a76a9c6a:


    "Guarda dentro quell'oscurità profonda..."


translate ita sitOnFloor_5cdba61f:


    "... e mentre ti struggi tra la realizzazione di ciò che sta per accadere..."


translate ita sitOnFloor_82ccfc29:


    "... e la curiosità verso ciò che la sta osservando a sua volta da quella profonda, profonda oscurità..."


translate ita sitOnFloor_8dabefc6_3:


    ".."


translate ita sitOnFloor_a20cefa7_5:


    "..."


translate ita sitOnFloor_91fe1774:


    "... la tua copia {i}ci salta dentro{/i}."


translate ita sitOnFloor_8dabefc6_4:


    ".."


translate ita sitOnFloor_a20cefa7_6:


    "..."


translate ita sitOnFloor_d88e36d3:


    "L'oscurità improvvisamente ti circonda con la sua presenza."


translate ita sitOnFloor_c6d24f52:


    "Ti schiaccia, spingendoti a terra..."


translate ita sitOnFloor_a6895774:


    "... e nonostante tutto ti senti... evanescente."


translate ita sitOnFloor_d861ceaf:


    "Non sapresti dire se stai precipitando, ma non capisci nemmeno se sei in piedi oppure no."


translate ita sitOnFloor_156d0dbf:


    "Senti caldo..."


translate ita sitOnFloor_3a06e0dd:


    "Senti freddo..."


translate ita sitOnFloor_bcd3d129:


    "Senti tutto..."


translate ita sitOnFloor_2b49bb86:


    "Non senti nulla..."


translate ita sitOnFloor_a20cefa7_7:


    "..."


translate ita sitOnFloor_1ef9b933:


    "Non senti {b}nulla{/b}."


translate ita sitOnFloor_a20cefa7_8:


    "..."


translate ita sitOnFloor_e8846d70:


    "Finale 3: Film Muto"


translate ita sitInChair_b3119c57:


    "Raddrizzi le spalle."


translate ita sitInChair_0a269556:


    you "Scusa, gattino, ma quello è il mio posto."


translate ita sitInChair_f57f352f:


    "Sollevi il gatto e lo metti a terra."


translate ita sitInChair_12dc27c4:


    cat "Miao!!!" with hpunch


translate ita sitInChair_3a47415e:


    "È chiaramente arrabbiato con te. Quando provi ad accarezzarlo per scusarti, schiva la tua mano e scappa via."


translate ita sitInChair_590b209f:


    "Alzi le spalle e metti un film a caso, prima di buttarti sulla poltrona."


translate ita sitInChair_761b0c81:


    "È un film horror che ti diverti a criticare dall'inizio alla fine."


translate ita sitInChair_c1831989:


    "Nient'altro che una serie infinita di spaventi inutili."


translate ita sitInChair_02d4fb14:


    "Gli autori non conoscevano il significato della parola \"originale\"?"


translate ita sitInChair_0420a8db:


    "{size=+15}{b}CRASH!{/b}{/size}" with vpunch


translate ita sitInChair_28b3ac41:


    you "!!!"


translate ita sitInChair_a9188f84:


    you "Cos'è stato?!? Veniva dal bagno...?"


translate ita sitInChair_f3f4fb49:


    "Il gatto sarà entrato nell'armadietto delle medicine o avrà rovesciato qualcosa."


translate ita sitInChair_d150cda1:


    "Fai un respiro profondo per calmare le palpitazioni, metti in pausa il film e vai a indagare."


translate ita sitInChair_ec1974d4:


    cat "Miao!" with hpunch


translate ita sitInChair_fc460430:


    you "Oh!" with vpunch


translate ita sitInChair_4f08c65a:


    "Dal salotto, il gatto sfreccia tra le tue gambe."


translate ita sitInChair_071d97e8:


    you "Se fuggi dal luogo del delitto sembri tu il colpevole, sai?"


translate ita sitInChair_c4cc6ce8:


    "Adesso sei ancora più riluttante a controllare i danni. Vorresti solo rilassarti con il tuo brutto film horror..."


translate ita sitInChair_eb15eef1:


    "Entri nel bagno e accendi la luce."


translate ita sitInChair_2a6c7408:


    "Proprio come pensavi, tutta la roba nell'armadietto delle medicine è sparsa per terra."


translate ita sitInChair_8b19c490:


    "Sospiri. Almeno non vedi nulla di rotto o danneggiato."


translate ita sitInChair_dc4e84a5:


    "Ti accovacci per raccogliere tutto."


translate ita sitInChair_84499443:


    "{size=-8}clac...{/size}"


translate ita sitInChair_90b68c87:


    you "...?"


translate ita sitInChair_3c037f7a:


    "La porta si è appena... chiusa? L'hai urtata accovacciandoti oppure...?"


translate ita sitInChair_a20cefa7:


    "..."


translate ita sitInChair_4f5638e2:


    "B-Beh... almeno il gatto non potrà entrare per combinare altri disastri-"


translate ita sitInChair_40d9ca73:


    "...?"


translate ita sitInChair_cdedc7c0:


    "Le luci?"


translate ita sitInChair_2bfd08b2:


    "Non avevi appena cambiato le lampadine? Erano forse difettose?"


translate ita sitInChair_f920211f:


    "Non ti ricordi mai di tenere gli scontrini per situazioni come queste."


translate ita sitInChair_0249ee11:


    "Dubiti di poter riavere i tuoi soldi indietro..."


translate ita sitInChair_a20cefa7_1:


    "..."


translate ita sitInChair_dae0ec55:


    you "..."


translate ita sitInChair_3a64e1bd:


    "Ti alzi."


translate ita sitInChair_c3acc1e2:


    "Ignori il dolore alle ginocchia e apri l'armadietto delle medicine."


translate ita sitInChair_29a4c348:


    "Con attenzione, rimetti tutto al proprio posto, accertandoti che non manchi niente."


translate ita sitInChair_3cbf6fbc:


    "Chiudi lo sportello dell'armadietto--{w=0.60}{nw}"


translate ita sitInChair_24c68cb1:


    you "{size=+30}AAAAAHHH!!!{/size}" with vpunch


translate ita sitInChair_77935352:


    "Balzi all'indietro, sbattendo contro il muro e coprendoti la bocca."


translate ita sitInChair_51841170:


    "Osservi di nuovo lo specchio sulla porta dell'armadietto e..."


translate ita sitInChair_8dabefc6:


    ".."


translate ita sitInChair_a20cefa7_2:


    "..."


translate ita sitInChair_e9a3c807:


    "... niente."


translate ita sitInChair_3a9199d1:


    "Niente?"


translate ita sitInChair_dc92f804:


    you "Ma... ma che diavolo...? Qualcosa... qualcosa era..."


translate ita sitInChair_312bb316:


    "Sai di aver appena visto qualcosa."


translate ita sitInChair_963cfd9b:


    "Lo {i}sai{/i} che è così."


translate ita sitInChair_9979a58c:


    "Giusto?"


translate ita movieBathroomJumpscare1_2144dee4:


    "Sì, di sicuro. Non rimarrai qui per--{w=0.4}{nw}"


translate ita movieBathroomJumpscare1_9998cb84:


    you "{size=+35}{b}AAAAAAAAHHHHH!!!{/b}{/size}" with hpunch


translate ita movieBathroomJumpscare1_9a70f959:


    "Scappi dal bagno e sbatti la porta dietro di te senza guardare."


translate ita movieBathroomJumpscare1_4482999d:


    "Entri in sala e-"


translate ita movieBathroomJumpscare1_8105eadd:


    you "No..."


translate ita movieBathroomJumpscare1_b3556bea:


    you "No no no no no!!!" with hpunch


translate ita movieBathroomJumpscare1_40feb4d7:


    "Cerchi di ripararti con le braccia e..."


translate ita movieBathroomJumpscare1_8dabefc6:


    ".."


translate ita movieBathroomJumpscare1_a20cefa7:


    "..."


translate ita movieBathroomJumpscare1_e9a3c807:


    "... nulla."


translate ita movieBathroomJumpscare1_4b236e0a:


    "Nulla. Di nuovo."


translate ita movieBathroomJumpscare1_7af0a5e1:


    "Sbirci tra le dita e vedi..."


translate ita movieBathroomJumpscare1_9949aa1e:


    "... il solito corridoio."


translate ita movieBathroomJumpscare1_0f5de544:


    "Tu..."


translate ita movieBathroomJumpscare1_6c66c891:


    "Non ti senti molto bene."


translate ita movieBathroomJumpscare1_a20cefa7_1:


    "..."


translate ita movieBathroomJumpscare1_63883ba3:


    "Devi sederti."


translate ita movieBathroomJumpscare1_3d95bb71:


    "Attentamente, con calma, torni nel salotto buio..."


translate ita movieBathroomJumpscare1_20b300df:


    "... cercando di non cadere in preda al panico."


translate ita movieBathroomJumpscare1_394dfa11:


    "Forse dovresti guardare qualcosa di più allegro..."


translate ita movieBathroomJumpscare1_038385fd:


    "... oppure potresti sdraiarti?"


translate ita movieBathroomJumpscare1_2f6db9fa:


    "Non lo sai."


translate ita movieBathroomJumpscare1_6866aca7:


    "Pensare ti risulta difficile..."


translate ita movieBathroomJumpscare1_d42b8f2e:


    "Hai solo... bisogno di {b}sederti.{/b}"


translate ita movieBathroomJumpscare1_5ec868b4:


    "Con difficoltà, raggiungi la poltrona..."


translate ita movieBathroomJumpscare1_2cdad339:


    "{color=#FF0000}Ma-{/color}"


translate ita movieBathroomJumpscare1_a110fb02:


    you "{size=+15}!!!!!{/size}" with vpunch


translate ita movieBathroomJumpscare1_8dabefc6_1:


    ".."


translate ita movieBathroomJumpscare1_a20cefa7_2:


    "..."


translate ita movieBathroomJumpscare1_a4cfcb7e:


    "È tutto a posto."


translate ita movieBathroomJumpscare1_d10408f3:


    "Calmati. Non è nulla."


translate ita movieBathroomJumpscare1_650a1380:


    "Solo il gatto... seduto di nuovo sulla poltrona. Ti guarda con curiosità."


translate ita movieBathroomJumpscare1_16879ce5:


    cat "Miao?"


translate ita movieBathroomJumpscare1_8dabefc6_2:


    ".."


translate ita movieBathroomJumpscare1_8dabefc6_3:


    ".."


translate ita movieBathroomJumpscare1_a20cefa7_3:


    "..."


translate ita movieBathroomJumpscare1_30fe06e7:


    "... Ma è abbastanza."


translate ita movieBathroomJumpscare1_b8391155:


    "Il misto di paura e angoscia ha fatto battere il tuo cuore così tanto..."


translate ita movieBathroomJumpscare1_ee49c0d1:


    "... da farlo cedere."


translate ita movieBathroomJumpscare1_217ef2ff:


    "I tuoi occhi si rovesciano all'indietro."


translate ita movieBathroomJumpscare1_ab3f5fb1:


    "Hai la sensazione di cadere."


translate ita movieBathroomJumpscare1_8dabefc6_4:


    ".."


translate ita movieBathroomJumpscare1_a20cefa7_4:


    "..."


translate ita movieBathroomJumpscare1_43180df7:


    "... Muori ancora prima di toccare il suolo."


translate ita movieBathroomJumpscare1_a20cefa7_5:


    "..."


translate ita movieBathroomJumpscare1_15eac906:


    "Finale 4--{w=0.3}{nw}"


translate ita movieBathroomJumpscare1_a20cefa7_6:


    "..."


translate ita movieBathroomJumpscare1_ca055f36:


    "Finale 4: Davvero \"Originale\""


translate ita napAlone_8f615c2b:


    "Ti senti a pezzi dopo gli eventi della giornata."


translate ita napAlone_dcbf1da5:


    "Prendere decisioni importanti come quella di accudire un'altra creatura vivente..."


translate ita napAlone_d9c98972:


    "... ti sfinisce per davvero."


translate ita napAlone_4505fdc0:


    "Un riposino ti farebbe bene."


translate ita napAlone_c3e294a3:


    "Vai nella tua stanza e indossi il pigiama, poi torni in cucina a prendere un bicchiere d'acqua."


translate ita napAlone_0fed84ed:


    "Rientri in camera tua, non vedi l'ora di fare un riposino..."


translate ita napAlone_ec1974d4:


    cat "Miao!" with hpunch


translate ita napAlone_fc460430:


    you "Oh!" with vpunch


translate ita napAlone_a5249354:


    "... ma il gatto ti sorpassa correndo e salta al centro del letto."


translate ita napAlone_919b944d:


    "Con tutta la calma del mondo, impasta le lenzuola, si sdraia e chiude gli occhi."


translate ita napAlone_cc63b22e:


    cat "Purr... Purr... Purr..."


translate ita napAlone_dae0ec55:


    you "..."


translate ita napAlone_13af021f:


    you "{i}Beh, è stato veloce...{/i}"


translate ita napAlone_5068475e:


    "Aggrotti la fronte."


translate ita napAlone_3bd08dfd:


    "Ora che ci pensi, avresti {i}davvero{/i} bisogno di schiacciare un pisolino nel tuo letto."


translate ita napAlone_661e2716:


    "Non puoi accontentarti di dormire sul divano. {i}Men che meno{/i} sulla poltrona..."


translate ita napAlone_91480ce3:


    "Il che significa che dovresti..."


translate ita napMenu_dae0ec55:


    you "..."


translate ita napMenu_b4e0a60e:


    "Forse potresti rimandare a {i}più tardi...{/i}"


translate ita napMenu_f2c5d8d3:


    "Decidi di passare il tempo in qualche altro modo."


translate ita napMoveCat_c4777c85:


    "Con esitazione, sposti il gatto nella speranza che si muova da solo."


translate ita napMoveCat_8dabefc6:


    ".."


translate ita napMoveCat_a20cefa7:


    "..."


translate ita napMoveCat_01382361:


    "Non si sposta di un millimetro."


translate ita napMoveCat2_60058abd:


    "Stavolta spingi con più decisione."


translate ita napMoveCat2_3af2f912:


    cat "Miao..."


translate ita napMoveCat2_dae0ec55:


    you "..."


translate ita napMoveCat2_35168c1b:


    "Il gatto sembra infastidito..."


translate ita napMoveCat2_7f0ac95c:


    cat "..."


translate ita napMoveCat3_a5040b05:


    "Il gatto apre un occhio giallo e alza lo sguardo verso di te."


translate ita napMoveCat3_f07f0105:


    cat "{b}Miaoooo...{/b}"


translate ita napMoveCat3_38a2a096:


    you "...!" with vpunch


translate ita napMoveCat3_24137500:


    "Non ha la voce più... profonda di prima?"


translate ita napMoveCat3_a20cefa7:


    "..."


translate ita napMoveCat3_7f0ac95c:


    cat "..."


translate ita napMoveCat4_98c26b25:


    "Vai avanti. {w}Vuoi spingere il gatto con tutte le tue forze--{w=1.5}{nw}"


translate ita napMoveCat4_87d1e4e3:


    "{size=+25}CRASH!{/size}" with vpunch


translate ita napMoveCat4_35bc070f:


    you "{size=+10}GASP!{/size}" with hpunch


translate ita napMoveCat4_267670c2:


    "Ricevi uno spintone da qualche forza invisibile e sbatti contro il comò, prima di cadere a terra."


translate ita napMoveCat4_e16be8b8:


    you "Ahi..."


translate ita napMoveCat4_f2025eea:


    "Senza fiato, alzi lo sguardo provando un capogiro..."


translate ita napMoveCat4_8ca8510a:


    you "!!!" with vpunch


translate ita napMoveCat4_0f5de544:


    "Tu..."


translate ita napMoveCat4_c335fc02:


    "Non comprendi appieno cosa stai vedendo."


translate ita napMoveCat4_1edf14ea:


    "Si è alzato un vento forte e vorticoso, che scaglia oggetti dappertutto..."


translate ita napMoveCat4_2e084285:


    "... come se un piccolo uragano fosse appena nato nella stanza."


translate ita napMoveCat4_d7c2d390:


    "E proprio al centro di tutto..."


translate ita napMoveCat4_73ca6c0a:


    "... c'è il gatto."


translate ita napMoveCat4_b37f5c41:


    "Fluttua nell'aria sopra il letto..."


translate ita napMoveCat4_f02e91e8:


    "Occhi spalancati, che brillano come lava..."


translate ita napMoveCat4_3e04d2ff:


    cat "Miaoooo..."


translate ita napMoveCat4_c2cbf478:


    cat "{size=+5}Miaoooo...{/size}" with vpunch


translate ita napMoveCat4_c64e3fd2:


    cat "{size=+10}{b}M i a o o o o...!{/b}{/size}" with vpunch


translate ita napMoveCat4_28b3ac41:


    you "!!!"


translate ita napMoveCat4_3db840b4:


    "Vedi un vortice espandersi al centro del tuo letto e..."


translate ita napMoveCat4_9c4942bc:


    "... vai nel panico quando il tifone comincia a {i}risucchiarti.{/i}"


translate ita napMoveCat4_4351a428:


    "{b}Ti attira{/b} verso il letto..."


translate ita napMoveCat4_67c9c705:


    you "Argh!" with hpunch


translate ita napMoveCat4_410731bd:


    "Le tue unghie si piantano e {b}{i}si spezzano{/i}{/b} mentre ti aggrappi disperatamente al tappeto... {w}al pavimento..."


translate ita napMoveCat4_20ed66fb:


    "... e a {i}qualsiasi{/i} mobile alla tua portata..."


translate ita napMoveCat4_c8ef0095:


    "... le tue dita sanguinanti scivolano goffe su ogni appiglio..."


translate ita napMoveCat4_8dabefc6:


    ".."


translate ita napMoveCat4_a20cefa7:


    "..."


translate ita napMoveCat4_fe111813:


    "... ma non c'è più niente da fare."


translate ita napMoveCat4_92ab24b3:


    "Appena sfiori il vortice... il tuo corpo comincia a..."


translate ita napMoveCat4_cb8978e7:


    "... {i}disintegrarsi.{/i}"


translate ita napMoveCat4_70bd56a0:


    "Piccole particelle del tuo corpo si separano e fluttuano nel nulla..."


translate ita napMoveCat4_9d7d7459:


    "L'ultima cosa che vedi è il gatto che salta agilmente sul letto e impasta le lenzuola..."


translate ita napMoveCat4_3bbf7816:


    "... prima di raggomitolarsi e tornare a dormire."


translate ita napMoveCat4_67107e6c:


    cat "Purr..."


translate ita napMoveCat4_a20cefa7_1:


    "..."


translate ita napMoveCat4_575b36ec:


    "Finale 5: Non Miao-lestarmi"


translate ita napTogether_4e7a8b32:


    "Fai spallucce. Dormire assieme non è un problema, giusto?"


translate ita napTogether_426f3adb:


    "È stata una lunga giornata per entrambi, dopotutto."


translate ita napTogether_a3583f06:


    "Cerchi di non urtare il gatto mentre ti sdrai, ma lui subito si sposta e si rannicchia contro di te comunque."


translate ita napTogether_cc63b22e:


    cat "Purr... Purr... Purr..."


translate ita napTogether_0ff74098:


    "Sorridi."


translate ita napTogether_416e2125:


    you "Sogni d'oro..."


translate ita napTogether_8dabefc6:


    ".."


translate ita napTogether_a20cefa7:


    "..."


translate ita napTogether_40d9ca73:


    "...?"


translate ita napTogether_37d6d699:


    you "Uhm...?"


translate ita napTogether_80a5c3e8:


    "Ti sembra di aver dormito a lungo."


translate ita napTogether_40d9ca73_1:


    "...?"


translate ita napTogether_1a1908b3:


    "Senti un peso caldo sulla schiena..."


translate ita napTogether_f1efd4f0:


    "Ma non vedi il-{w=0.6}{nw}"


translate ita napTogether_57f9ada2:


    cat "Purr... Purr... Purrr..."


translate ita napTogether_28052c77:


    "... Oh. Mistero risolto."


translate ita napTogether_3ab0f315:


    "Ti senti... a tuo agio...?"


translate ita napTogether_6a292af6:


    "Consideri di alzarti..."


translate ita napTogether_5bdd7954:


    "... ma non appena pensi di farlo, la tua mente si riempie di torpore e di un profondo senso di..."


translate ita napTogether_ef2259f2:


    "... disapprovazione?"


translate ita napTogether_dae0ec55:


    you "..."


translate ita napTogether_0ef6194c:


    you "{i}Non ancora, quindi? Ok...{/i}"


translate ita napTogether_614a2e6c:


    "Il gatto, scosso dai tuoi deboli movimenti, impasta dolorosamente la tua schiena prima di sistemarsi di nuovo e riaddormentarsi."


translate ita napTogether_2145b389:


    "Ti riaddormenti anche tu."


translate ita napTogether_8dabefc6_1:


    ".."


translate ita napTogether_a20cefa7_1:


    "..."


translate ita napTogether_a20cefa7_2:


    "..."


translate ita napTogether_3e8cc2f1:


    "È notte."


translate ita napTogether_b5717b9e:


    "Vuoi alzarti."


translate ita napTogether_d13d6302:


    you "Mmmh!" with vpunch


translate ita napTogether_45f5f5bd:


    "Degli artigli scavano la tua schiena minacciosi."


translate ita napTogether_dae0ec55_1:


    you "..."


translate ita napTogether_4c13fdd1:


    "... Domani allora, va bene?"


translate ita napTogether_55355e09:


    cat "Purr... Purr..."


translate ita napTogether_dae0ec55_2:


    you "..."


translate ita napTogether_8dabefc6_2:


    ".."


translate ita napTogether_a20cefa7_3:


    "..."


translate ita napTogether_e1a3bb11:


    "È mattina. Farai tardi a lavoro..."


translate ita napTogether_ccb83206:


    "... ma il gatto non si sposta."


translate ita napTogether_6faab910:


    "Non provi nemmeno ad alzarti stavolta."


translate ita napTogether_da0c099f:


    "Chiudi gli occhi e ti addormenti di nuovo."


translate ita napTogether_8dabefc6_3:


    ".."


translate ita napTogether_a20cefa7_4:


    "..."


translate ita napTogether_90b93b6a:


    "È..."


translate ita napTogether_a20cefa7_5:


    "..."


translate ita napTogether_7e35a8e3:


    "È passato un giorno..."


translate ita napTogether_a20cefa7_6:


    "..."


translate ita napTogether_432cfea9:


    "... sono trascorsi {b}molti{/b} giorni..."


translate ita napTogether_b3d9c927:


    "... O settimane?"


translate ita napTogether_a20cefa7_7:


    "..."


translate ita napTogether_8a135021:


    "{size=-8}O di più...?{/size}"


translate ita napTogether_a20cefa7_8:


    "..."


translate ita napTogether_4c91bf15:


    "Non ne hai la certezza."


translate ita napTogether_dae0ec55_3:


    you "..."


translate ita napTogether_421780e5:


    "Hai fame."


translate ita napTogether_f631369d:


    "Non sai da quanto tempo stai riposando."


translate ita napTogether_097a8871:


    "Hai dolore alla schiena, ma anche allo stomaco, alle braccia, al viso..."


translate ita napTogether_d6e6ac76:


    "Dappertutto..."


translate ita napTogether_6ebedf14:


    "Non ricordi il tuo ultimo pasto... {w}L'ultima volta che hai bevuto qualcosa..."


translate ita napTogether_151a082b:


    "Hai dormito per tutto questo tempo..."


translate ita napTogether_5255f5a0:


    "... ma ti senti {b}a pezzi{/b}. Non hai mai provato questa stanchezza in tutta la tua vita."


translate ita napTogether_e3a05912:


    "È come se una mano gigante ti {i}schiacciasse{/i} contro il letto."


translate ita napTogether_0fa6935c:


    "Non ricordi l'ultima volta che hai pensato di muoverti..."


translate ita napTogether_4c459194:


    "Ma in qualche modo sai..."


translate ita napTogether_2c153c83:


    "{size=-8}... che devi tornare a dormire {b}comunque{/b}.{/size}"


translate ita napTogether_f31145ff:


    "Tutto andrà bene se torni a dormire."


translate ita napTogether_8dabefc6_4:


    ".."


translate ita napTogether_a20cefa7_9:


    "..."


translate ita napTogether_b59d962a:


    "...?" with vpunch


translate ita napTogether_e82e813a:


    "Quando il gatto infine si sposta, pensi che sia un'allucinazione..."


translate ita napTogether_085f82bc:


    cat "Miao..."


translate ita napTogether_c3e31538:


    "Si stiracchia languidamente e salta giù dalla tua schiena."


translate ita napTogether_2f0da195:


    "Lo senti zampettare fuori dalla porta ancora aperta, poi il rumore dei passi svanisce nel corridoio."


translate ita napTogether_8dabefc6_5:


    ".."


translate ita napTogether_a20cefa7_10:


    "..."


translate ita napTogether_c45998b5:


    "Tieni gli occhi chiusi."


translate ita napTogether_9e3127bc:


    "Rimani {i}immobile.{/i}"


translate ita napTogether_a20cefa7_11:


    "..."


translate ita napTogether_40b03495:


    "Hai paura di non ricordarti più {b}come ci si muove.{/b}"


translate ita napTogether_7362ca19:


    "Temi che il torpore possa ritornare se ci provi..."


translate ita napTogether_a20cefa7_12:


    "..."


translate ita napTogether_3c068b44:


    "Ma alla fine lo {i}fai{/i}."


translate ita napTogether_cedc9e87:


    "Provi a tirarti su con il braccio."


translate ita napTogether_9728d600:


    "Non l'hai mai visto così sottile..."


translate ita napTogether_7accebe2:


    "Più sottile di quanto pensi sia {i}possibile-{/i}"


translate ita napTogether_f877cb8f:


    "{size=+10}CRASH!{/size}" with vpunch


translate ita napTogether_dae0ec55_4:


    you "..."


translate ita napTogether_bf2e0dee:


    "Il braccio si spezza sotto il peso del tuo corpo, polverizzandosi sulle lenzuola."


translate ita napTogether_a20cefa7_13:


    "..."


translate ita napTogether_205af2fa:


    "Non fa male per niente..."


translate ita napTogether_72a91789:


    "Come se i tuoi nervi si fossero seccati e fossero diventati inutili come..."


translate ita napTogether_e7fd628a:


    "... beh, inutili come ti senti tu {i}di solito.{/i}"


translate ita napTogether_afc8d8b5:


    "{size=-8}Ma da {b}quanto{/b} sei a letto...?{/size}"


translate ita napTogether_a20cefa7_14:


    "..."


translate ita napTogether_ac9494ba:


    "Non hai molto tempo per pensarci."


translate ita napTogether_ea722524:


    "Il tuo tentativo fallito di sederti ti fa rotolare giù dal letto come una bambola di pezza..."


translate ita napTogether_39ee23ef:


    "{size=+5}CRACK!{/size}" with vpunch


translate ita napTogether_f877cb8f_1:


    "{size=+10}CRACK!{/size}" with vpunch


translate ita napTogether_047fc669:


    "{size=+25}CRACK!{/size}" with vpunch


translate ita napTogether_1407836e:


    "Realizzi, forse, di essere più simile a una bambola di {i}ceramica{/i}..."


translate ita napTogether_394bdc78:


    "... quando il tuo corpo si disintegra {i}all'istante{/i} cadendo al suolo."


translate ita napTogether_d48b6485:


    "La tua testa rotola verso la porta..."


translate ita napTogether_118dceca:


    "... permettendoti di vedere il tuo corpo a pezzi e pieno di crepe..."


translate ita napTogether_fdee14d8:


    "... che si {i}sbriciola{/i}..."


translate ita napTogether_77f0a0e9:


    "... e va in {b}rovina{/b}, mentre la tua coscienza comincia a svanire."


translate ita napTogether_1d86a44d:


    "Poi il gatto appare... passeggiando davanti a te e pungola i fragili resti delle tue membra."


translate ita napTogether_59882995:


    "\"Gattino cattivo.\" {w}Provi a parlare..."


translate ita napTogether_a20cefa7_15:


    "..."


translate ita napTogether_c7e0166e:


    "Ma credi che anche la tua mascella si sia staccata."


translate ita napTogether_58a56e4d:


    "Quasi come se avvertisse la tua attenzione, il gatto si avvicina a te..."


translate ita napTogether_ebb54fa1:


    "O meglio... alla tua {i}testa{/i}..."


translate ita napTogether_3639e1f8:


    "... e nei tuoi ultimi secondi di coscienza lo vedi sdraiarsi, arrotolando il suo corpo attorno a te."


translate ita napTogether_55355e09_1:


    cat "Purr... Purr..."


translate ita napTogether_8dabefc6_6:


    ".."


translate ita napTogether_a20cefa7_16:


    "..."


translate ita napTogether_807ca19c:


    "È caldo."


translate ita napTogether_a20cefa7_17:


    "..."


translate ita napTogether_221cbb22:


    "Bene."


translate ita napTogether_a20cefa7_18:


    "..."


translate ita napTogether_ba93f838:


    "{size=-8}Un altro sonnellino non guasterebbe...{/size}"


translate ita napTogether_8dabefc6_7:


    ".."


translate ita napTogether_a20cefa7_19:


    "..."


translate ita napTogether_f7b8427a:


    "Finale 6: Un Semplice Pisolino"


translate ita petCat_52bd3edf:


    "Non hai spesso a che fare con un animale morbidoso e carino."


translate ita petCat_f910595b:


    "Cos'altro puoi fare se non accarezzarlo a più non posso?"


translate ita petCat_59866bfa:


    "Ti siedi sul pavimento del salotto e schiocchi la lingua per richiamare il gatto."


translate ita petCat_9542a4b9:


    cat "Mrrp!!!" with hpunch


translate ita petCat_59da5396:


    "Il gatto corre verso di te, saltando subito sul tuo grembo."


translate ita petCat_c59a408d:


    you "Poverino~ Vuoi solo un po' di attenzioni, non è vero?"


translate ita petCat_e5fab8a0:


    cat "Miao!"


translate ita petCat_cef992d7:


    you "Eheh, va bene, va bene!"


translate ita petCat_99ba38b9:


    "Accarezzi il gatto con delicatezza. {w}Un grattino dietro l'orecchio. {w}Uno sotto il mento. {w}Una carezza sulla schiena."


translate ita petCat_cc63b22e:


    cat "Purr... Purr... Purr..."


translate ita petCat_4d2c742f:


    you "Ti piace, eh?"


translate ita petCat_67107e6c:


    cat "Purr..."


translate ita petCat_79e12018:


    "Continui a coccolare il gatto, godendoti questo momento di intimità insieme..."


translate ita petCat_f5145a26:


    "... ma dopo un po' il gatto comincia ad agitarsi."


translate ita keepPetting_a20cefa7:


    "..."


translate ita keepPetting_e01ca199:


    "Non vuoi smettere ancora."


translate ita keepPetting_7107d5ed:


    "La {i}calma{/i} ti pervade... La ripetitività placa la tua mente, di solito irrequieta..."


translate ita keepPetting_8dabefc6:


    ".."


translate ita keepPetting_a20cefa7_1:


    "..."


translate ita keepPetting_afeb9142:


    "Continui ad accarezzare."


translate ita keepPetting_3af2f912:


    cat "Miao..."


translate ita keepPetting_a3f235fe:


    "Il gatto evita la carezza sulla testa."


translate ita keepPetting_1e8aea73:


    "Sta cercando di alzarsi dalle tue gambe."


translate ita keepPetting2_972c75fa:


    "Quando lo gratti sotto il metto, ti morde le dita."


translate ita keepPetting2_ae0c2b21:


    "Forse stai sanguinando, ma a malapena senti dolore."


translate ita keepPetting2_b3d3cd04:


    "È più che altro un avvertimento."


translate ita keepPetting2_ceceaf01:


    cat "Miao!" with hpunch


translate ita keepPetting2_746fba6a:


    "Il gatto si dimena nella tua presa."


translate ita keepPetting2_59092dab:


    "Ti guarda da vicino."


translate ita keepPetting2_dae0ec55:


    you "..."


translate ita keepPetting3_8dabefc6:


    ".."


translate ita keepPetting3_a20cefa7:


    "..."


translate ita keepPetting3_1ffa03f8:


    "Continui ad accarezzare il gatto-"


translate ita keepPetting3_df1f0434:


    cat "{b}{size=+5}MIAO!{/size}{/b}" with hpunch


translate ita keepPetting3_d51d0b13:


    "{size=+15}{b}CHOMP!{/b}{/size}" with vpunch


translate ita keepPetting3_28b3ac41:


    you "!!!"


translate ita keepPetting3_a20cefa7_1:


    "..."


translate ita keepPetting3_a513413e:


    "...!"


translate ita keepPetting3_f5b70ae2:


    "Il gatto..."


translate ita keepPetting3_439e3871:


    "... ti ha {b}staccato{/b} un dito."


translate ita keepPetting3_dae0ec55:


    you "..."


translate ita keepPetting3_62c0c671:


    "Fa male..."


translate ita keepPetting3_505e1acd:


    "Stai sanguinando {i}abbondantemente{/i} ora..."


translate ita keepPetting3_bf0874e3:


    "Ma..."


translate ita keepPetting3_a20cefa7_2:


    "..."


translate ita keepPetting3_a4bb9dbd:


    "... per qualche ragione..."


translate ita keepPetting3_a20cefa7_3:


    "..."


translate ita keepPetting3_92e28b8f:


    "{size=-8}... non riesci a {b}smettere.{/b}{/size}"


translate ita keepPetting3_0ecc6b91:


    "Non sai perché..."


translate ita keepPetting3_f43d701c:


    "Il suo pelo è molto più {b}{i}soffice{/i}{/b} di quanto pensassi..."


translate ita keepPetting3_99249dc1:


    "Dovrebbe scintillare sotto la luce fioca del tuo salotto, ma..."


translate ita keepPetting3_4b10ed10:


    "... è come se l'oscurità del manto nero del gatto stesse {i}assorbendo{/i} tutta la luce attorno a sé..."


translate ita keepPetting3_d09fbed4:


    "... rendendola completamente {i}vacua.{/i}"


translate ita keepPetting3_21d4057c:


    "Ti sta attirando. {w}É come se stessi tenendo un {b}abisso{/b} profondo e oscuro sul tuo grembo."


translate ita keepPetting3_8c8267dd:


    cat "Purr... Purrr..."


translate ita keepPetting3_2ba9ab53:


    "Adesso sembra più calmo mentre sgranocchia il tuo dito mozzato."


translate ita keepPetting3_03d25c7d:


    "Il moncherino tra il pollice e il dito medio sgocciola..."


translate ita keepPetting3_a20cefa7_4:


    "..."


translate ita keepPetting3_396fb77c:


    "... ma continui ad accarezzarlo."


translate ita keepPetting3_c18819d8:


    "Hai paura che il sangue rovini il suo pelo, ma al gatto non sembra importare."


translate ita keepPetting3_8dabefc6_1:


    ".."


translate ita keepPetting3_a20cefa7_5:


    "..."


translate ita keepPetting3_4d9e273d:


    "Il tempo passa. {w}Ora fuori è buio."


translate ita keepPetting3_7ff6d061:


    "Per quanto soffice sia il pelo, il tuo palmo inizia a scorticarsi a causa del costante attrito delle carezze."


translate ita keepPetting3_a20cefa7_6:


    "..."


translate ita keepPetting3_005a0a26:


    "{size=-7}Pensi vagamente che forse sia ora di smettere.{/size}"


translate ita keepPetting3_0d6d2a66:


    "Incominci ad allontanare la mano dal gatto..."


translate ita keepPetting3_0f665b3a:


    "... quando, in un istante--{w=0.5}{nw}"


translate ita keepPetting3_8ca8510a:


    you "!!!" with vpunch


translate ita keepPetting3_8dabefc6_2:


    ".."


translate ita keepPetting3_a20cefa7_7:


    "..."


translate ita keepPetting3_8dabefc6_3:


    ".."


translate ita keepPetting3_a20cefa7_8:


    "..."


translate ita keepPetting3_cb08e821:


    "... l'intera {b}mano{/b} si stacca dal polso."


translate ita keepPetting3_28e9e838:


    "Cade sul tuo grembo accanto al gatto."


translate ita keepPetting3_9ab57abe:


    "Gli artigli della sua zampa anteriore destra brillano di liquido cremisi."


translate ita keepPetting3_c40b465b:


    "Non lo avverti subito, ma il tuo corpo si irrigidisce..."


translate ita keepPetting3_f432849a:


    "... anticipando il dolore mentre guardi il gatto leccare il palmo insaguinato della tua mano mozzata."


translate ita keepPetting3_e5fab8a0:


    cat "Miao!"


translate ita keepPetting3_4a4e0688:


    you "A-ah...! Fa... male..."


translate ita keepPetting3_3476012a:


    "Fa tanto, {i}tanto{/i} male..."


translate ita keepPetting3_a268e071:


    "Poi... {w}il gatto ti guarda e tu... {w}ti senti in dovere..."


translate ita keepPetting3_a20cefa7_9:


    "..."


translate ita keepPetting3_c070fd95:


    "{size=-8}... di fargli altre {b}carezze.{/b}{/size}"


translate ita keepPetting3_6bbf2111:


    "Sei riluttante... ma hai anche paura di cosa potrebbe accadere se non gli dai retta."


translate ita keepPetting3_a3553d39:


    "Cos'altro perderai {i}ancora{/i} se provassi a resistere di nuovo?"


translate ita keepPetting3_a20cefa7_10:


    "..."


translate ita keepPetting3_0b8e27c7:


    "Prima hai ricevuto una punizione per le troppe carezze..."


translate ita keepPetting3_2f39be7c:


    "... e adesso per aver cercato di smettere?"


translate ita keepPetting3_85303526:


    "... Non ha senso, ma è questo che ti spaventa."


translate ita keepPetting3_9d61d6e2:


    "Non si può ragionare con questi capricci..."


translate ita keepPetting3_3feec0d7:


    "Tenti debolmente di accarezzare il gatto con la tua mano {b}{i}sana{/i}{/b}..."


translate ita keepPetting3_e419ea53:


    "... ma lui si irrigidisce e i suoi occhi dorati scintillano pericolosi."


translate ita keepPetting3_8dabefc6_4:


    ".."


translate ita keepPetting3_a20cefa7_11:


    "..."


translate ita keepPetting3_221cbb22:


    "Bene."


translate ita keepPetting3_a20cefa7_12:


    "..."


translate ita keepPetting3_7d2ae1e5:


    "{size=-10}D'accordo.{/size}"


translate ita keepPetting3_fa304b76:


    "Alzi il moncherino sanguinante e fai del tuo meglio per accarezzarlo."


translate ita keepPetting3_57f9ada2:


    cat "Purr... Purr... Purrr..."


translate ita keepPetting3_dae0ec55_1:


    you "..."


translate ita keepPetting3_b9a42afa:


    "Lo accarezzi..."


translate ita keepPetting3_70d03ba5:


    "... e sanguini."


translate ita keepPetting3_b9a42afa_1:


    "Lo accarezzi..."


translate ita keepPetting3_70d03ba5_1:


    "... e sanguini."


translate ita keepPetting3_b9a42afa_2:


    "Lo accarezzi..."


translate ita keepPetting3_70d03ba5_2:


    "... e sanguini."


translate ita keepPetting3_15f14ac5:


    "Lo accarezzi e..."


translate ita keepPetting3_a20cefa7_13:


    "..."


translate ita keepPetting3_73e94448:


    "... tu..."


translate ita keepPetting3_dae0ec55_2:


    you "..."


translate ita keepPetting3_a20cefa7_14:


    "..."


translate ita keepPetting3_31baff1c:


    "Finale 7: Confini Personali"


translate ita feedHome_87825912:


    "Il gatto sembra affamato, così decidi di nutrirlo."


translate ita feedHome_e8e76bb4:


    "Ti penti di non aver mangiato prima, visto che non hai molto in casa. Il giorno della spesa è domani, dopotutto... "


translate ita feedHome_5c57afc5:


    "Vai in cucina e schiocchi la lingua, assicurandoti che il gatto ti segua."


translate ita feedHome_393fa72b:


    "Lui salta agilmente sul bancone della cucina e ti guarda mentre pensi a cosa mangiare."


translate ita feedHome_a873ea07:


    you "Uhm, vediamo..."


translate ita feedHome_72d43a37:


    "Trovi cose che ti aspettavi:"


translate ita feedHome_aa2b7420:


    "Una scatoletta di tonno in dispensa..."


translate ita feedHome_8b7aae08:


    "Del polpettone avanzato nel frigo..."


translate ita feedHome_cb64e404:


    "E..."


translate ita feedHome_40d9ca73:


    "...?"


translate ita feedHome_8e2c51bf:


    you "Eh? {i}Che cos'è{/i}...?"


translate ita feedHome_af12342d:


    "Ti accorgi che c'è un contenitore ben sigillato sullo scaffale inferiore del frigo."


translate ita feedHome_8dabefc6:


    ".."


translate ita feedHome_a20cefa7:


    "..."


translate ita feedHome_24225f61:


    "{b}Non{/b} lo riconosci."


translate ita feedHome_36681b88:


    "Un odore terribile esce dal contenitore..."


translate ita feedHome_ea57ce22:


    "Qualsiasi cosa sia {i}non può{/i} essere idonea al consumo umano..."


translate ita feedHome_022b9bff:


    cat "Miao! Miao!"


translate ita feedHome_f909cf5f:


    you "Uh..."


translate ita feedHome_a20cefa7_1:


    "..."


translate ita feedHome_1350b083:


    "... ma il {i}gatto{/i} sembra eccitato. Sta proprio {i}sbavando{/i} per il contenuto..."


translate ita feedHome_dae0ec55:


    you "..."


translate ita feedHome_24b8e350:


    "Però {i}sei tu{/i} a doverti prendere cura di lui."


translate ita feedHome_2e4a58b3:


    "{i}Sei tu{/i} che devi decidere come è meglio nutrire un gatto affamato."


translate ita feedHome_cf9ca97b:


    "Quindi lo sfamerai con il..."


translate ita feedHomeMenu_f4bfafde:


    you "Eh, non ha molta fame adesso..."


translate ita feedHomeMenu_8b418ade:


    "Decidi di mettere da parte il cibo e fare altro."


translate ita feedTuna_d786e656:


    you "Ai gatti piace il pesce, giusto?"


translate ita feedTuna_96364a0d:


    "Scrollando le spalle, prendi il tonno per il gatto e il polpettone per te."


translate ita feedTuna_1712c85a:


    "Rimetti il contenitore, decisamente {i}sinistro{/i}, nel frigo."


translate ita feedTuna_1a9c9560:


    "Il gatto sembra un po' deluso."


translate ita feedTuna_a1a28824:


    "Pazienza."


translate ita feedTuna_ee9eb500:


    "Devi liberarti di quella strana... {b}{i}qualsiasi-cosa-sia{/i}{/b} più tardi."


translate ita feedTuna_e074c087:


    "Apri il tonno e lo metti in un piattino, che appoggi sul bancone della cucina accanto al gatto. "


translate ita feedTuna_a1f2544f:


    "Non pensi che dovresti incoraggiarlo a mangiare lì sopra..."


translate ita feedTuna_a98d3823:


    "... ma almeno non finirà per nutrirsi della sostanza tossica che voleva."


translate ita feedTuna_16879ce5:


    cat "Miao?"


translate ita feedTuna_6769c6cb:


    "Sembra che il gatto trovi il tonno..."


translate ita feedTuna_164d6921:


    "... accettabile."


translate ita feedTuna_6aad42ef:


    "Lo terrai a mente."


translate ita feedTuna_3b189997:


    you "Mangia, gattino."


translate ita feedTuna_085f82bc:


    cat "Miao..."


translate ita feedTuna_38b50666:


    "Mentre il gatto si gusta il pasto, vai a scaldare il polpettone nel microonde."


translate ita feedTuna_c294db5c:


    "Mentre imposti il timer, senti-"


translate ita feedTuna_2699cbe6:


    cat "{size=-7}*hic*...{/size}"


translate ita feedTuna_5d06f92b:


    you "Hm?"


translate ita feedTuna_70f82d13:


    "Ti volti e vedi il piatto completamente vuoto."


translate ita feedTuna_14924412:


    you "Wow, hai fatto presto... Dovresti mangiare più-"


translate ita feedTuna_5c31b794:


    cat "*hic*..." with hpunch


translate ita feedTuna_829d2012:


    cat "*hic*... *hic*..." with hpunch


translate ita feedTuna_75a36584:


    cat "{size=+5}*HIC*{/size}" with hpunch


translate ita feedTuna_0e9b573c:


    you "?!?"


translate ita feedTuna_b52ace45:


    you "Ma che...?"


translate ita feedTuna_8871fae2:


    "Con sconcerto, osservi il gatto singhiozzare, fino a quando..."


translate ita feedTuna_56982b7d:


    "... delle piccole bolle escono dalla sua bocca...?"


translate ita feedTuna_8dabefc6:


    ".."


translate ita feedTuna_a20cefa7:


    "..."


translate ita feedTuna_f0657274:


    "Bene."


translate ita feedTuna_a4c0df6c:


    "Va tutto bene."


translate ita feedTuna_6dfd9fc3:


    "Ce... Ce la puoi fare. Non è {i}del tutto{/i} fuori da ogni logica, giusto?"


translate ita feedTuna_a20cefa7_1:


    "..."


translate ita feedTuna_ff5f4bbc:


    "Giusto."


translate ita feedTuna_d1b6b37d:


    "Meglio non pensarci troppo."


translate ita feedTuna_3e1feb83:


    "Presto, la stanza si riempie di bolle fluttuanti."


translate ita feedTuna_20d20ae4:


    cat "h... h... {size=-5}*hic*{/size}..."


translate ita feedTuna_544efc67:


    "Il gatto rilascia un'ultima, piccola bolla prima di sbadigliare e sdraiarsi sul bancone."


translate ita feedTuna_cc63b22e:


    cat "Purr... Purr... Purr..."


translate ita feedTuna_13093fc6:


    you "Beh... Felice che ti sia piaciuto..."


translate ita feedTuna_2c4ee3ec:


    "Le bolle non hanno lasciato la stanza né sono esplose. Sembrano piuttosto resistenti... "


translate ita feedTuna_40d9ca73:


    "...?"


translate ita feedTuna_5a83a2b4:


    "Aspetta... Cosa?"


translate ita feedTuna_112822b7:


    you "Che cos'è...?"


translate ita feedTuna_f0eb37c9:


    "Quando una delle bolle si avvicina a te..."


translate ita feedTuna_b6cf5b97:


    "... noti che c'è qualcosa all'interno."


translate ita feedTuna_7a06a1b0:


    "Un piccolo..."


translate ita feedTuna_40d9ca73_1:


    "...?"


translate ita feedTuna_4208ab4d:


    "... pesce {i}peloso{/i}?"


translate ita feedTuna_dae0ec55:


    you "..."


translate ita feedTuna_a99e5490:


    you "Questa cosa sta diventando sempre più strana..."


translate ita feedTuna_b3e12ea5:


    "Però..."


translate ita feedTuna_f2728bdd:


    "Non puoi evitare lo stupore per l'impossibile meraviglia di fronte a te..."


translate ita feedTuna_8d18fd6d:


    "Alzi una mano..."


translate ita feedTuna_a20cefa7_2:


    "..."


translate ita feedTuna_09b77d88:


    "Avvicini un dito a una bolla..."


translate ita feedTuna_69d6aee8:


    "... Premi delicatamente contro la superficie-"


translate ita feedTuna_8ca8510a:


    you "!!!" with vpunch


translate ita feedTuna_b9de8c3d:


    "Il piccolo pesce all'interno scatta, affondando brutalmente le piccole zanne nel dito."


translate ita feedTuna_ba997575:


    "Non fa davvero male all'inizio ma poi..."


translate ita feedTuna_2da11494:


    you "AAH! O-Oh! Cosa...?" with vpunch


translate ita feedTuna_c7a75804:


    "Il dolore comincia a diffondersi dal tuo dito al resto del braccio..."


translate ita feedTuna_77c0c910:


    "Supera il polso..."


translate ita feedTuna_06c8ab12:


    "E se fosse... un qualche tipo di {b}veleno{/b}...?"


translate ita feedTuna_32fa58b5:


    "Scuoti il braccio per cercare di staccare il pesce, ma..."


translate ita feedTuna_8ca8510a_1:


    you "!!!" with vpunch


translate ita feedTuna_321fb0c5:


    you "{size=+15}{b}{i}GASP!{/i}{/b}{/size}" with hpunch


translate ita feedTuna_af541737:


    "... per sbaglio, il tuo braccio finisce contro diverse bolle fluttuanti."


translate ita feedTuna_48cade3b:


    "Altri piccoli pesci famelici si attaccano alla tua carne..."


translate ita feedTuna_d89404a4:


    "Indietreggi a causa del dolore e di un improvviso attacco di vertigini, ma urti altre bolle..."


translate ita feedTuna_6ae60f96:


    "... e altri pesci ti affondano i denti nella schiena."


translate ita feedTuna_4cf68681:


    you "Argh...! Mmhh..."


translate ita feedTuna_62c0c671:


    "Fa male..."


translate ita feedTuna_33314499:


    "Ti stanno venendo le vertigini..."


translate ita feedTuna_4a51b22e:


    "Devi... uscire..."


translate ita feedTuna_246f5c25:


    "Cerchi freneticamente di uscire dalla cucina incespicando..."


translate ita feedTuna_eec393f2:


    "... ma l'intera stanza è {i}piena{/i} di bolle mortali."


translate ita feedTuna_aa72ff49:


    "Quando collassi al suolo, i piccoli pesci arrabbiati e {b}mordaci{/b} ti ricoprono..."


translate ita feedTuna_39a7b474:


    "Le gambe... {w}Il busto... {w}Le braccia... {w}La {i}faccia{/i}..."


translate ita feedTuna_8dabefc6_1:


    ".."


translate ita feedTuna_a20cefa7_3:


    "..."


translate ita feedTuna_9b33ef77:


    "... Il dolore è {b}insopportabile.{/b}"


translate ita feedTuna_74c927c6:


    "Lo senti nella pelle, nei denti, negli occhi, nei capelli..."


translate ita feedTuna_ee1fb69a:


    "... ed è così {i}intenso{/i} che non ti accorgi di avere le convulsioni."


translate ita feedTuna_514dcaf6:


    "... Né di stare piangendo."


translate ita feedTuna_01f15502:


    "Non perdi i sensi."


translate ita feedTuna_ca0edb73:


    "I tuoi occhi si stanno ancora rovesciando all'indietro quando esali l'ultimo respiro."


translate ita feedTuna_8dabefc6_2:


    ".."


translate ita feedTuna_a20cefa7_4:


    "..."


translate ita feedTuna_b311580a:


    "Finale 8: Un Pesce Fuor d'Acqua"


translate ita feedMeatloaf_38761e59:


    "Hai la sensazione che al gatto non piacerà niente che esca da una lattina."


translate ita feedMeatloaf_b3808f59:


    "E tu {i}non{/i} gli darai da mangiare quella melma dall'aspetto tossico, qualunque cosa sia..."


translate ita feedMeatloaf_4217e4a0:


    "Allora è deciso..."


translate ita feedMeatloaf_6b525050:


    "Un panino al tonno per te e gli avanzi di polpettone per il tuo ospite felino."


translate ita feedMeatloaf_47300799:


    "Ignori i miagolii delusi del gatto mentre rimetti lo strano contenitore nel frigo per buttarlo via più tardi. "


translate ita feedMeatloaf_f17edea9:


    "Scaldi il polpettone nel microonde."


translate ita feedMeatloaf_8dabefc6:


    ".."


translate ita feedMeatloaf_a20cefa7:


    "..."


translate ita feedMeatloaf_6a13ca1e:


    "{size=+5}{i}BIIIP! BIIIP! BIIIP! BIIIP!{/i}{/size}" with hpunch


translate ita feedMeatloaf_187e6671:


    "Metti il polpettone caldo in un piattino vicino al gatto sul bancone."


translate ita feedMeatloaf_a1f2544f:


    "Non pensi che dovresti incoraggiarlo a mangiare lì sopra..."


translate ita feedMeatloaf_a98d3823:


    "... ma almeno non finirà per nutrirsi della sostanza tossica che voleva."


translate ita feedMeatloaf_16879ce5:


    cat "Miao?"


translate ita feedMeatloaf_6f042a3e:


    "Sembra che il gatto trovi il polpettone..."


translate ita feedMeatloaf_c595ac61:


    "... interessante."


translate ita feedMeatloaf_5291b869:


    "Per te va bene."


translate ita feedMeatloaf_3b189997:


    you "Mangia, gattino."


translate ita feedMeatloaf_085f82bc:


    cat "Miao..."


translate ita feedMeatloaf_e2cec0db:


    "Mentre il gatto si gusta il pasto, vai a cercare del pane per il tuo tramezzino al tonno."


translate ita feedMeatloaf_abbef2a5:


    "La ricerca ti distrae al punto che a stento senti-"


translate ita feedMeatloaf_92aab58b:


    "{size=-10}*squish*{/size}"


translate ita feedMeatloaf_5d06f92b:


    you "Hm?"


translate ita feedMeatloaf_c6afd330:


    "Ti volti e vedi che il polpettone è stato addentato {i}giusto{/i} un paio di volte..."


translate ita feedMeatloaf_e41d47bd:


    "Ma la cosa più allarmante..."


translate ita feedMeatloaf_074c7320:


    "É che sembra esserci una scia rossa di..."


translate ita feedMeatloaf_a20cefa7_1:


    "..."


translate ita feedMeatloaf_8dea9007:


    "... {i}qualcosa{/i}"


translate ita feedMeatloaf_a38b893d:


    "... che si allontana da dove si trovava il gatto..."


translate ita feedMeatloaf_c0b392d7:


    "... e dal bordo del bancone verso il salotto."


translate ita feedMeatloaf_bebfdc57:


    you "{i}È...{/i}"


translate ita feedMeatloaf_8de83a4b:


    you "{i}{size=-5}È sangue...?{/size}{/i}"


translate ita feedMeatloaf_a406bb9a:


    who "*gurgle*... *gurgle*... *urgh*... Mmmhh..."


translate ita feedMeatloaf_479c3431:


    you "!!!" with vpunch


translate ita feedMeatloaf_29b1ab2e:


    "Lo strano suono proveniente da dietro l'angolo ti fa sussultare."


translate ita feedMeatloaf_d5fe7a57:


    "Arriva da un punto lontano della casa."


translate ita feedMeatloaf_a20cefa7_2:


    "..."


translate ita feedMeatloaf_b94adebc:


    "Cerchi... di calmare i nervi."


translate ita feedMeatloaf_4ef1545a:


    "Fai un bel respiro, giri attorno al bancone e ti dirigi verso il salotto-"


translate ita feedMeatloaf_9a14f254:


    "*Squish*..."


translate ita feedMeatloaf_90b68c87:


    you "...?"


translate ita feedMeatloaf_8ca8510a:


    you "!!!" with vpunch


translate ita feedMeatloaf_56add764:


    "Hai calpestato qualcosa di bagnato e caldo..."


translate ita feedMeatloaf_e7fb65f3:


    "... e {color=#FF0000}rosso.{/color}"


translate ita feedMeatloaf_6aee484c:


    "Resisti alla tentazione di vomitare e ti allontani dalla scia di..."


translate ita feedMeatloaf_aa46a15a:


    "Di..."


translate ita feedMeatloaf_a20cefa7_3:


    "..."


translate ita feedMeatloaf_cb348c3a:


    "Segui la scia in salotto e vedi che porta al corridoio."


translate ita feedMeatloaf_2f827865:


    who "{size=+5}*gurgle*... *urgh*... *kurrgh*... Uuuhhg...{/size}"


translate ita feedMeatloaf_dae0ec55:


    you "..."


translate ita feedMeatloaf_98bfcf24:


    "È più forte."


translate ita feedMeatloaf_e71a3743:


    "È {i}sicuramente{/i} nel corridoio."


translate ita feedMeatloaf_8dabefc6_1:


    ".."


translate ita feedMeatloaf_a20cefa7_4:


    "..."


translate ita feedMeatloaf_1853155d:


    "Senti il cuore martellarti nel petto."


translate ita feedMeatloaf_a20cefa7_5:


    "..."


translate ita feedMeatloaf_de85b765:


    "Preghi che la cosa nel corridoio {i}non lo senta{/i}."


translate ita feedMeatloaf_e0863d49:


    "Il tuo corpo trema mentre vai avanti."


translate ita feedMeatloaf_a20cefa7_6:


    "..."


translate ita feedMeatloaf_28a75bbb:


    "... E avanti."


translate ita feedMeatloaf_a20cefa7_7:


    "..."


translate ita feedMeatloaf_28a75bbb_1:


    "... E avanti."


translate ita feedMeatloaf_a20cefa7_8:


    "..."


translate ita feedMeatloaf_8ffd6bf2:


    "... E {i}{b}avanti.{/b}{/i}"


translate ita feedMeatloaf_dae0ec55_1:


    you "..."


translate ita feedMeatloaf_3b66688a:


    "Sbirci..."


translate ita feedMeatloaf_e4196020:


    "dietro l'angolo..."


translate ita feedMeatloaf_8dabefc6_2:


    ".."


translate ita feedMeatloaf_a20cefa7_9:


    "..."


translate ita feedMeatloaf_40d9ca73:


    "...?"


translate ita feedMeatloaf_9850f53c:


    "Niente."


translate ita feedMeatloaf_4367dae0:


    "Lì non c'è niente."


translate ita feedMeatloaf_74be92cd:


    you "Cosa...?"


translate ita feedMeatloaf_dc6f132f:


    "Avanzi nel corridoio e vedi che la scia prosegue fino in fondo."


translate ita feedMeatloaf_b35a0aab:


    "Ma non c'è niente lì..."


translate ita feedMeatloaf_a20cefa7_10:


    "..."


translate ita feedMeatloaf_b02be747:


    "Non... provi sollievo. Ma almeno-"


translate ita feedMeatloaf_d22643f9:


    "{size=-10}*splat*{/size}"


translate ita feedMeatloaf_28b3ac41:


    you "!!!"


translate ita feedMeatloaf_887daca8:


    "Senti qualcosa di bagnato e caldo cadere sulla tua guancia."


translate ita feedMeatloaf_e8998afe:


    "Qualcosa... di {i}davvero{/i} caldo..."


translate ita feedMeatloaf_a56c59b7:


    "Ci passi sopra la mano tremante, la ritrai e vedi le dita ricoperte... di {color=#FF0000}qualcosa-{/color}"


translate ita feedMeatloaf_60bcdd54:


    who "{size=+15}*gurgle*... *gurgle*...{/size}"


translate ita feedMeatloaf_ded5babf:


    who "{size=+25}MIAooUuhgh!!!{/size}" with hpunch


translate ita feedMeatloaf_dae0ec55_2:


    you "..."


translate ita feedMeatloaf_81bc8fbe:


    "Alzi lo sguardo."


translate ita feedMeatloaf_415d7b3f:


    "E vedi ciò che puoi solo descrivere come..."


translate ita feedMeatloaf_bb123be3:


    "... {b}carne{/b}."


translate ita feedMeatloaf_c009ecbe:


    "L'intero soffitto del corridoio è coperto da uno spesso, ondulato e contorto strato di {b}carne{/b} pulsante..."


translate ita feedMeatloaf_eb3595a3:


    "... al centro del quale si trova un singolo occhio luminoso, che ruota freneticamente in ogni direzione..."


translate ita feedMeatloaf_8dabefc6_3:


    ".."


translate ita feedMeatloaf_a20cefa7_11:


    "..."


translate ita feedMeatloaf_f82e914d:


    "... finché non si fissa su di te."


translate ita feedMeatloaf_dc6af6ff:


    you "{size=-8}Ah... ah...!{/size}"


translate ita feedMeatloaf_ca526b52:


    "Provi a fare un passo indietro, per fuggire dal corridoio..."


translate ita feedMeatloaf_6d8938bf:


    "Per fuggire da questa {b}cosa{/b}..."


translate ita feedMeatloaf_b3f43ac7:


    "Ma-"


translate ita feedMeatloaf_56ebb028:


    you "!!!"


translate ita feedMeatloaf_20d52c76:


    "Prima ancora che tu possa urlare, spuntano dei tentacoli carnosi che ti afferrano."


translate ita feedMeatloaf_2982ba17:


    you "{size=+15}NNNOOO!!!{/size}" with hpunch


translate ita feedMeatloaf_3137a039:


    you "{size=+25}{i}LASCIATEMI!!!{/i}{/size}" with hpunch


translate ita feedMeatloaf_f3b9e9bf:


    "Ti sollevano."


translate ita feedMeatloaf_435dd3ca:


    "In alto..."


translate ita feedMeatloaf_25c927be:


    "... dentro a fauci che si aprono lentamente."


translate ita feedMeatloaf_b2782038:


    "... E poi-"


translate ita feedMeatloaf_82893c2b:


    "{b}{size=+30}CHOMP!!!{/size}{/b}" with vpunch


translate ita feedMeatloaf_8dabefc6_4:


    ".."


translate ita feedMeatloaf_a20cefa7_12:


    "..."


translate ita feedMeatloaf_34c3a0cf:


    "Finale 9: Avanzi"


translate ita feedMysteryFood_dae0ec55:


    you "..."


translate ita feedMysteryFood_e19f8a1e:


    you "{i}È davvero una buona idea?{/i}"


translate ita feedMysteryFood_36cb4eaa:


    cat "Miao! Miaooo!" with hpunch


translate ita feedMysteryFood_dae0ec55_1:


    you "..."


translate ita feedMysteryFood_c3369009:


    you "Ugh... Va bene, se è davvero quello che vuoi...?"


translate ita feedMysteryFood_36a3d8dc:


    "Apri il contenitore e..."


translate ita feedMysteryFood_f5cdd629:


    you "UGH! Ach...!" with hpunch


translate ita feedMysteryFood_7b89e96c:


    "Riesci a malapena a non vomitare."


translate ita feedMysteryFood_4f6fda05:


    "Ma solo {b}per miracolo.{/b} "


translate ita feedMysteryFood_bfa15d09:


    "La puzza è {b}{i}nauseante.{/i}{/b}"


translate ita feedMysteryFood_df33334e:


    you "*coff*! *gulp*..."


translate ita feedMysteryFood_ec1974d4:


    cat "Miao!" with hpunch


translate ita feedMysteryFood_d652c8bc:


    you "Sì, sì... D-Dammi un minuto..."


translate ita feedMysteryFood_dae0ec55_2:


    you "..."


translate ita feedMysteryFood_fd67a9c4:


    "Azzardi un'occhiata all'interno del contenitore, ma... "


translate ita feedMysteryFood_40d9ca73:


    "...?"


translate ita feedMysteryFood_7fb4ab6c:


    "Non riesci proprio a comprendere di cosa {i}si tratti{/i}."


translate ita feedMysteryFood_0d3260cd:


    "È tutto... {w}{b}mischiato{/b} insieme."


translate ita feedMysteryFood_d0e4106b:


    "Saresti davvero {i}molto{/i} felice se la natura di \"tutto ciò\" potesse rimanere un mistero."


translate ita feedMysteryFood_e5b4174b:


    "Forme diverse... {w}Dimensioni diverse... {w}{i}Consistenze{/i} diverse..."


translate ita feedMysteryFood_a20cefa7:


    "..."


translate ita feedMysteryFood_1f632afd:


    "Ma il colore..."


translate ita feedMysteryFood_0499b762:


    "{i}Quello{/i} è sempre lo stesso..."


translate ita feedMysteryFood_e5aaee76:


    "La tonalità di grigio più {b}infelice{/b} che tu abbia mai visto..."


translate ita feedMysteryFood_abfd3e68:


    "... macchiata con una nauseabonda pellicola {b}verde{/b} e {i}bagnata{/i} in superficie..."


translate ita feedMysteryFood_6251ddbe:


    you "Ach..."


translate ita feedMysteryFood_eebacd3d:


    you "Dovrei... Dovrei {i}scaldarla{/i} oppure...?"


translate ita feedMysteryFood_6c91135f:


    "Non sai davvero come servirla."


translate ita feedMysteryFood_6dadf976:


    "Ti assicuri di gettare {i}immediatamente{/i} ogni utensile o piatto che la tocchi."


translate ita feedMysteryFood_a1ab8862:


    "{b}Nessuna{/b} eccezione."


translate ita feedMysteryFood_ce04a664:


    "Dopodiché, laverai le mani con acqua calda e sapone fin quasi a consumarle completamente..."


translate ita feedMysteryFood_1c5ca3cc:


    "Decidi che non metterai questa roba nel microonde."


translate ita feedMysteryFood_e60b4396:


    "Dubiti che odore e sapore miglioreranno scaldandola."


translate ita feedMysteryFood_00b711bd:


    "Non la vuoi più tenere in mano, perciò scrolli la testa e lanci il contenitore sul bancone vicino al gatto."


translate ita feedMysteryFood_4303c63e:


    cat "{size=+5}MIAO!!!{/size}" with hpunch


translate ita feedMysteryFood_dd9d08f5:


    "Il gatto si lancia con entusiasmo verso la poltiglia sospetta, annusandola come se potesse assaporarne l'odore."


translate ita feedMysteryFood_7692df1d:


    "Ti volti verso il frigo e lo chiudi."


translate ita feedMysteryFood_a20cefa7_1:


    "..."


translate ita feedMysteryFood_6895d8e7:


    "Hai perso l'appetito."


translate ita feedMysteryFood_7f974e2b:


    "Stai per andare in bagno a lavarti le mani per la prossima ora o giù di lì, quando-"


translate ita feedMysteryFood_767bfdd5:


    cat "*chomp*!"


translate ita feedMysteryFood_b82c7bcd:


    "{size=-5}*crunch*!{/size}" with vpunch


translate ita feedMysteryFood_8ca8510a:


    you "!!!" with vpunch


translate ita feedMysteryFood_9b89e7c0:


    you "OUCH!!!" with hpunch


translate ita feedMysteryFood_529cb8ee:


    "Un forte dolore al piede ti fa inciampare."


translate ita feedMysteryFood_d7056fb1:


    "Ti tieni al lavandino della cucina, guardi in basso e vedi che la punta del tuo calzino è..."


translate ita feedMysteryFood_2d02d511:


    "{color=#FF0000}... rossa.{/color}"


translate ita feedMysteryFood_645b7424:


    "...?!?"


translate ita feedMysteryFood_5b076aa4:


    "E il rosso si sta lentamente spargendo su tutto il calzino."


translate ita feedMysteryFood_54172303:


    "Stai {b}{i}sanguinando?{/i}{/b}"


translate ita feedMysteryFood_eaef5df7:


    "Ti abbassi velocemente e ti togli il calzino per vedere la ferita."


translate ita feedMysteryFood_a20cefa7_2:


    "..."


translate ita feedMysteryFood_632d1a35:


    you "!!!" with hpunch


translate ita feedMysteryFood_a20cefa7_3:


    "..."


translate ita feedMysteryFood_40b6614a:


    "Il terzo dito è..."


translate ita feedMysteryFood_9342fc41:


    "... {b}sparito.{/b}"


translate ita feedMysteryFood_9117d01a:


    "È semplicemente {i}sparito{/i}... {w}Al suo posto c'è un moncherino... {w}che perde sangue sul pavimento."


translate ita feedMysteryFood_6558b781:


    you "Ah... Ah..."


translate ita feedMysteryFood_f42c7e0f:


    "Fai un goffo passo all'indietro, come se potessi scappare da tutto questo. La scia di sangue segue i tuoi movimenti."


translate ita feedMysteryFood_b3c55428:


    "1-1-2..."


translate ita feedMysteryFood_a20cefa7_4:


    "..."


translate ita feedMysteryFood_5355e62d:


    "Devi... chiamare il 1-1-2..."


translate ita feedMysteryFood_a378dc9c:


    you "T-Telefono... Dov'è il-"


translate ita feedMysteryFood_33af87d5:


    you "{b}!!!{/b}" with vpunch


translate ita feedMysteryFood_40d95a03:


    you "*COFF!* *COFF!* {b}*COFF!*{/b}" with vpunch


translate ita feedMysteryFood_8dabefc6:


    ".."


translate ita feedMysteryFood_a20cefa7_5:


    "..."


translate ita feedMysteryFood_cb722153:


    you "*blurgh* C... Co..."


translate ita feedMysteryFood_78617435:


    "La tua..."


translate ita feedMysteryFood_6e8b8ede:


    "La tua {i}lingua{/i} è...!"


translate ita feedMysteryFood_067d0202:


    you "Coa... {w}ucce...e?!?"


translate ita feedMysteryFood_dea300f2:


    you "{i}Cosa mi sta succedendo...?!?{/i}"


translate ita feedMysteryFood_2f81467a:


    cat "*chomp*... *chomp*... *chomp*..."


translate ita feedMysteryFood_a20cefa7_6:


    "..."


translate ita feedMysteryFood_db9cba4a:


    "Ti volti lentamente e vedi che il gatto sta ancora mangiando."


translate ita feedMysteryFood_f044b2af:


    "Ignora del tutto la tua sofferenza."


translate ita feedMysteryFood_2f81467a_1:


    cat "*chomp*... *chomp*... *chomp*..."


translate ita feedMysteryFood_a0ae4816:


    "Senza preoccuparti di provare a fermare il sangue che esce dalla tua bocca..."


translate ita feedMysteryFood_3b0a657b:


    "... continui a guardare il gatto che, con soddisfazione, mangia un grosso pezzo di..."


translate ita feedMysteryFood_40d9ca73_1:


    "...?"


translate ita feedMysteryFood_e81efaa7:


    "Aspetta..."


translate ita feedMysteryFood_dde83c31:


    "Quella..."


translate ita feedMysteryFood_90087fb1:


    "Guardi con più attenzione il cibo sospetto nella bocca del gatto."


translate ita feedMysteryFood_433e4a84:


    "Sembra stranamente familiare..."


translate ita feedMysteryFood_ed0337aa:


    "{w}Sembra... {w}essere..."


translate ita feedMysteryFood_55d4f761:


    "{size=-10}... una lingua?{/size}"


translate ita feedMysteryFood_ed5ea61e:


    you "Ah..."


translate ita feedMysteryFood_4f325bce:


    cat "*chomp*... *gulp*..."


translate ita feedMysteryFood_0e994b53:


    cat "Miaooo!" with hpunch


translate ita feedMysteryFood_0ffcdb7b:


    "Prima che tu possa anche solo pensare di fermarlo, il gatto si tuffa di nuovo nel contenitore..."


translate ita feedMysteryFood_1ccdd916:


    "... e morde un pezzo che sembra proprio essere--"


translate ita feedMysteryFood_60602550:


    you "{size=+10}AAHHH!!!{/size}" with vpunch


translate ita feedMysteryFood_b2b51942:


    you "ARGH...!!!" with vpunch


translate ita feedMysteryFood_d6477e05:


    "Cadi al suolo, stringendoti forte il petto."


translate ita feedMysteryFood_4ba5d8f7:


    "Piangendo, ti contorci sulle piastrelle macchiate di sangue..."


translate ita feedMysteryFood_f422db3b:


    "Qualcosa... {w}Qualcosa {i}dentro{/i} di te è appena..."


translate ita feedMysteryFood_d69064ca:


    you "Blurgh!!!" with vpunch


translate ita feedMysteryFood_668a5876:


    "Senti il sangue sgorgare dal profondo..."


translate ita feedMysteryFood_2c70abae:


    "Qualsiasi cosa fosse... {w}sembrava importante..."


translate ita feedMysteryFood_a20cefa7_7:


    "..."


translate ita feedMysteryFood_0b43b634:


    "... e anche quella probabilmente è sparita ora."


translate ita feedMysteryFood_a20cefa7_8:


    "..."


translate ita feedMysteryFood_62c0c671:


    "Fa male..."


translate ita feedMysteryFood_30734567:


    "Fa {i}molto{/i} male..."


translate ita feedMysteryFood_5aa5bc57:


    you "B... Basaa... i... pegoo"


translate ita feedMysteryFood_211a3f4c:


    "Provi con fatica ad avvicinarti al gatto sul bancone sopra di te..."


translate ita feedMysteryFood_84b8f508:


    "La tua vista è sfocata. Per lo sforzo... per il dolore... per le lacrime... per-"


translate ita feedMysteryFood_822363a9:


    you "AARRgh!!!" with vpunch


translate ita feedMysteryFood_a20cefa7_9:


    "..."


translate ita feedMysteryFood_cc9a5909:


    "!!!"


translate ita feedMysteryFood_0858d46d:


    you "Mmmhh..."


translate ita feedMysteryFood_8dabefc6_1:


    ".."


translate ita feedMysteryFood_a20cefa7_10:


    "..."


translate ita feedMysteryFood_75d1a549:


    "I tuoi occhi..."


translate ita feedMysteryFood_15ada053:


    "I tuoi {b}{i}occhi{/i}{/b}...!"


translate ita feedMysteryFood_a20cefa7_11:


    "..."


translate ita feedMysteryFood_bd9ff9f5:


    "Cadi a terra afflosciandoti."


translate ita feedMysteryFood_ac841cd1:


    "Stai perdendo sangue ovunque... {w}{i}da{/i} ogni parte..."


translate ita feedMysteryFood_e55d866a:


    "Il tuo piede... la bocca... le interiora... le orbite..."


translate ita feedMysteryFood_a20cefa7_12:


    "..."


translate ita feedMysteryFood_8ecf8642:


    "Inoltre, senti che la tua {i}vita{/i} sta svanendo..."


translate ita feedMysteryFood_a20cefa7_13:


    "..."


translate ita feedMysteryFood_caccfbd8:


    "Va tutto bene..."


translate ita feedMysteryFood_e46ce5d0:


    "Se questo significa non provare più dolore o perdere altre parti, allora..."


translate ita feedMysteryFood_8dabefc6_2:


    ".."


translate ita feedMysteryFood_a20cefa7_14:


    "..."


translate ita feedMysteryFood_69d0c3bc:


    "Speri che il gatto si prenda del tempo per mangiare i bulbi oculari..."


translate ita feedMysteryFood_1a12115a:


    "... e dia {i}a te{/i} il tempo... {w}{alpha=0.5}per...{/alpha} {w}{alpha=0.3}per...{/alpha}"


translate ita feedMysteryFood_dae0ec55_3:


    you "..."


translate ita feedMysteryFood_8dabefc6_3:


    ".."


translate ita feedMysteryFood_a20cefa7_15:


    "..."


translate ita feedMysteryFood_71436a3d:


    "Finale 10: \"Sei ciò che mangi...\""


translate ita playHome_8b57cab4:


    cat "Miiiao?"


translate ita playHome_e1260fe5:


    "Quella pallina di pelo si sarà annoiata a morte seduta nella scatola tutto il giorno..."


translate ita playHome_aa8c252a:


    "Guardando le persone camminarle vicino..."


translate ita playHome_84679d02:


    "{i}Ignorandola{/i}..."


translate ita playHome_a20cefa7:


    "..."


translate ita playHome_d87c1b74:


    "Non puoi proprio lasciarla sola appena arrivi a casa!"


translate ita playHome_af11a585:


    "Socializzare con un'altra specie non ti farà male, giusto?"


translate ita playHome_085f82bc:


    cat "Miao..."


translate ita playHome_3b415eb0:


    you "Oooh... Vuoi solo un po' di attenzione, vero? Vuoi giocare?"


translate ita playHome_ec1974d4:


    cat "Miao!" with hpunch


translate ita playHome_cbd9fef6:


    you "Eheh, ok!"


translate ita playHome_30cd7cf3:


    "A cosa giochiamo?"


translate ita playYarn_dd1cf4bc:


    "Se dovessi credere a ogni film e cartone animato con i gatti che hai visto durante l'infanzia..."


translate ita playYarn_e8f945eb:


    "... allora potresti dedurre con quasi {i}assoluta{/i} certezza..."


translate ita playYarn_cf283aac:


    "... che i gatti {b}impazziscono{/b} per i fili."


translate ita playYarn_a20cefa7:


    "..."


translate ita playYarn_83c46a64:


    "... Forse."


translate ita playYarn_f53e5eed:


    "Ne tiri fuori alcuni da una vecchia scatola nell'armadio in corridoio, piena di rimasugli di vari hobby passati."


translate ita playYarn_9882b599:


    "Potresti semplicemente dare il gomitolo rosso acceso al gatto e tenerlo sott'occhio da lontano..."


translate ita playYarn_447f557d:


    "... ma questo vanificherebbe l'idea di giocare {i}insieme{/i}, non è vero?"


translate ita playYarn_0c8da5b7:


    "Tagli un pezzo abbastanza lungo dal gomitolo e torni in salotto."


translate ita playYarn_143b5340:


    "Il gatto sta riposando sul pavimento."


translate ita playYarn_b46f2b82:


    "Non sta dormendo ma, quando entri nella stanza, ti dà l'impressione che sia sul punto di assopirsi."


translate ita playYarn_e2043592:


    "Rimedierai~"


translate ita playYarn_1f142b99:


    "Sorridi, felice della sorpresa che gli hai portato..."


translate ita playYarn_5a92a679:


    "... e lasci penzolare il filo appena sopra il pavimento, stretto tra il pollice e l'indice. "


translate ita playYarn_7f0ac95c:


    cat "..."


translate ita playYarn_e4612ec1:


    you "...!"


translate ita playYarn_7f0ac95c_1:


    cat "..."


translate ita playYarn_082fc8f9:


    "L'improvviso cambio d'umore del gatto fa battere il tuo cuore più velocemente."


translate ita playYarn_47f12df9:


    "La sua postura non è cambiata quasi per nulla."


translate ita playYarn_693f240f:


    "Una piccola rotazione della testa e delle orecchie..."


translate ita playYarn_c99bf353:


    "Una leggera tensione nelle spalle..."


translate ita playYarn_e3dd092d:


    "Uno sguardo aguzzo mentre fissa il filo che penzola a qualche centimetro da terra."


translate ita playYarn_bc8cebd1:


    "Il gatto potrebbe persino sembrare... rilassato."


translate ita playYarn_c57d0fe0:


    "Calmo."


translate ita playYarn_09c01095:


    "Tuttavia, l'aria è densa della sua impazienza di lanciarsi avanti..."


translate ita playYarn_9d4bad95:


    "... in attesa del momento giusto per agire."


translate ita playYarn_dae0ec55:


    you "..."


translate ita playYarn_ea936df6:


    "Ti senti come se avessi appena assistito alla nascita del predatore perfetto."


translate ita playYarn_c0a501b2:


    "Hai... quasi paura di sapere cosa accadrà quando farai la prima mossa..."


translate ita playYarn_7f0ac95c_2:


    cat "..."


translate ita playYarn_dae0ec55_1:


    you "..."


translate ita playYarn_a046cf90:


    "... Ma {i}sarai{/i} {i}tu{/i} a fare la prima mossa."


translate ita playYarn_75c8055f:


    "Fai un respiro profondo..."


translate ita playYarn_7f0ac95c_3:


    cat "..."


translate ita playYarn_6b7d4985:


    "Rilassi le spalle..."


translate ita playYarn_7f0ac95c_4:


    cat "..."


translate ita playYarn_cb64e404:


    "E..."


translate ita playYarn_a20cefa7_1:


    "..."


translate ita playYarn_eaa3eb7d:


    cat "{b}MIAO!!!{/b}" with hpunch


translate ita playYarn_80bfc06c:


    you "Ooops~!"


translate ita playYarn_ece07a96:


    "Il gatto balza in avanti non appena muovi il filo."


translate ita playYarn_1ec8f382:


    "Ma tu sei più veloce."


translate ita playYarn_f1e3bd8f:


    "Lo scatto del polso gli fa mancare del tutto il filo, che sfugge alla sua presa come un serpente terrorizzato."


translate ita playYarn_0a015919:


    "Il gatto si lancia con troppa foga, inciampa e si guarda intorno confuso per non essere riuscito ad afferrare il filo."


translate ita playYarn_6c8a9bcc:


    "Schiocchi la lingua per aiutarlo a orientarsi di nuovo. Il gatto si volta di scatto per il suono."


translate ita playYarn_9111e7f0:


    "Fissa il filo con talmente tanta intensità che ti sorprende."


translate ita playYarn_dc3f454b:


    "Ma tu persisti."


translate ita playYarn_0d970e5b:


    "Agiti di nuovo il filo incoraggiandolo... {w}e sì, forse deridendolo {i}un pochino{/i}."


translate ita playYarn_28d461a7:


    "Questa volta, il gatto anticipa il movimento del filo e salta in alto per colpirlo..."


translate ita playYarn_1e32b6e1:


    "Ma tu sei già un passo avanti. Agiti il filo e lo fai dondolare di nuovo fuori dalla sua portata."


translate ita playYarn_ceceaf01:


    cat "Miaoo!" with hpunch


translate ita playYarn_046c475d:


    you "Eheh, forza, puoi farcela~"


translate ita playYarn_00cf3674:


    "Sai che è un po' condiscendente, ma non riesci a farne a meno."


translate ita playYarn_defd1036:


    "Per qualche motivo, far abbassare un po' la cresta al gatto ti fa stare bene."


translate ita playYarn_74d03aa0:


    cat "Miao! Miao!"


translate ita playYarn_9f124326:


    "Quantomeno, sembra si stia divertendo, no?"


translate ita playYarn_79f40d3e:


    "Almeno {i}speri{/i}..."


translate ita playYarn_a20cefa7_2:


    "..."


translate ita playYarn_5d2e14ac:


    "Continui."


translate ita playYarn_82c37b27:


    cat "Miao!{w=0.7}{nw}" with vpunch


translate ita playYarn_c2d58782:


    cat "{size=+5}Miao!!!{/size}{w=0.7}{nw}" with vpunch


translate ita playYarn_ddbf4218:


    cat "{size=+10}Miao!!!{/size}{w=0.7}{nw}" with vpunch


translate ita playYarn_238eca43:


    "I movimenti del gatto si fanno più... aggressivi."


translate ita playYarn_b85635f2:


    "Deve sentirsi scoraggiato."


translate ita playYarn_15e0cfc4:


    "{i}Giureresti{/i} che ti abbia guardato malissimo l'ultima volta, dopo quel salto così alto e imprevedibile..."


translate ita playYarn_b6240bec:


    "Stai muovendo il filo a un ritmo costante, con la paura di rallentare."


translate ita playYarn_7c40740c:


    "Il polso comincia a farti male..."


translate ita playYarn_f8a8c5e7:


    "Però il gatto non sembra stancarsi."


translate ita playYarn_abbf9704:


    "È come..."


translate ita playYarn_f401f029:


    "... se fosse sempre più veloce."


translate ita playYarn_9416f814:


    cat "{b}Miao!{/b}" with vpunch


translate ita playYarn_f2676f04:


    "*Flip*"


translate ita playYarn_d1bee282:


    cat "{size=+5}{b}Miao!{/b}{/size}" with vpunch


translate ita playYarn_f2676f04_1:


    "*Flip*"


translate ita playYarn_06cf9fb4:


    cat "{size=+10}{b}Miao!{/b}{/size}" with vpunch


translate ita playYarn_6c59984d:


    "*Flip*-"


translate ita playYarn_0174bdad:


    you "Mmh!"


translate ita playYarn_363b732f:


    "Alla fine un forte crampo al polso..."


translate ita playYarn_91e83780:


    "... ti causa un dolore tale da farti perdere il controllo del filo, che ti sfiora lo stomaco-"


translate ita playYarn_9e69e751:


    "{size=+25}{i}SLASH!!!{/i}{/size}" with hpunch


translate ita playYarn_88a29bc2:


    you "...!!! URGH!!!" with vpunch


translate ita playYarn_fa719f0e:


    "Provi un dolore lancinante alla pancia..."


translate ita playYarn_9d6f51b9:


    "... al suo {i}interno{/i}."


translate ita playYarn_0670ea4a:


    you "B-Blurgh!" with vpunch


translate ita playYarn_3fa6ed31:


    "Dalla tua bocca esce sangue..."


translate ita playYarn_93c8a750:


    "Abbassi lo sguardo e vedi una macchia rossa sbocciare lentamente sulla maglietta... tra gli strappi nel tessuto..."


translate ita playYarn_28f0d5c3:


    you "*coff* *coff*-"


translate ita playYarn_b11bba49:


    "{size=+10}{b}SPLAT!{/b}{/size}" with vpunch


translate ita playYarn_56ebb028:


    you "!!!"


translate ita playYarn_cfd9f7c0:


    you "A-Ah...!"


translate ita playYarn_a3378925:


    "Vedi delle corde spesse e lunghe di..."


translate ita playYarn_083f1354:


    "{i}... qualcosa...{/i}"


translate ita playYarn_c9be29f0:


    "... uscire da sotto la maglietta in un ammasso sanguinolento e finire ai tuoi piedi."


translate ita playYarn_36f9ea20:


    "Una singola corda striata di rosso pende ancora da te... {w}{i}collegandoti{/i} a tutto quel... {b}macello{/b}."


translate ita playYarn_98fb658f:


    "Sono... {w}Sono le tue...?"


translate ita playYarn_afbea56b:


    "Crolli a terra e cadi su un fianco."


translate ita playYarn_101de09f:


    "La tua vista si fa annebbiata..."


translate ita playYarn_bf0874e3:


    "Ma..."


translate ita playYarn_a49bee6a:


    "... riesci a distinguere una piccola sagoma nera come la pece che si avvicina, ti ispeziona..."


translate ita playYarn_a5942a18:


    "{size=-10}Oddio, sono le tue {i}budella{/i}...{/size}"


translate ita playYarn_59d3b133:


    "... e comincia a rotolarsi dentro l'ammasso di interiora insanguinate vicino a te."


translate ita playYarn_5e84b463:


    cat "Miao! Miao!"


translate ita playYarn_a0096ee8:


    "L'oscurità ti avvolge..."


translate ita playYarn_e5fab8a0:


    cat "Miao!"


translate ita playYarn_dae0ec55_2:


    you "..."


translate ita playYarn_99e0e8b8:


    "Il gatto... {w}sembra felice."


translate ita playYarn_6d107ba2:


    "Per assurdo, ti domandi dove sia finito il filo, ma... {w}non c'è bisogno di preoccuparsi."


translate ita playYarn_2773433b:


    "Il gatto sembra soddisfatto di questa soluzione."


translate ita playYarn_a20cefa7_3:


    "..."


translate ita playYarn_472f27e0:


    "Finale 11: Hai Tirato Troppo la Corda"


translate ita playLaser_fb5ad6dc:


    "I gatti sono creature curiose di natura..."


translate ita playLaser_c4ace2d3:


    "Sono anche dei cacciatori nati... più o meno."


translate ita playLaser_80e551db:


    "Potresti passare del tempo facendogli cacciare qualcosa che non capirà mai del tutto."


translate ita playLaser_a20cefa7:


    "..."


translate ita playLaser_75f82259:


    "A pensarci bene, potrebbe sembrare una cattiveria..."


translate ita playLaser_914e4419:


    "Ma il gatto non lo saprà comunque."


translate ita playLaser_1a75f885:


    "\"Beata ignoranza\", così dicono."


translate ita playLaser_9007c0d7:


    "Tiri fuori il tuo vecchio puntatore laser, che usavi ai tempi della scuola per le presentazioni di gruppo."


translate ita playLaser_c3d8ff06:


    "Lo accendi e noti che, nonostante il tempo trascorso, le pile funzionano ancora."


translate ita playLaser_9c176f96:


    "Ti diverti un mondo a puntarlo contro uno specchio appeso in salotto, in modo che si rifletta sul vetro..."


translate ita playLaser_679296d6:


    "... facendo apparire un puntino rosso sul tuo ginocchio."


translate ita playLaser_751f71d9:


    cat "... Miao?"


translate ita playLaser_ebec2255:


    "Il gatto si avvicina lentamente, fermandosi a ogni passo per lanciarti un'occhiata sospettosa."


translate ita playLaser_1f6e99f2:


    "Quando ti raggiunge, appoggia leggermente una zampa sul tuo ginocchio..."


translate ita playLaser_7afb7281:


    "... come se cercasse di prendere il puntino nel modo più disinvolto possibile."


translate ita playLaser_6e2311a9:


    you "Mmpf!" with vpunch


translate ita playLaser_e7427e1b:


    "Riesci a trattenere una risata. Non che importi molto."


translate ita playLaser_51f4c068:


    "Il gatto non ti sta prestando attenzione, totalmente rapito dal puntino di luce che ora si trova sulla sua zampa."


translate ita playLaser_c6366437:


    you "Eheh~"


translate ita playLaser_a1c9ebec:


    "Sposti la luce un po' più in alto sopra il ginocchio."


translate ita playLaser_bdf0b7fa:


    "Il gatto reagisce subito, cercando di catturarla..."


translate ita playLaser_1e13c86f:


    "... ma un momento dopo, l'hai già spostata sul pavimento."


translate ita playLaser_e51a55ad:


    "Il gatto ti segue a scatti, tentando un balzo più energico quando sposti il puntino rosso..."


translate ita playLaser_27fb2bef:


    "Di qua..."


translate ita playLaser_99bbe8fa:


    "Di là..."


translate ita playLaser_c2405716:


    "Da un'altra parte..."


translate ita playLaser_a4dbb992:


    "Vicino al divano..."


translate ita playLaser_7b4b553d:


    "{i}Sul{/i} divano..."


translate ita playLaser_555c0370:


    cat "Miao! Miao!" with hpunch


translate ita playLaser_0931d500:


    you "Eheheh!"


translate ita playLaser_33d860e3:


    "Il gatto ti starà anche ignorando, ma tu ti stai divertendo moltissimo."


translate ita playLaser_98b699aa:


    "È da tanto che non ridevi così."


translate ita playLaser_a20cefa7_1:


    "..."


translate ita playLaser_2ca4176f:


    "Stai ridendo {i}così{/i} tanto..."


translate ita playLaser_0f656f12:


    "... che per sbaglio sposti il puntino rosso su una lampada vicino al divano."


translate ita playLaser_a4314429:


    cat "{size=+10}Miao!{/size}" with hpunch


translate ita playLaser_c80ec7e6:


    "Preso dalla foga del momento, il gatto salta sulla lampada e la butta a terra."


translate ita playLaser_c9873f7d:


    "{size=+20}CRASH!!!{/size}" with vpunch


translate ita playLaser_2cb154e5:


    you "*Gasp* Oh mio Dio!"


translate ita playLaser_4cd0c099:


    "Il gatto si è seduto in mezzo ai cocci della lampada..."


translate ita playLaser_4e66e4b9:


    "... ricurvo, e si guarda intorno freneticamente, preso dal panico."


translate ita playLaser_68f4b17b:


    "Spegni subito il puntatore laser e ti precipiti da lui."


translate ita playLaser_d789f24b:


    you "Mi dispiace! S-Stai bene? Ti sei fatto male?"


translate ita playLaser_d4abd66b:


    "Ti chini per prendere il gatto e controllare se è ferito quando-"


translate ita playLaser_8fdc8cf1:


    cat "{size=+5}MIAO!!!{/size}" with vpunch


translate ita playLaser_ec457ab1:


    "{size=+20}{i}SLASH!{/i}{/size}" with hpunch


translate ita playLaser_327933f5:


    you "OUCH! Ehi!"


translate ita playLaser_a708b99f:


    "Il gatto ti colpisce con gli artigli sfoderati."


translate ita playLaser_da2387c2:


    "Arretra e si divincola, muovendosi velocemente da una parte all'altra come se stesse cercando qualcosa..."


translate ita playLaser_663f6b23:


    "... o {i}aspettando{/i} che qualcosa appaia."


translate ita playLaser_290f624d:


    you "Oh, cavolo... Ha fatto male, sai..."


translate ita playLaser_38b4ee56:


    "Ti porti la mano graffiata al petto."


translate ita playLaser_eee45712:


    "Sta sanguinando, ma non è grave. Più che altro è fastidioso, ma..."


translate ita playLaser_e78aaa6d:


    cat "Miao!{w=0.75}{nw}" with hpunch


translate ita playLaser_1bb5166d:


    cat "Miao! Miao!{w=1}{nw}" with hpunch


translate ita playLaser_ab09fb6c:


    "... d'un tratto il fastidio si trasforma in preoccupazione."


translate ita playLaser_e92b7d98:


    cat "{i}MIAO!{/i}" with vpunch


translate ita playLaser_539c898a:


    "Guardi a bocca aperta il gatto che corre in giro strappando il tappeto, il divano e la poltrona..."


translate ita playLaser_f45e7675:


    "Vuoi fermarlo, ma hai paura che possa travolgerti con la sua furia."


translate ita playLaser_8920b0ca:


    "Vorresti chiamare un veterinario e chiedergli aiuto per calmarlo, ma per qualche motivo..."


translate ita playLaser_a20cefa7_2:


    "..."


translate ita playLaser_12cd3024:


    "{size=-10}... intuisci che non sarebbe una buona idea.{/size}"


translate ita playLaser_a20cefa7_3:


    "..."


translate ita playLaser_5fb40629:


    you "Che ti è successo...? Sei...?"


translate ita playLaser_38a2a096:


    you "...!" with vpunch


translate ita playLaser_d478bf3d:


    "Ti viene un'idea. O forse è un'illuminazione?"


translate ita playLaser_688dec48:


    "Afferri il puntatore laser, direzionandolo con cautela verso il pavimento, al centro del soggiorno... "


translate ita playLaser_3ab47bcb:


    "Pensando... {w}{i}sperando{/i}... {w}che il gatto si calmi una volta trovato ciò che stava cercando..."


translate ita playLaser_74fa8018:


    "... accendi il puntatore laser."


translate ita playLaser_ab6d5659:


    cat "!!!" with hpunch


translate ita playLaser_8dabefc6:


    ".."


translate ita playLaser_a20cefa7_4:


    "..."


translate ita playLaser_10394fe2:


    "La reazione del gatto è {b}immediata.{/b}"


translate ita playLaser_e362f7cd:


    cat "Mriao!" with hpunch


translate ita playLaser_d6063309:


    cat "{size=+15}MRAOOR!!! {/size}" with hpunch


translate ita playLaser_e47b681a:


    cat "{size=+25}{b}MROOAARR!!!{/b}{/size}" with hpunch


translate ita playLaser_56ebb028:


    you "!!!"


translate ita playLaser_a20cefa7_5:


    "..."


translate ita playLaser_02bcbf4d:


    "{size=-8}... Hai fatto un casino.{/size}"


translate ita playLaser_ff446bcf:


    "Nel giro di pochi secondi, vedi il gatto che appollaiato sulla poltrona a brandelli, punta alla lucina rossa..."


translate ita playLaser_bcb1443f:


    "... salta in aria..."


translate ita playLaser_ce89eeea:


    "... fa una {i}{b}piroetta{/b}{/i}..."


translate ita playLaser_b7ce2ec0:


    "{size=+35}{b}CRASH!!!{/b}{/size}{w=0.2}{nw}" with hpunch


translate ita playLaser_3aae9beb:


    "{size=+35}{b}CRASH!!!{/b}{/size}" with vpunch


translate ita playLaser_56ebb028_1:


    you "!!!"


translate ita playLaser_cd394c54:


    "... e si schianta sul puntino a terra, con una forza tale da {i}scuotere{/i} l'intero appartamento."


translate ita playLaser_41d12d34:


    "Forse anche l'intero edificio."


translate ita playLaser_f7f341a9:


    "Ti domandi come mai nessuno degli inquilini si sia precipitato a lamentarsi del rumore..."


translate ita playLaser_a1efdf2a:


    "Eppure, continui a fissare ciò che hai davanti..."


translate ita playLaser_189e50c9:


    "Il gatto sembra essere {i}più grande{/i}..."


translate ita playLaser_0d1c6dcc:


    "... gli occhi sporgenti e luminosi... {w}la coda che ondeggia... {w}i denti più grandi, digrignanti e paurosamente ricoperti di schiuma..."


translate ita playLaser_b78125ff:


    "Gli artigli giganti lacerano e strappano il tappeto, sollevano le piastrelle, scavano {b}addirittura{/b} il pavimento... "


translate ita playLaser_29b85512:


    "... cercando furiosamente il puntino rosso."


translate ita playLaser_3917623e:


    "Le tue mani tremano."


translate ita playLaser_a225310b:


    "Non sai cosa fare. Ti senti in trappola. Devi allontanarti."


translate ita playLaser_82568cc9:


    "... Allontanarti da {i}lui{/i}."


translate ita playLaser_28b3ac41:


    you "!!!"


translate ita playLaser_94047747:


    "Ti avvicini lentamente alla porta."


translate ita playLaser_76076a2d:


    "La lucina si muove con te."


translate ita playLaser_f2573342:


    cat "{size=+10}!!!{/size}" with hpunch


translate ita playLaser_56ebb028_2:


    you "!!!"


translate ita playLaser_4d205848:


    "D'istinto allontani la luce da una parte all'altra e il gatto la insegue... "


translate ita playLaser_cb465f82:


    "{size=+30}{b}CRASH!!!{/b}{/size}" with vpunch


translate ita playLaser_69d96002:


    you "{i}É veloce...{/i}"


translate ita playLaser_195b9941:


    "... distrugge la TV... spacca il divano a metà..."


translate ita playLaser_17efb246:


    "{size=+30}{b}CRASH!!!{/b}{/size}{w=0.2}{nw}" with vpunch


translate ita playLaser_5fdd654f:


    "{size=+30}{b}CRASH!!! CRASH!!!{/b}{/size}" with vpunch


translate ita playLaser_adef04a7:


    you "{i}Troppo veloce...{/i}"


translate ita playLaser_555778c7:


    "... sfonda il muro ed entra nel corridoio."


translate ita playLaser_3aae9beb_1:


    "{size=+35}{b}CRASH!!!{/b}{/size}" with vpunch


translate ita playLaser_28b3ac41_1:


    you "!!!"


translate ita playLaser_7984bc3e:


    "Una possibilità!"


translate ita playLaser_67119f3b:


    "Ti giri pensando di scappare fuori dalla porta e non tornare mai più..."


translate ita playLaser_a741a67f:


    "... ma per la fretta, hai {b}dimenticato{/b} qualcosa."


translate ita playLaser_4dfa2f4a:


    "Hai dimenticato {i}parecchie{/i} cose."


translate ita playLaser_3ef81c43:


    "Hai dimenticato il puntatore laser, che stringi ancora in mano come un salvagente..."


translate ita playLaser_e94069c8:


    cat "!!!"


translate ita playLaser_6d278a4f:


    "Hai dimenticato lo specchio, che è ancora appeso per miracolo sul muro vicino al corridoio..."


translate ita playLaser_aa8d0cf9:


    "... Il laser colpisce lo specchio..."


translate ita playLaser_e6c0f1f9:


    "... e forma un piccolo puntino rosso luminoso..."


translate ita playLaser_a20cefa7_6:


    "..."


translate ita playLaser_69603a8b:


    "... che si riflette sulla tua nuca..."


translate ita playLaser_7f0ac95c:


    cat "..."


translate ita playLaser_80207668:


    "E quando raggiungi la porta..."


translate ita playLaser_9b41848f:


    cat "{b}*GROWL*{/b}"


translate ita playLaser_a20cefa7_7:


    "..."


translate ita playLaser_35fdb28d:


    "... scopri di aver dimenticato di averla chiusa."


translate ita playLaser_8dabefc6_1:


    ".."


translate ita playLaser_a20cefa7_8:


    "..."


translate ita playLaser_8b4b67e6:


    "Non hai neanche il tempo di girarti che il gatto si lancia su di te dall'altra parte della stanza."


translate ita playLaser_dae0ec55:


    you "..."


translate ita playLaser_f57c18d4:


    "Ti ritrovi a fettine prima di poter battere ciglio."


translate ita playLaser_a20cefa7_9:


    "..."


translate ita playLaser_fa28c27c:


    "Finale 12: Sotto Tiro"


translate ita playHideSeek_4bd0d419:


    you "Che ne pensi di nascondino...?"


translate ita playHideSeek_16879ce5:


    cat "Miao?"


translate ita playHideSeek_dae0ec55:


    you "..."


translate ita playHideSeek_7f0ac95c:


    cat "..."


translate ita playHideSeek_501b5875:


    "Non hai idea... di come far funzionare il tutto."


translate ita playHideSeek_2dd47eb6:


    "Può un gatto capire il concetto di un {i}gioco...{/i} {w}anche se semplice come nascondino?"


translate ita playHideSeek_990e7450:


    you "Uhm... Vediamo..."


translate ita playHideSeek_d9b6c5b2:


    "Prendi il gatto e lo fai voltare, andando poi a nasconderti dietro alla poltrona."


translate ita playHideSeek_0b37453e:


    "Hai quasi la certezza che il gatto si sia girato e ti abbia visto nasconderti... {w}un po' confuso, se non altro..."


translate ita playHideSeek_16879ce5_1:


    cat "Miao?"


translate ita playHideSeek_caa03df3:


    "In ogni caso, dopo qualche istante, il gatto sbircia dietro la poltrona con occhi curiosi."


translate ita playHideSeek_bfd68843:


    "Sorridi e lo prendi in braccio, tenendolo di fronte a te."


translate ita playHideSeek_bf4f65f9:


    you "Mi hai trovato! Hai vinto!!!"


translate ita playHideSeek_321f01a1:


    cat "Miao! Miao!" with hpunch


translate ita playHideSeek_3b87374e:


    "Il gatto sembra confuso, ma contento dei complimenti."


translate ita playHideSeek_ef6ad04d:


    "Ora lo metti sulla poltrona in modo che non veda il tuo nascondiglio così facilmente."


translate ita playHideSeek_1f14505c:


    "Corri verso la cucina, nascondendoti dietro il bancone."


translate ita playHideSeek_dd4584c0:


    "Il gatto ci mette un po' di più a trovarti, stavolta."


translate ita playHideSeek_8fa4c58e:


    "Questa volta, quando ti trova, ti spaventa saltandoti in grembo dal ripiano del bancone."


translate ita playHideSeek_fc460430:


    you "Ahh!" with vpunch


translate ita playHideSeek_fbbaa7ef:


    cat "Miao! Miao!" with hpunch


translate ita playHideSeek_5afcd17c:


    you "Mi hai trovato di nuovo!"


translate ita playHideSeek_b003a621:


    cat "Miao!"


translate ita playHideSeek_fc37ae68:


    you "Eheh, ok ok, hai vinto!"


translate ita playHideSeek_044aa542:


    "Quando si avvicina, gli fai dei grattini dietro l'orecchio e sotto il mento per premiarlo."


translate ita playHideSeek_78b6d9cf:


    cat "Purr... Purr..."


translate ita playHideSeek_6e23df72:


    you "Eheh~ Ok, perché non provi tu?"


translate ita playHideSeek_16879ce5_2:


    cat "Miao?"


translate ita playHideSeek_4b3553e2:


    "Vai e ti metti in mezzo al salotto..."


translate ita playHideSeek_ab912efe:


    "... il gatto ti segue."


translate ita playHideSeek_13e57d68:


    "Fai finta di coprirti gli occhi e girarti."


translate ita playHideSeek_3d4baad1:


    you "Okay~"


translate ita playHideSeek_d05e788f:


    you "5... 4... 3... 2... 1... Via!"


translate ita playHideSeek_43176d29:


    "Ti giri e noti che il gatto non c'è."


translate ita playHideSeek_a96ff075:


    you "Uh, di certo impari in fretta..."


translate ita playHideSeek_659c41b9:


    "Non ci sono molti posti nel tuo appartamento dove uno della tua taglia possa nascondersi..."


translate ita playHideSeek_138bf664:


    "... e senza i pollici opponibili per aprire le porte chiuse nel corridoio, anche il gatto ha i suoi limiti."


translate ita playHideSeek_46edf521:


    "Si gioca alla pari."


translate ita playHideSeek_e97341d6:


    you "Okay, dove posso cercare~"


translate ita seekLivingRoom_b174d0b4:


    "Guardi dietro il divano e la poltrona... {w}Poi sotto il tavolino..."


translate ita seekLivingRoom_a20cefa7:


    "..."


translate ita seekLivingRoom_3f311f83:


    "Niente. Dopotutto, il soggiorno è piuttosto scarno per quanto riguarda l'arredamento."


translate ita seekKitchen_8e951d9b:


    "Sbirci dietro il bancone... {w}Prendi una sedia e controlli in cima al frigo..."


translate ita seekKitchen_b35ddd37:


    "Apri anche gli armadietti lungo il pavimento, nel caso sia riuscito a infilarcisi dentro..."


translate ita seekKitchen_a20cefa7:


    "..."


translate ita seekKitchen_67b7b559:


    "Niente. Pensi sia meglio così, in fondo."


translate ita seekKitchen_6e50a758:


    "La cucina si usa per cucinare, non per giocare."


translate ita seekHallway_7248db28:


    "Sbirci dietro l'angolo del corridoio..."


translate ita seekHallway_a20cefa7:


    ".."


translate ita seekHallway_a20cefa7_1:


    "..."


translate ita seekHallway_4e973a05:


    "Non c'è. Che ti aspettavi?"


translate ita seekHallway_957bcdee:


    "Con tutte le porte chiuse..."


translate ita seekHallway_148b7481:


    "Il gatto non può certo nascondersi qui."


translate ita seekingDone_2b449ce4:


    "Non riesci a trovare il gatto da nessuna parte..."


translate ita seekingDone_e2a5632e:


    "Inizi a preoccuparti un po' quando senti un leggero suono provenire dal... corridoio...?"


translate ita seekingDone_dc5e6416:


    "Ti dirigi verso il corridoio e ascolti ancora."


translate ita seekingDone_8dabefc6:


    ".."


translate ita seekingDone_a20cefa7:


    "..."


translate ita seekingDone_d5aac1e5:


    "{size=-5}*scratch* *scratch*{/size}"


translate ita seekingDone_90425976:


    "Sembrava provenire dalla... tua camera... ma..."


translate ita seekingDone_4902eb0a:


    "Procedi lungo il corridoio verso la tua camera e apri la porta con cautela-"


translate ita seekingDone_ec1974d4:


    cat "Miao!" with hpunch


translate ita seekingDone_e74ed2e1:


    you "Gasp!" with vpunch


translate ita seekingDone_a479bdf3:


    "Il gatto sbuca fuori e corre attorno alle tue gambe, miagolando insistentemente."


translate ita seekingDone_5e84b463:


    cat "Miao! Miao!"


translate ita seekingDone_5e30cc7e:


    "Sembra... {w}in qualche modo deluso? {w}Forse dalle tue capacità di ricerca apparentemente mediocri..."


translate ita seekingDone_bf0874e3:


    "Ma..."


translate ita seekingDone_edd5757f:


    "Prendi il gatto in braccio e guardi la porta della camera."


translate ita seekingDone_ba8a4d17:


    you "Come sei... entrato nella mia stanza?"


translate ita seekingDone_e5fab8a0:


    cat "Miao!"


translate ita seekingDone_dae0ec55:


    you "..."


translate ita seekingDone_93d1adf7:


    "Tu... {w}Tu {i}sai{/i} che la porta era chiusa."


translate ita seekingDone_31c44218:


    "{size=-5}Giusto...?{/size}"


translate ita seekingDone_be5113cc:


    "Il gatto si divincola e corre fuori dal corridoio."


translate ita seekingDone_dae0ec55_1:


    you "..."


translate ita seekingDone_c00c8735:


    "Lo segui e lo vedi seduto in mezzo al salotto."


translate ita seekingDone_e5fab8a0_1:


    cat "Miao!"


translate ita seekingDone_e131e1c8:


    "Appena ti vede, il gatto si gira subito."


translate ita seekingDone_63775626:


    "Forse vuole cercarti lui adesso?"


translate ita seekingDone_cc17d7e1:


    "Stai pensando se nasconderti di nuovo dietro al bancone quando-"


translate ita seekingDone_28b3ac41:


    you "!!!"


translate ita seekingDone_0cea138b:


    "Le luci... È saltata la corrente?"


translate ita seekingDone_1a77e248:


    you "Cavolo..."


translate ita seekingDone_5c8a1500:


    "Mentre aspetti che i tuoi occhi si abituino all'oscurità..."


translate ita seekingDone_88a23747:


    "... ti accorgi che il gatto non si è mosso di un millimetro."


translate ita seekingDone_3bb63b1d:


    "Era spaventato?"


translate ita seekingDone_60b30750:


    you "Ehi, hai-"


translate ita seekingDone_b48bd826:


    "*Tu-tump* *Tu-tump* *Tu-tump*"


translate ita seekingDone_40d9ca73:


    "...?"


translate ita seekingDone_67aaa788:


    "Cosa?"


translate ita seekingDone_8e3bedbd:


    "Per qualche motivo..."


translate ita seekingDone_ecdba21d:


    "... il tuo cuore inizia a battere più in fretta."


translate ita seekingDone_0f5de544:


    "Tu..."


translate ita seekingDone_ae699357:


    "Pensi di andare dal gatto..."


translate ita seekingDone_26358dc1:


    "Ma quando lo fai..."


translate ita seekingDone_bcc0f247:


    "... quell'idea ti fa sentire..."


translate ita seekingDone_84220bdf:


    you ".."


translate ita seekingDone_dae0ec55_2:


    you "..."


translate ita seekingDone_796928f5:


    "... come se la tua vita fosse in pericolo."


translate ita seekingDone_8dabefc6_1:


    ".."


translate ita seekingDone_a20cefa7_1:


    "..."


translate ita seekingDone_c73db94c:


    "Devi nasconderti."


translate ita seekingDone_e42d7264:


    "{b}Ora.{/b}"


translate ita time_out_a20cefa7:


    "..."


translate ita time_out_ff2c9b51:


    "Hai fallito."


translate ita time_out_a20cefa7_1:


    "..."


translate ita time_out_d4b5152a:


    "Provi di nuovo?"


translate ita hidingArmchair_dfc43610:


    "No, è troppo vicino. Ti troverebbe subito."


translate ita hidingKitchen_9e1fc511:


    "Hai già provato quel nascondiglio e ti ha trovato quasi subito. Non funzionerà."


translate ita hidingHall_6093fc0a:


    "Forse... nel corridoio?"


translate ita hidingHall_3fe08047:


    "{size=-5}{b}Non c'è un posto dove {i}nascondersi{/i} nel corridoio.{/b}{/size}"


translate ita hidingHallCloset_35447e61:


    "Ti infili silenziosamente nell'armadio del corridoio..."


translate ita hidingHallCloset_a20cefa7:


    "..."


translate ita hidingHallCloset_632d1a35:


    you "!!!" with hpunch


translate ita hidingHallCloset_3d6395df:


    "Quando entri, la porta non si chiude perché una scatola pesante la sta bloccando."


translate ita hidingHallCloset_50bac2df:


    "Se provassi a spostarla, il gatto la sentirebbe."


translate ita hidingHallCloset_19a963ab:


    "Sempre che non ti abbia già sentito."


translate ita hidingHallCloset_a067a470:


    "Non funzionerà. Devi nasconderti da un'altra parte."


translate ita hidingHallCloset_0c125b36:


    "Sbrigati!"


translate ita hidingBathroom_ee79f861:


    "Corri di soppiatto verso il bagno e-"


translate ita hidingBathroom_823cbce9:


    "*clink!* *clink!* *clink!*" with hpunch


translate ita hidingBathroom_24bdca17:


    you "{i}Cosa?!? Perché la porta è {b}chiusa?!?{/b}{/i}"


translate ita hidingBathroom_96a60aa2:


    "Ti blocchi dopo aver realizzato quanto rumore hai appena fatto cercando di entrare e trattieni il fiato."


translate ita hidingBathroom_5650ad03:


    "Ascolti..."


translate ita hidingBathroom_dae0ec55:


    you "..."


translate ita hidingBathroom_1e37664c:


    "Il silenzio che proviene dal salotto sembra più pesante di prima. Più irrequieto. "


translate ita hidingBathroom_0df09957:


    "Anche se ora la porta si aprisse per miracolo, lui saprebbe esattamente dove sei. Non va bene."


translate ita hidingBedroom_1ff5c45d:


    "Corri in silenzio in camera, chiudendo con cautela la porta dietro di te."


translate ita hidingBedroom_8fc59726:


    "L'unico posto dove nascondersi in camera è l'armadio."


translate ita hideAndSeekEnd_7a6998e3:


    "Chiudi la porta a chiave il più silenziosamente possibile prima di nasconderti nell'armadio."


translate ita hideAndSeekEnd_04f7409b:


    "Non appena hai chiuso le ante dell'armadio..."


translate ita hideAndSeekEnd_2aeed70c:


    "... senti all'improvviso che l'appartamento è cambiato."


translate ita hideAndSeekEnd_7dfa20bb:


    "Come se qualcosa sentisse che è giunto il momento..."


translate ita hideAndSeekEnd_8d5830fc:


    "Come se sentisse..."


translate ita hideAndSeekEnd_18e07b28:


    "... che la caccia è iniziata."


translate ita hideAndSeekEnd_c4340c4a:


    "Un brivido orribile ti scorre lungo la schiena appena realizzi cosa è diventato questo gioco."


translate ita hideAndSeekEnd_dec1d69c:


    "Non è più un semplice nascondino."


translate ita hideAndSeekEnd_db025406:


    "Questo è essere {i}cacciati{/i} da un predatore... e tu sei la preda."


translate ita hideAndSeekEnd_90116c90:


    "Non..."


translate ita hideAndSeekEnd_008b199b:


    "{size=-10}Non importava davvero quale sarebbe stato il nascondiglio, giusto?{/size}"


translate ita hideAndSeekEnd_e993f131:


    "{size=+15}*BAM!!!*{/size}" with hpunch


translate ita hideAndSeekEnd_8ca8510a:


    you "!!!" with vpunch


translate ita hideAndSeekEnd_006cf29b:


    "Come in risposta alla tua domanda, senti sbattere forte sulla porta della camera."


translate ita hideAndSeekEnd_1d63d4b0:


    "Riesci {i}a stento{/i} a non urlare quando senti quel rumore."


translate ita hideAndSeekEnd_3523c074:


    "{size=+20}*BAM!!! BAM!!!*{/size}" with hpunch


translate ita hideAndSeekEnd_981dfd0d:


    "Il tuo battito aumenta di nuovo, rendendoti difficile respirare in silenzio. O respirare in generale..."


translate ita hideAndSeekEnd_f29fbbed:


    "{size=+25}*BAM!!! BAM!!! BAM!!!*{/size}" with hpunch


translate ita hideAndSeekEnd_4331beee:


    "Ti si riempiono gli occhi di lacrime mentre ti copri la bocca con mani tremanti."


translate ita hideAndSeekEnd_bc2b365b:


    "Lui sa."


translate ita hideAndSeekEnd_aa5ace4f:


    "Lui {i}{b}sa{/b}{/i}."


translate ita hideAndSeekEnd_7507be91:


    "Piangendo con le mani sulla bocca, provando a soffocare i suoni strozzati che emetti..."


translate ita hideAndSeekEnd_30c5f04c:


    "... scivoli lungo il muro in fondo all'armadio e ti accasci sul pavimento."


translate ita hideAndSeekEnd_a785ec8d:


    "{size=+30}*BAM!!! BAM!!! BAM!!! BAM!!! BAM!!! BAM!!! BAM!!!*{/size}" with vpunch


translate ita hideAndSeekEnd_64e5c3aa:


    "{size=+35}{i}{b}*CRACK!!! CRASH!!!*{/b}{/i}{/size}" with hpunch


translate ita hideAndSeekEnd_510fa47c:


    "Sussulti bruscamente al rumore della porta che viene scardinata... {w}seguito da un forte schianto contro il muro dall'altra parte della stanza..."


translate ita hideAndSeekEnd_d11501ae:


    "Come se la porta fosse stata {b}spazzata{/b} via..."


translate ita hideAndSeekEnd_8dabefc6:


    ".."


translate ita hideAndSeekEnd_a20cefa7:


    "..."


translate ita hideAndSeekEnd_0adc35ae:


    "Il silenzio che segue... è quasi troppo da sopportare."


translate ita hideAndSeekEnd_40c73218:


    "Non... Non riesci..."


translate ita hideAndSeekEnd_a822f67c:


    you "{size=-8}*sob*{/size}" with vpunch


translate ita hideAndSeekEnd_48cca663:


    "Un unico singhiozzo di sfugge dal naso."


translate ita hideAndSeekEnd_a20cefa7_1:


    "..."


translate ita hideAndSeekEnd_a56b7772:


    "Il rumore che hai fatto echeggia nel silenzio della stanza. Chiudi gli occhi per la sconfitta."


translate ita hideAndSeekEnd_944d62b1:


    "Non ha più molto senso continuare a nascondersi, giusto?"


translate ita hideAndSeekEnd_54d98921:


    "Istintivamente, con l'energia che ti è rimasta cerchi di captare un rumore di passi..."


translate ita hideAndSeekEnd_f054e4f2:


    "... anche se ti estranei emotivamente."


translate ita hideAndSeekEnd_ba5567da:


    "Ma non senti nulla."


translate ita hideAndSeekEnd_97d7e1ff:


    "... Nulla."


translate ita hideAndSeekEnd_b1eedee3:


    "... {w}... Nulla."


translate ita hideAndSeekEnd_f64ee9d8:


    "Poi..."


translate ita hideAndSeekEnd_a20cefa7_2:


    "..."


translate ita hideAndSeekEnd_1ae26af9:


    "{size=-10}*Sssssssst*{/size}"


translate ita hideAndSeekEnd_56ebb028:


    you "!!!"


translate ita hideAndSeekEnd_973413d4:


    "Qualcosa..."


translate ita hideAndSeekEnd_cc2670ce:


    "... spalanca le ante dell'armadio."


translate ita hideAndSeekEnd_d3ef84de:


    "Adesso sei in posizione raggomitolata."


translate ita hideAndSeekEnd_37dac42d:


    "Ginocchia su... {w}Schiena ricurva... {w}Testa bassa... {w}Bocca coperta... {w}Occhi chiusi, così forte da farti male."


translate ita hideAndSeekEnd_169ad8da:


    "Non vuoi guardare."


translate ita hideAndSeekEnd_9be26059:


    "Non vuoi {i}{b}guardare{/b}{/i}."


translate ita hideAndSeekEnd_9288147d:


    "Ma è quello che ti aspetta."


translate ita hideAndSeekEnd_b4897419:


    "Non ti finirà senza quest'ultimo atto di crudeltà."


translate ita hideAndSeekEnd_38e8ce5b:


    "Costringerti a {b}guardare{/b} prima di toglierti la vita."


translate ita hideAndSeekEnd_f6781194:


    "É... {i}così{/i} crudele."


translate ita hideAndSeekEnd_3964a50d:


    "Vuoi solo che finisca..."


translate ita hideAndSeekEnd_42b896f8:


    "Quindi..."


translate ita hideAndSeekEnd_8dabefc6_1:


    ".."


translate ita hideAndSeekEnd_a20cefa7_3:


    "..."


translate ita hideAndSeekEnd_07ae2bce:


    "... apri gli occhi."


translate ita hideAndSeekEnd_05f9ce7c:


    "Vedi... {w}{i}qualcosa...{/i} {w}che ti fissa dall'oscurità oltre le ante dell'armadio."


translate ita hideAndSeekEnd_532712c0:


    "Sembra..."


translate ita hideAndSeekEnd_a20cefa7_4:


    "..."


translate ita hideAndSeekEnd_c5599256:


    "... deluso."


translate ita hideAndSeekEnd_e501a69b:


    "Un attimo prima di esalare l'ultimo respiro, ti viene quasi voglia di scusarti per essere una preda così indegna."


translate ita hideAndSeekEnd_fdce8679:


    "Evidentemente, la tua capacità di nasconderti è tanto scadente quanto quella di ricerca."


translate ita hideAndSeekEnd_8dabefc6_2:


    ".."


translate ita hideAndSeekEnd_a20cefa7_5:


    "..."


translate ita hideAndSeekEnd_bebf47e2:


    "Finale 13: Preda Deludente"


translate ita hidingGetOut_d6bdd900:


    "Sei a metà strada dalla porta d'ingresso quando-{w=0.75}{nw}"


translate ita hidingGetOut_8ca8510a:


    you "!!!" with vpunch


translate ita hidingGetOut_dec8c6c7:


    "Guardi la porta e vedi che ci sono molte più serrature di quante {i}pensavi{/i} di averne."


translate ita hidingGetOut_3df65a5c:


    "Dai un'occhiata al gatto. Non ti sta guardando, ma..."


translate ita hidingGetOut_5b6ca7ca:


    "... ti senti praticamente travolgere dalla sua ondata di delusione."


translate ita hidingGetOut_298892a1:


    "Sembra quasi..."


translate ita hidingGetOut_050be7e5:


    "... un avvertimento."


translate ita hidingGetOut_dae0ec55:


    you "..."


translate ita hidingGetOut_b0ee1743:


    "Ti alloni dalla porta e quella sensazione si attenua lentamente, lasciandoti respirare di nuovo."


translate ita hidingGetOut_d9de9905:


    "Non c'è via d'uscita, allora."


translate ita hidingGetOut_c73db94c:


    "Devi nasconderti."


translate ita hidingSitOnCouch_a20cefa7:


    "..."


translate ita hidingSitOnCouch_e26ed14e:


    "Stiamo scherzando?"


translate ita hidingSitOnCouch_85ef84c7:


    "Senti che il gatto non gradirà il tuo poco impegno, ma ad ogni modo..."


translate ita hidingSitOnCouch_aa165348:


    "{size=-8}... col {b}cavolo{/b} che ti avvicinerai di più a lui.{/size}"


translate ita hidingSitOnCouch_8d4b014b:


    "Smettila di perdere tempo e trova un nascondiglio."


translate ita cleanCat_1f0122ea:


    "Guardandolo meglio..."


translate ita cleanCat_73bbf6e8:


    "... ti accorgi che il gatto non è esattamente pulito."


translate ita cleanCat_2dad982f:


    "Non c'è da stupirsi, prima che lo portassi a casa viveva in una vecchia scatola sporca..."


translate ita cleanCat_3e60fb93:


    "... dentro un vicolo pieno di spazzatura... {w}e per chissà quanto tempo..."


translate ita cleanCat_b2b50516:


    "Hai sentito dire che i gatti sanno tenersi puliti..."


translate ita cleanCat_8a02a14f:


    "... ma potrebbe essere l'occasione giusta per un aiutino, no?"


translate ita cleanCat_e97a3dc8:


    "Vai in bagno e prepari tutto, cercando di ricordare come si lava un gatto."


translate ita cleanCat_e263c12b:


    "Non hai esperienza in merito, ma credi che il modo migliore di pulire un gatto sia farlo..."


translate ita cleanQuick_78d7a181:


    "Ai gatti non piace l'acqua, da quanto ne sai..."


translate ita cleanQuick_4e407771:


    "Quindi un bagno veloce sarebbe il modo migliore, giusto?"


translate ita cleanQuick_7f064cd9:


    "Decidi di fare tutto in una volta, riempiendo la vasca con acqua calda e sapone."


translate ita cleanQuick_c39a4c6e:


    "Lo immergi velocemente, gli dai una strofinatina, lo risciacqui e lo asciughi."


translate ita cleanQuick_9e8e5dea:


    "Sarà tutto finito prima che il gatto se ne accorga."


translate ita cleanQuick_71d98443:


    "Apri la porta e schiocchi la lingua, invitando il gatto a entrare."


translate ita cleanQuick_85ffbc84:


    "Lui si precipita dentro la stanza, incuriosito da questo nuovo scenario."


translate ita cleanQuick_03c62019:


    "Chiudi la porta in modo che non possa scappare e mettere a soqquadro l'appartamento..."


translate ita cleanQuick_9f0ef82a:


    "Facendoti coraggio, ti rimbocchi le maniche."


translate ita cleanQuick_f62bf066:


    "Sollevi il gatto e lo porti nella vasca."


translate ita cleanQuick_4b2a2198:


    "Il tuo piano è già compromesso, il gatto inizia a dimenarsi dalla tua presa."


translate ita cleanQuick_83e9b6c8:


    "Forse avresti dovuto tenerlo in modo che non vedesse l'acqua?"


translate ita cleanQuick_1422090a:


    you "Ouch! Ouch, ehi!"


translate ita cleanQuick_26e1e230:


    "Ti graffia le braccia. {w}Sapevi che non sarebbe stato contento dell'acqua..."


translate ita cleanQuick_5f15c75c:


    "... ma non pensavi sarebbe stato {i}così{/i} adirato."


translate ita cleanQuick_2b5c1bb2:


    "Tuttavia, anche se ti terrà il broncio per un po'... {w}sai che è la cosa migliore."


translate ita cleanQuick_5bf8a6d7:


    "Un brutto graffio al braccio ti fa sussultare..."


translate ita cleanQuick_b7d98ebe:


    "... facendoti cadere il gatto nella vasca."


translate ita cleanQuick_0e4fefa1:


    cat "{size=+10}MIAAOOOO!!!{/size}" with hpunch


translate ita cleanQuick_53f96c50:


    "{size=+20}{b}SPLASH!!!{/b}{/size}" with vpunch


translate ita cleanQuick_4ab5e1b8:


    you "!!! Accidenti! Gattino?!?"


translate ita cleanQuick_a20cefa7:


    "..."


translate ita cleanQuick_9755cc74:


    "Ti aspetti che il gatto riemerga soffiando e miagolando, ma non succede."


translate ita cleanQuick_56ebb028:


    you "!!!"


translate ita cleanQuick_d3c199bb:


    "Ti lanci sulla vasca e immergi le braccia sotto la superficie insaponata, in cerca del gatto."


translate ita cleanQuick_28c52c35:


    "E se sbattesse la testa e perdesse i sensi?!? Annegherebbe!"


translate ita cleanQuick_8dabefc6:


    ".."


translate ita cleanQuick_a20cefa7_1:


    "..."


translate ita cleanQuick_da164869:


    "Ma non riesci a trovarlo."


translate ita cleanQuick_4cb92d86:


    "Invece..."


translate ita cleanQuick_6d15e014:


    you "...?!? Ma che...?"


translate ita cleanQuick_37bc76a0:


    "... l'acqua inizia a scurirsi."


translate ita cleanQuick_bbf488b7:


    "All'inizio pensi sia solo lo sporco del gatto e senti di aver preso la decisione giusta dopotutto, ma..."


translate ita cleanQuick_1cd5e3cc:


    "... l'acqua diventa sempre più scura..."


translate ita cleanQuick_0d858457:


    "... finché non sembra che la vasca sia stata riempita di {i}inchiostro nero{/i}, anziché d'acqua."


translate ita cleanQuick_b024b629:


    "Anche le bolle ormai sembrano fatte di ossidiana lucida..."


translate ita cleanQuick_5d31ed33:


    you "Questo è..."


translate ita cleanQuick_0667ddd5:


    "C'è qualcosa... che non va."


translate ita cleanQuick_28ef0d48:


    "Ma non appena questo pensiero ti sfiora-"


translate ita cleanQuick_c27265ab:


    "!!!" with vpunch


translate ita cleanQuick_8825e5a8:


    you "E-Ehii!"


translate ita cleanQuick_8dabefc6_1:


    ".."


translate ita cleanQuick_a20cefa7_2:


    "..."


translate ita cleanQuick_f51b5d50:


    "C'è..."


translate ita cleanQuick_2703b498:


    "C'è qualcosa che ti sta tirando da sotto la superficie."


translate ita cleanQuick_04ac177f:


    "Cerchi di allontanarti... ma il braccio non si muove."


translate ita cleanQuick_1e1011d4:


    "Qualunque cosa sia, ti trascina verso l'acqua."


translate ita cleanQuick_ea4d65f2:


    "Provi a togliere il tappo dello scarico con l'altra mano..."


translate ita cleanQuick_49f8d758:


    "... ma quando la immergi d'istinto nell'acqua..."


translate ita cleanQuick_af07684a:


    "... anche quella viene {i}catturata.{/i}"


translate ita cleanQuick_7bc9d3d3:


    "Con entrambe le mani bloccate, non riesci a fare leva per liberarti."


translate ita cleanQuick_9b4985ab:


    you "A-AIU-"


translate ita cleanQuick_959e6733:


    "{size=+30}{b}{i}SPLASH!!!{/i}{/b}{/size}" with vpunch


translate ita cleanQuick_8dabefc6_2:


    ".."


translate ita cleanQuick_a20cefa7_3:


    "..."


translate ita cleanQuick_9920ee06:


    "Finisci nelle acque torbide della vasca."


translate ita cleanQuick_d4cb78f0:


    "Vai sempre più giù..."


translate ita cleanQuick_803774b5:


    "E giù..."


translate ita cleanQuick_292fd1e4:


    "E ancora più giù..."


translate ita cleanQuick_effa8a23:


    "Molto più giù di quanto sia possibile nella tua vasca da bagno..."


translate ita cleanQuick_0f5de544:


    "Tu..."


translate ita cleanQuick_89ffaa13:


    "Non riesci a respirare."


translate ita cleanQuick_6ff0ecd8:


    "Non riesci a vedere nulla..."


translate ita cleanQuick_c4107513:


    "... ma quando esali l'ultimo respiro..."


translate ita cleanQuick_19e72cc3:


    "... ti sembra di intravedere la cosa che ti sta trascinando giù."


translate ita cleanQuick_3be28426:


    "Un essere che riposa nelle profondità più recondite..."


translate ita cleanQuick_117208a3:


    "Qualcosa che sta aspettando..."


translate ita cleanQuick_a20cefa7_4:


    "..."


translate ita cleanQuick_3c2769fc:


    "... proprio {i}te.{/i}"


translate ita cleanQuick_a20cefa7_5:


    "..."


translate ita cleanQuick_e75202ef:


    "Finale 14: Odio Fare il Bagno"


translate ita cleanCareful_76034b76:


    "Preferisci procedere con cautela."


translate ita cleanCareful_753310b5:


    "I gatti non sempre amano l'acqua, quindi dubiti che possa apprezzare un bagno vero e proprio."


translate ita cleanCareful_1e17f067:


    "Quindi prendi il gatto e lo metti delicatamente nel lavandino, prima di aprire l'acqua."


translate ita cleanCareful_ec1974d4:


    cat "Miao!" with hpunch


translate ita cleanCareful_0e8202cd:


    "Il gatto è agitato ma alla fine..."


translate ita cleanCareful_0a111937:


    "... non cerca di scappare!"


translate ita cleanCareful_52edc0ce:


    "Bene."


translate ita cleanCareful_8897c5e8:


    "Ti insaponi le mani e, con attenzione, strofini e massaggi il gatto dappertutto."


translate ita cleanCareful_f506c017:


    "Dopo qualche minuto, lo risciacqui bene, lo avvolgi in una coperta e lo asciughi."


translate ita cleanCareful_0d9cd6eb:


    "Poi prendi una spazzola e la passi delicatamente sul suo pelo."


translate ita cleanCareful_57f9ada2:


    cat "Purr... Purr... Purrr..."


translate ita cleanCareful_1d903d7d:


    "Mentre lo spazzoli sembra che il gatto si senta in paradiso."


translate ita cleanCareful_079980a1:


    "Alcuni peli ti restano attaccati, ma non ti... dispiace..."


translate ita cleanCareful_40d9ca73:


    "...?"


translate ita cleanCareful_c3f6a165:


    "In realtà..."


translate ita cleanCareful_c94a020a:


    "... {i}molti{/i} peli ti si attaccano addosso."


translate ita cleanCareful_65471dfb:


    "Provi a toglierli ma non ci riesci."


translate ita cleanCareful_5b936bac:


    "A quanto pare il prossimo bagno toccherà a te..."


translate ita cleanCareful_085f82bc:


    cat "Miao..."


translate ita cleanCareful_dae0ec55:


    you "..."


translate ita cleanCareful_da765a9f:


    "Cerchi di finire in fretta con il gatto, ignorando i peli, ma quelli non smettono di attaccarsi."


translate ita cleanCareful_ffccba96:


    "Alle mani, alle braccia..."


translate ita cleanCareful_711ff096:


    "D'un tratto, ti ritrovi sotto un manto di peli che non accenna a staccarsi."


translate ita cleanCareful_52386fff:


    "È abbastanza spesso da provare a strapparlo via ma-"


translate ita cleanCareful_c4b43d4e:


    you "Ouch! Cosa...?"


translate ita cleanCareful_22aea2b6:


    "Senti un dolore lancinante dove hai tirato."


translate ita cleanCareful_8ca8510a:


    you "!!!" with vpunch


translate ita cleanCareful_197758f7:


    "Osservi più attentamente e... {w}vedi che i peli stanno..."


translate ita cleanCareful_68e96464:


    "... {i}crescendo{/i}..."


translate ita cleanCareful_a20cefa7:


    "..."


translate ita cleanCareful_80ea14b2:


    "{size=-5}{b}... crescendo {i}su{/i} di te.{/b}{/size}"


translate ita cleanCareful_01e37002:


    you "Ah... Ah...!"


translate ita cleanCareful_1ce5a910:


    "Puoi effettivamente {b}sentirli{/b} adesso."


translate ita cleanCareful_b86f7ef8:


    "Peli che {i}crescono{/i} sulla schiena, sul collo..."


translate ita cleanCareful_12fc6531:


    "sulla faccia..."


translate ita cleanCareful_f9ae2b18:


    "sugli occhi..."


translate ita cleanCareful_3489b447:


    "sulla lingua..."


translate ita cleanCareful_eeaf3b6e:


    "Crescono persino dentro la {i}gola-{/i}"


translate ita cleanCareful_06b758f9:


    you "*Gasp!* *Coff!* *Coff!*" with vpunch


translate ita cleanCareful_8dabefc6:


    ".."


translate ita cleanCareful_a20cefa7_1:


    "..."


translate ita cleanCareful_1d671d77:


    "Ti accasci e inizi a soffocare a causa del pelo sempre più folto nel tuo esofago..."


translate ita cleanCareful_dae75121:


    "... il gatto si avvicina per leccare il pelo che ti cresce sulla fronte..."


translate ita cleanCareful_cb7d4fad:


    "... curandolo con la stessa attenzione che hai avuto prima con lui."


translate ita cleanCareful_b53c4107:


    cat "Purr... Purrr..."


translate ita cleanCareful_96b21532:


    "Sarebbe perfino tenero... {w}se non stessi soffocando."


translate ita cleanCareful_ba1d39d4:


    "Però..."


translate ita cleanCareful_ebb0a00f:


    "È bello... {w}essere accuditi e assistiti in qualche modo."


translate ita cleanCareful_c9790759:


    "Anche se solo per un po' di tempo."


translate ita cleanCareful_4d45e938:


    "La toelettatura attenta del gatto è l'ultima cosa che senti..."


translate ita cleanCareful_a20cefa7_2:


    "..."


translate ita cleanCareful_2ed36266:


    "... prima di esalare l'ultimo respiro."


translate ita cleanCareful_a20cefa7_3:


    "..."


translate ita cleanCareful_dc678fac:


    "Finale 15: A-mici di Toelettatura"

translate ita strings:


    old "Do something alone."
    new "Fai qualcosa per conto tuo"


    old "Do something with cat."
    new "Fai qualcosa con il gatto"


    old "Clean apartment"
    new "Pulisci l'appartamento"


    old "Watch a movie"
    new "Guarda un film"


    old "Take a nap"
    new "Fai un riposino"


    old "On second thought..."
    new "Ripensandoci..."


    old "Pet cat"
    new "Accarezza il gatto"


    old "Feed cat"
    new "Nutri il gatto"


    old "Play with cat"
    new "Gioca con il gatto"


    old "Clean cat"
    new "Pulisci il gatto"


    old "Keep cleaning"
    new "Continua a pulire"


    old "Catch cat in the act"
    new "Cogli il gatto in flagrante"


    old "Sit on the floor."
    new "Siediti sul pavimento"


    old "Reclaim your throne."
    new "Reclama il tuo trono"


    old "You saw something."
    new "Hai visto qualcosa"


    old "You {i}definitely{/i} saw something"
    new "Hai {i}di sicuro{/i} visto qualcosa"


    old "Move the cat."
    new "Sposta il gatto"


    old "Sleep next to cat"
    new "Dormi di fianco al gatto"


    old "Do something else"
    new "Fai qualcos'altro"


    old "Move the cat?"
    new "Sposti il gatto?"


    old "Keep trying. This is {i}your{/i} bed."
    new "Riprova. Questo è il {i}tuo{/i} letto"


    old "Again. You WILL sleep in your own bed."
    new "Di nuovo. DORMIRAI nel tuo letto"


    old "I don't know. It sounds mad..."
    new "Non lo so. Sembra folle..."


    old "{size=-5}Move the cat?{/size}"
    new "{size=-5}Sposti il gatto?{/size}"


    old "Move. The. Cat."
    new "Sposta. Il. Gatto."


    old "Seriously last chance. You {i}really{/i} want to do this?"
    new "È l'ultima possibilità. Vuoi farlo {i}davvero{/i}?"


    old "Keep petting"
    new "Continua ad accarezzare"


    old "Let's do something else..."
    new "Facciamo qualcos'altro..."


    old "Keep petting..."
    new "Continua ad accarezzare..."


    old "That's enough. Let's do something else."
    new "Basta. Facciamo qualcos'altro"


    old "...{i}Keep{/i} petting."
    new "...{i}Continua{/i} ad accarezzare"


    old "{b}Seriously...{/b} Let's do something else."
    new "{b}Davvero...{/b} Facciamo qualcos'altro"


    old "Tuna"
    new "Tonno"


    old "Meatloaf"
    new "Polpettone"


    old "Mystery food"
    new "Cibo misterioso"


    old "Actually, let's eat later."
    new "Sai che c'è? Mangiamo più tardi"


    old "Let's play with the cat!"
    new "Gioca con il gatto!"


    old "Look for some yarn?"
    new "Cerchi del filo?"


    old "I think my laser pointer still works..."
    new "Credo che il mio puntatore laser vada ancora..."


    old "Hide and seek: A classic!"
    new "Nascondino: Un classico!"


    old "Living Room"
    new "Salotto"


    old "Kitchen"
    new "Cucina"


    old "Hallway"
    new "Corridoio"


    old "Hide behind the armchair."
    new "Nasconditi dietro la poltrona"


    old "Hide behind kitchen counter."
    new "Nasconditi dietro il bancone della cucina"


    old "Hide in the hall."
    new "Nasconditi in corridoio"


    old "Hide in the hallway closet."
    new "Nasconditi nell'armadio del corridoio"


    old "Hide in the bathroom."
    new "Nasconditi in bagno"


    old "Hide in your bedroom..."
    new "Nasconditi in camera..."


    old "Get out of the apartment."
    new "Esci dall'appartamento"


    old "Sit on the couch."
    new "Siediti sul divano"


    old "Hide in the closet."
    new "Nasconditi nell'armadio"


    old "Risk another hiding spot."
    new "Cerca un altro nascondiglio"


    old "Quickly"
    new "Velocemente"


    old "Carefully"
    new "Delicatamente"

    old "Yes"
    new "Sì"

    old "No"
    new "No"

    old "Don't look behind you..."
    new "Non guardarti alle spalle..."

    old "{alpha=0.2}How disappointing...{/alpha}"
    new "{alpha=0.2}Che delusione...{/alpha}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
