## == Web Port Build (auto-patched) ==
## Run: renpy.sh launcher web_build <this_folder>



translate ita strings:


    old "Do NOT Take This Cat Home"
    new "NON Portare Questo Gatto a Casa"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
