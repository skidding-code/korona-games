


translate ita theirLove1_9ea2f78c:


    " "


translate ita theirLove1_9ea2f78c_1:


    " "


translate ita theirLove1_9ea2f78c_2:


    " "


translate ita theirLove1_9ea2f78c_3:


    " "


translate ita theirLove1_9ea2f78c_4:


    " "


translate ita theirLove1_9ea2f78c_5:


    " "


translate ita theirLove1_9ea2f78c_6:


    " "


translate ita theirLove1_9ea2f78c_7:


    " "


translate ita theirLove1_9ea2f78c_8:


    " "


translate ita theirLove1_9ea2f78c_9:


    " "


translate ita theirLove1_9ea2f78c_10:


    " "


translate ita theirLove1_9ea2f78c_11:


    " "


translate ita theirLove1_9ea2f78c_12:


    " "


translate ita theirLove1_9ea2f78c_13:


    " "


translate ita theirLove1_9ea2f78c_14:


    " "


translate ita theirLove1_9ea2f78c_15:


    " "


translate ita theirLove1_9ea2f78c_16:


    " "


translate ita theirLove1_9ea2f78c_17:


    " "


translate ita theirLove1_9ea2f78c_18:


    " "


translate ita theirLove1_9ea2f78c_19:


    " "


translate ita theirLove2_9ea2f78c:


    " "


translate ita theirLove2_9ea2f78c_1:


    " "


translate ita theirLove2_9ea2f78c_2:


    " "


translate ita theirLove2_9ea2f78c_3:


    " "


translate ita theirLove2_9ea2f78c_4:


    " "


translate ita theirLove2_9ea2f78c_5:


    " "


translate ita theirLove2_9ea2f78c_6:


    " "


translate ita theirLove2_9ea2f78c_7:


    " "


translate ita theirLove2_9ea2f78c_8:


    " "


translate ita theirLove2_9ea2f78c_9:


    " "


translate ita theirLove2_9ea2f78c_10:


    " "


translate ita theirLove2_9ea2f78c_11:


    " "


translate ita theirLove2_9ea2f78c_12:


    " "


translate ita theirLove2_9ea2f78c_13:


    " "


translate ita theirLove2_9ea2f78c_14:


    " "


translate ita theirLove2_9ea2f78c_15:


    " "


translate ita theirLove2_9ea2f78c_16:


    " "


translate ita theirLove2_9ea2f78c_17:


    " "


translate ita theirLove2_9ea2f78c_18:


    " "


translate ita theirLove2_9ea2f78c_19:


    " "


translate ita theirLove2_9ea2f78c_20:


    " "


translate ita theirLove2_9ea2f78c_21:


    " "


translate ita theirLove2_9ea2f78c_22:


    " "


translate ita theirLove3_9ea2f78c:


    " "


translate ita theirLove3_9ea2f78c_1:


    " "


translate ita theirLove3_9ea2f78c_2:


    " "


translate ita theirLove3_9ea2f78c_3:


    " "


translate ita theirLove3_9ea2f78c_4:


    " "


translate ita theirLove3_9ea2f78c_5:


    " "


translate ita theirLove3_9ea2f78c_6:


    " "


translate ita theirLove3_9ea2f78c_7:


    " "


translate ita theirLove3_9ea2f78c_8:


    " "


translate ita theirLove3_9ea2f78c_9:


    " "


translate ita theirLove3_9ea2f78c_10:


    " "


translate ita theirLove3_9ea2f78c_11:


    " "


translate ita theirLove3_9ea2f78c_12:


    " "


translate ita theirLove3_9ea2f78c_13:


    " "


translate ita theirLove3_9ea2f78c_14:


    " "


translate ita theirLove3_9ea2f78c_15:


    " "


translate ita theirLove3_9ea2f78c_16:


    " "


translate ita theirLove3_9ea2f78c_17:


    " "


translate ita theirLove3_9ea2f78c_18:


    " "


translate ita theirLove3_9ea2f78c_19:


    " "

translate ita strings:
    old "I'm sorry..."
    new "Mi dispiace..."

    old "I'm so sorry..."
    new "Mi dispiace davvero..."

    old "I was just so tired...\n\nOf everything..."
    new "Ero veramente a pezzi...\n\nPer tutto..."

    old "Not you... Never you..."
    new "Non per te... Mai per te..."

    old "But I couldn't be the person you deserve...\n\nCouldn't ever hope to be."
    new "Non ho potuto essere la persona che meritavi...\n\nNon avrei mai potuto esserlo."

    old "You were so amazing...\n\nSmart and talented and independent...\n\n\nYou shined..."
    new "Tu eri così eccezionale...\n\nIntelligente, di talento e indipendente...\n\n\nEri brillante..."

    old "But in comparison, I..."
    new "Ma in confronto, io..."

    old "Dammit..."
    new "Accidenti..."

    old "So stupid..."
    new "Ero così idiota..."

    old "So worthless..."
    new "Inutile..."

    old "But when {color=#FF0000}IT{/color} approached me..."
    new "Ma quando {color=#FF0000}IL GATTO{/color} si è avvicinato..."

    old "...{color=#FF0000}IT{/color} didn't tell me that {color=#FF0000}IT{/color} wanted me..."
    new "... {color=#FF0000}LUI{/color} non ha dovuto spiegare quanto {color=#FF0000}LUI{/color} ci tenesse a me..."

    old "...{color=#FF0000}IT{/color} {i}{b}needed{/b}{/i} me."
    new "... {color=#FF0000}LUI{/color} {i}{b}aveva bisogno{/b}{/i} di me."

    old "Maybe that's what I wanted all along."
    new "Forse era questo ciò che avevo sempre voluto."

    old "{i}Wanting{/i} could be so fleeting...\n\nBut to be {i}needed?{/i}"
    new "{i}Desiderare{/i} qualcuno è futile... \n\nEd {i}essere desiderati{/i} allora?"

    old "There was nothing I wouldn't give\n\nto have someone tell me that I mattered to them..."
    new "Avrei fatto di tutto per\n\navere qualcuno a cui importasse di me..."

    old "That {i}they{/i} needed {i}me.{/i}"
    new "{i}Qualcuno{/i} che avesse bisogno di {i}me.{/i}"

    old "In the days leading up to my meeting with {color=#FF0000}IT{/color},\n\nI'd been obsessed with a memory..."
    new "Nei giorni precedenti al mio incontro con {color=#FF0000}LUI{/color},\n\nmi ossessionava un ricordo..."

    old "Someone precious to {i}me{/i}...\n\nhad found someone precious to {i}them{/i}."
    new "Qualcuno di importante per {i}me{/i}...\n\naveva trovato qualcun altro di importante per {i}sé{/i}."

    old "My best friend..."
    new "La persona più cara che avevo..."

    old "My {i}only{/i} friend..."
    new "La mia {i}unica{/i} amicizia..."

    old "I was happy for them, {i}{b}truly{/b}{/i}..."
    new "Ero felice per quella persona, {i}{b}davvero{/b}{/i}..."

    old "...but then I'd been happy for the others too."
    new "... ma in fondo anche per gli altri."

    old "They promised it wouldn't happen to me again..."
    new "Aveva promesso che non sarebbe successo di nuovo..."

    old "That they knew how it felt to be told by someone you cared for...\n\nthat they'd outgrown you and your friendship..."
    new "Perché sapeva cosa si prova nel sentirsi dire da una persona cara...\n\nche non c'è più quel legame d'amicizia..."

    old "That they'd never, ever do such a thing to me..."
    new "E aveva promesso che non mi avrebbe mai e poi mai fatto una cosa simile..."

    old "There's not a moment that passes now\n\nthat I wish I'd risked the pain of their rejection..."
    new "Continuo a pensare\n\nche vorrei aver rischiato il dolore del rifiuto..."

    old "and just...\n\n{b}believed{/b} them..."
    new "e semplicemente...\n\n{b}averci creduto{/b}..."

    old "...But I didn't."
    new "... ma non l'ho fatto."

    old "I pulled away before they could,\n\ntrying to protect my fragile heart..."
    new "Ho fatto un passo indietro prima che potesse ferirmi,\n\nnel tentativo di proteggere il mio fragile cuore..."

    old "But it only hurt all the more."
    new "Ma così fa ancora più male."

    old "Selfish as it was...\n\nI'd wanted them to fight harder to keep me around."
    new "Per quanto sembri egoista...\n\navrei voluto che avesse lottato di più per me."

    old "When {color=#FF0000}IT{/color} appeared before me,\n\n{color=#FF0000}IT{/color} promised to be just {i}that{/i}..."
    new "Quando {color=#FF0000}IL GATTO{/color} è arrivato,\n\n{color=#FF0000}LUI{/color} mi ha promesso proprio {i}questo{/i}..."

    old "A friend that would never, {i}ever{/i} let me go..."
    new "Un amico che non mi avrebbe mai e poi {i}mai{/i} abbandonato..."

    old "A friend that would never, {i}ever{/i} leave me..."
    new "Un amico che non mi avrebbe mai e poi {i}mai{/i} lasciato..."

    old "And all I had to do..."
    new "E tutto ciò che avrei dovuto fare..."

    old "...was promise the same thing in return."
    new "... sarebbe stato promettergli lo stesso in cambio."

    old "I never believed in unconditional love..."
    new "Non ho mai creduto che qualcuno potesse amarmi incondizionatamente..."

    old "...not even as young as I was on the day that changed my life forever."
    new "... neanche quando, da giovane, arrivò il giorno che cambiò la mia vita per sempre."

    old "Still...\n\nI always assumed that {b}{i}they{/i}{/b} would come the closest\n\nto granting it to me."
    new "Eppure...\n\nho sempre pensato che a farlo sarebbe stata{b}{i}la persona{/i}{/b}\n\npiù vicina a me."

    old "It's what they always say, right?"
    new "È ciò che dicono tutti, giusto?"

    old "That a parent's love is unconditional..."
    new "Che l'amore di un genitore è incondizionato..."

    old "The wounds they'd inflicted on my skin and in my heart...\n\nhad long since scarred over the day they dealt the final blow..."
    new "Le ferite che ha inflitto sulla mia pelle e al mio cuore...\n\nerano già cicatrici quando arrivò il giorno dell'ultima batosta..."

    old "And all it took were two little words..."
    new "E bastarono soltanto due piccole parole..."

    old "{alpha=0.2}\"Get out.\"{/alpha}"
    new "{alpha=0.2}\"Vai via.\"{/alpha}"

    old "The day they finally turned their backs on me...\n\n{b}abandoned{/b} me..."
    new "Il giorno in cui mi ha voltato le spalle, in cui...\n\nho conosciuto {b}l'abbandono{/b}..."

    old "That was the day {color=#FF0000}IT{/color} found me."
    new "È stato il giorno in cui la strada del {color=#FF0000}GATTO{/color} e la mia si sono incrociate."

    old "{color=#FF0000}IT{/color} offered me an unfathomable kind of love."
    new "{color=#FF0000}LUI{/color} mi ha offerto un amore incommensurabile."

    old "A love that could be limitless...\n\nEndless...\n\nPowerful...\n\nAll-consuming..."
    new "Un amore sconfinato...\n\nSenza limiti...\n\nPotente...\n\nChe ti consuma..."

    old "A love unmatched..."
    new "Un amore insuperabile..."

    old "A love unlike anything\n\nthat could exist in this world..."
    new "Un amore diverso\n\nda qualsiasi altra cosa al mondo..."

    old "But there was one thing that the love {color=#FF0000}IT{/color} offered could {b}{i}never{/i}{/b} be..."
    new "Ma l'amore che {color=#FF0000}LUI{/color} mi ha offerto non sarebbe {b}{i}mai{/i}{/b} potuto essere..."

    old "...Unconditional."
    new "... incondizionato."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
