


translate ita end_Hint_71219ec6:


    "Cosa fare con un gatto che è stato {i}molto...{/i}"


translate ita end_Hint_8794b742:


    "{i}molto...{/i}"


translate ita end_Hint_ba6b8484:


    "{i}{size=+10}molto...{/size}{/i}"


translate ita end_Hint_7cf748e5:


    "{color=#FF0000}{b}b i r i c h i n o . . . ?{/b}{/color}"


translate ita end_Hint2_8d9f4bf5:


    "Qualcosa che {color=#FF0000}si merita.{/color}"


translate ita end_Hint2_22b30d96:


    "Qualcosa... {w}{color=#FF0000}{b}di definitivo...{/b}{/color}"


translate ita end_Hint3_829c3289:


    "Qualcosa che ha fatto a te per tutto questo tempo."


translate ita end_Hint3_bd62e827:


    "... Ancora e ancora e {i}{b}ancora{/b}{/i}, di continuo."


translate ita end_Hint4_40d9ca73:


    "...?"


translate ita end_Hint4_2ace7158:


    "L'atto di prendersi una vita...?"


translate ita end_Hint4_a3784eb7:


    "{alpha=0.1}uccidilo{/alpha}"


translate ita end_Hint5_a3784eb7:


    "{alpha=0.1}uccidilo{/alpha}"


translate ita end_Hint5_cc680146:


    "{alpha=0.3}uccidilo{/alpha}"


translate ita end_Hint5_e0c70f7b:


    "{alpha=0.5}{size=+5}uccidilo{/size}{/alpha}"


translate ita end_Hint5_f209d4a5:


    "{alpha=0.7}{size=+10}uccidilo{/size}{/alpha}"


translate ita end_Hint5_4190fec2:


    "{size=+20}{color=#FF0000}{b}uccidilo{/b}{/color}{/size}"

translate ita strings:


    old "Hint?"
    new "Un indizio?"


    old "Begin restoration: _ _ _ _  _ _{#2nd_game}"
    new "Inserisci password: _ _ _ _ _ _"


    old "Begin restoration: K _ _ _  _ _"
    new "Esecuzione in corso: U _ _ _ _ _"


    old "Begin restoration: K I _ _  _ _"
    new "Esecuzione in corso: U C _ _ _ _"


    old "Begin restoration: K I L _  _ _"
    new "Esecuzione in corso: U C C _ _ _"


    old "Begin restoration: K I L L  _ _"
    new "Esecuzione in corso: U C C I _ _"


    old "Begin restoration: K I L L  I _"
    new "Esecuzione in corso: U C C I D _"


    old "Restoration Complete: K I L L  I T"
    new "Esecuzione Completata: U C C I D I"


    old "Ok, got it."
    new "Ok, ho capito."


    old "Need another hint."
    new "Ho bisogno di un indizio."


    old "Gonna need another hint."
    new "Mi serve un altro indizio."


    old "Still not following..."
    new "Non ci arrivo ancora..."


    old "Okay, one more hint..."
    new "Ok, un altro indizio..."


    old "..?"
    new "...?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
