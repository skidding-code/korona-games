


translate ita inAlley_start_a20cefa7:


    "..."


translate ita inAlley_start_28a9f6c1:


    "{b}{size=-10}Non è il momento.{/size}{/b}"


translate ita inAlley_start_e3e320e6:


    "Un'ultima cosa..."


translate ita inAlley_start_42b896f8:


    "Allora..."


translate ita inAlley_start_71219ec6:


    "Cosa fare con un gatto che è stato {i}molto...{/i}"


translate ita inAlley_start_8794b742:


    "{i}molto...{/i}"


translate ita inAlley_start_ba6b8484:


    "{i}{size=+10}molto...{/size}{/i}"


translate ita inAlley_start_7cf748e5:


    "{color=#FF0000}{b}b i r i c h i n o . . ?{/b}{/color}"


translate ita leaveCat_dae0ec55:


    you "..."


translate ita leaveCat_569a4a54:


    "Non pensi sia una buona idea illudere il gatto di avere trovato una persona fidata, se non vuoi prendertene cura."


translate ita leaveCat_0035fbdc:


    "E se si affezionasse e ti seguisse fino a casa?"


translate ita leaveCat_5330941f:


    "{size=-10}Allora, non te ne staccheresti più.{/size}{w=0.4}{nw}"


translate ita leaveCat_a85b90f1:


    you "Mi spiace... Ci vediamo in giro, immagino."


translate ita leaveCat_21aa06c6:


    "Ti alzi, mentre il gatto osserva ogni tua mossa."


translate ita leaveCat_bcd29f0b:


    "Arrivi a metà del vicolo, quando il gatto miagola in modo quasi patetico."


translate ita leaveCat_708ef71a:


    cat "Miaooo... Miaooo... Miaooo..."


translate ita leaveCat_dae0ec55_1:


    you "..."


translate ita leaveCat_9590def2:


    "No. Non se ne parla. Devi stroncarla sul nascere e andare avanti."


translate ita leaveCat_c45c05a0:


    "È la cosa migliore sia per te che per lui."


translate ita leaveCat_57513084:


    "Lasci il vicolo e prosegui per la tua strada."


translate ita leaveCat_b844458f:


    you "Aspetta, che stavo facendo...?"


translate ita leaveCat_8b6a5b93:


    "L'emozione provata nel gestire il tuo dilemma peloso..."


translate ita leaveCat_5dec36ba:


    "... ti ha fatto scordare che non hai ancora deciso come impiegare il tuo giorno libero."


translate ita leaveCat_cda3a886:


    "Ooooh~"


translate ita leaveCat_f75bff4c:


    "Come si fa a voltare le spalle a {i}quello?{/i}"


translate ita leaveCat_f3abd822:


    "Che {b}mostro{/b} saresti, se lo facessi davvero?"


translate ita goToMovies_74698f4f:


    "È passato parecchio dall'ultima volta che è uscito un film abbastanza interessante da convincerti ad andare al cinema..."


translate ita goToMovies_16041c5e:


    "... ma sembra ce ne sia uno proprio al vecchio cinema."


translate ita goToMovies_08ebae1d:


    "Il film era troppo di nicchia per essere proiettato nel nuovo cinema che ha aperto sull'altro lato della strada."


translate ita goToMovies_b01bac60:


    "Non è un problema, però. Non stravedi per le folle."


translate ita goToMovies_6430cdc2:


    "E non c'è niente di peggio per te che guardare un nuovo film con un pubblico rumoroso."


translate ita moviesMenu_927147c9:


    "Non sai perché...{w} ma l'idea di restare per conto tuo non ti fa sentire molto bene, ora come ora."


translate ita oldTheater_1be5a36c:


    "Compri con impazienza il biglietto dal vecchio all'entrata e prosegui all'interno."


translate ita oldTheater_db3599c5:


    "Il posto è spoglio e deserto. Gli arredi sembrano rimasti quelli degli anni Ottanta..."


translate ita oldTheater_77b6ae49:


    "... forse addirittura Settanta."


translate ita oldTheater_599278f5:


    "Ma ci speravi."


translate ita oldTheater_7ad62eb8:


    "Ti chiedi se comprare dei popcorn..."


translate ita oldTheater_025c7a51:


    "... ma hai il timore che tutti i prodotti del chioschetto siano ormai scaduti."


translate ita oldTheater_52bad82a:


    "Procedi camminando per i corridoi, fino ad arrivare alla sala segnata sul tuo biglietto."


translate ita oldTheater_2bf14d35:


    "Come previsto, la sala in cui viene proiettato il film è vuota. "


translate ita oldTheater_5a0a5807:


    "Perfetto."


translate ita oldTheater_d0351c7d:


    "Prendi posto al centro, conti perfino le poltrone e calcoli lo spazio delle scale."


translate ita oldTheater_408d2f47:


    "Mentre ti sistemi, le luci soffuse si spengono, lasciando la stanza al buio per alcuni secondi..."


translate ita oldTheater_8dabefc6:


    ".."


translate ita oldTheater_a20cefa7:


    "..."


translate ita oldTheater_a4fb4a3e:


    "... prima che lo schermo prenda vita."


translate ita oldTheater_dd520a72:


    "Nessuna pubblicità o trailer. Il film inzia e basta."


translate ita oldTheater_a5c79df4:


    "Felice, ti rilassi e ti lasci catturare dalla scena iniziale."


translate ita oldTheater_1b0c5dc9:


    "Ma proprio durante il preludio..."


translate ita oldTheater_b6693490:


    "... le porte si aprono alle tue spalle, inondando la stanza di luce per un attimo e rovinando l'atmosfera."


translate ita oldTheater_e56dc443:


    "Emetti un sospiro frustrato."


translate ita oldTheater_c6d5d2d2:


    "È un luogo pubblico, dopotutto."


translate ita oldTheater_4fa1403a:


    "Il cinema chiuderebbe i battenti se ci andassi {i}soltanto tu{/i}."


translate ita oldTheater_93c887ef:


    "Cerchi di concentrarti sul film, ma puoi percepire la figura appena arrivata aggirarsi per la sala..."


translate ita oldTheater_b4c5e205:


    "... e in seguito dirigersi verso di te."


translate ita oldTheater_8dabefc6_1:


    ".."


translate ita oldTheater_a20cefa7_1:


    "..."


translate ita oldTheater_4d11e7f3:


    you "...?!? Ma che..."


translate ita oldTheater_b0959e10:


    "Guardi con sconcerto lo sconosciuto percorrere la fila di poltrone e infine sedersi {b}ESATTAMENTE{/b} davanti a te."


translate ita oldTheater_dae0ec55:


    you "..."


translate ita oldTheater_8ff13d0b:


    "Non c'è nessun altro qui e ci sono tanti posti dove mettersi."


translate ita oldTheater_67b56825:


    "Lo sconosciuto per di più è..."


translate ita oldTheater_2264fca6:


    "... {i}straordinariamente{/i} alto."


translate ita oldTheater_d21b2508:


    "Anche con le poltrone disposte come allo stadio, riesce a bloccarmi la visuale."


translate ita oldTheater_452114d6:


    "Troppo strano."


translate ita oldTheater_f9c856d9:


    "Decidi di lasciare la sala, perché ti senti a disagio. Hai ancora tempo a sufficenza per dedicarti ad altro."


translate ita oldTheater_16617c12:


    "E adesso?"


translate ita moveTheater1_40036af7:


    "Non vuoi che la situazione prenda una piega ancora più bizzarra. Ti senti già abbastanza sulle spine."


translate ita moveTheater1_30d6713a:


    "Perché sedersi proprio davanti a te? Doveva sapere che in questo modo non avresti potuto vedere niente."


translate ita moveTheater1_badbf0f2:


    "Scuoti la testa con fare passivo-aggressivo verso lo sconosciuto... {w}con riluttanza, scegli un'altra poltrona, stavolta meno perfetta..."


translate ita moveTheater1_bf0874e3:


    "Ma..."


translate ita moveTheater1_cc8c4a97:


    "Mentre ti sistemi..."


translate ita moveTheater1_62c67dd0:


    "... vedi lo strano individuo alzarsi..."


translate ita moveTheater1_89af2519:


    "... e venire a sedersi di nuovo {i}esattamente{/i} davanti a te."


translate ita moveTheater1_56ebb028:


    you "!!!"


translate ita moveTheater1_51a47b38:


    "Ti guardi attorno disperatamente, come aspettandoti che qualcuno confermi in silenzio quanto tutto ciò sia strano."


translate ita moveTheater1_e5a8d006:


    "O, quantomeno, ti spieghi che si tratta di uno scherzo elaborato."


translate ita moveTheater1_4bc7f00e:


    "Ma non c'è nessun altro a parte te. Hai sempre preferito così, eppure..."


translate ita moveTheater1_a20cefa7:


    "..."


translate ita moveTheater1_b0de34e0:


    "Finisci col pensare che sarebbe perfino piacevole avere {i}qualcuno{/i} vicino, pur di non restare da soli con questo strambo..."


translate ita moveTheater1_452114d6:


    "Troppo strano."


translate ita moveTheater1_f9c856d9:


    "Decidi di lasciare la sala, perché ti senti a disagio. Hai ancora tempo a sufficenza per dedicarti ad altro."


translate ita moveTheater1_16617c12:


    "E adesso?"


translate ita moveTheater2_287d233d:


    "Ti sposti di nuovo..."


translate ita moveTheater2_cc9a5909:


    "!!!"


translate ita moveTheater2_198c5f02:


    "... e {i}di nuovo,{/i} si siede davanti a te."


translate ita moveTheater2_1cea2bd2:


    "Ti irrigidisci, provando fastidio e un po' di umiliazione."


translate ita moveTheater2_663c60ce:


    "Lo fa per divertirsi o cosa?"


translate ita moveTheater2_22dd2b12:


    "Hai passato così tanto tempo a preoccuparti di questo idiota che hai perso il filo del film."


translate ita moveTheater2_dae0ec55:


    you "..."


translate ita moveTheater2_452114d6:


    "Troppo strano."


translate ita moveTheater2_f9c856d9:


    "Decidi di lasciare la sala, perché ti senti a disagio. Hai ancora tempo a sufficenza per dedicarti ad altro."


translate ita moveTheater2_16617c12:


    "E adesso?"


translate ita confrontTheater_d20e8806:


    "Odi il confronto. Ti sudano i palmi solo a pensarci."


translate ita confrontTheater_a9c192bd:


    "Hai un nodo alla gola e cominci a tremare."


translate ita confrontTheater_2938ac47:


    "Hai sempre preferito 'alzare i tacchi' che 'alzare le mani'..."


translate ita confrontTheater_ba742fb9:


    "... ma hai pagato il biglietto. {w}Erano secoli che volevi vedere questo film..."


translate ita confrontTheater_4133c851:


    "... e ora questo sconosciuto ti ha rovinato la festa."


translate ita confrontTheater_31224555:


    "Non c'è nessuno in sala che può aiutarti, se qualcosa va storto..."


translate ita confrontTheater_56f5734b:


    "Ma provi troppa rabbia per ascoltare il tuo corpo che ti implora di scappare il più lontano possibile da questo individuo."


translate ita confrontTheater_4d121ecf:


    "Ti alzi in piedi. Pur trovandoti in posizione soprelevata rispetto a lui, lo sconosciuto risulta {i}almeno{/i} una spanna più alto."


translate ita confrontTheater_7ecc8825:


    "Il film scorre in sottofondo, ma ti sembra che nella sala sia calato un silenzio improvviso."


translate ita confrontTheater_61ee470d:


    "... come se lo sconosciuto stesse aspettando la tua prossima mossa."


translate ita confrontTheater_36eaf556:


    "Raddrizzi le spalle e cerchi di fare la voce grossa."


translate ita confrontTheater_635cbfd8:


    you "{size=+10}{b}EHI!{/b}{/size}" with hpunch


translate ita confrontTheater_c6fd0e1b:


    "Per lo sforzo, la tua voce suona più dura di quanto volessi, come quella di un cane rabbioso che abbaia all'improvviso..."


translate ita confrontTheater_77452538:


    "... ma pensi che, alla fine, se lo meriti."


translate ita confrontTheater_72a25472:


    you "Ti stai comportando da vero stronzo, lo sai? A che gioco stai giocando, eh? Cerchi di farmi innervosire?"


translate ita confrontTheater_6f50b679:


    who "..."


translate ita confrontTheater_dae0ec55:


    you "..."


translate ita confrontTheater_8dabefc6:


    ".."


translate ita confrontTheater_a20cefa7:


    "..."


translate ita confrontTheater_f6344799:


    "Il silenzio che segue è {b}assordante{/b}..."


translate ita confrontTheater_93861255:


    "... al punto che dai un'occhiata allo schermo e scopri che il film è..."


translate ita confrontTheater_fee70e3c:


    "... in pausa?"


translate ita confrontTheater_90b68c87:


    you "...?"


translate ita confrontTheater_28b3ac41:


    you "!!!"


translate ita confrontTheater_169210d3:


    "Guardi subito lo sconosciuto di fronte a te, che si è mosso leggermente."


translate ita confrontTheater_dbc8ab64:


    "Come una piccola preda che cerca disperata di prevedere la mossa del predatore... {w}{b}rimani immobile.{/b}"


translate ita confrontTheater_74dfd95b:


    "Non distogli lo sguardo. {w}Non osi {i}sbattere le palpebre.{/i}"


translate ita confrontTheater_0dd1ea0a:


    "Ma spalanchi gli occhi quando lui inizia a girare la testa..."


translate ita confrontTheater_5654bfb2:


    "E la gira ancora..."


translate ita confrontTheater_a20cefa7_1:


    "..."


translate ita confrontTheater_b88269b6:


    "E ancora... {i}oltre{/i} l'umanamente possibile... Le ossa del collo {i}scricchiolano{/i}..."


translate ita confrontTheater_61ab54e3:


    "... finché non ti ritrovi a fissare la sua faccia."


translate ita confrontTheater_17cf9e73:


    you "...ah ..."


translate ita confrontTheater_c6ce8445:


    "Non riesci a muoverti."


translate ita confrontTheater_d758f471:


    "Due occhi grandi e luminosi ti scrutano, incorniciati da un largo ghigno."


translate ita confrontTheater_6b167f7f:


    "Lo sconosciuto apre la bocca, e quello che ne esce..."


translate ita confrontTheater_2177217c:


    "... è al di là di ogni logica."


translate ita confrontTheater_742b5efd:


    who "Miaaaa-a-a-a-a-a-aoo~{w=2.75}{nw}"


translate ita confrontTheater_24840d69:


    you "?!?"


translate ita confrontTheater_65a6a073:


    who "Miaaaa-a-a-a-a-a-aoo~{w=2.5}{nw}"


translate ita confrontTheater_d46cc080:


    who "Miaaaa{w=0.75}-a{w=0.75}-a{w=0.75}-a{w=0.75}-aaaooo~"


translate ita confrontTheater_8ca8510a:


    you "!!!" with vpunch


translate ita confrontTheater_8d5e95ad:


    "La voce è profonda e cigola come un portone, sinistra e inaspettatamente meolodica..."


translate ita confrontTheater_98a755c6:


    "È suadente..."


translate ita confrontTheater_2ff3b202:


    "Ma è capace anche di risvegliarti dallo stato di trance indotto dal terrore e, prima di accorgertene, sei alla porta."


translate ita confrontTheater_0051e82f:


    "Fuggi nei corridoi del cinema deserto per raggiungere l'uscita."


translate ita confrontTheater_3a3a66e0:


    "Senti una presenza che ti insegue..."


translate ita confrontTheater_10fd18e4:


    "{size=-5}... ma hai troppa paura per voltarti.{/size}"


translate ita confrontTheater_a376e0ce:


    "Vedi l'uscita, corri più veloce che puoi e spalanchi le porte."


translate ita confrontTheater_c6a8f088:


    "Ti guardi attorno freneticamente e noti il cinema affollato sull'altro lato della strada."


translate ita confrontTheater_1b77491a:


    "Delle persone! È quello che ci voleva. La sicurezza data dai grandi numeri... "


translate ita confrontTheater_e6eacea8:


    "Senza pensarci, attraversi la strada di corsa, ma un brivido sinistro ti scuote, suggerendoti di guardarti alle spalle."


translate ita lookBehindYou_movie_d5f8a487:


    "Ti rifiuti di ascoltare l'istinto e ti affretti a raggiungere il nuovo cinema."


translate ita lookBehindYou_movie_a724453f:


    "Senti una pressione terribile, ma lo realizzi solo..."


translate ita lookBehindYou_movie_a20cefa7:


    "..."


translate ita lookBehindYou_movie_1812debc:


    "... quando quella sensazione svanisce all'improvviso."


translate ita lookBehindYou_movie_4036cbd4:


    "Il lato positivo è che respiri meglio."


translate ita lookBehindYou_movie_e1da1ba0:


    "{size=-7}Pensi che dimenticare {b}tutto{/b} quello che è accaduto sia la cosa migliore.{/size}"


translate ita lookBehindYou_movie_a20cefa7_1:


    "..."


translate ita lookBehindYou_movie_4914da37:


    "Già..."


translate ita endOldMovie_8dabefc6:


    ".."


translate ita endOldMovie_a20cefa7:


    "..."


translate ita endOldMovie_5583c4ca:


    "Anche se cerchi di resistere..."


translate ita endOldMovie_0fcf7c3b:


    "... il bisogno di girarti a guardare è troppo forte."


translate ita endOldMovie_7f250539:


    "Nel bel mezzo della strada..."


translate ita endOldMovie_dfc24e13:


    "... intravedi una figura grottesca dietro le porte di vetro del vecchio cinema..."


translate ita endOldMovie_67373714:


    "Ti guarda intensamente..."


translate ita endOldMovie_747a081d:


    "E tiene qualcosa tra le braccia..."


translate ita endOldMovie_973413d4:


    "Qualcosa..."


translate ita endOldMovie_8ae0fc15:


    "{size=-10}... di familiare.{/size}"


translate ita endOldMovie_a20cefa7_1:


    "..."


translate ita endOldMovie_bf0874e3:


    "Ma..."


translate ita endOldMovie_a9494a86:


    "{size=+30}{b}{i}BEEP!{/i}{/b}{/size}" with hpunch


translate ita endOldMovie_90b68c87:


    you "...?"


translate ita endOldMovie_8ca8510a:


    you "!!!" with vpunch


translate ita endOldMovie_f5377255:


    "Vedi la scena solo di sfuggita..."


translate ita endOldMovie_e22cae7b:


    "... perché un camion {b}si schianta{/b} a tutta velocità contro di te."


translate ita endOldMovie_8dabefc6_1:


    ".."


translate ita endOldMovie_a20cefa7_2:


    "..."


translate ita endOldMovie_0b13bd09:


    "Muori all'istante. Il tuo corpo viene spiattellato sulla strada e asfaltato dalle ruote pesanti."


translate ita endOldMovie_a20cefa7_3:


    "..."


translate ita endOldMovie_7444e453:


    "Finale 16: Cinema tra A-mici"


translate ita newCinema_fb646a70:


    "Decidi di aspettare che il film sia disponibile su DVD o in streaming..."


translate ita newCinema_e6448215:


    "... e ti accodi alla lunga fila fuori dal nuovo cinema."


translate ita newCinema_0f82186d:


    "Quando finalmente raggiungi la biglietteria, non vedi l'ora di entrare..."


translate ita newCinema_2e8f7eeb:


    "... così scegli un film a caso e compri il biglietto dall'adolescente con l'aria stanca dietro il bancone."


translate ita newCinema_6fcdd2f1:


    "Gli arredi sono alla moda e raffinati, e l'interno del cinema brulica di persone."


translate ita newCinema_df337005:


    "Non rientra nel tuo stile..."


translate ita newCinema_ebfd36e0:


    "... ma, in un certo senso, è bello non essere soli..."


translate ita newCinema_16ea2ab5:


    "... anche se provi un po' di solitudine a guardare le famiglie e i gruppi di amici che ridono tra di loro."


translate ita newCinema_8a84e9c7:


    "Prenderesti volentieri dei popcorn, ma la coda per il chioschetto è lunga e i prezzi sono illegali."


translate ita newCinema_f8963506:


    "Vaghi per i corridoi..."


translate ita newCinema_6a610267:


    "... seguendo le indicazioni per la sala riportata sul tuo biglietto, prima di entrare."


translate ita newCinema_8dabefc6:


    ".."


translate ita newCinema_a20cefa7:


    "..."


translate ita newCinema_cfd045e6:


    you "*Sigh*..."


translate ita newCinema_a0c7900b:


    "Sospiri alla vista della sala gremita di gente."


translate ita newCinema_2aeb5f16:


    "Ti dirigi verso la tua poltrona, ma la persona di fianco ti informa che il posto è riservato a qualcun altro."


translate ita newCinema_2c48e4bd:


    "La stessa cosa si ripete altre due o tre volte, poi riesci a sederti in un punto fastidiosamente decentrato rispetto allo schermo."


translate ita newCinema_66e2f315:


    "Lo schermo, perlomeno, è visibile, anche se un po' troppo vicino. Quindi stringi i denti e sopporti."


translate ita newCinema_84b297cd:


    "Le luci si spengono..."


translate ita newCinema_76f1cc33:


    "... ma il chiacchiericcio continua."


translate ita newCinema_ccf5589e:


    "Il pubblico parla con disinvoltura durante le pubblicità e perfino durante i trailer."


translate ita newCinema_e5244e34:


    "Speri che la gente si zittisca con l'inizio del film..."


translate ita newCinema_42922d85:


    "... ma il loro tono di voce non si abbassa nemmeno {i}di un filo{/i} quando parte la prima scena."


translate ita newCinema_056cb5d7:


    "Sospiri rumorosamente, consapevole che nessuno ti sentirà comunque."


translate ita newCinema_fe9b2aa2:


    "Ecco perché eviti i cinema come la peste."


translate ita newCinema_c70c22ac:


    "D'un tratto, lo schermo cambia e appare il muso di un gatto nero..."


translate ita newCinema_a20cefa7_1:


    "..."


translate ita newCinema_5bd888eb:


    "{size=-8}Un gatto nero {b}familiare{/b}.{/size}"


translate ita newCinema_bf2cad6b:


    "La sala si riempie di mormorii confusi... ma poi... {w}il gatto sullo schermo..."


translate ita newCinema_7f5ff8a8:


    "{b}... miagola.{/b}"


translate ita newCinema_d752482c:


    catOnScreen "Miao... Miao... Miaaa-a-a-a-oo..."


translate ita newCinema_28b3ac41:


    you "!!!"


translate ita newCinema_2e7e53ad:


    "Il suono è... {i}strano{/i} e per nulla simile al verso che un gatto {i}dovrebbe{/i} fare."


translate ita newCinema_4a94d4f7:


    "È inquietante... Quasi melodico..."


translate ita newCinema_d7d1f702:


    "E stratificato, come se fosse composto da tante voci di creature diverse."


translate ita newCinema_96a32759:


    "Creature che non direbbero mai..."


translate ita newCinema_d752482c_1:


    catOnScreen "Miao... Miao... Miaaa-a-a-a-oo..."


translate ita newCinema_dae0ec55:


    you "..."


translate ita newCinema_7865d364:


    "Resti lì con aria perplessa e ti domandi perché non ti stia alzando per andare a lamentarti con lo staff del cinema... "


translate ita newCinema_04be082d:


    "Ma poi lo {b}senti{/b}..."


translate ita newCinema_b5b4f2e8:


    "All'inizio è un rumore sporadico e disarmonico... ma tra il pubblico... qualcuno inizia a cantare assieme al gatto sullo schermo."


translate ita newCinema_b67f4dca:


    audience "{size=-10}Miao... Miao... Miaaa-a-a-a-oo...{/size}"


translate ita newCinema_45f08096:


    audience "{size=-5}Miao... Miao... Miaaa-a-a-a-oo...{/size}"


translate ita newCinema_764e589b:


    audience "Miao... Miao... Miaaa-a-a-a-oo..."


translate ita newCinema_b95dc8fe:


    "Nel giro di poco... tutti in sala stanno cantando all'unisono, fissando intensamente il gatto sullo schermo."


translate ita newCinema_9eb4296f:


    "Anche tu senti una strana attrazione verso lo schermo..."


translate ita newCinema_59b62632:


    "... ma l'impulso di fissarlo con aria assente non è forte come negli altri..."


translate ita newCinema_53224b1d:


    "... per {b}ora.{/b}"


translate ita newCinema_3595f06e:


    "Poi... {w}cominci ad accorgerti, con la coda dell'occhio..."


translate ita newCinema_fc9293fc:


    "... che alcune persone vicino a te... ti stanno {w}{i}guardando{/i}..."


translate ita newCinema_7072f3b4:


    "No..."


translate ita newCinema_8adc7d4f:


    "Ti fissano con occhi {b}gelidi{/b}, senza smettere di cantare."


translate ita newCinema_46abeb33:


    "Senza perdere il ritmo, iniziano a corrugare la fronte in segno di palese disapprovazione..."


translate ita newCinema_c4ad1bed:


    "Le loro smorfie crescono, come se fossero...{w} {i}impazienti...{/i}"


translate ita leaveCinema_b24b4053:


    you "{i}La situazione è troppo strana... Devo andarmene...{/i}"


translate ita leaveCinema_14daa181:


    "Con coraggio...{w} o forse con paura, ti alzi{w} con l'intenzione di lasciare la sala..."


translate ita leaveCinema_a20cefa7:


    "..."


translate ita leaveCinema_ad7223b1:


    "... quando tutti si {b}FERMANO{/b} all'improvviso."


translate ita leaveCinema_dff334e8:


    "Il canto termina, perfino quello del gatto sullo schermo."


translate ita leaveCinema_dae0ec55:


    you "..."


translate ita leaveCinema_2f1c4fb2:


    "Ti irrigidisci e ti guardi attorno di sfuggita."


translate ita leaveCinema_8ca8510a:


    you "!!!" with vpunch


translate ita leaveCinema_fe50f822:


    "Ti stanno osservando tutti."


translate ita leaveCinema_50e5017d:


    "Ogni. {w}Singola. {w}Persona."


translate ita leaveCinema_352295ee:


    "Non si muovono. Non sbattono nemmeno {i}le palpebre.{/i}"


translate ita leaveCinema_99a1a0e1:


    "Deglutisci. Hai la gola secca, nonostante tu abbia i vestiti zuppi di sudore."


translate ita leaveCinema_661663c4:


    "Dubiti fortemente che sedersi in fondo cambi qualcosa."


translate ita leaveCinema_213963ee:


    "Ti tremano le gambe sotto lo sguardo intenso e indagatore del pubblico..."


translate ita leaveCinema_f71571f9:


    "... ma ti sforzi di fare un passo, poi un altro e {i}un altro ancora{/i}, finché non arrivi alla fine del corridoio laterale."


translate ita leaveCinema_dba70b8c:


    "Sulle scale, l'interesse collettivo non fa che aumentare."


translate ita leaveCinema_87d1ef1d:


    "Le teste di tutti sono piegate innaturalmente a sinistra per guardarti."


translate ita leaveCinema_f70351ce:


    "Lo schermo illumina le facce delle persone... accentuando i loro occhi vacui."


translate ita leaveCinema_004b0a78:


    "Sembrano perfino più {i}turbati{/i} di qualche minuto fa, come mostrano le loro fronti corrugate in espressioni identiche."


translate ita leaveCinema_dae0ec55_1:


    you "..."


translate ita leaveCinema_3252a987:


    "Continui a camminare, sentendo l'atmosfera che si fa sempre più oppressiva a ogni passo."


translate ita leaveCinema_fb8531cb:


    "Provi così tanta tensione che ti aspetti, da un momento all'altro, che qualcuno ti afferri da dietro..."


translate ita leaveCinema_8dabefc6:


    ".."


translate ita leaveCinema_a20cefa7_1:


    "..."


translate ita leaveCinema_0a4bb949:


    "... ma non succede niente."


translate ita leaveCinema_40a5c55d:


    "Dal silenzio, sembrerebbe che nessuno si stia alzando."


translate ita leaveCinema_6bc983be:


    "Lasci la sala con il fiato sospeso mentre le porte si chiudono alle tue spalle."


translate ita leaveCinema_ffbf4484:


    "Ti affretti per i corridoi nella speranza di allontanarti il più possibile dalla sala piena di gente."


translate ita leaveCinema_26c08f03:


    "Finalmente, raggiungi l'ingresso ansimando e per un pelo non cadi a terra."


translate ita leaveCinema_83668abb:


    you "*anf*... *anf*... *anf*..."


translate ita leaveCinema_52ec6324:


    "Ti aspetti di provare sollievo quando recuperi fiato..."


translate ita leaveCinema_a1d9994b:


    "... ma il terrore che senti non fa che salire alle stelle quando ti accorgi..."


translate ita leaveCinema_9a5f33b8:


    "... di cosa succede."


translate ita leaveCinema_1aa73f86:


    "Alzi lo sguardo...{w} e il tuo stomaco si {b}contorce.{/b}"


translate ita leaveCinema_8ca8510a_1:


    you "!!!" with vpunch


translate ita leaveCinema_a20cefa7_2:


    "..."


translate ita leaveCinema_af1c2015:


    "Le persone nell'atrio del cinema..."


translate ita leaveCinema_a38e0614:


    "... quelle in fila al chioschetto..."


translate ita leaveCinema_0e53b020:


    "... {i}tutte{/i} quante..."


translate ita leaveCinema_b615e9cc:


    "... ti stanno fissando."


translate ita leaveCinema_b88c436c:


    "E sembrano..."


translate ita leaveCinema_a20cefa7_3:


    "..."


translate ita leaveCinema_fc56246f:


    "{size=-8}Ancora più arrabbiate di quelle in sala.{/size}"


translate ita leaveCinema_87f864e9:


    "Stavolta non esiti."


translate ita leaveCinema_3d21a06a:


    "Abbassi la testa, evitando il contatto visivo, e lasci il cinema."


translate ita leaveCinema_f685e7ad:


    "Ignori le occhiatacce del personale e della gente in coda alla biglietteria."


translate ita leaveCinema_80db9421:


    "Ti avvii verso casa."


translate ita leaveCinema_f0a2809d:


    "Ogni volta che osi incrociare lo sguardo di qualcuno per strada..."


translate ita leaveCinema_bda94720:


    "... sussulti per la rabbia evidente, la furia e il {i}disgusto{/i} dipinto sul suo viso."


translate ita leaveCinema_964bc827:


    "Ti pare di sentire il miagolio lontano di un gatto dietro di te... o forse di un gattino?"


translate ita leaveCinema_57e876a1:


    "Non importa. Vuoi solo arrivare a casa."


translate ita leaveCinema_b807a344:


    "Arrivi davanti alla porta e traffichi con le chiavi..."


translate ita leaveCinema_f4f2f1d2:


    "... nascondendoti dall'occhiata piena di odio che ti lancia il vicino dall'entrata di casa sua."


translate ita leaveCinema_8dabefc6_1:


    ".."


translate ita leaveCinema_a20cefa7_4:


    "..."


translate ita leaveCinema_cddd7eac:


    "Alla fine, riesci a entrare nell'appartamento..."


translate ita leaveCinema_4632e734:


    "... chiudi la porta a doppia mandata..."


translate ita leaveCinema_490b851e:


    "... e ti lasci cadere sul pavimento con la schiena contro la porta."


translate ita leaveCinema_157a374f:


    you "*anf*... *anf*... *gulp*... *anf*..."


translate ita leaveCinema_57aaf835:


    "Ti concedi un momento per respirare."


translate ita leaveCinema_f125ce05:


    "Ora che sei a casa, la tachicardia cala lentamente, fino a lasciarti uno strano senso di..."


translate ita leaveCinema_0f7ae6ad:


    "... vuoto."


translate ita leaveCinema_a20cefa7_5:


    "..."


translate ita leaveCinema_bf467465:


    "Attraversi la cucina, arrivi in camera da letto e scivoli sotto le coperte, nel tentativo di addormentarti."


translate ita leaveCinema_dbaf51d5:


    "Forse è tutto un brutto sogno."


translate ita leaveCinema_f54febea:


    "Mentre sprofondi in un sonno agitato, colmo di incubi e occhi maligni..."


translate ita leaveCinema_83eadebb:


    "... cerchi di ignorare il suono sempre più insistente di gatti che miagolano e urlano in lontananza."


translate ita leaveCinema_a20cefa7_6:


    "..."


translate ita leaveCinema_d23cedee:


    "Finale 17: Pecora Nera"


translate ita blendInCinema_6757b12e:


    audience "..."


translate ita blendInCinema_af2b87f0:


    "Pensi in fretta, fissi lo schermo e ti unisci al coro del pubblico."


translate ita blendInCinema_baf609ba:


    you "M-Miao... Miao... Miaaa-a-a-a-ao..."


translate ita blendInCinema_6757b12e_1:


    audience "..."


translate ita blendInCinema_3f83d36c:


    you "Miao... Miao... Miaaa-a-a-a-ao..."


translate ita blendInCinema_6757b12e_2:


    audience "..."


translate ita blendInCinema_6757b12e_3:


    audience "..."


translate ita blendInCinema_d090b91d:


    "Senti la spietatezza dei loro sguardi evaporare..."


translate ita blendInCinema_5580b6b9:


    "... e l'atmosfera nella sala farsi di nuovo leggera."


translate ita blendInCinema_764e589b:


    audience "Miao... Miao... Miaaa-a-a-a-ao..."


translate ita blendInCinema_0b4d7107:


    "Esali un respiro tremante e ti rendi conto che stavi trattenendo il fiato."


translate ita blendInCinema_a20cefa7:


    "..."


translate ita blendInCinema_b2294dd7:


    "Non sai che fare."


translate ita blendInCinema_042d621e:


    "Di certo non puoi alzarti e andare via {i}adesso...{/i}"


translate ita blendInCinema_cf356d17:


    "Non dopo... {i}qualsiasi{/i} cosa fosse quello che è successo..."


translate ita blendInCinema_ed742197:


    "Le persone attorno a te sembrano serene ora..."


translate ita blendInCinema_15fcd1a9:


    "... ma potrebbero tornare aggressive al minimo cenno di movimento..."


translate ita blendInCinema_b896225e:


    "... figuriamoci poi se ti alzassi per andare via."


translate ita blendInCinema_68b1d26e:


    "Decidi che è meglio seguire la corrente. Con un po' di fortuna, arriverà qualcuno..."


translate ita blendInCinema_9979a58c:


    "Giusto?"


translate ita blendInCinema_4cc0ec01:


    "{size=-5}O magari la programmazione verrà cancellata?{/size}"


translate ita blendInCinema_a20cefa7_1:


    "..."


translate ita blendInCinema_0de27b67:


    "Continui a cantare assieme agli altri..."


translate ita blendInCinema_3f83d36c_1:


    you "Miao... Miao... Miaaa-a-a-a-ao..."


translate ita blendInCinema_8dabefc6:


    ".."


translate ita blendInCinema_a20cefa7_2:


    "..."


translate ita blendInCinema_397110ce:


    "Cominci a sentire un certo stordimento..."


translate ita blendInCinema_8b1e92a6:


    "Ti sembra di addormentarti, ma non senti le palpebre pesanti."


translate ita blendInCinema_7ff2d155:


    "Cerchi di guardarti attorno per sondare lo stato emotivo degli spettatori..."


translate ita blendInCinema_a20cefa7_3:


    "..."


translate ita blendInCinema_40d9ca73:


    "...?"


translate ita blendInCinema_a90dd9a4:


    "Ma non riesci a distogliere lo sguardo dallo schermo."


translate ita blendInCinema_2a365272:


    "Provi di nuovo, ma è impossibile spezzare il contatto visivo con il gatto sullo schermo."


translate ita blendInCinema_d752482c:


    catOnScreen "Miao... Miao... Miaaa-a-a-a-ao..."


translate ita blendInCinema_764e589b_1:


    audience "Miao... Miao... Miaaa-a-a-a-ao..."


translate ita blendInCinema_3f83d36c_2:


    you "Miao... Miao... Miaaa-a-a-a-ao..."


translate ita blendInCinema_496d9edf:


    "Ti sforzi di guardare da un'altra parte."


translate ita blendInCinema_d9f4b72f:


    "Tieni i nervi saldi, per gettarti a terra con prontezza nel caso ce ne sia bisogno..."


translate ita blendInCinema_3e3a5b69:


    "Eppure il tuo corpo funziona solo per un attimo, prima di rilassarsi completamente..."


translate ita blendInCinema_2fb3a1df:


    "... e afflosciarsi sulla poltrona."


translate ita blendInCinema_2a71630f:


    "Dovresti andare nel panico..."


translate ita blendInCinema_a6dd5ae6:


    "Ma anche il tuo cervello è disconnesso..."


translate ita blendInCinema_8cf039a1:


    "... e i tuoi pensieri assumono tinte rosa pastello..."


translate ita blendInCinema_1beaa2de:


    "... sono leggeri..."


translate ita blendInCinema_ced05056:


    "... smielati e vorticosi..."


translate ita blendInCinema_57ea3fbe:


    "... come zucchero filato."


translate ita blendInCinema_a20cefa7_4:


    "..."


translate ita blendInCinema_0f5de544:


    "A te..."


translate ita blendInCinema_54c46a6d:


    "A te piace lo zucchero filato..."


translate ita blendInCinema_cb63a8d9:


    "Pensi che non sarebbe così male se il tuo corpo e la tua mente assomigliassero a zucchero filato..."


translate ita blendInCinema_7c477b17:


    "In tal caso... {w}perché alzarsi e {i}rovinare{/i} tutto?"


translate ita blendInCinema_ba89262e:


    "Si sta bene qui."


translate ita blendInCinema_e24de160:


    "Non avevi mai provato tanta pace a stare in una stanza affollata come questa."


translate ita blendInCinema_c24bdd0d:


    "Stai ancora cantando. Senti una connessione che non avevi mai vissuto con un'altra persona..."


translate ita blendInCinema_31f93be4:


    "... {i}tanto meno{/i} con una stanza piena zeppa di sconosciuti."


translate ita blendInCinema_04d14b81:


    "Non provi..."


translate ita blendInCinema_a20cefa7_5:


    "..."


translate ita blendInCinema_9d11f320:


    "Non provi solitudine..."


translate ita blendInCinema_ae0146e0:


    "Con la coda dell'occhio, vedi la persona di fianco a te sprofondare ulteriormente nella poltrona..."


translate ita blendInCinema_5f0ca8c0:


    "Sprofonda ancora."


translate ita blendInCinema_5929012b:


    "E {i}ancora.{/i}"


translate ita blendInCinema_ab0534b1:


    "Non sembra si stia stravaccando o stia reclinando il sedile, sembra più si stia..."


translate ita blendInCinema_8dabefc6_1:


    ".."


translate ita blendInCinema_a20cefa7_6:


    "..."


translate ita blendInCinema_a20cefa7_7:


    "..."


translate ita blendInCinema_38fb2682:


    "{size=-5}... {b}sgonfiando.{/b}{/size}"


translate ita blendInCinema_e38a1999:


    "La sua pelle si accartoccia e si increspa come carta. Sembra che i suoi muscoli... le sue {i}ossa...{/i} si stiano disintegrando. "


translate ita blendInCinema_debf73aa:


    "I suoi occhi si spengono, prima di affondare nelle orbite."


translate ita blendInCinema_35c42551:


    "La sua bocca, ancora intenta a cantare, si spalanca, troncando di netto la litania \"Mia-\"..."


translate ita blendInCinema_a9055c48:


    "... che termina in un orribile {i}{b}sibilo{/b}{/i}... un ultimo, debole respiro. "


translate ita blendInCinema_a20cefa7_8:


    "..."


translate ita blendInCinema_16800af4:


    "Ti chiedi se una scena simile dovrebbe scioccarti o meno..."


translate ita blendInCinema_b9788577:


    "... ma anche {i}allora,{/i} la pace che ti avvolge non accenna a sparire."


translate ita blendInCinema_214e33b0:


    "All'improvviso, dal mucchio di pelle e vestiti di fianco a te... {w}vedi muoversi una massa informe..."


translate ita blendInCinema_594564ce:


    "Guardi con fascinazione il grumo che si fa strada nella parte di pelle dove risiedeva la testa..."


translate ita blendInCinema_67dceeae:


    "E dalla bocca..."


translate ita blendInCinema_7c9b7fd7:


    "... fuoriesce un gattino nero."


translate ita blendInCinema_a20cefa7_9:


    "..."


translate ita blendInCinema_3f83d36c_3:


    you "Miao... Miao... Miaaa-a-a-a-ao..."


translate ita blendInCinema_193a0367:


    "Senti il sibilo familiare che si propaga attorno a te, mentre il coro di voci si acquieta... "


translate ita blendInCinema_83fb5231:


    "... per essere rimpiazzato da un lieve miagolio di micetti."


translate ita blendInCinema_51f8946e:


    "Alla fine, la tua voce è l'unica che continua a cantare... ancora umana..."


translate ita blendInCinema_31826a8b:


    "Da sola... {w}di nuovo."


translate ita blendInCinema_5d0ac8cd:


    "{size=-8}Non vuoi che sia così. {w}Non vuoi tornare alla solitudine. {w}Non vuoi. {w}Non vuoi... {w}{b}Per favore...{/b}{/size}"


translate ita blendInCinema_a927f418:


    "A quel punto, ti afflosci."


translate ita blendInCinema_84c8a0dd:


    "Senti il corpo leggero, anche se potrebbe pesare tonnellate..."


translate ita blendInCinema_92382baf:


    "... visto che, in un attimo, realizzi di non poterti muovere..."


translate ita blendInCinema_c3f227f7:


    "Neanche di un {b}centimetro.{/b}"


translate ita blendInCinema_e963d3dd:


    "Non puoi muovere gli occhi per guardarti attorno..."


translate ita blendInCinema_c72a7267:


    "Non puoi nemmeno {i}respirare...{/i}"


translate ita blendInCinema_0c96f132:


    "Ma in qualche modo..."


translate ita blendInCinema_9096c895:


    "... il canto continua a fluire debolmente dalla tua bocca."


translate ita blendInCinema_af288514:


    you "{size=-5}M-Miao... Miao... M-Miaaa-a-a-a-ao...{/size}"


translate ita blendInCinema_635a2b3f:


    "Alcuni gattini si fanno avanti per appollaiarsi sulle poltrone vicino a te..."


translate ita blendInCinema_a149e153:


    "... e per guardare il tuo corpo che sprofonda..."


translate ita blendInCinema_d292541d:


    "... Miagolano, in attesa che il loro fratellino più giovane emerga..."


translate ita blendInCinema_5d4fa878:


    "... da {i}te.{/i}"


translate ita blendInCinema_7a472b2f:


    "Dozzine di occhi luminosi ti guardano dall'alto..."


translate ita blendInCinema_d4e4181d:


    "... e mentre i {i}tuoi{/i} occhi iniziano ad affondare nelle orbite del tuo cranio molle..."


translate ita blendInCinema_24c93db0:


    "... intravedi la forma di un gatto {b}familiare{/b}, raggomitolato sulla poltrona che hai di fronte..."


translate ita blendInCinema_cb38fcb2:


    "La vista si offusca..."


translate ita blendInCinema_0af14a4f:


    "E con quell'ultimo sibilo d'aria espulso dalla tua bocca..."


translate ita blendInCinema_cc2adb18:


    "... senti qualcosa di piccolo e {b}{i}vivo{/i}{/b} agitarsi sotto la tua pelle."


translate ita blendInCinema_8dabefc6_2:


    ".."


translate ita blendInCinema_a20cefa7_10:


    "..."


translate ita blendInCinema_d2ce5919:


    "Finale 18: Congratulazioni! È un... gatto"


translate ita goToCarnival_54663883:


    "Passi la giornata al luna park."


translate ita goToCarnival_295775c9:


    "La ruota panoramica, le montagne russe, la nave pirata... {w}Tutte giostre che hai già provato."


translate ita goToCarnival_0d9e8fc3:


    "Il canestro, il lancio della moneta, i dardi... {w}Tutti giochi a cui hai già giocato."


translate ita goToCarnival_32a40a6e:


    "Mele caramellate, popcorn, zucchero filato... {w}Tutti cibi che hai già assaggiato."


translate ita goToCarnival_d6de1944:


    "Tutte cose che ti sono piaciute {i}in passato.{/i}"


translate ita goToCarnival_c3c9efe7:


    "Intorno a te ci sono gruppi di persone che si divertono assieme..."


translate ita goToCarnival_7598c0f4:


    "Ridono, giocano, mangiano, fanno foto... Costruiscono ricordi..."


translate ita goToCarnival_b0255334:


    "E poi ci sei tu."


translate ita goToCarnival_a20cefa7:


    "..."


translate ita goToCarnival_a7421486:


    "Il sole non sta tramontando, è ancora alto nel cielo, ma presto calerà."


translate ita goToCarnival_527d7f2b:


    "Cominci a chiederti se forse non sia arrivata l'ora di andare a casa... {w}quando ti arresti di colpo."


translate ita goToCarnival_2f469756:


    "Noti qualcosa di...{w} {i}inaspettato.{/i} {w}Un'attrazione mai vista prima."


translate ita goToCarnival_ee0a18bc:


    "Un labirinto di... specchi?"


translate ita goToCarnival_c0de53a5:


    "Sembra..."


translate ita goToCarnival_a20cefa7_1:


    "..."


translate ita goToCarnival_3a26a699:


    "... piuttosto noioso, a dire il vero."


translate ita goToCarnival_4686437f:


    "Non c'è nemmeno la coda all'entrata."


translate ita goToCarnival_a20cefa7_2:


    "..."


translate ita goToCarnival_cbb84cc7:


    "Ma d'altronde... {w}cos'altro hai da fare...?"


translate ita goToCarnival_ba0e6a77:


    "Deve esserci un modo migliore di passare la giornata che non sia vagare in mezzo a strani specchi..."


translate ita goToCarnival_16617c12:


    "E adesso?"


translate ita enteringMaze_1d094261:


    "Entri nel labirinto."


translate ita enteringMaze_8f41cd1a:


    "Dopo alcune stanze, ti rendi conto che non {i}tutti{/i} gli specchi sono strani."


translate ita enteringMaze_f78b0a7d:


    "Alcuni ti mostrano solo il {i}tuo{/i} riflesso."


translate ita enteringMaze_8d2086a8:


    "Noia... Tanta stanchezza... E molta, molta..."


translate ita enteringMaze_a20cefa7:


    "..."


translate ita enteringMaze_8dabefc6:


    ".."


translate ita enteringMaze_a20cefa7_1:


    "..."


translate ita enteringMaze_95cd8199:


    "... Forse è stato un errore."


translate ita enteringMaze_9712bff9:


    "Perché hai pensato che fosse una buona idea entrare in un labirinto di {b}specchi{/b}, anche se era un'esperienza nuova?"


translate ita enteringMaze_14d0b867:


    you "{i}Non... Non posso farcela oggi...{/i}"


translate ita enteringMaze_316b5d4c:


    "Ti giri per tornare fuori..."


translate ita enteringMaze_7515fb32:


    "... ma ti schianti contro uno specchio."


translate ita enteringMaze_97c66c9f:


    you "Ouch! Ma che...? Dov'è l'uscita?"


translate ita enteringMaze_b06acef3:


    "Provi di nuovo, ma c'è un altro specchio che ti blocca la strada."


translate ita enteringMaze_fbd47643:


    "Dopo averle provate tutte, realizzi che la strada che hai percorso non esiste più."


translate ita enteringMaze_632d1a35:


    you "!!!" with hpunch


translate ita enteringMaze_8dabefc6_1:


    ".."


translate ita enteringMaze_a20cefa7_2:


    "..."


translate ita enteringMaze_7d0d986d:


    you "V-Va bene, niente panico. Devo solo... proseguire... giusto?"


translate ita enteringMaze_c0fd94ff:


    "Passi per l'unica apertura che riesci a trovare e per poco non inciampi su qualcosa."


translate ita enteringMaze_d113f422:


    "Ti chini e lo prendi da terra."


translate ita enteringMaze_90b68c87:


    you "...?"


translate ita enteringMaze_1ec82967:


    you "E {i}questa{/i} che ci fa qui?"


translate ita enteringMaze_c5a1d33c:


    "Hai in mano una vecchia torcia."


translate ita enteringMaze_cab20fdf:


    "La accendi per curiosità."


translate ita enteringMaze_09d06ab8:


    "*Click*"


translate ita enteringMaze_dfb9ab96:


    "... {w}Uhm... {w}La luce non sembra molto-{w=1.0}{nw}"


translate ita enteringMaze_28b3ac41:


    you "!!!"


translate ita enteringMaze_ed7cc831:


    you "Cavolo! Le luci!"


translate ita enteringMaze_8f63ef28:


    "La corrente è saltata, oppure l'addetto si è dimenticato che sei qui dentro?"


translate ita enteringMaze_a20cefa7_3:


    "..."


translate ita enteringMaze_2babdbaa:


    "Da {i}quanto{/i} tempo sei qui, tra l'altro?"


translate ita enteringMaze_10b8c8d1:


    "Tiri fuori il telefono per controllare l'ora o magari per chiamare la polizia..."


translate ita enteringMaze_8dabefc6_2:


    ".."


translate ita enteringMaze_a20cefa7_4:


    "..."


translate ita enteringMaze_fe084e57:


    "{size=-6}Il telefono è scarico.{/size}"


translate ita enteringMaze_a20cefa7_5:


    "..."


translate ita enteringMaze_f293e828:


    "Stringi la torcia che hai in mano."


translate ita enteringMaze_776c58c3:


    "La luce che ha emesso prima era abbastanza debole da farti pensare che la batteria non durerà ancora a lungo."


translate ita enteringMaze_e64595f9:


    "Meglio risparmiarla per i momenti più difficili e andare a tentoni."


translate ita enteringMaze_60f2d28e:


    "Sì, dai, puoi farcela."


translate ita enteringMaze_ddbe6ff4:


    "Fai un respiro profondo."


translate ita enteringMaze_fb40dccf:


    you "{i}Bene. {w}Avanti tutta...{/i}"


translate ita enteringMaze_a20cefa7_6:


    "..."


translate ita goToDogPark_5c14c202:


    "Decidi di fare una passeggiata al parco o qualcosa del genere."


translate ita goToDogPark_e1880432:


    "Nelle vicinanze c'è solo un'area cani."


translate ita goToDogPark_31ab9223:


    "Pensi che ti solleverà l'umore."


translate ita goToDogPark_b35402c8:


    "Prima hai incontrato un gatto adorabile, adesso tocca a un cane adorabile!"


translate ita goToDogPark_a749d8ba:


    "A {i}molti{/i} cani, in realtà."


translate ita goToDogPark_3d36b825:


    "Il parco pullula di padroni con i loro compagni a quattro zampe."


translate ita goToDogPark_615bff09:


    "Giocano a frisbee, riportano la palla, corrono, saltano, alcuni sonnecchiano~!"


translate ita goToDogPark_9df30f1c:


    "Che carini-{w=0.5}{nw}"


translate ita goToDogPark_40780276:


    "{size=-8}{b}Che importa. {w}Non vuoi avere niente a che fare con questi cagnacci rognosi.{/b}{/size}"


translate ita goToDogPark_a2a49044:


    you "{i}...?!?{/i}"


translate ita goToDogPark_a20cefa7:


    "..."


translate ita goToDogPark_0b798a8a:


    "... Che succede?"


translate ita goToDogPark_58b82d2c:


    "Perché pensare una cosa simile?"


translate ita goToDogPark_8dabefc6:


    ".."


translate ita goToDogPark_a20cefa7_1:


    "..."


translate ita goToDogPark_50754116:


    "Decidi di proseguire."


translate ita goToDogPark_c5900d2a:


    "I cani che vedi sono dolcissimi. Vorresti accarezzare ogni pelosetto che incontri..."


translate ita goToDogPark_e4211dcf:


    "... ma sai che non tutti i padroni apprezzano gli sconosciuti che si avvicinano per strapazzare i loro animali."


translate ita goToDogPark_4f5fba4a:


    "Nemmeno i cani li apprezzano a volte."


translate ita goToDogPark_4f7be349:


    "Così passeggi per il parco, cercando di emanare vibrazioni positive che convincano uno dei cagnolini a venirti incontro."


translate ita goToDogPark_3dd44abb:


    "Non devi aspettare molto."


translate ita goToDogPark_1176e05a:


    who "Bau!"


translate ita goToDogPark_08c12ebd:


    "Ti fermi mentre il cucciolo più carino e tenero che tu abbia mai visto zampetta verso di te, bloccandoti la strada~"


translate ita puppyMenu_11e3ab75:


    who "{b}sì via via via i cani sono stupidi meritano tutti di-{/b}{w=1.5}{nw}"


translate ita puppyMenu_16617c12:


    "E adesso?"


translate ita puppyMenu_4289f415:


    you "{i}... Come?!? Ma è solo un cucciolo!{/i}"


translate ita puppyMenu_8ca8510a:


    you "!!!" with vpunch


translate ita puppyMenu_c19f215c:


    you "{i}{b}NO!{/b} Che cosa orribile!!!{/i}"


translate ita puppyMenu_8ca8510a_1:


    you "!!!" with vpunch


translate ita puppyMenu_90c2904a:


    you "{i}Disgustoso! Mi viene da vomitare...{/i}"


translate ita dontHurtPuppy_592a1c9d:


    you "{i}Non farei {b}mai{/b} una cosa del genere!{/i}"


translate ita pickUpPup_eef93c07:


    "Prendi in braccio il cucciolo e-{w=0.75}{nw}"


translate ita time_outPup_cc83c025:


    you "AAAHH!" with hpunch


translate ita time_outPup_2458cb0a:


    "In preda al terrore, lasci cadere il cucciolo... {w}praticamente gettandolo."


translate ita time_outPup_20de8723:


    "Ti senti una persona orribile e sussulti non appena senti il piccolo latrato che emette quando colpisce il terreno."


translate ita time_outPup_23e2545d:


    "Il padrone ti spinge via con un'occhiata di fuoco e se ne va di corsa con il suo cucciolo."


translate ita time_outPup_529cf39a:


    you "M-Mi dispiace!"


translate ita time_outPup_4eef1ef7:


    "Gridi, ma lui non si volta o risponde."


translate ita time_outPup_7d44f3d1:


    "Non ti aspettavi lo facesse comunque."


translate ita time_outPup_30fdc351:


    "Te lo {i}meriti{/i}."


translate ita heldPup_8ca8510a:


    you "!!!" with vpunch


translate ita heldPup_8dabefc6:


    ".."


translate ita heldPup_a20cefa7:


    "..."


translate ita heldPup_209b2328:


    "Riesci a reprimere con fatica l'impulso di gettare il cucciolo il più lontano possibile."


translate ita heldPup_dae0ec55:


    you "..."


translate ita heldPup_54632163:


    "Con mani tremanti, adagi il cucciolo sull'erba e fai qualche balzo indietro."


translate ita heldPup_3b0e2416:


    "Il padrone sembra confuso dalla tua reazione, {w}ma tu ti limiti a salutare con un gesto assente e corri via incespicando."


translate ita leavePark1_dae0ec55:


    you "..."


translate ita leavePark1_6b46ce4b:


    "La passeggiata al parco non ti fa sentire alla grande. Forse dovresti {b}andartene{/b}?"


translate ita leavePark1_a20cefa7:


    "..."


translate ita leavePark1_c5fa6fdf:


    "Bene."


translate ita leavePark1_8dabefc6:


    ".."


translate ita leavePark1_a20cefa7_1:


    "..."


translate ita stayAtPark_8dabefc6:


    ".."


translate ita stayAtPark_a20cefa7:


    "..."


translate ita stayAtPark_a20cefa7_1:


    "..."


translate ita stayAtPark_7af3e563:


    "{size=+32}{b}RIMANI AL PARCO.{/b}{/size}"


translate ita stayAtPark_dae0ec55:


    you "..."


translate ita stayAtPark_2ae435aa:


    "Cerchi di calmarti guardando i cani da lontano mentre cammini..."


translate ita stayAtPark_e94f558f:


    "... ma di tanto in tanto, uno di loro ti viene incontro..."


translate ita stayAtPark_f578fbad:


    "E quando lo fa, il cane ha qualcosa di..."


translate ita stayAtPark_26921232:


    "... sbagliato."


translate ita stayAtPark_659594cd:


    "I loro padroni non sembrano notarlo."


translate ita stayAtPark_f9b5bdd2:


    "Trovi una panchina e ti siedi per una breve pausa, chiudendo gli occhi."


translate ita stayAtPark_7cc99210:


    "Forse... {w}non è stata una buona idea venire qui."


translate ita stayAtPark_5917d0bd:


    "Forse..."


translate ita stayAtPark_a20cefa7_2:


    "..."


translate ita stayAtPark_a20cefa7_3:


    "..."


translate ita stayAtPark_8442ca13:


    "d o v e v i \ r e s t a r e \ c o n \ m e"


translate ita stayAtPark_dae0ec55_1:


    you "..."


translate ita stayAtPark_a20cefa7_4:


    "..."


translate ita stayAtPark_90b68c87:


    you "...?"


translate ita stayAtPark_895c5168:


    "Le tue riflessioni si interrompono quando qualcosa ti atterra delicatamente in grembo."


translate ita stayAtPark_0a7e463f:


    "Guardi in basso e vedi un frisbee sulle tue gambe."


translate ita stayAtPark_1221e21a:


    who "Ehi! Scusa, non volevo! Potresti lanciarlo indietro?"


translate ita stayAtPark_bbb377a7:


    "Alzi lo sguardo e noti un padrone che gesticola in lontananza..."


translate ita stayAtPark_200e4ba1:


    "Ma soprattutto..."


translate ita stayAtPark_60fece2b:


    dog "Bau! Bau! {b}Bau!!!{/b}" with hpunch


translate ita stayAtPark_90b68c87_1:


    you "...?"


translate ita stayAtPark_594ff454:


    dog "Bau!{w=0.5}{nw}" with hpunch


translate ita stayAtPark_594ff454_1:


    dog "Bau!{w=0.5}{nw}" with hpunch


translate ita stayAtPark_594ff454_2:


    dog "Bau!{w=0.5}{nw}" with hpunch


translate ita stayAtPark_467ad46e:


    "Una serie di ululati di gioia catturano la tua attenzione, e vedi un grosso cane che corre verso di te."


translate ita stayAtPark_dae0ec55_2:


    you "..."


translate ita stayAtPark_264ae177:


    dog "bau bau bau bau bau bau bau bau bau bau bau bau bau bau bau bau bau bau bau bau bau"


translate ita stayAtPark_8dabefc6_1:


    ".."


translate ita stayAtPark_a20cefa7_5:


    "..."


translate ita stayAtPark_b6c8c1b0:


    "Una serie di ululati di gioia catturano la tua attenzione, e vedi un grosso \ {b}c a n e{/b} \ che corre verso di te."


translate ita stayAtPark_85913fb3:


    who "E-Ehi! Sbrigati a tirarlo!"


translate ita stayAtPark_af2033bb:


    you "Oh! Ugh...!"


translate ita stayAtPark_a20cefa7_6:


    "..."


translate ita stayAtPark_5aa3617c:


    "Bene. E non tornare."


translate ita stayAtPark_8dabefc6_2:


    ".."


translate ita stayAtPark_a20cefa7_7:


    "..."


translate ita didntThrowFrisbee_632d1a35:


    you "!!!" with hpunch


translate ita didntThrowFrisbee_519d8628:


    "Il cane ti attacca improvvisamente, arrabbiato... {b}feroce{/b}..."


translate ita didntThrowFrisbee_ea9a7b78:


    "Ti strappa gli arti dal {color=#FF0000}corpo-{/color}{w=0.6}{nw}"


translate ita didntThrowFrisbee_8ca8510a:


    you "!!!" with vpunch


translate ita didntThrowFrisbee_a20cefa7:


    "..."


translate ita didntThrowFrisbee_38dcb322:


    you "{i}È... {w}successo davvero...?{/i}"


translate ita threwFrisbee_0420908d:


    "Lanci il frisbee e il cane corre in direzione opposta..."


translate ita threwFrisbee_5d168864:


    "... prima di saltare e prenderlo al volo."


translate ita threwFrisbee_8dabefc6:


    ".."


translate ita threwFrisbee_a20cefa7:


    "..."


translate ita threwFrisbee_25aa3339:


    "Notevole."


translate ita threwFrisbee_b51ea75d:


    "Il cane e il padrone ti raggiungono."


translate ita threwFrisbee_d0cab412:


    who "Grazie per l'aiuto. Puoi accarezzarlo, se vuoi!"


translate ita threwFrisbee_8b661a0a:


    "Il cane ti guarda, impaziente di ricevere una rincompensa in coccole per aver acchiappato il frisbee."


translate ita threwFrisbee_dae0ec55:


    you "..."


translate ita threwFrisbee_0cee522d:


    you "{i}Dovrei...?{/i}"


translate ita threwFrisbee_8dabefc6_1:


    ".."


translate ita threwFrisbee_a20cefa7_1:


    "..."


translate ita threwFrisbee_f5df0148:


    "Saggia decisione."


translate ita threwFrisbee_8dabefc6_2:


    ".."


translate ita threwFrisbee_a20cefa7_2:


    "..."


translate ita threwFrisbee_8dabefc6_3:


    ".."


translate ita threwFrisbee_a20cefa7_3:


    "..."


translate ita threwFrisbee_f5df0148_1:


    "Saggia decisione."


translate ita threwFrisbee_8dabefc6_4:


    ".."


translate ita threwFrisbee_a20cefa7_4:


    "..."


translate ita threwFrisbee_8dabefc6_5:


    ".."


translate ita threwFrisbee_a20cefa7_5:


    "..."


translate ita threwFrisbee_f5df0148_2:


    "Saggia decisione."


translate ita threwFrisbee_8dabefc6_6:


    ".."


translate ita threwFrisbee_a20cefa7_6:


    "..."


translate ita threwFrisbee_8dabefc6_7:


    ".."


translate ita threwFrisbee_a20cefa7_7:


    "..."


translate ita threwFrisbee_f5df0148_3:


    "Saggia decisione."


translate ita threwFrisbee_8dabefc6_8:


    ".."


translate ita threwFrisbee_a20cefa7_8:


    "..."


translate ita threwFrisbee_8dabefc6_9:


    ".."


translate ita threwFrisbee_a20cefa7_9:


    "..."


translate ita threwFrisbee_f5df0148_4:


    "Saggia decisione."


translate ita threwFrisbee_8dabefc6_10:


    ".."


translate ita threwFrisbee_a20cefa7_10:


    "..."


translate ita threwFrisbee_8dabefc6_11:


    ".."


translate ita threwFrisbee_a20cefa7_11:


    "..."


translate ita threwFrisbee_f5df0148_5:


    "Saggia decisione."


translate ita threwFrisbee_8dabefc6_12:


    ".."


translate ita threwFrisbee_a20cefa7_12:


    "..."


translate ita threwFrisbee_8dabefc6_13:


    ".."


translate ita threwFrisbee_a20cefa7_13:


    "..."


translate ita threwFrisbee_f5df0148_6:


    "Saggia decisione."


translate ita threwFrisbee_8dabefc6_14:


    ".."


translate ita threwFrisbee_a20cefa7_14:


    "..."


translate ita lastChance_a20cefa7:


    "..."


translate ita lastChance_be011780:


    "Davvero?"


translate ita lastChance_12c3bc88:


    "Vuoi farlo davvero?"


translate ita lastChance_8dabefc6:


    ".."


translate ita lastChance_a20cefa7_1:


    "..."


translate ita lastChance_e5bcb204:


    "Ti avverto."


translate ita lastChance_7a59abb9:


    "{b}Non{/b} toccare quel cagnaccio..."


translate ita lastChance_3f44ff49:


    "{size=-10}... o te ne {b}pentirai{/b}.{/size}"


translate ita lastChance_8dabefc6_1:


    ".."


translate ita lastChance_a20cefa7_2:


    "..."


translate ita lastChance_6f0c5ba2:


    "{size=+5}{b}B e n e.{/b}{/size}"


translate ita lastChance_8dabefc6_2:


    ".."


translate ita lastChance_a20cefa7_3:


    "..."


translate ita petTheDog_8dabefc6:


    ".."


translate ita petTheDog_a20cefa7:


    "..."


translate ita petTheDog_b546b376:


    "Allunghi la mano..."


translate ita petTheDog_8dabefc6_1:


    ".."


translate ita petTheDog_a20cefa7_1:


    "..."


translate ita petTheDog_e3a5738f:


    "... e accarezzi il \ {b}c a n e.{/b}"


translate ita petTheDog_dae0ec55:


    you "..."


translate ita petTheDog_2f6d34a3:


    dog "ARF! ARF!" with vpunch


translate ita petTheDog_2b8101ea:


    "Il cane sembra compiaciuto."


translate ita petTheDog_8dabefc6_2:


    ".."


translate ita petTheDog_a20cefa7_2:


    "..."


translate ita petTheDog_92c9b5da:


    "Non ti senti bene."


translate ita petTheDog_f8342e66:


    "D'un tratto..."


translate ita petTheDog_8802d801:


    "... il cielo si oscura."


translate ita petTheDog_73f12812:


    "Guardi il cielo assieme ai padroni dei cani solo per scoprire che il sole è stato eclissato dalla luna in un battito di ciglia."


translate ita petTheDog_ff907ae0:


    "Ti ricordi vagamente che non dovresti osservare un'eclissi a occhio nudo... {w}ma per qualche ragione..."


translate ita petTheDog_906bee7c:


    "... non distogli lo sguardo."


translate ita petTheDog_9ddc62b3:


    who "{size=+35}{b}REOWWWWRRRRR!!!{/b}{/size}" with vpunch


translate ita petTheDog_34554171:


    "Un urlo assordante perfora l'aria, facendo tremare il terreno sotto di te."


translate ita petTheDog_509639fb:


    "Ti muovi d'istinto per ripararti le orecchie con le mani..."


translate ita petTheDog_bf0874e3:


    "Ma..."


translate ita petTheDog_4e2b93b2:


    "... ma le mani che accarezzavano la testa del cane si muovono..."


translate ita petTheDog_982bff5c:


    "... {b}a fatica.{/b}"


translate ita petTheDog_990002ee:


    "... {i}A fatica{/i} per colpa di una colla che appiccica il tuo palmo alla testa del cane."


translate ita petTheDog_8ca8510a:


    you "!!!" with vpunch


translate ita petTheDog_2917a3d2:


    "La colla si allunga con i tuoi movimenti."


translate ita petTheDog_caf85056:


    "Anche la {i}testa{/i} del cane si allunga... e l'animale comincia a..."


translate ita petTheDog_680a68f3:


    "... {b}sciogliersi.{/b}"


translate ita petTheDog_8c69f73c:


    "Si scioglie..."


translate ita petTheDog_027c5d74:


    "{b}irrimediabilmente{/b}..."


translate ita petTheDog_8dabefc6_3:


    ".."


translate ita petTheDog_a20cefa7_3:


    "..."


translate ita petTheDog_d5860291:


    "... finché non diventa una roba viscida ai tuoi piedi."


translate ita petTheDog_d1718122:


    you "Ah...! Ah..."


translate ita petTheDog_11b3323e:


    "Ti guardi attorno con stupore in cerca del padrone, ma trovi solo una pila di vestiti al suo posto."


translate ita petTheDog_02dce559:


    "Disseminati nel parco, vedi mucchi di vestiti simili accompagnati da ammassi di roba viscida."


translate ita petTheDog_91eaf471:


    "Tutti i cani..."


translate ita petTheDog_ce3e3588:


    "Tutti i padroni..."


translate ita petTheDog_a20cefa7_4:


    "..."


translate ita petTheDog_4b8cc143:


    "La sostanza viscida del cane davanti a te viene scossa da un tremito."


translate ita petTheDog_632d1a35:


    you "!!!" with hpunch


translate ita petTheDog_ae1a0e2d:


    "Striscia nell'erba per andare al centro del parco..."


translate ita petTheDog_9d855a0a:


    "{size=-5}Il resto degli ammassi viscidi fanno lo stesso...{/size}"


translate ita petTheDog_74d9ed3c:


    "Si fondono assieme per creare un unico essere che muta, ondeggia, si gonfia e {b}cresce{/b}..."


translate ita petTheDog_56ebb028:


    you "!!!"


translate ita petTheDog_14c0cd48:


    "Lo fissi con orrore mentre si riempie e prende la forma..."


translate ita petTheDog_4f09ae08:


    "... di un cane{size=+5} {b}gigantesco{/b}{/size}."


translate ita petTheDog_f6366ef7:


    "Ringhia con la bava alla bocca... e i suoi occhi si muovono freneticamente..."


translate ita petTheDog_a20cefa7_5:


    "..."


translate ita petTheDog_40b96f53:


    "... fino ad arrestarsi su di te."


translate ita petTheDog_4a61b65e:


    who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}{w=0.2}{nw}" with hpunch


translate ita petTheDog_8d3a4df3:


    who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}{w=0.2}{nw}" with vpunch


translate ita petTheDog_3c469b8e:


    who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}" with hpunch


translate ita petTheDog_6f38f7c1:


    "Il ringhio che emette è così cupo e profondo che ti senti schiacciare..."


translate ita petTheDog_8dabefc6_4:


    ".."


translate ita petTheDog_a20cefa7_6:


    "..."


translate ita petTheDog_bcf6dd4d:


    "No."


translate ita petTheDog_6fc296fe:


    "Hai avuto la tua chance."


translate ita petTheDog_7c3bd630:


    "{b}{size=-10}M e g l i o{/size}{size=+20} \ {/size}{size=-10}s e{/size}{size=+20} \ {/size}{size=-10}c o r r i~{/size}{/b}"


translate ita petTheDog_8dabefc6_5:


    ".."


translate ita petTheDog_a20cefa7_7:


    "..."


translate ita justRunDog_512655b9:


    "Cerchi di correre."


translate ita justRunDog_a20cefa7:


    "..."


translate ita justRunDog_ecb852e9:


    "{size=-8}... Ma non sei abbastanza veloce.{/size}"


translate ita justRunDog_16f8c477:


    "Il mostro fa un paio di balzi e ti sovrasta."


translate ita justRunDog_8ca8510a:


    you "!!!" with vpunch


translate ita justRunDog_38a2a096:


    you "...!" with vpunch


translate ita justRunDog_fa171d08:


    you "..." with vpunch


translate ita justRunDog_8dabefc6:


    ".."


translate ita justRunDog_a20cefa7_1:


    "..."


translate ita justRunDog_cd0aadea:


    "Ti fa a pezzi finché di te non rimane più {b}niente{/b}."


translate ita justRunDog_8dabefc6_1:


    ".."


translate ita justRunDog_a20cefa7_2:


    "..."


translate ita justRunDog_d7087055:


    "Finale 21: Amante dei \ {color=#FF0000}c a n i{/color}"


translate ita turnedBack_f75320e6:


    "Sospiri e torni dal gatto."


translate ita turnedBack_d26d3e42:


    cat "Miao! Miiaooo!" with hpunch


translate ita turnedBack_08f3a6f7:


    "Sembra disperato... la sua coda ondeggia veloce mentre si piega verso di te..."


translate ita turnedBack_3df2e65f:


    "... come ad aspettare la tua prossima mossa."


translate ita stayWithCat_dae0ec55:


    you "..."


translate ita stayWithCat_cba272fa:


    "... Strano."


translate ita stayWithCat_9be0e991:


    "Più resti fermo nel vicolo... più ti ritrovi a domandarti..."


translate ita stayWithCat_17dfe7fb:


    "... {i}\"Che senso avrebbe?\"{/i}"


translate ita stayWithCat_a7dcd07a:


    "Dove {i}andresti?{/i}"


translate ita stayWithCat_1c44447e:


    "A fare {i}cosa?{/i}"


translate ita stayWithCat_3e3445a0:


    "Che senso avrebbe, visto che passi il tempo sempre e comunque {i}in solitudine?{/i}"


translate ita stayWithCat_780c15a3:


    "Anche tornare al tuo appartamento non aiuterebbe, vero?"


translate ita stayWithCat_247ad3ce:


    "Una camera da letto. Un bagno."


translate ita stayWithCat_2b464023:


    "... Ci vivi {i}tu{/i}, tu e basta."


translate ita stayWithCat_53cba332:


    "La situazione è così da tanto tempo..."


translate ita stayWithCat_a20cefa7:


    "..."


translate ita stayWithCat_2ce5ae19:


    "{i}Tanto{/i} tempo..."


translate ita stayWithCat_aa965c11:


    cat "Miaoo..."


translate ita stayWithCat_38a2a096:


    you "...!" with vpunch


translate ita stayWithCat_cb2e56dc:


    "Ti accorgi con stupore che ha posato una zampetta incredibilmente soffice sulla tua guancia bagnata."


translate ita stayWithCat_a20cefa7_1:


    "..."


translate ita stayWithCat_e92a5260:


    "Ti accorgi solo adesso che stavi piangendo."


translate ita stayWithCat_6b313aa1:


    "E che la tua piccola crisi ti ha messo in ginocchio, letteralmente... proprio davanti allo scatolone del gatto."


translate ita stayWithCat_7a5c58a5:


    "La cosa ti imbarazza, ma il gatto reagisce come se avesse percepito l'umiliazione che si fa strada dentro di te."


translate ita stayWithCat_fbbaa7ef:


    cat "Miao! Miao!" with hpunch


translate ita stayWithCat_59ede497:


    "Preme la zampa sulla tua guancia per tre volte rapidamente..."


translate ita stayWithCat_b17e43f8:


    "... come per risvegliarti dal tuo stato malinconico..."


translate ita stayWithCat_11b3d26b:


    "... ma è così morbida che gli schiaffi assomigliano più a tenere carezze."


translate ita stayWithCat_dae0ec55_1:


    you "..."


translate ita stayWithCat_c1ba2b2d:


    you "Eh... Eheh..."


translate ita stayWithCat_c169d67d:


    "Non puoi fare a meno di ridacchiare."


translate ita stayWithCat_43d916f4:


    you "È assurdo che io abbia un tracollo in un vicolo vecchio e sporco... con un gatto randagio che mi consola..."


translate ita stayWithCat_e5fab8a0:


    cat "Miao!"


translate ita stayWithCat_a0caf1eb:


    "Sorridi e mostri la tua riconoscenza dando una grattatina al mento del gatto."


translate ita stayWithCat_67107e6c:


    cat "Purr..."


translate ita stayWithCat_b6d97d6f:


    you "Grazie... Sto bene, davvero. Mi capita a volte..."


translate ita stayWithCat_16879ce5:


    cat "Miao?"


translate ita stayWithCat_b9131292:


    you "Mi piace {i}sul serio{/i} stare per conto mio, la maggior parte del tempo."


translate ita stayWithCat_638b0480:


    you "È l'unico modo che ho di sentirmi a mio agio, capisci?"


translate ita stayWithCat_bac70924:


    you "... Ma perfino {i}io{/i} soffro la solitudine di tanto in tanto."


translate ita stayWithCat_5bf669ab:


    you "Quando ho la giornata indaffarata non ci penso..."


translate ita stayWithCat_2ba4676d:


    you "Ecco perché ho deciso di uscire oggi, credo..."


translate ita stayWithCat_085f82bc:


    cat "Miao..."


translate ita stayWithCat_94d526e4:


    you "Mah, forse invece speravo di trovare un amico o qualcosa del genere..."


translate ita stayWithCat_7393f44f:


    you "... anche se non sarebbe una buona idea, immagino."


translate ita stayWithCat_623ea201:


    you "Dubito che una persona come me potrebbe essere una buona amicizia per qualcuno..."


translate ita stayWithCat_33634540:


    cat "Miao! Miao! {i}Miao!{/i}" with hpunch


translate ita stayWithCat_37101878:


    you "Eheheh! Va bene, va bene, non è il caso di {i}esagerare,{/i} ma..."


translate ita stayWithCat_8dabefc6:


    ".."


translate ita stayWithCat_a20cefa7_2:


    "..."


translate ita stayWithCat_e7e24fe2:


    "Rimani."


translate ita stayWithCat_319a0073:


    "Rimani e... parli con il gatto."


translate ita stayWithCat_16f8a04a:


    "Di tutto quello che ti passa per la testa."


translate ita stayWithCat_42df3336:


    "Del tuo isolamento... {w}della tua solitudine..."


translate ita stayWithCat_297381cd:


    "Delle tue paure... {w}delle tue sconfitte... {w}del tuo senso di {i}vuoto{/i}..."


translate ita stayWithCat_8dc6e13c:


    "Eppure..."


translate ita stayWithCat_ecd85097:


    "Più a lungo rimani lì... più piccolo diventa quel vuoto interiore che provi."


translate ita stayWithCat_bd68e443:


    "Era da tanto che qualcuno non ti... ascoltava."


translate ita stayWithCat_152f4e90:


    "I tuoi discorsi virano su tematiche positive..."


translate ita stayWithCat_ae2b8e89:


    "Speranze... {w}sogni... {w}ricordi felici..."


translate ita stayWithCat_92865e06:


    "Mentre parli, non ti accorgi nemmeno che le pareti di cemento freddo del vicolo diventano simili a carne... {w}calda e rosa..."


translate ita stayWithCat_87393f7d:


    "... e che entrambi iniziate a essere inglobati da quella massa morbida."


translate ita stayWithCat_8a1fe200:


    "Il suono della tua stessa voce sembra quasi ipnotico..."


translate ita stayWithCat_fff68cb0:


    "... e ti incoraggia a parlare apertamente di ciò che si cela nel profondo del tuo cuore..."


translate ita stayWithCat_0e2e8677:


    "Ti arrendi facilmente..."


translate ita stayWithCat_e7e1c877:


    "Quando {i}smetti{/i} di parlare, ti rendi conto di aver perso la nozione del tempo. "


translate ita stayWithCat_0e608ebb:


    "Ma questo non sembra essere un problema per te."


translate ita stayWithCat_b3e12ea5:


    "Eppure..."


translate ita stayWithCat_eb93532e:


    "Una strana domanda si fa largo nella tua testa..."


translate ita stayForever_8dabefc6:


    ".."


translate ita stayForever_a20cefa7:


    "..."


translate ita stayForever_dae0ec55:


    you "..."


translate ita stayForever_30bd3818:


    you "{i}Perché dovrei volerlo fare...?{/i}"


translate ita stayForever_a654ceef:


    "La stanchezza prende il sopravvento."


translate ita stayForever_9655b73f:


    "Mettere a nudo il tuo cuore e la tua anima ti ha sorprendentemente provato, ma non hai alcun rimpianto."


translate ita stayForever_411ac15d:


    "Ti senti così..."


translate ita stayForever_27a37757:


    "... felice."


translate ita stayForever_1fa1c68c:


    "Forse nessuno ti aveva mai ascoltato così..."


translate ita stayForever_177b5180:


    "O {i}capito{/i} in questo modo..."


translate ita stayForever_925e7315:


    "Chini il capo per far riposare la testa sulla scatola."


translate ita stayForever_0acae387:


    "Il cartone non è ruvido come ti aspettavi..."


translate ita stayForever_4d5b0ea2:


    "La tua testa è appoggiata su... {i}qualcosa di...{/i}"


translate ita stayForever_a51bed06:


    "Morbido, leggermente umido e caldo."


translate ita stayForever_b873f6ae:


    "Tanto, {i}tanto{/i} caldo..."


translate ita stayForever_e8057081:


    "Ma non ti interessa sapere di che cosa si tratta."


translate ita stayForever_bc4c2b4d:


    "Hai... molto sonno."


translate ita stayForever_dec216e1:


    "Chiudi gli occhi..."


translate ita stayForever_bcb743d5:


    "... e qualcosa ti dice che non li riaprirai mai più."


translate ita stayForever_9fb636b8:


    "Mentre il calore ti avvolge piano piano, {i}completamente{/i}..."


translate ita stayForever_a20cefa7_1:


    "..."


translate ita stayForever_6c8098ae:


    "... provi solo pura soddisfazione. "


translate ita stayForever_8dabefc6_1:


    ".."


translate ita stayForever_a20cefa7_2:


    "..."


translate ita stayForever_2dacdaff:


    "Finale 22: In Compagnia"


translate ita leaveCat2_62d83bb2:


    "Non puoi {i}davvero{/i} permetterti di portare il gatto a casa."


translate ita leaveCat2_bfab167e:


    "Beh..."


translate ita leaveCat2_35db1bfe:


    "Forse non è {i}del tutto{/i} impossibile..."


translate ita leaveCat2_45d354de:


    "Un taglio qua e là a qualche spesa extra e magari le cose potrebbero funzionare."


translate ita leaveCat2_b03adc09:


    "C'è solo un piccolo problema che ti ha fatto vacillare per tutto questo tempo... "


translate ita leaveCat2_0af247dd:


    "Una cosa che semplicemente non puoi ignorare."


translate ita leaveCat2_8335c1ba:


    "Il problema è che..."


translate ita leaveCat2_a20cefa7:


    "..."


translate ita leaveCat2_e43e2eb3:


    "{size=-10}... tu non ti fidi di questo gatto.{/size}"


translate ita leaveCat2_dae0ec55:


    you "..."


translate ita leaveCat2_9bd5d3d6:


    " Sembra ridicolo anche solo pensarlo."


translate ita leaveCat2_35a1162a:


    "Non devi fidarti di un gatto per prendertene cura."


translate ita leaveCat2_6e2bb326:


    "Non sono capaci di tradirti o ingannarti, soprattutto perché, come tutti gli altri animali... "


translate ita leaveCat2_4a2b5d96:


    "... si preoccupano solo di sopravvivere, riprodursi e stare comodi."


translate ita leaveCat2_03e4f8cf:


    "Di solito, la malvagità non è nella natura dei gatti..."


translate ita leaveCat2_da78fda5:


    "Eppure..."


translate ita leaveCat2_c353258e:


    "Tu lo senti."


translate ita leaveCat2_172fd88c:


    "Senti che dietro quell'adorabile musetto strappalacrime..."


translate ita leaveCat2_95ccc501:


    "... c'è qualcosa di pericoloso."


translate ita leaveCat2_f41ec9ee:


    "E quel \"qualcosa\"... ti ha portato qui. "


translate ita leaveCat2_6b709127:


    "Ti ha {i}attirato{/i} qui."


translate ita leaveCat2_cc7203ce:


    "Sei una persona curiosa, ma persino {i}tu{/i} non riesci a scrollarti di dosso quel desiderio di-"


translate ita leaveCat2_7844b763:


    "{size=-10}vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via {/size}"


translate ita leaveCat2_dae0ec55_1:


    you "..."


translate ita leaveCat2_7f0ac95c:


    cat "..."


translate ita leaveCat2_ec8eee8f:


    "Lo sguardo del gatto sembra spento."


translate ita leaveCat2_f138e706:


    "Non è la prima volta che un gatto ti guarda così, ma stavolta sembra..."


translate ita leaveCat2_9232c2e0:


    "{size=-5}{i}... più tagliente.{/i}{/size}"


translate ita leaveCat2_f9e83d9e:


    "Come se ti leggesse nel pensiero e sapesse che vuoi andare via..."


translate ita leaveCat2_26b934d7:


    "... e ti stesse sfidando a {b}provarci.{/b} "


translate ita leaveCat2_dae0ec55_2:


    you "..."


translate ita leaveCat2_1d0166ae:


    "Ti alzi lentamente."


translate ita leaveCat2_428f29c1:


    "Il gatto segue i tuoi movimenti con lo sguardo, senza disturbarsi a muovere la testa."


translate ita leaveCat2_0e2ae1c1:


    "Non dici nulla."


translate ita leaveCat2_7ca87e19:


    "Cerchi addirittura di non pensare..."


translate ita leaveCat2_7844b763_1:


    "{size=-10}vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via {/size}"


translate ita leaveCat2_a20cefa7_1:


    "..."


translate ita leaveCat2_58e3ca69:


    "... ma non ci riesci."


translate ita leaveCat2_8fd85953:


    "Ti volti e ti allontani velocemente dal vicolo, sentendoti addosso quello sguardo penetrante per tutto il tempo. "


translate ita leaveCat2_ec6bd7ee:


    "Quando sei abbastanza distante, riesci finalmente a respirare."


translate ita leaveCat2_83668abb:


    you "*anf*... *anf*... *anf*..."


translate ita leaveCat2_a20cefa7_2:


    "..."


translate ita leaveCat2_0f5de544:


    "Tu..."


translate ita leaveCat2_9d5e507d:


    "Ti senti meglio ora."


translate ita leaveCat2_336142e1:


    "E hai ancora tanto tempo per goderti il giorno libero!"


translate ita leaveCat2_8dabefc6:


    ".."


translate ita leaveCat2_a20cefa7_3:


    "..."


translate ita leaveCat2_e666a796:


    "A patto che tu riesca a dimenticare cosa è appena successo."


translate ita leaveCat2_33744274:


    "{b}Ma cosa fare?{/b}"


translate ita getAway1_e4612ec1:


    you "...!"


translate ita getAway1_7f0ac95c:


    cat "..."


translate ita getAway1_71b06060:


    "Ma che ca...?!?"


translate ita getAway1_5fd62bd2:


    "Come hai fatto a tornare lì?!?"


translate ita getAway1_a20cefa7:


    "..."


translate ita getAway1_f2809dbd:


    "{size=-10}{color=#FF0000}vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via {/color}{/size}"


translate ita getAway1_8dabefc6:


    ".."


translate ita getAway1_a20cefa7_1:


    "..."


translate ita getAway1_d4f2db8f:


    "Ti allontani dal vicolo. {i}Di corsa.{/i}"


translate ita getAway1_8dabefc6_1:


    ".."


translate ita getAway1_a20cefa7_2:


    "..."


translate ita getAway1_bcf48cbf:


    "E adesso...?"


translate ita getAway2_e4612ec1:


    you "...!"


translate ita getAway2_7f0ac95c:


    cat "..."


translate ita getAway2_82f0e91d:


    "Lo sguardo di quel gatto sembra..."


translate ita getAway2_a20cefa7:


    "..."


translate ita getAway2_f2809dbd:


    "{size=-10}{color=#FF0000}vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via {/color}{/size}"


translate ita getAway2_8dabefc6:


    ".."


translate ita getAway2_a20cefa7_1:


    "..."


translate ita getAway2_d4f2db8f:


    "Ti allontani dal vicolo. {i}Di corsa.{/i}"


translate ita getAway2_8dabefc6_1:


    ".."


translate ita getAway2_a20cefa7_2:


    "..."


translate ita getAway2_bcf48cbf:


    "E adesso...?"


translate ita getAway3_e4612ec1:


    you "...!"


translate ita getAway3_7f0ac95c:


    cat "..."


translate ita getAway3_82f0e91d:


    "Lo sguardo di quel gatto sembra..."


translate ita getAway3_a20cefa7:


    "..."


translate ita getAway3_f2809dbd:


    "{size=-10}{color=#FF0000}vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via {/color}{/size}"


translate ita getAway3_8dabefc6:


    ".."


translate ita getAway3_a20cefa7_1:


    "..."


translate ita getAway3_d4f2db8f:


    "Ti allontani dal vicolo. {i}Di corsa.{/i}"


translate ita getAway3_8dabefc6_1:


    ".."


translate ita getAway3_a20cefa7_2:


    "..."


translate ita getAway3_bcf48cbf:


    "E adesso...?"


translate ita getAway4_dd4a8909:


    you "...!" with hpunch


translate ita getAway4_7f0ac95c:


    cat "..."


translate ita getAway4_82f0e91d:


    "Lo sguardo di quel gatto sembra..."


translate ita getAway4_90b93b6a:


    "È..."


translate ita getAway4_a20cefa7:


    "..."


translate ita getAway4_f2809dbd:


    "{size=-10}{color=#FF0000}vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via vai via {/color}{/size}"


translate ita getAway4_52402223:


    cat "{b}miao miao miao miao miao miao miao miao miao miao miao miao miao miao{/b}"


translate ita getAway4_8dabefc6:


    ".."


translate ita getAway4_a20cefa7_1:


    "..."


translate ita getAway4_d4f2db8f:


    "Ti allontani dal vicolo. {i}Di corsa.{/i}"


translate ita getAway4_8dabefc6_1:


    ".."


translate ita getAway4_a20cefa7_2:


    "..."


translate ita getAway4_bcf48cbf:


    "E adesso...?"


translate ita goToMoviesFAKE_74698f4f:


    "È passato parecchio dall'ultima volta che è uscito un film abbastanza interessante da convincerti ad andare al cinema..."


translate ita goToMoviesFAKE_16041c5e:


    "... ma sembra ce ne sia uno proprio al vecchio cinema."


translate ita goToMoviesFAKE_86d53b16:


    "Il film era troppo di nicchia per essere proiettato nel nuovo cinema che ha aperto sull'altro lato della strada."


translate ita goToMoviesFAKE_b01bac60:


    "Non è un problema, però. Non stravedi per le folle."


translate ita goToMoviesFAKE_6430cdc2:


    "E non c'è niente di peggio per te che guardare un nuovo film con un pubblico rumoroso."


translate ita oldTheaterFAKE_2c8cdd54:


    "Compri con impazienza il biglietto dal vecchio all'entrata e prosegui all'interno..."


translate ita oldTheaterFAKE_8dabefc6:


    ".."


translate ita oldTheaterFAKE_a20cefa7:


    "..."


translate ita newCinemaFAKE_927147c9:


    "Non sai perché...{w} ma l'idea di restare per conto tuo non ti fa sentire molto bene, ora come ora."


translate ita newCinemaFAKE_fb646a70:


    "Decidi di aspettare che il film sia disponibile su DVD o in streaming..."


translate ita newCinemaFAKE_e6448215:


    "... e ti accodi alla lunga fila fuori dal nuovo cinema."


translate ita newCinemaFAKE_0f82186d:


    "Quando finalmente raggiungi la biglietteria, non vedi l'ora di entrare..."


translate ita newCinemaFAKE_78abbe21:


    "... così scegli un film a caso e compri il biglietto dall'adolescente con l'aria stanca dietro il bancone."


translate ita newCinemaFAKE_259b126d:


    "Entri..."


translate ita newCinemaFAKE_8dabefc6:


    ".."


translate ita newCinemaFAKE_a20cefa7:


    "..."


translate ita goToCarnivalFAKE_54663883:


    "Passi la giornata al luna park."


translate ita goToCarnivalFAKE_295775c9:


    "La ruota panoramica, le montagne russe, la nave pirata... {w}Tutte giostre che hai già provato."


translate ita goToCarnivalFAKE_0d9e8fc3:


    "Il canestro, il lancio della moneta, i dardi... {w}Tutti giochi a cui hai già giocato."


translate ita goToCarnivalFAKE_32a40a6e:


    "Mele caramellate, popcorn, zucchero filato... {w}Tutti cibi che hai già assaggiato."


translate ita goToCarnivalFAKE_d6de1944:


    "Tutte cose che ti sono piaciute {i}in passato.{/i}"


translate ita goToCarnivalFAKE_c3c9efe7:


    "Intorno a te ci sono gruppi di persone che si divertono assieme..."


translate ita goToCarnivalFAKE_7598c0f4:


    "Ridono, giocano, mangiano, fanno foto... Costruiscono ricordi..."


translate ita goToCarnivalFAKE_b0255334:


    "E poi ci sei tu."


translate ita goToCarnivalFAKE_a20cefa7:


    "..."


translate ita goToCarnivalFAKE_a7421486:


    "Il sole non sta tramontando, è ancora alto nel cielo, ma presto calerà."


translate ita goToCarnivalFAKE_527d7f2b:


    "Cominci a chiederti se forse non sia arrivata l'ora di andare a casa... {w}quando ti arresti di colpo."


translate ita goToCarnivalFAKE_2f469756:


    "Noti qualcosa di... {w} {i}inaspettato.{/i} {w}Un'attrazione mai vista prima."


translate ita goToCarnivalFAKE_ee0a18bc:


    "Un labirinto di... specchi?"


translate ita goToCarnivalFAKE_c0de53a5:


    "Sembra..."


translate ita goToCarnivalFAKE_3a26a699:


    "... piuttosto noioso, a dire il vero."


translate ita goToCarnivalFAKE_4686437f:


    "Non c'è nemmeno la coda all'entrata."


translate ita goToCarnivalFAKE_a20cefa7_1:


    "..."


translate ita goToCarnivalFAKE_cbb84cc7:


    "Ma d'altronde... {w}cos'altro hai da fare...?"


translate ita enteringMazeFAKE_d4f61e22:


    "Entri nel labirinto..."


translate ita enteringMazeFAKE_8dabefc6:


    ".."


translate ita enteringMazeFAKE_a20cefa7:


    "..."


translate ita goToDogParkFAKE_5c14c202:


    "Decidi di fare una passeggiata al parco o qualcosa del genere."


translate ita goToDogParkFAKE_184323de:


    "Nelle vicinanze c'è solo un'area cani."


translate ita goToDogParkFAKE_31ab9223:


    "Pensi che ti solleverà l'umore."


translate ita goToDogParkFAKE_b35402c8:


    "Prima hai incontrato un gatto adorabile, adesso tocca a un cane adorabile!"


translate ita goToDogParkFAKE_a749d8ba:


    "A {i}molti{/i} cani, in realtà."


translate ita goToDogParkFAKE_3d36b825:


    "Il parco pullula di padroni con i loro compagni a quattro zampe."


translate ita goToDogParkFAKE_615bff09:


    "Giocano a frisbee, riportano la palla, corrono, saltano, alcuni sonnecchiano~!"


translate ita goToDogParkFAKE_479e8904:


    "Che carini--{w=0.3}{nw}"


translate ita goToDogParkFAKE_9b32ff27:


    "{size=+25}{b}{i}I CANI SONO DISGUSTOSI!!!{/i}{/b}{/size}{w=0.8}{nw}" with hpunch


translate ita goToDogParkFAKE_f222b266:


    "{size=+30}{b}{i}DEVONO MORIREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE!!!{/i}{/b}{/size}{w=0.8}{nw}" with vpunch


translate ita goToDogParkFAKE_3d1b02dc:


    you "{i}!!!{/i}" with vpunch


translate ita goToDogParkFAKE_8dabefc6:


    ".."


translate ita goToDogParkFAKE_a20cefa7:


    "..."


translate ita goToDogParkFAKE_0f5de544:


    "Tu..."


translate ita goToDogParkFAKE_a20cefa7_1:


    "..."


translate ita goToDogParkFAKE_b21fc0cc:


    "{size=-8}Decidi di non pensarci.{/size}"


translate ita goToDogParkFAKE_c5900d2a:


    "I cani che vedi sono dolcissimi. Vorresti accarezzare ogni pelosetto che incontri..."


translate ita goToDogParkFAKE_e4211dcf:


    "... ma sai che non tutti i padroni apprezzano gli sconosciuti che si avvicinano per strapazzare i loro animali."


translate ita goToDogParkFAKE_4f5fba4a:


    "Nemmeno i cani li apprezzano a volte."


translate ita goToDogParkFAKE_4f7be349:


    "Così passeggi per il parco, cercando di emanare vibrazioni positive che convincano uno dei cagnolini a venirti incontro."


translate ita goToDogParkFAKE_3dd44abb:


    "Non devi aspettare molto."


translate ita goToDogParkFAKE_8dabefc6_1:


    ".."


translate ita goToDogParkFAKE_a20cefa7_2:


    "..."


translate ita goToDogParkFAKE_08c12ebd:


    "Ti fermi mentre il cucciolo più carino e tenero che tu abbia mai visto zampetta verso di te, bloccandoti la strada~"


translate ita pickUpPupFAKE_a20cefa7:


    "..."


translate ita pickUpPupFAKE_b6fd4c68:


    "Prendi in braccio il cucciolo e-"


translate ita pickUpPupFAKE_8dabefc6:


    ".."


translate ita pickUpPupFAKE_a20cefa7_1:


    "..."


translate ita escapeAlley_71862052:


    "... Aspetta."


translate ita escapeAlley_754ba1f6:


    "Non..."


translate ita escapeAlley_9c5945d1:


    "Non l'avevi già fatto prima?"


translate ita escapeAlley_a20cefa7:


    "..."


translate ita escapeAlley_eda5b581:


    "Non ti senti molto bene."


translate ita escapeAlley_a9ce0125:


    "Ti guardi intorno e all'improvviso ti accorgi che, a differenza di prima..."


translate ita escapeAlley_09fb1093:


    "... non c'è nessuno lì con te."


translate ita escapeAlley_39499d9b:


    "Nessun altro."


translate ita escapeAlley_107c4642:


    "Non c'è {i}assolutamente{/i} nessuno..."


translate ita escapeAlley_a20cefa7_1:


    "..."


translate ita escapeAlley_2d017637:


    "{size=-10}... Ma allora perché hai la sensazione che qualcuno ti stia guardando?{/size}"


translate ita escapeAlley_dae0ec55:


    you "..."


translate ita escapeAlley_24944022:


    "Il tuo cuore inizia a battere all'impazzata."


translate ita escapeAlley_167183bf:


    "Hai bisogno di tornare a casa."


translate ita escapeAlley_e42d7264:


    "{b}Subito.{/b}"


translate ita escapeAlley_d2c662af:


    "Torni verso casa e la sensazione di avere degli occhi puntati addosso peggiora a ogni passo."


translate ita escapeAlley_c746b9ce:


    "Mentre lotti con le chiavi di casa, inizi a sudare freddo."


translate ita escapeAlley_c6dde281:


    "La pelle inizia a pizzicarti..."


translate ita escapeAlley_173b31a9:


    "... gli occhi che senti addosso sembrano premuti fisicamente sulla tua carne... {w}appiccicosi e innaturali."


translate ita escapeAlley_a73461a6:


    "Finalmente riesci a entrare e..."


translate ita escapeAlley_8dabefc6:


    ".."


translate ita escapeAlley_a20cefa7_2:


    "..."


translate ita escapeAlley_bfcb9214:


    you "Fiuu...!" with hpunch


translate ita escapeAlley_9200f492:


    "Il {b}profondo{/b} sospiro di sollievo che ti esce dalle labbra ti fa {i}rabbrividire.{/i}"


translate ita escapeAlley_9a73ee02:


    "Quell'orribile sensazione che avvertivi prima svanisce, come non fosse mai esistita."


translate ita escapeAlley_940938e5:


    "Resti lì, tremando per il freddo nei tuoi vestiti bagnati di sudore..."


translate ita escapeAlley_d1777533:


    "... ma ti senti così bene che non ti interessa."


translate ita escapeAlley_c0c88e96:


    "Ti senti KO, non consideri nemmeno {i}l'idea{/i} di mangiare e vai subito in camera da letto."


translate ita escapeAlley_dae0ec55_1:


    you "..."


translate ita escapeAlley_935de6d6:


    "Apri la porta, vuoi metterti subito a dorm--{w=0.75}{nw}"


translate ita escapeAlley_7f0ac95c:


    cat "..."


translate ita escapeAlley_8ca8510a:


    you "!!!" with vpunch


translate ita escapeAlley_b640810c:


    "Non di nuovo! No..."


translate ita escapeAlley_cbb4eb55:


    "{size=+25}NO!{/size}" with vpunch


translate ita escapeAlley_e96e16bd:


    "Con il terrore addosso, indietreggi... {w}gli occhi fissi sul gatto e sul suo orribile ghigno."


translate ita escapeAlley_42a6e76b:


    "Devi scappare."


translate ita escapeAlley_20a8bb11:


    "Devi andare via da lì."


translate ita escapeAlley_cc7f2700:


    "Ma se persino {b}casa{/b} tua non è più sicura..."


translate ita escapeAlley_b120d39e:


    "Dove {i}andrai{/i}...?"


translate ita escapeAlley_a013ff83:


    "Ti azzardi a guardarti intorno e..."


translate ita escapeAlley_8ca8510a_1:


    you "!!!" with vpunch


translate ita escapeAlley_9f28660e:


    "Vedi che le pareti intorno a te sono diventate di carne e sono ricoperte di denti affilati... "


translate ita escapeAlley_e633f9bf:


    "Il pavimento è una lingua che serpeggia sotto i tuoi piedi..."


translate ita escapeAlley_69312007:


    "Nel panico, ti rendi conto che l'ingresso del vicolo diventa sempre più piccolo..."


translate ita escapeAlley_eb65f2ee:


    "{i}Chiudendosi{/i}... {w}come una bocca..."


translate ita escapeAlley_51da09f7:


    "Provi a correre verso l'uscita..."


translate ita escapeAlley_650717a6:


    "{size=-10}{i}nessun posto dove nascondersi nessun posto dove nascondersi nessun posto dove nascondersi nessun posto dove nascondersi nessun posto dove nascondersi nessun posto dove nascondersi nessun posto dove nascondersi nessun posto dove nascondersi nessun posto dove nascondersi nessun posto dove nascondersi {/i}{/size}"


translate ita escapeAlley_9bb38d7d:


    "... ma cercare di correre su quella lingua ti rallenta molto e ti fa inciampare."


translate ita escapeAlley_546d120e:


    you "{size=-8}No...{/size}"


translate ita escapeAlley_5ad13b7d:


    "Guardi impotente l'ultimo sprazzo di luce che filtra dall'entrata, così piccola da non poter sperare di passarci attraverso... "


translate ita escapeAlley_e8c1286e:


    "Mentre l'oscurità ti avvolge... {w}senti l'umido di quelle fauci intorno a te... "


translate ita escapeAlley_634c4b03:


    "Le pareti... quelle mura di denti... {i}le fauci...{/i}"


translate ita escapeAlley_dbef0163:


    "... si chiudono molto lentamente."


translate ita escapeAlley_624b526a:


    "Di più..."


translate ita escapeAlley_57fba23d:


    "Sempre di più..."


translate ita escapeAlley_12317a15:


    "E-{w=0.2}{nw}"


translate ita escapeAlley_632d1a35:


    you "!!!" with hpunch


translate ita escapeAlley_dae0ec55_2:


    you "..."


translate ita escapeAlley_8dabefc6_1:


    ".."


translate ita escapeAlley_a20cefa7_3:


    "..."


translate ita escapeAlley_59e53cf3:


    "Finale 23: Circolo vizioso"


translate ita feedAlley_60ed29e3:


    "Il gatto avrà fame, no?"


translate ita feedAlley_ca7535de:


    "Non avrà mangiato molto se è così attaccato a quella scatola."


translate ita feedAlley_15894b36:


    "Eppure... non sembra sia malnutrito..."


translate ita feedAlley_91d870df:


    "{i}Avrà{/i} lasciato la scatola per cercare del cibo...?"


translate ita feedAlley_a20cefa7:


    "..."


translate ita feedAlley_63420a88:


    "Per qualche motivo... qualcosa nel profondo della tua mente ti dice che non è così..."


translate ita feedAlley_f8c64864:


    "{size=-10}... e che non devi pensarci più.{/size}"


translate ita feedAlley_dae0ec55:


    you "..."


translate ita feedAlley_d93fe1cb:


    "Beh, comunque..."


translate ita feedAlley_b7ea0fa5:


    "Non puoi goderti la giornata sapendo di aver ignorato un gatto affamato."


translate ita feedAlley_0d1b62a9:


    "Soprattutto perché potresti fare qualcosa per aiutarlo."


translate ita feedAlleyMenu_42b896f8:


    "Quindi..."


translate ita feedAlleyMenu_949c2306:


    "Che fare per questo gattino affamato?"


translate ita feedAlleyMenu_a2c5487f:


    "Non ancora..."


translate ita feedPockets_5cfb3464:


    "Cerchi nelle tasche."


translate ita feedPockets_f8c73033:


    "Trovi un pezzetto di filo nella tasca sinistra. Non è molto utile."


translate ita feedPockets_ab3079c6:


    "Il filo è decisamente troppo corto."


translate ita feedPockets_c0209341:


    "Un gatto ansioso ed eccitato che ci gioca potrebbe facilmente{w=1.0}{nw}"


translate ita feedPockets_632d1a35:


    you "!!!" with hpunch


translate ita feedPockets_8dabefc6:


    ".."


translate ita feedPockets_a20cefa7:


    "..."


translate ita feedPockets_f42805d9:


    "Un gatto ansioso ed eccitato che ci gioca potrebbe facilmente morderti o graffiarti."


translate ita feedPockets_f8cb7b4a:


    "Nella tua tasca destra..."


translate ita feedPockets_d38263f6:


    "{size=-10}... c'è una barretta di {color=#FF0000}cioccolato.{/color}{/size}"


translate ita feedPockets_f3654da7:


    "{size=-5}mi dispiace {w=0.5}mi dispiace {w=0.5}mi dispiace {w=0.5}mi dispiace {w=0.5}mi dispiace {w=0.5}mi dispiace {w=0.5}mi dispiace {w=0.5}mi disp {/size}{w=0.2}{nw}"


translate ita feedPockets_dae0ec55:


    you "..."


translate ita feedPockets_31772800:


    "... c'è una barretta di cioccolato."


translate ita feedPockets_3d145f61:


    "Hai trovato una {i}barretta di cioccolato?!?{/i}"


translate ita feedPockets_1bd01551:


    "È...? No, non è nemmeno scaduta!"


translate ita feedPockets_7ee41c3c:


    "Una bella scoperta!"


translate ita feedPockets_5fd3d678:


    "Stai quasi per darla al gatto..."


translate ita feedPockets_632d1a35_1:


    you "!!!" with hpunch


translate ita feedPockets_f4a2553e:


    "... quando all'improvviso sei colto dal senso di colpa, perché ti ricordi di una cosa agghiacciante..."


translate ita feedPockets_a20cefa7_1:


    "..."


translate ita feedPockets_c0157c69:


    "Il cioccolato è {color=#FF0000}{b}tossico{/b}{/color} per i gatti."


translate ita feedPockets_8abfb425:


    you "Oh, mio Dio! Mi disp..."


translate ita feedPockets_44e1c462:


    "Resisti all'impulso di vomitare per l'errore che stavi per fare."


translate ita feedPockets_71316bbd:


    "Ti senti in colpa e butti via la cioccolata in un bidone della spazzatura lì vicino."


translate ita feedPockets_3c3040ce:


    "Chi ha quasi compiuto un gatti-cidio non merita il cioccolato."


translate ita feedPockets_87694524:


    "Torni verso il gatto e fai fatica a guardarlo, con quel suo sguardo innocente."


translate ita feedPockets_16879ce5:


    cat "Miao?"


translate ita feedPockets_dae0ec55_1:


    you "..."


translate ita feedPockets_2c29b15f:


    "Non sa che tu l'hai quasi..."


translate ita feedPockets_a20cefa7_2:


    "..."


translate ita feedPockets_f37947e9:


    you "Mi... mi dispiace tanto... Non so nemmeno cosa dire..."


translate ita feedPockets_8b57cab4:


    cat "Miaoo?"


translate ita feedPockets_a20cefa7_3:


    "..."


translate ita feedPockets_5cd20361:


    "Sei una persona {b}o r r i b i l e{/b}..."


translate ita feedPockets_0bfbcb68:


    you "... Sai una cosa? Resta qui, torno subito!"


translate ita feedPockets_16879ce5_1:


    cat "Miao?"


translate ita feedPockets_ab8229b4:


    "Lasci il vicolo..."


translate ita feedPockets_8dabefc6_1:


    ".."


translate ita feedPockets_a20cefa7_4:


    "..."


translate ita feedPockets_82310cee:


    "... e torni con un {i}pesce intero{/i} che hai comprato in un negozio lì vicino."


translate ita feedPockets_3926ea50:


    "Un po' caro..."


translate ita feedPockets_2b3ea52c:


    "{size=-8}... ma era il {b}minimo{/b} che potessi fare.{/size}"


translate ita feedPockets_ec1974d4:


    cat "Miao!" with hpunch


translate ita feedPockets_8c4b404a:


    "Il gatto accetta famelico la tua offerta, sgranocchiando felice il pesce che gli hai messo davanti alla scatola."


translate ita feedPockets_1c62c81c:


    cat "Miao! Miao! Miao!!!" with hpunch


translate ita feedPockets_be47b116:


    "Vorresti sorridere davanti a quella scena, ma ti senti davvero..."


translate ita feedPockets_b690d28d:


    "... {i}male.{/i}"


translate ita feedPockets_d14a2a5b:


    you "... S-scusami ancora."


translate ita feedPockets_dd5772de:


    "Il gatto sembra non badare a te quando te ne vai."


translate ita feedPockets_7b39a56c:


    "Senti di non meritarti una tranquilla giornata in giro, quindi decidi di tornare a casa."


translate ita feedPockets_8dabefc6_2:


    ".."


translate ita feedPockets_a20cefa7_5:


    "..."


translate ita feedPockets_730bba6f:


    who "Reow..."


translate ita feedPockets_90b68c87:


    you "...?"


translate ita feedPockets_3c4d90d1:


    "Sulla strada verso casa, noti molti più gatti del solito, che ti osservano dai loro nascondigli..."


translate ita feedPockets_905314c8:


    "... ma cerchi di non pensarci."


translate ita feedPockets_2d48655c:


    "Non puoi fare a meno di chiederti..."


translate ita feedPockets_c4bde9d1:


    "... se sappiano cosa hai quasi {b}fatto.{/b}"


translate ita feedPockets_bf0874e3:


    "Ma..."


translate ita feedPockets_703b363c:


    "Non volevi fare del male a nessuno..."


translate ita feedPockets_c53bacd0:


    "{size=-8}... giusto?{/size}"


translate ita feedPockets_8dabefc6_3:


    ".."


translate ita feedPockets_a20cefa7_6:


    "..."


translate ita feedPockets_3eb6f147:


    "Finalmente arrivi al tuo appartamento. Stai per aprire la porta quando..."


translate ita feedPockets_0fcae0c9:


    who "Reow... Reow... Reowwww...!"


translate ita feedPockets_90b68c87_1:


    you "...?"


translate ita feedPockets_8ca8510a:


    you "!!!" with vpunch


translate ita feedPockets_eefed842:


    "Ti volti... e vedi {i}dozzine{/i} di gatti fermi lì."


translate ita feedPockets_3c7fb7cb:


    "A fissarti."


translate ita feedPockets_4184a661:


    "Forse ti hanno visto dare da mangiare al gatto nel vicolo e hanno pensato che avessi del cibo anche per loro..?"


translate ita feedPockets_f32454e0:


    you "Mi... mi dispiace, non ho altro da mangiare..."


translate ita feedPockets_4bb08b75:


    "Nessuno di loro muove un muscolo."


translate ita feedPockets_7f4239d9:


    "Inizi a sentirti un po' a disagio, quando finalmente un gatto fa qualche passo avanti e... "


translate ita feedPockets_7f0ac95c:


    cat "..."


translate ita feedPockets_06197af2:


    you "Oh! Sei t-!"


translate ita feedPockets_8ca8510a_1:


    you "!!!" with vpunch


translate ita feedPockets_9ed134ce:


    "Oh..."


translate ita feedPockets_90b93b6a:


    "È..."


translate ita feedPockets_a20cefa7_7:


    "..."


translate ita feedPockets_3f4e0e68:


    "Stretta tra i suoi denti, c'è la barretta di cioccolato che avevi buttato via prima."


translate ita feedPockets_ba9d5a1b:


    "Mette la barretta di ciocciolato per terra e si volta a guardarti."


translate ita feedPockets_0fa5f48b:


    "{i}Tutti{/i} i gatti ti fissano..."


translate ita feedPockets_a20cefa7_8:


    "..."


translate ita feedPockets_cb8b1ea4:


    "{size=-5}Puoi sentire che ti stanno giudicando...{/size}"


translate ita feedPockets_ca13fffe:


    you "!!!" with hpunch


translate ita feedPockets_8ca8510a_2:


    you "!!!" with vpunch


translate ita feedPockets_61c83dbb:


    "Riesci quasi ad avvertire il peso dei tuoi peccati sulle spalle."


translate ita feedPockets_3a1db100:


    "Ma non avendo abbastanza soldi per comprare cibo a tutti..."


translate ita feedPockets_f1fb8cef:


    "Non sai che fare..."


translate ita begForgive_c11b9ea5:


    "Crolli sulle ginocchia e ti prostri, implorandoli di perdonarti."


translate ita begForgive_5d26ba72:


    you "Mi dispiace! Lo giuro!" with vpunch


translate ita begForgive_11f39ee6:


    you "Io... farei qualsiasi cosa per rimediare, ma...!"


translate ita begForgive_0b6b468c:


    "... Ma non sai che fare."


translate ita begForgive_f8342e66:


    "All'improvviso..."


translate ita begForgive_b3351a0a:


    you "Ach! Urgh! *cough*!!!" with vpunch


translate ita begForgive_1a0306e2:


    "Senti qualcosa che si muove e nuota nel tuo stomaco e che ti risale in gola..."


translate ita begForgive_9d069fba:


    "... impedendoti di respirare mentre cerca di liberarsi. "


translate ita begForgive_f00aa018:


    you "C-Coff!" with vpunch


translate ita begForgive_7e07a3c9:


    "Finalmente riesce a liberarsi."


translate ita begForgive_c76c10fb:


    you "Guk!!!" with hpunch


translate ita begForgive_dae0ec55:


    you "..."


translate ita begForgive_90b68c87:


    you "...?"


translate ita begForgive_632d1a35:


    you "!!!" with hpunch


translate ita begForgive_9035e3f2:


    you "{size=-8}Ma... che...?{/size}"


translate ita begForgive_30e5bd77:


    "Sul pavimento di fronte a te..."


translate ita begForgive_3c6fad90:


    "... c'è un pesce che si dibatte."


translate ita begForgive_0fa59e4c:


    "Hai appena... {w}vomitato un pesce {i}vivo{/i}..."


translate ita begForgive_2e05a79f:


    you "{size=-8}Ma che diamine...?{/size}"


translate ita begForgive_28305204:


    "I gatti ti corrono incontro, buttandosi famelici sul pesce."


translate ita begForgive_23a3bbe5:


    "Sei..."


translate ita begForgive_a360cc29:


    "Sei {i}felice{/i} di aver aiutato, davvero... {w}ma come-{w=0.2}{nw}"


translate ita begForgive_d69064ca:


    you "Puh!" with vpunch


translate ita begForgive_8dabefc6:


    ".."


translate ita begForgive_a20cefa7:


    "..."


translate ita begForgive_15d57735:


    "... Hai appena vomitato un altro pesce."


translate ita begForgive_c76c10fb_1:


    you "Hurk!!!" with hpunch


translate ita begForgive_27069f53:


    "E un altro..."


translate ita begForgive_c76c10fb_2:


    you "Puh!!!" with hpunch


translate ita begForgive_f2db7641:


    "E un altro {i}ancora{/i}..."


translate ita begForgive_c76c10fb_3:


    you "Hurk!!!" with hpunch


translate ita begForgive_cb64e404:


    "E..."


translate ita begForgive_a20cefa7_1:


    "..."


translate ita begForgive_dbd6d155:


    "Ti fa male lo stomaco. {w}Stai diventando... debole."


translate ita begForgive_971a5312:


    "Cadi sulle ginocchia..."


translate ita begForgive_fe9dfa69:


    "Le lacrime ti scorrono sul viso mentre, con un colpo di tosse, vomiti l'ultimo, minuscolo pesce {i}{color=#FF0000}insaguinato{/color}{/i}, prima di crollare in avanti. "


translate ita begForgive_a7387d16:


    "Senti la gola e lo stomaco {i}bruciare{/i} in modo preoccupante."


translate ita begForgive_0f08eefa:


    "Ti senti svenire..."


translate ita begForgive_21f2fb4d:


    "Ma nonostante il dolore..."


translate ita begForgive_2585da06:


    "... senti un inaspettato moto di speranza e orgoglio."


translate ita begForgive_56367ba7:


    "Hai rimediato ai tuoi {b}deplorevoli{/b} errori..."


translate ita begForgive_f0ecbc05:


    "... Hai ottenuto il perdono."


translate ita begForgive_edbc3af1:


    "Il suono di tutti quei gattini felici che si gustano i pesci ti riempie le orecchie..."


translate ita begForgive_f64ee9d8:


    "Ma poi..."


translate ita begForgive_5bfd48b0:


    "... senti che ti viene spinto in mano qualcosa. "


translate ita begForgive_f3f141f9:


    "Sembra quasi..."


translate ita begForgive_28b3ac41:


    you "!!!"


translate ita begForgive_5da9aa6a:


    "È la barretta di cioccolato che avevi trovato in tasca."


translate ita begForgive_dae0ec55_1:


    you "..."


translate ita begForgive_10d5d7ff:


    you "{size=-8}U-Uh...{/size}"


translate ita begForgive_254220ed:


    "Sorridi debolmente."


translate ita begForgive_08515ef1:


    "Hai espiato le tue colpe, ma non hai la forza di mangiare la tua ricompensa."


translate ita begForgive_aa483b68:


    "Purtroppo, l'ultimo sapore che ti resterà in bocca mentre abbandoni questo mondo non sarà quello del cioccolato... "


translate ita begForgive_5408dec4:


    "... ma quello del pesce crudo."


translate ita begForgive_a20cefa7_2:


    "..."


translate ita begForgive_1ecfdb72:


    "Finale 24: A pesca di scuse"


translate ita leaveHungryCats_919a1f52:


    "Decidi di darci un taglio ed entrare."


translate ita leaveHungryCats_32bb90cb:


    "Ti senti in colpa, ma alla fine sei solo un essere umano. Cos'altro puoi fare?"


translate ita leaveHungryCats_8f6616fa:


    you "{i}Cavolo...{/i}"


translate ita leaveHungryCats_e7b16877:


    "Cerchi di ignorare quell'insistente miagolio e ti dedichi alle cose da fare."


translate ita leaveHungryCats_5a3d572d:


    "Potresti preparare la cena..."


translate ita leaveHungryCats_b1727d2d:


    "... ma come faresti a godertela sapendo che quei poveri gattini là fuori muoiono di fame?"


translate ita leaveHungryCats_d620406e:


    "Quelli che tu hai offeso?"


translate ita leaveHungryCats_4814405d:


    "Decidi di farti un bagno e andare subito a dormire {b}senza{/b} cena. "


translate ita leaveHungryCats_f9c0255f:


    "La giusta punizione per una persona come te."


translate ita leaveHungryCats_ae952792:


    "Rinunci perfino alle bolle di sapone perché non te le meriti e ti immergi nell'acqua con un sospiro."


translate ita leaveHungryCats_ff1845cf:


    "La tua mente corre ma non riesci proprio a pensare a una soluzione rapida che non richieda soldi."


translate ita leaveHungryCats_2bf55488:


    "Vorresti poter fare qualcosa, {i}qualunque cosa{/i}, per rimediare."


translate ita leaveHungryCats_3e71eb84:


    "All'improvviso... {w}iniziano a pruderti le gambe."


translate ita leaveHungryCats_17310a3f:


    "Sollevi una gamba per vedere cosa c'è che non va, ma ciò che esce dall'acqua non ha niente a che vedere con delle gambe..."


translate ita leaveHungryCats_8ca8510a:


    you "!!!" with vpunch


translate ita leaveHungryCats_67f84009:


    "Ma è...{w} Una coda di pesce...?"


translate ita leaveHungryCats_867810a1:


    "Ti... Ti senti svenire alla vista... Forse stai avendo le allucinazioni per lo stress?"


translate ita leaveHungryCats_a20cefa7:


    "..."


translate ita leaveHungryCats_5c9b6efd:


    "Provi ad arrampicarti fuori dalla vasca per rinfrescarti le idee... ma invece delle tue mani..."


translate ita leaveHungryCats_d0c358fd:


    "... una pinna fa capolino sull'orlo della vasca."


translate ita leaveHungryCats_c20b4b4f:


    "Non riesce a reggere il tuo peso. Sei sotto shock per lo stupore..."


translate ita leaveHungryCats_479c3431:


    you "!!!" with vpunch


translate ita leaveHungryCats_dae0ec55:


    you "..."


translate ita leaveHungryCats_34e36922:


    "... tanto da scivolare e sbattere la testa sul bordo della vasca, svenendo all'istante."


translate ita leaveHungryCats_8dabefc6:


    ".."


translate ita leaveHungryCats_a20cefa7_1:


    "..."


translate ita leaveHungryCats_08a2bbac:


    "Torni in te. O almeno {i}credi{/i}."


translate ita leaveHungryCats_15f20a2c:


    "Apri gli occhi e..."


translate ita leaveHungryCats_36e9324f:


    "Mmh? Sei... sott'acqua...?"


translate ita leaveHungryCats_80806592:


    "...! Sicuramente sei sotto la superficie dell'acqua della vasca! D'istinto, annaspi in cerca d'aria."


translate ita leaveHungryCats_29b1a09a:


    "... Più o meno."


translate ita leaveHungryCats_e46f8488:


    "Una bolla fluttua fuori dalla tua bocca... su, su, sempre più {i}su{/i} verso la superficie."


translate ita leaveHungryCats_424a2cfe:


    "Non hai un soldo, quindi {i}sai{/i} che la tua vasca da bagno non è {i}così{/i} grande. "


translate ita leaveHungryCats_9e0f57e7:


    "Il...?"


translate ita leaveHungryCats_a20cefa7_2:


    "..."


translate ita leaveHungryCats_a2da44e5:


    "Il tuo corpo... si è {w}{b}rimpicciolito?{/b}"


translate ita leaveHungryCats_eac07da9:


    "Ma {i}come?{/i}"


translate ita leaveHungryCats_e1102cc4:


    "Ma anche se ci fosse una risposta sensata..."


translate ita leaveHungryCats_09da957d:


    "... non spiegherebbe come tu abbia fatto a non {b}annegare{/b}..."


translate ita leaveHungryCats_6d9bb603:


    "Nuoti fino al bordo della vasca e, vedendo la tua ombra, scopri la verità..."


translate ita leaveHungryCats_28b3ac41:


    you "!!!"


translate ita leaveHungryCats_18e23bb0:


    "Ma sei... {w}sei un {i}{b}pesce?!?{/b}{/i}"


translate ita leaveHungryCats_be932f7f:


    you "{i}{size=-5}Non... Non è {b}possibile{/b}...{/size}{/i}"


translate ita leaveHungryCats_06e0acd2:


    "Purtoppo, non hai il tempo di pensarci..."


translate ita leaveHungryCats_2c77c5b6:


    "Perché in quel momento..."


translate ita leaveHungryCats_6274a0c8:


    "... un'ombra incombe dall'alto."


translate ita leaveHungryCats_16744c4a:


    "Guardi in su e vedi... il gatto?"


translate ita leaveHungryCats_7a9ce7a5:


    "Ti osserva dall'alto, sopra la superficie dell'acqua..."


translate ita leaveHungryCats_dae0ec55_1:


    you "..."


translate ita leaveHungryCats_8ca8510a_1:


    you "!!!" with vpunch


translate ita leaveHungryCats_a20cefa7_3:


    "..."


translate ita leaveHungryCats_637fa4bd:


    "E poi..."


translate ita leaveHungryCats_1141e85b:


    "Alla fine {i}comprendi.{/i}"


translate ita leaveHungryCats_3613f8e2:


    "È {b}questa{/b} la risposta..."


translate ita leaveHungryCats_c16f4226:


    "È così... {w}che devi chiedere perdono."


translate ita leaveHungryCats_dae0ec55_2:


    you "..."


translate ita leaveHungryCats_2387281a:


    "A malincuore..."


translate ita leaveHungryCats_a20cefa7_4:


    "..."


translate ita leaveHungryCats_23382f12:


    "... risali verso la superficie."


translate ita leaveHungryCats_c44e377e:


    cat "Miao!" with hpunch


translate ita leaveHungryCats_479c3431_1:


    you "!!!" with vpunch


translate ita leaveHungryCats_49411296:


    "Il gatto ti afferra, trascinandoti fuori dalla vasca e buttandoti sul pavimento del bagno."


translate ita leaveHungryCats_3c17e5ed:


    "Mentre annaspi in cerca di aria..."


translate ita leaveHungryCats_26f6c95f:


    "(o di acqua...?)"


translate ita leaveHungryCats_74646257:


    "... ti accorgi che quel gatto non è da solo."


translate ita leaveHungryCats_5fa71d4e:


    "Dozzine di gatti affamati ti stanno fissando."


translate ita leaveHungryCats_6494036d:


    "Riesci a sentire i lamenti di forse centinaia di gatti fuori dalla porta del bagno."


translate ita leaveHungryCats_2c0a5c25:


    "Rivolgi un ultimo sguardo al gatto prima di chiudere gli occhi e abbracciare il tuo destino."


translate ita leaveHungryCats_716c98f8:


    "Mentre i gatti si lanciano su di te, strappandoti via la carne..."


translate ita leaveHungryCats_d6080537:


    "... sei triste pensando che..."


translate ita leaveHungryCats_a20cefa7_5:


    "..."


translate ita leaveHungryCats_4d9c1486:


    "{size=-6}... non sei nemmeno abbastanza grande da sfamarli tutti.{/size}"


translate ita leaveHungryCats_75e13727:


    "Persino alla fine..."


translate ita leaveHungryCats_6e125249:


    "... non ce l'hai fatta."


translate ita leaveHungryCats_0328dbd4:


    "Tutti i tuoi sforzi, la tua stessa {i}vita{/i}..."


translate ita leaveHungryCats_9f0317b6:


    "Tutto questo..."


translate ita leaveHungryCats_a20cefa7_6:


    "..."


translate ita leaveHungryCats_d2cc2d23:


    "... non è servito a {b}niente{/b}."


translate ita leaveHungryCats_8dabefc6_1:


    ".."


translate ita leaveHungryCats_a20cefa7_7:


    "..."


translate ita leaveHungryCats_06568472:


    "Finale 25: Offerta di Pesce"


translate ita feedLookAround_6adec316:


    "Ti guardi intorno, in quel vicolo buio e squallido..."


translate ita feedLookAround_172f73ee:


    "... e vedi solo spazzatura, cassonetti, scatole vuote e lettiere sparse qua e là."


translate ita feedLookAround_8a2477ca:


    "Se ci fosse stato qualcosa da mangiare per il gatto, ormai l'avrebbe sicuramente trovato, no?"


translate ita feedLookAround_1c7afc63:


    "Ma non vuoi arrenderti così facilmente."


translate ita feedLookAround_1b9dbcae:


    "Continui a cercare."


translate ita feedLookAround_37ccdc14:


    "Dai un'occhiata in giro e vedi solo spazzatura."


translate ita feedLookAround_7206a2c2:


    "Senti solo il tanfo dell'immondizia."


translate ita feedLookAround_15a42f3c:


    "Tendi le orecchie..."


translate ita feedLookAround_8dabefc6:


    ".."


translate ita feedLookAround_a20cefa7:


    "..."


translate ita feedLookAround_8a367b77:


    "{size=-10}*scritch* *scritch*{/size}"


translate ita feedLookAround_a513413e:


    "...!"


translate ita feedLookAround_4f966ec3:


    "Riesci appena a distinguire il debole rumore di qualcosa che corre vicino a un cassonetto, non molto lontano da te."


translate ita feedLookAround_b659571e:


    "Lentamente... Molto lentamente... ti fai strada fino al bidone della spazzatura..."


translate ita feedLookAround_cb64e404:


    "E..."


translate ita feedLookAround_8dabefc6_1:


    ".."


translate ita feedLookAround_a20cefa7_1:


    "..."


translate ita feedLookAround_a513413e_1:


    "...!"


translate ita feedLookAround_d8c7093a:


    "{size=+5}Fai un {i}balzo!{/i}{/size}"


translate ita feedLookAround_d304d4e5:


    "{size=+20}{b}CRASH!!!{/b}{/size}" with vpunch


translate ita feedLookAround_a20cefa7_2:


    "..."


translate ita feedLookAround_2ea47ee5:


    "Non è stato un tentativo molto aggraziato."


translate ita feedLookAround_262f7f90:


    "Hai inciampato e buttato all'aria una pila di scatole piene di spazzatura, {w}ma quando ti rialzi..."


translate ita feedLookAround_5398ed86:


    "... stretto tra le dita..."


translate ita feedLookAround_a20cefa7_3:


    "..."


translate ita feedLookAround_7d0b6abb:


    "... c'è un topolino."


translate ita feedLookAround_9db0dda0:


    rat "Squeak! Squeak!" with vpunch


translate ita feedLookAround_2f69184a:


    "Il topo squittisce e strilla, cercando disperatamente di liberarsi dalla tua presa."


translate ita feedLookAround_bb6730d7:


    "Lo tieni stretto, forse troppo, ma almeno così non può morderti o graffiarti."


translate ita feedLookAround_204f821b:


    "Sfinito, ti guarda con i suoi occhietti neri..."


translate ita feedLookAround_a20cefa7_4:


    "..."


translate ita feedLookAround_0d800538:


    "È {i}completamente{/i} alla tua mercé."


translate ita spareMouse_085f82bc:


    cat "Miao..."


translate ita spareMouse_37478095:


    "Non vorrai..."


translate ita spareMouse2_9cad6637:


    cat "Miaooo..."


translate ita spareMouse2_317daa48:


    "Riesci a sentire la pancia del gatto brontolare."


translate ita spareMouse2_3b182f71:


    "Dev'essere così affamato..."


translate ita spareMouse2_302b36d5:


    "Starà {b}morendo di fame...{/b}"


translate ita spareMouse3_2cea6c44:


    ".{w=1.0}.{w=1.0}.{w=1.0}{nw}"


translate ita spareMouse3_8c265d6b:


    cat "{size=+10}{b}MIAO!{/b}{/size}" with hpunch


translate ita spareMouse3_b7235e3b:


    "Sai che il gatto ha fame."


translate ita spareMouse3_33159e4f:


    "Perché stai esitando?"


translate ita spareMouse3_f002086d:


    "Hai trovato una preda per il suo bene, no?"


translate ita spareMouse3_e75c361b:


    "Ora pensi davvero che la vita di un lurido topo valga più di quella del gatto?"


translate ita spareMouse4_8dabefc6:


    ".."


translate ita spareMouse4_a20cefa7:


    "..."


translate ita spareMouse4_ee44cce1:


    "{size=-8}{color=#FF0000}Mi prendi in giro, vero?{/color}{/size}"


translate ita spareMouse4_dd07c1d2:


    "Ultima occasione..."


translate ita spareMouse4_8f248444:


    "D e v i... {w}d a r g l i... {w}q u e l l a... {w}p r e d a... "


translate ita spareMouse4_e7eb980b:


    "{b}{color=#FF0000}Adesso.{/color}{/b}"


translate ita freeMouse_8dabefc6:


    ".."


translate ita freeMouse_a20cefa7:


    "..."


translate ita freeMouse_85bf2796:


    "Lasci andare il topo."


translate ita freeMouse_2dd146aa:


    "Scappa, infilandosi in un minuscolo buco nel muro..."


translate ita freeMouse_dac972a5:


    "Ma non ci presti molta attenzione."


translate ita freeMouse_edd804dd:


    "All'improvviso, una zampa con gli artigli sfoderati ti si para davanti..."


translate ita freeMouse_27890332:


    "... bloccandoti la strada."


translate ita freeMouse_19d2abd9:


    "Non che ti illudessi davvero di poter scappare."


translate ita freeMouse_a20cefa7_1:


    "..."


translate ita freeMouse_c4176d5e:


    "In fondo, il gatto ha fame."


translate ita freeMouse_3e1401c3:


    "Chiudi gli occhi, consapevole del tuo destino, mentre quella zampa ti spinge delicatamente indietro..."


translate ita freeMouse_068b5ee7:


    "Ancora..."


translate ita freeMouse_057a9a91:


    "E-{w=0.175}{nw}"


translate ita freeMouse_cc8fcc0d:


    "{size=+20}{b}CHOMP!!!{/b}{/size}" with hpunch


translate ita freeMouse_8dabefc6_1:


    ".."


translate ita freeMouse_a20cefa7_2:


    "..."


translate ita freeMouse_8b12d547:


    "Finale 26: Una vita risparmiata"


translate ita feedCatMouse_927f34df:


    "Il topo sembra spaventato, come se capisse le tue intenzioni."


translate ita feedCatMouse_7313e03e:


    "Debolmente, prova di nuovo a lottare."


translate ita feedCatMouse_ff457211:


    rat "{size=+10}SQUEAK! SQUEAK! {b}SQUEEEAAK!!!{/b}{/size}" with hpunch


translate ita feedCatMouse_8dabefc6:


    ".."


translate ita feedCatMouse_a20cefa7:


    "..."


translate ita feedCatMouse_ca6ee73d:


    "{size=-10}Il topolino è titubante.{/size}"


translate ita feedCatMouse2_8dabefc6:


    ".."


translate ita feedCatMouse2_a20cefa7:


    "..."


translate ita feedCatMouse2_32660fc9:


    "Lasci che il gatto se lo mangi."


translate ita feedCatMouse2_0e994b53:


    cat "Miaooo!" with hpunch


translate ita feedCatMouse2_d59fd9a8:


    "Il gatto lo fa subito a pezzi..."


translate ita feedCatMouse2_ff68e97c:


    rat "SQUEAK!" with hpunch


translate ita feedCatMouse2_b09043ec:


    rat "SQUEAK! {b}SQUEEEAAK!!!{/b}" with hpunch


translate ita feedCatMouse2_02199255:


    rat "SQUE-{w=0.175}{nw}" with hpunch


translate ita feedCatMouse2_a20cefa7_1:


    "..."


translate ita feedCatMouse2_6240b97d:


    "Il topolino squittisce e urla per il dolore, fino a quando non si interrompe bruscamente. "


translate ita feedCatMouse2_5318aee4:


    "Soddisfatto, il gatto miagola felice verso di te, con il muso sporco di sangue."


translate ita feedCatMouse2_b003a621:


    cat "Miaoo!"


translate ita feedCatMouse2_dae0ec55:


    you "..."


translate ita feedCatMouse2_50910e06:


    "Il gatto si rintana nella sua scatola ormai sporca di sangue e va a dormire."


translate ita feedCatMouse2_dae0ec55_1:


    you "..."


translate ita feedCatMouse2_f737576e:


    "Ne approfitti per andartene."


translate ita feedCatMouse2_10a52902:


    "Un gatto ben nutrito potrebbe anche seguirti fino a casa..."


translate ita feedCatMouse2_991cb618:


    "... ma per quanto possa essere carino..."


translate ita feedCatMouse2_a20cefa7_2:


    "..."


translate ita feedCatMouse2_2316a09e:


    "... non puoi proprio permetterti un animale adesso."


translate ita feedCatMouse2_8045cc18:


    "Ti senti ancora un po' in colpa per quel topolino, così decidi di andare a casa."


translate ita feedCatMouse2_dae0ec55_2:


    you "..."


translate ita feedCatMouse2_a20cefa7_3:


    "..."


translate ita feedCatMouse2_dae0ec55_3:


    you "..."


translate ita feedCatMouse2_a20cefa7_4:


    "..."


translate ita feedCatMouse2_dae0ec55_4:


    you "..."


translate ita feedCatMouse2_0338822b:


    "Dopo una lunga camminata, finalmente entri in casa..."


translate ita feedCatMouse2_99073e13:


    "Te ne vai subito in camera..."


translate ita feedCatMouse2_fead6e35:


    "... e ti butti sul letto, sprofondando in un sonno agitato. "


translate ita feedCatMouse2_8dabefc6_1:


    ".."


translate ita feedCatMouse2_a20cefa7_5:


    "..."


translate ita feedCatMouse2_9669528e:


    "Più tardi..."


translate ita feedCatMouse2_0e0f046c:


    "Ti svegli..."


translate ita feedCatMouse2_3ef36ef7:


    "{size=-5}*scritch* *scritch*{/size}"


translate ita feedCatMouse2_aed29e03:


    who "{size=-5}squeak squeak squeak...{/size}"


translate ita feedCatMouse2_75fd645a:


    "... perché senti squittii e rumori {b}tutto{/b} intorno a te... "


translate ita feedCatMouse2_731d880d:


    "... così lamentosi e costanti che sembrano quasi delle {i}grida.{/i} "


translate ita feedCatMouse2_3502244d:


    "Nel buio della tua stanza..."


translate ita feedCatMouse2_a20cefa7_6:


    "..."


translate ita feedCatMouse2_3b018980:


    "... vedi la tremolante ombra di {b}{i}centinaia{/i}{/b} di topi che circondano il tuo letto. "


translate ita feedCatMouse2_56ebb028:


    you "!!!"


translate ita feedCatMouse2_a55f18e5:


    "Provi a scappare..."


translate ita feedCatMouse2_8ca8510a:


    you "!!!" with vpunch


translate ita feedCatMouse2_5c6c5752:


    you "AAH!" with vpunch


translate ita feedCatMouse2_2ffa7999:


    "Ma urli di dolore quando due fitte lancinanti ti trafiggono le gambe."


translate ita feedCatMouse2_a5230802:


    "Cadi dal letto mentre cerchi di scappare..."


translate ita feedCatMouse2_d6ce36d0:


    "... l'orda di topi ti schiva quando ti schianti sul pavimento."


translate ita feedCatMouse2_0f5de544:


    "Tu..."


translate ita feedCatMouse2_a20cefa7_7:


    "..."


translate ita feedCatMouse2_ea714275:


    "{size=-8}Non riesci ad alzarti.{/size}"


translate ita feedCatMouse2_191bfb14:


    "Quando ti guardi alle spalle, strizzando gli occhi nel buio, {w}scopri l'origine del tuo dolore... "


translate ita feedCatMouse2_4b8f74bf:


    "La carne e i tendini dei tuoi talloni e delle caviglie è maciullata..."


translate ita feedCatMouse2_017438eb:


    "{b}Divorata{/b} attraverso le calze..."


translate ita feedCatMouse2_2f0d3863:


    you "N-no... no! L-Lasciatemi in pace...!" with hpunch


translate ita feedCatMouse2_af41a66d:


    "Cerchi disperatamente di strisciare verso la porta..."


translate ita feedCatMouse2_8dabefc6_2:


    ".."


translate ita feedCatMouse2_a20cefa7_8:


    "..."


translate ita feedCatMouse2_bc2fabcc:


    "I topi ti saltano addosso..."


translate ita feedCatMouse2_8ca8510a_1:


    you "!!!" with vpunch


translate ita feedCatMouse2_21d8e99a:


    "... mordendoti la pelle."


translate ita feedCatMouse2_8ca8510a_2:


    you "!!!" with vpunch


translate ita feedCatMouse2_f62320f5:


    "Strappandoti {b}pezzi{/b} di carne... "


translate ita feedCatMouse2_dae0ec55_5:


    you "..."


translate ita feedCatMouse2_9943b33e:


    "Stai iniziando a perdere i sensi..."


translate ita feedCatMouse2_efcd9d02:


    "... ma riesci a raggiungere la maniglia della porta..."


translate ita feedCatMouse2_2cb23dbf:


    "... Il tuo braccio è appesantito dai topi che vi si arrampicano con i denti e gli artigli."


translate ita feedCatMouse2_fb2f2154:


    "Riesci a spingere la maniglia abbastanza da far aprire un po' la porta..."


translate ita feedCatMouse2_7128cb1f:


    "*TONF!*" with hpunch


translate ita feedCatMouse2_a20cefa7_9:


    "..."


translate ita feedCatMouse2_50f50169:


    "... ma il tuo braccio cade improvvisamente a terra come un peso morto."


translate ita feedCatMouse2_56ebb028_1:


    you "!!!"


translate ita feedCatMouse2_f764243f:


    "I topi sono riusciti a mangiucchiare la carne e le ossa del tuo braccio."


translate ita feedCatMouse2_3b178dd0:


    "Mentre alcuni topi strisciano in avanti, curiosi, per ispezionare il braccio, tu lo fissi con occhi vuoti per un momento prima di sollevare lo sguardo."


translate ita feedCatMouse2_9ffc28d3:


    "Dalla porta socchiusa, vedi qualcosa di familiare..."


translate ita feedCatMouse2_40d9ca73:


    "...?"


translate ita feedCatMouse2_6d3f28fc:


    "... Il topo?"


translate ita feedCatMouse2_115c17a3:


    "Ti fissa."


translate ita feedCatMouse2_95e298fc:


    "L'oscurità nei suoi occhi neri e pungenti... {w}È impossibile capirne la profondità..."


translate ita feedCatMouse2_a20cefa7_10:


    "..."


translate ita feedCatMouse2_bb419a8e:


    "Né l'odio che li accende."


translate ita feedCatMouse2_9f0317b6:


    "Tutto questo..."


translate ita feedCatMouse2_fa45f11e:


    "... è rivolto a {b}te.{/b}"


translate ita feedCatMouse2_63539327:


    you "A-Ah..."


translate ita feedCatMouse2_11499480:


    "Crolli a terra sbattendo la testa, mentre anche l'altro braccio viene divorato."


translate ita feedCatMouse2_771b6f54:


    "Non sai se sei ancora cosciente o meno. Il dolore dovrebbe essere disumano..."


translate ita feedCatMouse2_595186a8:


    "Eppure... senti solo un senso di vuoto..."


translate ita feedCatMouse2_33bce6c6:


    "I topi si sono ammassati lungo la tua schiena..."


translate ita feedCatMouse2_c3e0a8e8:


    "... rosicchiandola e mordendola, facendosi strada tra le tue costole..."


translate ita feedCatMouse2_8019dadd:


    "Nella tua schiena... Nel tuo {i}petto--{/i}"


translate ita feedCatMouse2_632d1a35:


    you "!!!" with hpunch


translate ita feedCatMouse2_bfc63f92:


    you "*cough*! *cough*!..." with hpunch


translate ita feedCatMouse2_30ab43e2:


    "... Tossisci sangue, debolmente. Devono aver danneggiato qualcosa di importante..."


translate ita feedCatMouse2_8b59ccb1:


    "Senti che qualcosa viene {i}spinto fuori dal tuo corpo...{/i}"


translate ita feedCatMouse2_f2234e60:


    "E nel momento in cui ti si offusca la vista..."


translate ita feedCatMouse2_13fb74b2:


    "{size=-8}*splat*{/size}"


translate ita feedCatMouse2_633ae29e:


    "... senti che qualcosa di bagnato è caduto a terra, davanti a te."


translate ita feedCatMouse2_bbaaac8d:


    "Apri gli occhi con curiosità e {i}lo{/i} vedi, davanti al topo..."


translate ita feedCatMouse2_b7184c45:


    "Deforme, ricoperto di sangue e {b}pulsante{/b}..."


translate ita feedCatMouse2_9330ef6a:


    "Oh, ma quello è..."


translate ita feedCatMouse2_55a10ea9:


    "È il tuo cuore... {w}non è così...?"


translate ita feedCatMouse2_e608f022:


    "Gli altri topi vi si buttano sopra, dimenticandosi del tuo corpo mezzo maciullato..."


translate ita feedCatMouse2_c5119fab:


    "Stai... perdendo molto sangue."


translate ita feedCatMouse2_98bc0f41:


    "Hai sonno... {w}Però..."


translate ita feedCatMouse2_84fb2e85:


    "Senti... anche..."


translate ita feedCatMouse2_40d9ca73_1:


    "...?"


translate ita feedCatMouse2_1e59d740:


    "Rabbia?"


translate ita feedCatMouse2_c33553a7:


    "... {b}Sì.{/b}"


translate ita feedCatMouse2_f367bb97:


    "Così... {i}tanta{/i} rabbia."


translate ita feedCatMouse2_bc4dfa80:


    "Come osano...?"


translate ita feedCatMouse2_a20cefa7_11:


    "..."


translate ita feedCatMouse2_481997a6:


    "{size=-6}Come {b}si{/b} permettono...?{/size}"


translate ita feedCatMouse2_b41033e1:


    "L'ultima cosa che vedi prima di svenire..."


translate ita feedCatMouse2_0f017232:


    "... sono due occhi luminosi dietro la porta."


translate ita feedCatMouse2_262f03ab:


    "Senti squittii e strilli di terrore intorno a te... "


translate ita feedCatMouse2_8b513e6c:


    "Bassi ululati... {w}un ringhio profondo... {w}{i}denti che digrignano...{/i} {w}{b}strappano la carne...{/b}"


translate ita feedCatMouse2_9e1e42e3:


    "Mentre stai per svenire del tutto..."


translate ita feedCatMouse2_588df3af:


    "... sorridi, con le tue ultime forze..."


translate ita feedCatMouse2_7f3c4ffb:


    "... quando qualcosa di morbido, umido, appiccicoso e peloso ti solletica il collo."


translate ita feedCatMouse2_8c8e6f27:


    who "Purr..."


translate ita feedCatMouse2_8dabefc6_3:


    ".."


translate ita feedCatMouse2_a20cefa7_12:


    "..."


translate ita feedCatMouse2_2c38d82c:


    you "{i}Bravo micio.{/i}"


translate ita feedCatMouse2_a20cefa7_13:


    "..."


translate ita feedCatMouse2_85830579:


    "Finale 27: Ben Nutrito"


translate ita feedBlood_9cad6637:


    cat "Miaoooo..."


translate ita feedBlood_81d09fc7:


    "Il gatto emette un suono triste, lamentoso."


translate ita feedBlood_77603d0b:


    "Ha fame."


translate ita feedBlood_2ecc0964:


    "Starà morendo di fame."


translate ita feedBlood_42b896f8:


    "Quindi..."


translate ita feedBlood_0f5de544:


    "Tu..."


translate ita feedBlood_dae0ec55:


    you "..."


translate ita feedBlood_5ca2097f:


    "Ti guardi intorno e vedi un frammento di vetro nelle vicinanze..."


translate ita feedBlood_6d915dc6:


    "Il tuo corpo si muove come se sapesse già cosa fare... {w}Cosa {i}va{/i} fatto... "


translate ita feedBlood_71be69bc:


    "Prendi il frammento e..."


translate ita feedBlood_a20cefa7:


    "..."


translate ita feedBlood_39a0ef61:


    "...?!?" with hpunch


translate ita feedBlood_1a1c5607:


    "Cos-"


translate ita feedBlood_7ecd134e:


    "{b}{i}Perché mai vorresti—{/i}{/b}"


translate ita feedBlood_a20cefa7_1:


    "..."


translate ita feedBlood_01b83f04:


    "{size=-8}Perché mai {b}vorresti{/b} fare una cosa del genere?{/size}"


translate ita feedBlood_762defa2:


    "Tieni attentamente il dito sul gatto."


translate ita feedBlood_7d18846b:


    "Perle di sangue rosso scuro sgorgano dalla ferita... "


translate ita feedBlood_e39facbe:


    "... prima di diventare abbastanza pesanti da cadere dritte nelle fauci del gatto."


translate ita feedBlood_c4ed09d4:


    "Ti rivolge un miagolio felice."


translate ita feedBlood_ba1796d7:


    cat "Miaooo!"


translate ita feedBlood_c2c5bcf6:


    "Sorridi calorosamente e infili la mano nella scatola..."


translate ita feedBlood_45c2e033:


    "... accarezzi la guancia del gatto, prima di lasciargli gentilmente leccare la ferita."


translate ita feedBlood_dbbb8fed:


    "Quando il flusso diminuisce e il gatto miagola per chiederne ancora, stringi la ferita per far uscire più sangue."


translate ita feedBlood_28db8729:


    "Avverti quasi un senso di benessere da quello strano scambio."


translate ita feedBlood_51e619d4:


    "Un altro essere vivente era affamato..."


translate ita feedBlood_ebe79259:


    "... e {i}tu{/i} gli hai dato da mangiare."


translate ita feedBlood_74acde15:


    "Da un errore è nata una cosa giusta... {w}anche se strana e solo temporanea."


translate ita feedBlood_4c836b64:


    "Ironicamente, proprio in quel momento inizi a sentire... le vertigini..."


translate ita feedBlood_19b6fd1b:


    "Non pensavi che avresti perso così tanto sangue..."


translate ita feedBlood_6207f576:


    "Ti accasci contro la scatola e lo senti miagolare in preda all'agitazione."


translate ita feedBlood_6bbdcd7a:


    cat "Mreow! Mreowww!" with hpunch


translate ita feedBlood_31c0a678:


    "Sembra quasi preoccupato per te. O almeno, questo è quello che ti {i}piace{/i} pensare."


translate ita feedBlood_7db1edf8:


    "{i}Potrebbe{/i} solo volere più sangue."


translate ita feedBlood_cbe24519:


    "Il gatto salta fuori dalla scatola e ti sale sulle gambe, strofinando il naso contro il tuo stomaco e miagolando infelice."


translate ita feedBlood_e33e9f59:


    "Vorresti rassicurarlo, ma non è che vi possiate parlare."


translate ita feedBlood_7c678cc4:


    "Cerchi di ricordare quando è stata l'ultima volta in cui hai parlato con {i}qualcuno{/i}, in realtà..."


translate ita feedBlood_e9b924ed:


    "Se dovessi morire adesso, qui, in questo vicolo..."


translate ita feedBlood_78256794:


    "... quanto ci metterebbe qualcuno ad accorgersi della tua assenza?"


translate ita feedBlood_dba3e829:


    "Che non ci sei {b}{i}più{/i}{/b}...?"


translate ita feedBlood_a20cefa7_2:


    "..."


translate ita feedBlood_b0768480:


    cat "{size=+10}Miao!!!{/size}" with hpunch


translate ita feedBlood_28b3ac41:


    you "!!!"


translate ita feedBlood_1742e74d:


    "L'insistente miagolio del gatto che si allunga sulle tue gambe interrompe i tuoi pensieri."


translate ita feedBlood_2183d3c6:


    "Non fai in tempo a porti delle domande, perché una voce risuona all'entrata del vicolo."


translate ita feedBlood_f44a447d:


    who "Ehi...?"


translate ita feedBlood_e7a89ae7:


    who "Ehi, tu! Stai... bene?"


translate ita feedBlood_d209807a:


    "Non rispondi. Non pensi di {i}riuscirci.{/i}"


translate ita feedBlood_8208fd13:


    "La tua voce sembra bloccata... in profondità, dentro di te."


translate ita feedBlood_bc95f001:


    "Il gatto ti guarda a lungo... {w}come se ti stesse valutando."


translate ita feedBlood_c058177f:


    "Guarda in direzione della voce e dopo aver strofinato il naso sul tuo stomaco un'ultima volta..."


translate ita feedBlood_93a5d8f4:


    "... ti salta giù dalle gambe e cammina verso l'entrata del vicolo..."


translate ita feedBlood_4e4b3a2b:


    "Ma poi..."


translate ita feedBlood_6e3d0e44:


    "... inizia a {b}cambiare{/b}... come-{w=0.5}{nw}"


translate ita feedBlood_922194c3:


    "Crack!" with vpunch


translate ita feedBlood_90b68c87:


    you "...?"


translate ita feedBlood_56ebb028:


    you "!!!"


translate ita feedBlood_bcc1608b:


    "La sua faccia... {i}si apre{/i}..."


translate ita feedBlood_1a0a44a7:


    "{size=+15}{b}CRACK!!!{/b}{/size}" with vpunch


translate ita feedBlood_6a8f2f72:


    "Si ritrae."


translate ita feedBlood_18494b91:


    "... e si apre {i}di nuovo{/i}... "


translate ita feedBlood_54d0e137:


    "... dei tentacoli contorti sbucano dal punto in cui dovrebbe trovarsi la bocca."


translate ita feedBlood_30bf4da2:


    "L'ombra sconosciuta si ferma all'entrata del vicolo... "


translate ita feedBlood_300597e8:


    who "C-che diavolo è-?"


translate ita feedBlood_84218509:


    "Ma non ha modo di finire la domanda."


translate ita feedBlood_aa46e9c3:


    "I tentacoli convergono in uno solo..."


translate ita feedBlood_7e5bb0e2:


    "... fuoriescono dalle fauci del gatto-"


translate ita feedBlood_168a8ded:


    "... e {i}{b}penetrano{/b}{/i} nella spalla dello sconosciuto."


translate ita feedBlood_71716684:


    who "{size=+10}AAH!!!{/size}" with vpunch


translate ita feedBlood_c13159e5:


    who "{size=+10}{i}A-AAAHHHHH!{/i}{/size}" with vpunch


translate ita feedBlood_e6c19910:


    "Emette un grido di dolore... e di terrore."


translate ita feedBlood_bc6e9a70:


    "Si aggrappa ai tentacoli, cercando di tirarli via... {w}ma senza successo. "


translate ita feedBlood_55e0cee4:


    "Tu... {w}non riesci a reagire."


translate ita feedBlood_d3b6988c:


    "Fissi la creatura davanti a te..."


translate ita feedBlood_f2277d90:


    "Così diversa dal gatto che poco prima stava miagolando preoccupato..."


translate ita blood_stopCat_282f048b:


    "Non puoi..."


translate ita blood_stopCat_aba81e88:


    "Non puoi lasciare che accada."


translate ita blood_stopCat_dae0ec55:


    you "..."


translate ita blood_stopCat_e5406a2e:


    "Tremante, strisci in avanti..."


translate ita blood_stopCat_b4131218:


    "... e afferri debolmente i tentacoli che pulsano mentre drenano il sangue dello sconosciuto. "


translate ita blood_stopCat_072b7df9:


    "Tiri più forte che puoi, i tentacoli smettono di pulsare... e il gatto si gira verso di te."


translate ita blood_stopCat_36245d43:


    cat "Plrr? Pllrrr?"


translate ita blood_stopCat_6fca227b:


    "Fa uno strano rumore, sembra quasi una domanda..."


translate ita blood_stopCat_e1a9cee7:


    "Ma non hai risposte."


translate ita blood_stopCat_f007bcff:


    "Non riesci nemmeno a capire cosa voglia..."


translate ita blood_stopCat_b9b06782:


    "Ti limiti ad attirare a te la creatura... {w}il {i}gatto{/i}... {w}cullandolo tra le braccia."


translate ita blood_stopCat_6a141fd0:


    "Guardi la luce all'entrata del vicolo quasi con nostalgia."


translate ita blood_stopCat_f70d6c24:


    "Non sai cosa stia succedendo..."


translate ita blood_stopCat_53834d64:


    "... ma non puoi restare lì a guardare qualcuno che viene divorato in quel modo..."


translate ita blood_stopCat_d84cf8f5:


    "Non quando ha solo provato a vedere se stessi bene..."


translate ita blood_stopCat_a20cefa7:


    "..."


translate ita blood_stopCat_da22d380:


    "... Non quando potresti sacrificarti al suo posto."


translate ita blood_stopCat_705c4802:


    "Pensi che quella persona si sia salvata..."


translate ita blood_stopCat_0c3e5209:


    "... perché senti il suono di scarpe che sfregano sul marciapiede e svaniscono in lontananza..."


translate ita blood_stopCat_5b8efe03:


    you "Agh!" with vpunch


translate ita blood_stopCat_3a5f5491:


    "... Senti qualcosa di appuntito che ti buca la schiena. "


translate ita blood_stopCat_183312a6:


    "Sembra sottile... {w}come un ago... {w}quindi il dolore passa velocemente mentre il corpo si adatta all'intruso."


translate ita blood_stopCat_123c6d3b:


    "Sai per certo che non era così sottile quando ha infilzato la spalla dello sconosciuto prima..."


translate ita blood_stopCat_c69f0708:


    "... ma senti il sangue scorrerti via dal corpo, lentamente, come se venisse pompato fuori..."


translate ita blood_stopCat_5a001e33:


    "... Pensare diventa più difficile e la tua vista inizia a offuscarsi."


translate ita blood_stopCat_67bd589d:


    "La creatura tra le tue braccia emette un piccolo suono."


translate ita blood_stopCat_f316015b:


    "La stringi a te il più possibile, anche se senti le braccia deboli."


translate ita blood_stopCat_a20cefa7_1:


    "..."


translate ita blood_stopCat_aca7b3c0:


    "Va bene... {w}Per te va bene così... "


translate ita blood_stopCat_b8bfa8a5:


    "Non sai se questo cambierà qualcosa..."


translate ita blood_stopCat_07e8897d:


    "Sicuramente il gatto avrà di nuovo fame dopo che sarai..."


translate ita blood_stopCat_436f749d:


    "... {i}non è più un'{b}opzione{/b}{/i}..."


translate ita blood_stopCat_a20cefa7_2:


    "..."


translate ita blood_stopCat_bf0874e3:


    "Ma..."


translate ita blood_stopCat_4145e893:


    "Almeno {i}questa{/i} volta..."


translate ita blood_stopCat_6cf080cc:


    "... hai... {w}salvato qualcuno."


translate ita blood_stopCat_8dabefc6:


    ".."


translate ita blood_stopCat_a20cefa7_3:


    "..."


translate ita blood_stopCat_68d32565:


    "Finale 28: Il pranzo è servito"


translate ita blood_letCatFeed_af799a70:


    who "AAAHH!" with hpunch


translate ita blood_letCatFeed_f1a276a2:


    who "Qualcuno mi aiuti! Aiuto! Aiutatemi!" with vpunch


translate ita blood_letCatFeed_7ec51c3a:


    who "*gurgle* Aiu...t..."


translate ita blood_letCatFeed_dae0ec55:


    you "..."


translate ita blood_letCatFeed_849e135c:


    "Distogli lo sguardo mentre la creatura divora lo sconosciuto..."


translate ita blood_letCatFeed_dd2ab70b:


    "... prosciugandolo fino a quando non resta altro che un mucchio di ossa, pelle e vestiti sul pavimento."


translate ita blood_letCatFeed_a20cefa7:


    "..."


translate ita blood_letCatFeed_b7ce0db6:


    "Ti senti malissimo però..."


translate ita blood_letCatFeed_1357f3f7:


    "Cosa potevi fare?"


translate ita blood_letCatFeed_e77a0648:


    "Anche quella creatura è un essere vivente..."


translate ita blood_letCatFeed_44d1ec02:


    "Non ha anche lei il diritto di mangiare ciò che le serve?"


translate ita blood_letCatFeed_37410cf6:


    "Non ha forse anche lei il diritto di fare ciò che deve per sopravvivere?"


translate ita blood_letCatFeed_a20cefa7_1:


    "..."


translate ita blood_letCatFeed_53cc9d41:


    "Ignori la vocina nella tua testa che ti chiede se poteva andare diversamente."


translate ita blood_letCatFeed_a6d2e181:


    "Certo, non hai cercato di capire se potesse mangiare qualcosa oltre al sangue... {w}{i}sangue umano{/i}..."


translate ita blood_letCatFeed_48f6f1e3:


    "{size=-10}{b}...non {i}l'hai fatto{/i}, no?{/b}{/size}"


translate ita blood_letCatFeed_dae0ec55_1:


    you "..."


translate ita blood_letCatFeed_d7365832:


    "La creatura fa le fusa mentre si strofina contro il tuo braccio."


translate ita blood_letCatFeed_1282871c:


    "Ti accorgi che, dopo aver riposato un po', ti senti meglio."


translate ita blood_letCatFeed_a20cefa7_2:


    "..."


translate ita blood_letCatFeed_bf0874e3:


    "Ma..."


translate ita blood_letCatFeed_84f45571:


    "Pensi anche che..."


translate ita blood_letCatFeed_3d2f6324:


    "... qualcosa dentro di te..."


translate ita blood_letCatFeed_90f90ddb:


    "{size=-8}... si sia rotto.{/size}"


translate ita blood_letCatFeed_a20cefa7_3:


    "..."


translate ita blood_letCatFeed_e93c9366:


    "Ma non sai ancora cosa."


translate ita blood_letCatFeed_8dabefc6:


    ".."


translate ita blood_letCatFeed_a20cefa7_4:


    "..."


translate ita blood_letCatFeed_cbc44f0b:


    "Ti alzi e allunghi le braccia."


translate ita blood_letCatFeed_8517210f:


    you "Hai ancora fame?"


translate ita blood_letCatFeed_f8095b37:


    cat "Pllrrrrrrp!" with hpunch


translate ita blood_letCatFeed_3cdc6c20:


    "La creatura emette un suono e ti salta felice tra le braccia."


translate ita blood_letCatFeed_dae0ec55_2:


    you "..."


translate ita blood_letCatFeed_7255bffc:


    you "... Andiamo allora, sì?"


translate ita blood_letCatFeed_33f9f94c:


    cat "Plrrrr..."


translate ita blood_letCatFeed_a20cefa7_5:


    "..."


translate ita blood_letCatFeed_ce06cd2d:


    "Andate via insieme."


translate ita blood_letCatFeed_f363c184:


    "Vi affacciate al mondo {i}insieme.{/i} "


translate ita blood_letCatFeed_a20cefa7_6:


    "..."


translate ita blood_letCatFeed_53d0da23:


    "Il gatto ha fame..."


translate ita blood_letCatFeed_4919a924:


    "... e d'ora in poi, sarà spesso affamato."


translate ita blood_letCatFeed_d58fc52c:


    "{i}Molto{/i} spesso."


translate ita blood_letCatFeed_a20cefa7_7:


    "..."


translate ita blood_letCatFeed_701eb808:


    "Urla di terrore vi seguono ovunque andiate..."


translate ita blood_letCatFeed_7a7de0ae:


    "E senza preoccupartene minimamente..."


translate ita blood_letCatFeed_d2542ef5:


    "Te ne stai in disparte..."


translate ita blood_letCatFeed_fb3d9cf0:


    "{size=-8}... e \ {b}g u a r d i{/b}.{/size}"


translate ita blood_letCatFeed_8dabefc6_1:


    ".."


translate ita blood_letCatFeed_a20cefa7_8:


    "..."


translate ita blood_letCatFeed_637cffb5:


    "Finale 29: All You Can Eat al Sangue"


translate ita playAlley_4367a7aa:


    cat "Miao! Miaoo!"


translate ita playAlley_eea1ecbb:


    you "Oooh... vuoi solo un po' di attenzioni, vero?"


translate ita playAlley_67107e6c:


    cat "Purr..."


translate ita playAlley_4926c274:


    "Quel povero gattino sarà annoiato, tutto il giorno seduto in quella scatola."


translate ita playAlley_bab8d9a9:


    "Di certo non sei una compagnia interessante, ma vuoi fare del tuo meglio."


translate ita playAlley_f719e5a9:


    "Ci sarà qualcosa che puoi fare per intrattenere quella bestiolina..."


translate ita playAlley_66c13733:


    "Ma cosa?"


translate ita play_pockets_5cfb3464:


    "Cerchi nelle tasche."


translate ita play_pockets_f8c73033:


    "Trovi un pezzetto di filo nella tasca sinistra. Non è molto utile."


translate ita play_pockets_ab3079c6:


    "Il filo è decisamente troppo corto."


translate ita play_pockets_c0209341:


    "Un gatto ansioso ed eccitato potrebbe facilmente{w=1.0}{nw}"


translate ita play_pockets_632d1a35:


    you "!!!" with hpunch


translate ita play_pockets_8dabefc6:


    ".."


translate ita play_pockets_a20cefa7:


    "..."


translate ita play_pockets_f42805d9:


    "Un gatto ansioso ed eccitato potrebbe facilmente morderti o graffiarti."


translate ita play_pockets_f8cb7b4a:


    "Nella tua tasca destra..."


translate ita play_pockets_d38263f6:


    "{size=-10}... c'è una barretta di {color=#FF0000}cioccolato.{/color}{/size}"


translate ita play_pockets_f3654da7:


    "{size=-5}mi dispiace {w=0.5}mi dispiace {w=0.5}mi dispiace {w=0.5}mi dispiace {w=0.5}mi dispiace {w=0.5}mi dispiace {w=0.5}mi dispiace {w=0.5}mi disp {/size}{w=0.2}{nw}"


translate ita play_pockets_dae0ec55:


    you "..."


translate ita play_pockets_31772800:


    "... c'è una barretta di cioccolato."


translate ita play_pockets_d3dcd610:


    "Non ti serve al momento."


translate ita play_pockets_632cc2c6:


    "L'unica cosa che hai con te è il telefono."


translate ita play_pockets_a20cefa7_1:


    "..."


translate ita play_pockets_6a7c031d:


    "Di certo non è l'ideale per farci giocare il gatto..."


translate ita play_pockets_ff3c3ccc:


    "Però {i}c'è{/i} qualcosa che {i}tu{/i} puoi fare..."


translate ita play_pockets_4e248d1e:


    "{size=+15}{b}{i}Fotooo~!!!{/i}{/b}{/size}" with hpunch


translate ita play_pockets_a20cefa7_2:


    "..."


translate ita play_pockets_297839ea:


    you "Beh, è stato divertente, no?"


translate ita play_pockets_7f0ac95c:


    cat "..."


translate ita play_pockets_dae0ec55_1:


    you "..."


translate ita play_pockets_fa1cff19:


    "Beh, per {i}te{/i} lo è stato..."


translate ita play_pockets_aa21a61c:


    "Senza nient'altro da fare e zero intenzioni di portare il gatto a casa..."


translate ita play_pockets_3d3eeb7e:


    "... decidi che forse è meglio andare via."


translate ita play_pockets_be1c1ed6:


    "In fondo, non vuoi che il gatto ti si affezioni troppo."


translate ita play_pockets_f0eb3116:


    "Almeno hai qualche ricordo da tenere con te."


translate ita play_pockets_dfcd2239:


    you "Okay, ehm... Ci vediamo in giro, credo. Buona fortuna?"


translate ita play_pockets_7f0ac95c_1:


    cat "..."


translate ita play_pockets_fa41c4c2:


    you "... Ok."


translate ita play_pockets_18133987:


    "Ti giri e ti incammini, ma mentre stai andando via dal vicolo-{w=1.2}{nw}"


translate ita play_pockets_1919fb1f:


    "*BZZT*!" with hpunch


translate ita play_pockets_5d06f92b:


    you "Uhm?"


translate ita play_pockets_bc2cce8e:


    "Hai ricevuto un messaggio."


translate ita play_pockets_ab96140d:


    "Lo apri e..."


translate ita play_pockets_a20cefa7_3:


    "..."


translate ita play_pockets_40d9ca73:


    "...?"


translate ita play_pockets_74be92cd:


    you "Cosa...?"


translate ita play_pockets_4b6994e1:


    phoneText "{b}--non sono carino???--{/b}"


translate ita play_pockets_f8a1ca53:


    "È la foto di un gatto dall'aria familiare..."


translate ita play_pockets_c90675bd:


    you "Uh?"


translate ita play_pockets_c4799a25:


    "Il gatto {i}in effetti{/i} sembra carino..."


translate ita play_pockets_308c65d2:


    "E più felice nella foto..."


translate ita play_pockets_a20cefa7_4:


    "..."


translate ita play_pockets_122874da:


    "... ma è una foto che {b}non{/b} riconosci."


translate ita play_pockets_22b5aa5b:


    you "Ma che cavolo...? Ho...?"


translate ita play_pockets_5f369989:


    "{size=-10}non hai scattato tu questa foto.{/size}"


translate ita play_pockets_63fc373e:


    "Lanci uno sguardo al gatto..."


translate ita play_pockets_a20cefa7_5:


    "..."


translate ita play_pockets_6d6c3c7a:


    "... ma il gatto ti sta semplicemente guardando."


translate ita play_pockets_9cad6637:


    cat "Miaooo..."


translate ita play_pockets_f0c613db:


    "Miagola triste, come se ti stesse pregando di tornare indietro."


translate ita play_pockets_dae0ec55_2:


    you "..."


translate ita play_pockets_10090c2b:


    you "Beh... forse posso rimanere ancora un po'..."


translate ita play_pockets_c44e377e:


    cat "Miaoo!" with hpunch


translate ita play_pockets_a43f8b59:


    you "Ma ora cosa facciamo..."


translate ita play_pockets_16879ce5:


    cat "Miao?"


translate ita phoneHome_dae0ec55:


    you "..."


translate ita phoneHome_b31d124d:


    "Ignori il gatto e vai via dal vicolo senza guardarti indietro."


translate ita phoneHome_b0f8881c:


    you "Fiuu..."


translate ita phoneHome_474b3625:


    you "È stato strano..."


translate ita phoneHome_48a233a3:


    "Sei abbastanza distante quando-"


translate ita phoneHome_1919fb1f:


    "*BZZT*!" with hpunch


translate ita phoneHome_8a8661d4:


    you "...! Non di nuovo..."


translate ita phoneHome_d472fea1:


    "Riluttante, guardi il nuovo messaggio e..."


translate ita phoneHome_f6b2a9a9:


    phoneText "{b}--non mi ignorareee ;_;--{/b}"


translate ita phoneHome_8dabefc6:


    ".."


translate ita phoneHome_a20cefa7:


    "..."


translate ita phoneHome_e1c95b67:


    "Hai i brividi... e decidi di tornare a casa."


translate ita phoneHome_1919fb1f_1:


    "*BZZT*" with hpunch


translate ita phoneHome_934d45d4:


    phoneText "{b}--so che li stai leggendo--{/b}"


translate ita phoneHome_1919fb1f_2:


    "*BZZT*!" with hpunch


translate ita phoneHome_f089ea18:


    phoneText "{b}--torna indietro--{/b}"


translate ita phoneHome_dae0ec55_1:


    you "..."


translate ita phoneHome_1919fb1f_3:


    "*BZZT*!" with hpunch


translate ita phoneHome_f089ea18_1:


    phoneText "{b}--torna indietro--{/b}"


translate ita phoneHome_1919fb1f_4:


    "*BZZT*!" with hpunch


translate ita phoneHome_f089ea18_2:


    phoneText "{b}--torna indietro--{/b}"


translate ita phoneHome_1919fb1f_5:


    "*BZZT*" with hpunch


translate ita phoneHome_f089ea18_3:


    phoneText "{b}--torna indietro--{/b}"


translate ita phoneHome_1919fb1f_6:


    "*BZZT*" with hpunch


translate ita phoneHome_f089ea18_4:


    phoneText "{b}--torna indietro--{/b}"


translate ita phoneHome_1919fb1f_7:


    "*BZZT*" with hpunch


translate ita phoneHome_d4d2616a:


    "*BZZT* *BZZT*" with hpunch


translate ita phoneHome_65ea3a0a:


    phoneText "{b}--torna indietro torna indietro torna indietro torna indietro torna indietro torna indietro torna indietro torna indietro torna indietro torna indietro torna indietro torna indietro torna indietro torna indietro torna indietro--{/b}"


translate ita phoneHome_dae0ec55_2:


    you "..."


translate ita phoneHome_99f007c0:


    "{size=-8}*bzzt*...{/size}"


translate ita phoneHome_4b8a63af:


    phoneText "{b}--riesco a vederti--{/b}"


translate ita phoneHome_99f007c0_1:


    "{size=-8}*bzzt*...{/size}"


translate ita phoneHome_42283d6e:


    phoneText "{b}--riesco SEMPRE a vederti--{/b}"


translate ita phoneHome_36feac05:


    phoneText "{b}--NON PUOI NASCONDERTI--{/b}"


translate ita phoneHome_4f8f387e:


    phoneText "{b}--io ti troverò sempreeee OwO--{/b}"


translate ita phoneHome_dae0ec55_3:


    you "..."


translate ita phoneHome_6ba80fd4:


    "Ti guardi nervosamente intorno... {i}con la certezza{/i} che ti stiano seguendo. "


translate ita phoneHome_8dabefc6_1:


    ".."


translate ita phoneHome_a20cefa7_1:


    "..."


translate ita phoneHome_f89b839f:


    "{size=-8}Ma qui non c'è nulla.{/size}"


translate ita phoneHome_dae0ec55_4:


    you "..."


translate ita phoneHome_8dabefc6_2:


    ".."


translate ita phoneHome_a20cefa7_2:


    "..."


translate ita phoneHome_e6e0bd68:


    "Finalmente sei a casa, ma l'agitazione ti impedisce di calmarti."


translate ita phoneHome_86f767b7:


    "Corri in bagno e ti chiudi la porta alle spalle."


translate ita phoneHome_5489dbe4:


    you "Va tutto bene..."


translate ita phoneHome_1d1ef86b:


    you "Non è reale..."


translate ita phoneHome_cb8665e3:


    "È solo un brutto sogno..."


translate ita phoneHome_88b66f2a:


    "Va tutto... bene..."


translate ita phoneHome_a20cefa7_3:


    "..."


translate ita phoneHome_fa440177:


    "Arranchi nel buio e apri il rubinetto per sciacquarti il viso con l'acqua fredda..."


translate ita phoneHome_274213b7:


    "... sperando che ti aiuti a calmarti... {w}e a fermare le allucinazioni."


translate ita phoneHome_ba425576:


    "{size=-5}Perché è di questo che si tratta, no?{/size}"


translate ita phoneHome_03f60dc4:


    "{size=-8}... Allucinazioni?{/size}"


translate ita phoneHome_a20cefa7_4:


    "..."


translate ita phoneHome_366ae109:


    "Ti penti di aver messo il naso fuori di casa oggi."


translate ita phoneHome_207ad5fd:


    "Devi aver lavorato troppo, più di quanto pensassi..."


translate ita phoneHome_d200e00e:


    "Già... Deve essere qu-"


translate ita phoneHome_05b04601:


    "{b}*BZZT*!{/b}" with hpunch


translate ita phoneHome_8ca8510a:


    you "!!!" with vpunch


translate ita phoneHome_d4eb578f:


    "Ti spaventi quando ricevi la notifica di un altro messaggio."


translate ita phoneHome_dae0ec55_5:


    you "..."


translate ita checkPhone_8fa7a50f:


    "Con le mani tremanti, guardi il telefono..."


translate ita checkPhone_2bd17ff9:


    phoneText "{b}--cIaO--{/b}"


translate ita checkPhone_8ca8510a:


    you "!!!" with vpunch


translate ita checkPhone_af7e27d2:


    you "Cos... Cosa...?"


translate ita checkPhone_db4a3473:


    "Ti giri intorno e istintivamente salti all'indietro..."


translate ita checkPhone_a20cefa7:


    "..."


translate ita checkPhone_0f5de544:


    "Tu..."


translate ita checkPhone_8b35204f:


    "Tu {i}scivoli...{/i}"


translate ita checkPhone_22c24f7e:


    "... sbattendo la nuca contro lo specchio del bagno."


translate ita checkPhone_2168405d:


    "Non ti accorgi subito del dolore. I tuoi occhi perlustrano la stanza."


translate ita checkPhone_8dabefc6:


    ".."


translate ita checkPhone_a20cefa7_1:


    "..."


translate ita checkPhone_7af4a8ac:


    "Non..."


translate ita checkPhone_a9f7a5de:


    "Non c'è niente qui."


translate ita checkPhone_bd69546a:


    "Niente di niente..."


translate ita checkPhone_a20cefa7_2:


    "..."


translate ita checkPhone_f887a3f9:


    "... Ti senti debole."


translate ita checkPhone_74fa22f3:


    "Ti tocchi la nuca ed esamini la tua mano."


translate ita checkPhone_8dabefc6_1:


    ".."


translate ita checkPhone_a20cefa7_3:


    "..."


translate ita checkPhone_9eca284d:


    "Non riesci a vedere nulla..."


translate ita checkPhone_a20cefa7_4:


    "..."


translate ita checkPhone_e5477b1e:


    "Ma senti calore..."


translate ita checkPhone_fb2e25e6:


    "... e qualcosa di {i}bagnato.{/i}"


translate ita checkPhone_8e7eed80:


    "L'odore di rame riempie l'aria..."


translate ita checkPhone_c953e0ca:


    "In stato confusionario, crolli sulle mattonelle del bagno."


translate ita checkPhone_bf69ea4a:


    you "Aiut... o..."


translate ita checkPhone_72ca9f5f:


    "Raggiungi il telefono per chiamare un'ambulanza..."


translate ita checkPhone_8dabefc6_2:


    ".."


translate ita checkPhone_a20cefa7_5:


    "..."


translate ita checkPhone_842f2398:


    "... La batteria è morta."


translate ita checkPhone_8dabefc6_3:


    ".."


translate ita checkPhone_a20cefa7_6:


    "..."


translate ita checkPhone_a5333c46:


    "Finale 30: Photo bomber"


translate ita ignorePhone_05b04601:


    "{b}*BZZT*!{/b}" with hpunch


translate ita ignorePhone_45e226d6:


    "{b}*BZZT*! *BZZT*! *BZZT*!{/b}" with hpunch


translate ita ignorePhone_3e5256b6:


    "{size=+20}{b}*BZZT*!{/b}{/size}" with hpunch


translate ita ignorePhone_43511216:


    "Il telefono continua a vibrare senza sosta..."


translate ita ignorePhone_a20cefa7:


    "..."


translate ita ignorePhone_6741af6f:


    "... ma non riesci a guardarlo."


translate ita ignorePhone_97d37cc5:


    "Tieni gli occhi chiusi, le dita strette al bordo del lavandino."


translate ita ignorePhone_9e64b774:


    "Nella tua testa, preghi che chiunque... o {i}qualunque cosa{/i} stia facendo questo la smetta... "


translate ita ignorePhone_702b5575:


    "Per favore... Per favore..."


translate ita ignorePhone_6a348634:


    you "Per favore... metti fine alle mie sofferenze."


translate ita ignorePhone_dcdacf88:


    "Parli sottovoce. Non... lo pensi {i}davvero{/i}."


translate ita ignorePhone_6ce1cb34:


    "Non {i}sul serio.{/i}"


translate ita ignorePhone_a20cefa7_1:


    "..."


translate ita ignorePhone_7bc58a93:


    "Ma quando queste parole prendono forma negli angoli più bui della tua mente..."


translate ita ignorePhone_58827019:


    "... il telefono smette {i}immediatamente{/i} di vibrare."


translate ita ignorePhone_e2a45fdf:


    "Pensavi che questo ti avrebbe fatto sentire meglio..."


translate ita ignorePhone_a20cefa7_2:


    "..."


translate ita ignorePhone_ae9f462d:


    "... ma provi solo un profondo terrore nello stomaco."


translate ita ignorePhone_698fca08:


    "Senti degli occhi addosso..."


translate ita ignorePhone_19e3c7ae:


    "Avverti un soffio d'aria sul collo... {w}umido, intenso e {b}lento{/b}... "


translate ita ignorePhone_0f7f3730:


    "Fai un respiro profondo e apri gli occhi..."


translate ita ignorePhone_d6fac14d:


    "Guardi..."


translate ita ignorePhone_0f5c8741:


    "... lo specchio."


translate ita ignorePhone_8dabefc6:


    ".."


translate ita ignorePhone_a20cefa7_3:


    "..."


translate ita ignorePhone_97d7e1ff:


    "... Niente."


translate ita ignorePhone_7688b87e:


    "Dai un'occhiata veloce alla stanza."


translate ita ignorePhone_8dabefc6_1:


    ".."


translate ita ignorePhone_a20cefa7_4:


    "..."


translate ita ignorePhone_d39ba71d:


    "... Ancora nulla. {w}Niente di niente... "


translate ita ignorePhone_fa14a2fd:


    "Ma tu lo sai. Tu {i}sai{/i} che lì c'è qualcosa..."


translate ita ignorePhone_3a16261e:


    "Che aspetta di essere visto..."


translate ita ignorePhone_9080b186:


    "Aspetta che ti accorga della sua esistenza."


translate ita ignorePhone_195993dc:


    "Solo {i}allora{/i} ti lascerà in pace..."


translate ita ignorePhone_0d88251d:


    "... ti libererà da una vita passata a guardarti alle spalle..."


translate ita ignorePhone_98aa90d7:


    "... dalla paura della tua stessa immagine... {w}del tuo stesso riflesso."


translate ita ignorePhone_0a31632a:


    "Avverti la sua pazienza, infinita e antica."


translate ita ignorePhone_7d6512f3:


    "Non puoi vincere in una guerra di logoramento."


translate ita ignorePhone_f8fa2106:


    "La tua vita finirà prima che si stanchi di te."


translate ita ignorePhone_42b896f8:


    "Quindi..."


translate ita ignorePhone_a20cefa7_5:


    "..."


translate ita ignorePhone_dec216e1:


    "Chiudi gli occhi..."


translate ita ignorePhone_8dabefc6_2:


    ".."


translate ita ignorePhone_a20cefa7_6:


    "..."


translate ita ignorePhone_3275149d:


    "... e ti arrendi."


translate ita ignorePhone_632d1a35:


    you "!!!" with hpunch


translate ita ignorePhone_dae0ec55:


    you "..."


translate ita ignorePhone_902a5fbf:


    "Quando la tua testa si stacca dal collo, senti un senso di pace... {w}felice che almeno..."


translate ita ignorePhone_e515cfae:


    "... tu non abbia dovuto {color=#FF0000}vederlo.{/color}"


translate ita ignorePhone_faca898b:


    "Qualunque {color=#FF0000}cosa{/color} fosse..."


translate ita ignorePhone_8dabefc6_3:


    ".."


translate ita ignorePhone_a20cefa7_7:


    "..."


translate ita ignorePhone_3d7f79a0:


    "Finale 31: Colpo di testa"


translate ita play_lookAround_fe95c45e:


    "Cerchi nei dintorni..."


translate ita play_lookAround_26d8fe49:


    "... ma nel vicolo non c'è niente che sembri abbastanza interessante da farci giocare il gatto."


translate ita play_lookAround_d230d6d0:


    "Quindi forse..."


translate ita play_lookAround_8895ca7b:


    you "Che ne dici di... un gioco?"


translate ita play_lookAround_16879ce5:


    cat "Miao?"


translate ita play_lookAround_09d74134:


    "Opti per un gioco che conosci dall'infanzia..."


translate ita play_lookAround_6a840dc3:


    "Un, due, tre... stella... {w}un classico."


translate ita play_lookAround_fb2631f7:


    "Insegnarlo a un gatto potrebbe essere difficile..."


translate ita play_lookAround_fcf103dd:


    "... ma hai la sensazione che l'instito di caccia dei felini ti sarà utile."


translate ita play_lookAround_ef9d4eaf:


    "Cammini verso l'ingresso del vicolo, il gatto miagola verso di te."


translate ita play_lookAround_4367a7aa:


    cat "Miao! Miaoo!"


translate ita play_lookAround_cfb6ac60:


    you "Non preoccuparti, non vado via~"


translate ita play_lookAround_3d7739d9:


    "Fai movimenti esagerati, ti copri gli occhi con le mani e... ti volti."


translate ita play_lookAround_79b5cf51:


    you "Uno... {w}Due... {w}Tre... {w}.{w}.{w}."


translate ita play_lookAround_1b42e081:


    you "... Stella!" with hpunch


translate ita play_lookAround_93fd1982:


    "Ti volti."


translate ita play_lookAround_b4e52671:


    "Il gatto non si è mosso dalla scatola, la testa piegata mentre ti guarda confuso ma incuriosito."


translate ita play_lookAround_7c7b7c3d:


    "Forse il concetto è troppo difficile per un gatto..."


translate ita play_lookAround_e64afe7e:


    "Non fa niente. Penserai a qualcos'altro da fare."


translate ita playRedLight_ddbe32ac:


    "Ci provi di nuovo."


translate ita playRedLight_3c3c3328:


    "Questa volta un po' più piano."


translate ita playRedLight_e64b19d2:


    you "Uno..."


translate ita playRedLight_a20cefa7:


    "..."


translate ita playRedLight_382ca646:


    you "Duue~"


translate ita playRedLight_a20cefa7_1:


    "..."


translate ita playRedLight_68231842:


    you "Treeeee~"


translate ita playRedLight_8dabefc6:


    ".."


translate ita playRedLight_a20cefa7_2:


    "..."


translate ita playRedLight_652686fc:


    you "STELLA~!" with hpunch


translate ita playRedLight_5f5eef33:


    "Stavolta, quando ti giri..."


translate ita playRedLight_6319ec5c:


    "... il gatto è uscito dalla scatola."


translate ita playRedLight_ab6d5659:


    cat "!!!" with hpunch


translate ita playRedLight_20c4e0a4:


    "Il gatto si ferma quando lo guardi, come se pensasse di non essere visto se non si muove."


translate ita playRedLight_13bef835:


    you "{i}Che carino~{/i}"


translate ita playRedLight_0743b011:


    "Felice che il gatto ci stia prendendo la mano, ti giri ancora... stavolta più velocemente."


translate ita playRedLight_488ec393:


    you "Uno... Due... Tre..."


translate ita playRedLight_30030125:


    you "Stella!" with hpunch


translate ita playRedLight_65781c81:


    "Ti volti..."


translate ita playRedLight_d6257afb:


    "Il gatto ora è andato avanti, ti guarda da dietro un cassonetto..."


translate ita playRedLight_74164412:


    "... i suoi occhi sono concentrati piuttosto... {w}{i}intensamente{/i} su di te."


translate ita playRedLight_a20cefa7_3:


    "..."


translate ita playRedLight_c450b224:


    "Beh... {w}almeno si sta divertendo, no?"


translate ita playRedLight_a20cefa7_4:


    "..."


translate ita playRedLight_5a29d90a:


    "Ti giri di nuovo..."


translate ita playRedLight_a20cefa7_5:


    "..."


translate ita playRedLight_e3ca830a:


    "... e senti un brivido improvviso lungo la schiena."


translate ita playRedLight_90b68c87:


    you "...?"


translate ita playRedLight_0c09560a:


    "Forse è ridicolo... {w}ma non puoi fare a meno di contare un {i}po'{/i} più veloce questa volta..."


translate ita playRedLight_7f66eaea:


    you "Un, due, tre, stella!" with hpunch


translate ita playRedLight_79eb9703:


    "... Ti volti dopo aver detto \"stella!\""


translate ita playRedLight_a20cefa7_6:


    "..."


translate ita playRedLight_3f788947:


    "Guardi il gatto..."


translate ita playRedLight_18019ca8:


    "È a metà strada, più vicino a te, ma..."


translate ita playRedLight_a20cefa7_7:


    "..."


translate ita playRedLight_5812c142:


    "... è come se ci fosse qualcosa di {b}sbagliato{/b} nella prospettiva."


translate ita playRedLight_325acab7:


    "Il gatto sembra un po'... {w}{i}più grande{/i}, no...?"


translate ita playRedLight_4390a056:


    "Le sue pupille adesso sono sottili."


translate ita playRedLight_7f0ac95c:


    cat "..."


translate ita playRedLight_dae0ec55:


    you "..."


translate ita playRedLight_973413d4:


    "C'è qualcosa..."


translate ita playRedLight_2aad8b65:


    "{size=-5}C'è qualcosa che non va.{/size}"


translate ita playRedLight_4f37bfcc:


    cat "Roaarrr..."


translate ita playRedLight_84627845:


    "Il gatto miagola di nuovo, ma questa volta il suono è molto più {b}profondo{/b}."


translate ita playRedLight_cee07e8b:


    "È accovacciato... come fosse pronto a scattare..."


translate ita playRedLight_133b6978:


    "Il respiro diventa affannoso e il tuo cuore inizia a battere forte."


translate ita playRedLight_e43c0e50:


    "Instintivamente, fai un passo indietro-"


translate ita playRedLight_1948cb48:


    cat "{size=+20}{b}ROOOAAARRR!{/b}{/size}" with hpunch


translate ita playRedLight_8ca8510a:


    you "!!!" with vpunch


translate ita playRedLight_4f55a03f:


    "Ti blocchi immediatamente."


translate ita playRedLight_0e14e06c:


    "Il gatto sembra..."


translate ita playRedLight_a34925d6:


    "... {b}impaziente{/b}."


translate ita playRedLight_8dbd85ab:


    "Vuole... vuole continuare a giocare?"


translate ita playRedLight_9897df30:


    "{size=-5}Ma...{/size}"


translate ita playRedLight_dae0ec55_1:


    you "..."


translate ita playRedLight_8ed89f65:


    "Sussulti e ti volti, {w}contando velocemente e girandoti subito..."


translate ita playRedLight_41759c18:


    you "{size=-5}U-Un-due-tre-stella!!!{/size}"


translate ita playRedLight_3aae9beb:


    "{size=+35}{b}CRASH!!!{/b}{/size}" with vpunch


translate ita playRedLight_632d1a35:


    you "!!!" with hpunch


translate ita playRedLight_6022342a:


    "Il pavimento trema mentre ti volti..."


translate ita playRedLight_100dd9e8:


    "... e ti ritrovi a fissare un manto di pelo nero."


translate ita playRedLight_e2847060:


    "Alzi lo sguardo lentamente..."


translate ita playRedLight_435dd3ca:


    "Più in alto..."


translate ita playRedLight_c9db0979:


    "Ancora {i}di più{/i}..."


translate ita playRedLight_a20cefa7_8:


    "..."


translate ita playRedLight_40543d82:


    "... e vedi un'ombra gigantesca, ricurva su di te con uno sguardo malizioso."


translate ita playRedLight_caf41941:


    "La saliva che cola dalle zanne..."


translate ita playRedLight_26619c65:


    "Gli artigli che graffiano le pareti del vicolo..."


translate ita playRedLight_70fb954c:


    "Gli occhi che lampeggiano, senza battere le palpebre, ti fissano... {w}il gatto aspetta il tuo prossimo turno."


translate ita playRedLight_c97b388a:


    "Ma è così {b}vicino{/b}... {w}Se ti giri {i}{b}adesso{/b}...{/i}"


translate ita playRedLight_dae0ec55_2:


    you "..."


translate ita playRedLight_0f5de544:


    "Tu..."


translate ita playRedLight_9fd59da9:


    "{size=-10}non vuoi più giocare{/size}."


translate ita play_gameRun_632d1a35:


    you "!!!" with hpunch


translate ita play_gameRun_08ea5e28:


    "Non riesci nemmeno a voltarti prima che gli artigli ti afferrino il busto..."


translate ita play_gameRun_65b129bb:


    "... strappandoti la carne dello stomaco con facilità."


translate ita play_gameRun_fbb16dfe:


    "Mentre ti trascina verso l'alto, spalanca le fauci..."


translate ita play_gameRun_8515e08c:


    "... dev'esserci un altro modo per uscire da questa situazione."


translate ita play_gameRun_cacea3a1:


    "Ma i rimorsi inutili sono il tuo pane quotidiano..."


translate ita play_gameRun_55ef6376:


    "{size=-5}... non è così?{/size}"


translate ita play_gameRun_a20cefa7:


    "..."


translate ita play_gameRun_479119e0:


    "Finale 32: Codardia Improvvisa"


translate ita play_backUp_50e0caa3:


    "Tenendo gli occhi fissi sulla gigantesca creatura curva su di te..."


translate ita play_backUp_1f17c6e2:


    "... fai un passo indietro."


translate ita play_backUp_f2f2471a:


    who "No."


translate ita play_backUp_d36f2d70:


    who "Questo è {b}barare{/b}."


translate ita runBackUp_93206a37:


    who "Che stai facendo?"


translate ita runBackUp_0a8c0018:


    who "{size=+15}{b}FERMATI!{/b}{/size}" with hpunch


translate ita runBackUp_5110274f:


    who "{size=+25}{b}ROMPERAI TUTT-{/b}{/size}{w=0.5}{nw}" with hpunch


translate ita backedUp_895b7892:


    "Il gatto \ {b}t i f i s s a {/b} mentre, senza perderlo di vista, fai un passo indietro..."


translate ita backedUp_4050e13d:


    "Un passo indiEtro..."


translate ita backedUp_ea56939f:


    "Un AltrO..."


translate ita backedUp_d13e6e4f:


    "E quaNDo faI un alTro paSSo indiETro fuoRI daL vicOlO..."


translate ita backedUp_8dabefc6:


    ".."


translate ita backedUp_a20cefa7:


    "..."


translate ita backedUp_dae0ec55:


    you "..."


translate ita backedUp_8dabefc6_1:


    ".."


translate ita backedUp_a20cefa7_1:


    "..."


translate ita backedUp_05374f43:


    "ERRORE."


translate ita backedUp_05374f43_1:


    "ERRORE."


translate ita backedUp_05374f43_2:


    "ERRORE."


translate ita backedUp_05374f43_3:


    "ERRORE."


translate ita backedUp_dc5c1f8b:


    "ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE. ERRORE."


translate ita backedUp_8dabefc6_2:


    ".."


translate ita backedUp_a20cefa7_2:


    "..."


translate ita backedUp_9ff185ae:


    "Il mondo al di fuori del vicolo sembra... {w}{i}rotto.{/i}"


translate ita backedUp_f8eca25b:


    "{size=-8}Che cosa hai {b}fatto?{/b}{/size}"


translate ita backedUp_a20cefa7_3:


    "..."


translate ita backedUp_da5037e5:


    "Finale 33: {b}eRRoRe{/b} \ RiLevAtO"


translate ita play_buyToy_17b6ceba:


    "Dopo essere stato tutto solo così a lungo in quel vicolo..."


translate ita play_buyToy_dc10009e:


    "... credi che il tuo amico pelosetto meriti qualcosa di {b}speciale{/b}."


translate ita play_buyToy_c0eeee5a:


    you "Torno subito, va bene?"


translate ita play_buyToy_16879ce5:


    cat "Miao?"


translate ita play_buyToy_29937c3a:


    "Vai via di corsa e raggiungi il negozio di animali più vicino."


translate ita play_buyToy_ec2f406b:


    "Dai un'occhiata a tutti i giocattoli per gatti. "


translate ita play_buyToy_bf05eeff:


    "Ce ne sono così tanti tra cui scegliere... soffici, colorati, con l'aroma d'erba gatta..."


translate ita play_buyToy_bf0874e3:


    "Ma..."


translate ita play_buyToy_e86004a8:


    "Realizzi che la maggior parte di quei giochi non è fatta per giocarci da solo."


translate ita play_buyToy_57b2fbb2:


    "Non puoi restare nel vicolo a giocare {i}per sempre...{/i}"


translate ita play_buyToy_9b14289c:


    "E non puoi permetterti di prendere {i}un altro{/i} gatto come compagno di giochi..."


translate ita play_buyToy_a20cefa7:


    "..."


translate ita play_buyToy_5c68eec6:


    "\"Un altro...\""


translate ita play_buyToy_0fdaeb98:


    you "{i}{size=+8}Ecco!{/size}{/i}" with vpunch


translate ita play_buyToy_ce5d2ac5:


    "Adesso sai esattamente cosa prendere!"


translate ita play_buyToy_72c661ba:


    "Dopo una veloce e fruttuosa ricerca in negozio..."


translate ita play_buyToy_c96d5702:


    "... paghi e corri verso il vicolo... {w}impaziente di mostrare il tuo acquisto."


translate ita play_buyToy_d120113b:


    you "Eccomi~!"


translate ita play_buyToy_ec1974d4:


    cat "Miao!" with hpunch


translate ita play_buyToy_755cfe9c:


    "Il vicolo sembra ancora più cupo dopo aver passato del tempo alla luce del sole..."


translate ita play_buyToy_0f6e5e68:


    "Questo ti fa sentire ancora più felice del tuo regalo."


translate ita play_buyToy_84f515b2:


    "Ti avvicini al gatto e inizi a cercare nella busta del negozio."


translate ita play_buyToy_50f51005:


    you "Ho qualcosa per te~"


translate ita play_buyToy_16879ce5_1:


    cat "Miao?"


translate ita play_buyToy_94919086:


    "Il gatto si affaccia, incuriosito, per vedere cosa c'è nella busta."


translate ita play_buyToy_8dabefc6:


    ".."


translate ita play_buyToy_a20cefa7_1:


    "..."


translate ita play_buyToy_c8e2fc6b:


    "Tiri fuori il regalo e..."


translate ita play_buyToy_e5e73efe:


    you "{size=+5}TADA~!{/size}" with hpunch


translate ita play_buyToy_6003bca0:


    "È un gattino di peluche."


translate ita play_buyToy_4f8666f2:


    "È un gattino di peluche rosso a strisce marroni, {w}che lo fanno sembrare un soriano. "


translate ita play_buyToy_b5de0f8d:


    "La pelliccia sintetica è morbida, sembra quasi vera..."


translate ita play_buyToy_54c1b109:


    "... e gli occhi sono verde pallido, un colore che non ti aspettavi per un giocattolo. "


translate ita play_buyToy_053e2879:


    "Di certo è un pupazzo, ma questi dettagli lo rendono quasi..."


translate ita play_buyToy_55022625:


    "... {b}inspiegabilmente{/b} simile a un gatto vero."


translate ita play_buyToy_a20cefa7_2:


    "..."


translate ita play_buyToy_1b1eee42:


    "Perciò è {i}perfetto.{/i}"


translate ita play_buyToy_c1f68b0f:


    "Un compagno per il gatto {w}che puoi permetterti senza problemi."


translate ita play_buyToy_6b205f71:


    "Vincono tutti."


translate ita play_buyToy_16879ce5_2:


    cat "Miao?"


translate ita play_buyToy_2d9feb3d:


    you "E non è finita qui!"


translate ita play_buyToy_54cca3c7:


    "Schiacci il peluche e-"


translate ita play_buyToy_b4578bdf:


    catDoll "{i}miiaooo{/i}"


translate ita play_buyToy_7f0ac95c:


    cat "..."


translate ita play_buyToy_0e14e06c:


    "Il gatto sembra..."


translate ita play_buyToy_335f91cb:


    "... indifferente."


translate ita play_buyToy_f297b97b:


    you "{i}Mmh.{/i}"


translate ita play_buyToy_750dec0e:


    "Beh. {w}{i}Tu{/i} pensi che sia carino..."


translate ita play_buyToy_c7218d6f:


    "Forse non è stato un grande acquisto, dopotutto."


translate ita play_buyToy_fd1a09e7:


    "Non sapendo che altro fare e con pochi soldi in tasca, {w}appoggi goffamente il peluche nella scatola, vicino al gatto."


translate ita play_buyToy_0c88972c:


    "Ti alzi e fai per andartene."


translate ita play_buyToy_82edeab8:


    "Hai fatto pochi passi quando senti un miagolio elettronico dietro di te."


translate ita play_buyToy_b4578bdf_1:


    catDoll "{i}miiaooo{/i}"


translate ita play_buyToy_c90675bd:


    you "Eh?"


translate ita play_buyToy_0776796a:


    "Ti giri e vedi il peluche per terra vicino alla scatola."


translate ita play_buyToy_d1cca908:


    "Il gatto ti sta fissando."


translate ita pickUpDoll_82161d60:


    "Sospiri e ti avvicini per raccogliere il giocattolo..."


translate ita pickUpDoll_2aa568f9:


    you "Tu {i}vuoi{/i} solo attenzioni, non è così?"


translate ita pickUpDoll_022b9bff:


    cat "Miao! Miaoo!"


translate ita pickUpDoll_89a6495c:


    "Tieni in mano il peluche e lo esamini un po'..."


translate ita pickUpDoll_8dabefc6:


    ".."


translate ita pickUpDoll_a20cefa7:


    "..."


translate ita pickUpDoll_704e0eb5:


    "Sembra... diverso."


translate ita pickUpDoll_479c3431:


    you "!!!" with vpunch


translate ita pickUpDoll_e22dd6c2:


    "Non ti ha appena..."


translate ita pickUpDoll_23c671a1:


    "{size=-8}... {b}guardato{/b}?{/size}"


translate ita pickUpDoll_b4578bdf:


    catDoll "{i}miiaooo{/i}"


translate ita pickUpDoll_a20cefa7_1:


    "..."


translate ita pickUpDoll_69d038c5:


    catDoll "{i}{b}m i i a a o o...{/b}{/i}{w=0.8}{nw}"


translate ita pickUpDoll_bd45ae33:


    catDoll "{i}{b}m i i a a o o-oo...{/b}{/i}{w=0.8}{nw}"


translate ita pickUpDoll_8606d94b:


    catDoll "{i}{b}m i i a a o o-oo-oo...{/b}{/i}{w=0.8}{nw}"


translate ita pickUpDoll_f88ef7f7:


    catDoll "{i}{b}m i i a a o o-oo-oo-oo...{/b}{/i}{w=0.8}{nw}"


translate ita pickUpDoll_3b489aee:


    catDoll "{i}{b}m i i a a o o-oo-oo-oo-oo...{/b}{/i}"


translate ita pickUpDoll_12a250d7:


    "{size=+20}{b}{i}CHOMP!!!{/i}{/b}{/size}" with hpunch


translate ita pickUpDoll_8ca8510a:


    you "!!!" with vpunch


translate ita pickUpDoll_6e0cdb4a:


    "In qualche modo, il peluche apre la bocca semicucita e ti morde il polso!"


translate ita pickUpDoll_9275ba69:


    you "{b}AHI!!!{/b} B-BASTA!" with vpunch


translate ita pickUpDoll_4afb1a12:


    "Provi a togliertelo di dosso, ma è avvinghiato a te mentre beve famelico e frenetico il tuo sangue."


translate ita pickUpDoll_05c892b0:


    "Lo sbatti contro la parete del vicolo..."


translate ita pickUpDoll_6530086c:


    "Cerchi di farlo a pezzi..."


translate ita pickUpDoll_354ced13:


    "Ma qualsiasi cosa tu faccia, sembra che niente possa ferirlo o fermarlo..."


translate ita pickUpDoll_ed657fd0:


    "In fondo è solo un giocattolo."


translate ita pickUpDoll_d9df7f92:


    "Alla fine, inizi a sentirti debole... {w}e crolli sulle ginocchia. "


translate ita pickUpDoll_ae5955fe:


    "Il peluche sta bevendo con più calma adesso..."


translate ita pickUpDoll_3458d0b1:


    "... come se la sua aggressività dipendesse solo dalla tua reazione disperata."


translate ita pickUpDoll_a20cefa7_2:


    "..."


translate ita pickUpDoll_e5b804f8:


    "Sembra soddisfatto, ora che hai smesso di lottare."


translate ita pickUpDoll_8dabefc6_1:


    ".."


translate ita pickUpDoll_a20cefa7_3:


    "..."


translate ita pickUpDoll_17adc77a:


    "Forse hai perso conoscenza per qualche secondo..."


translate ita pickUpDoll_cb31072e:


    "... perché anche se sei ancora lì e sei cosciente, i tuoi occhi sono chiusi."


translate ita pickUpDoll_0f5de544:


    "Tu..."


translate ita pickUpDoll_79beda1e:


    "Ti senti così debole..."


translate ita pickUpDoll_8c840e9e:


    "Ti sforzi il più possibile di aprire gli occhi quando..."


translate ita pickUpDoll_40d9ca73:


    "...?"


translate ita pickUpDoll_35a7a74d:


    "... vedi un... {w}gattino?"


translate ita pickUpDoll_47bd6cb5:


    "Il suo pelo arancione con strisce scure ti è familiare..."


translate ita pickUpDoll_a20cefa7_4:


    "..."


translate ita pickUpDoll_b3f7547c:


    "Ti sta leccando il polso..."


translate ita pickUpDoll_d587e6e7:


    "Il gattino solleva la testa e ti osserva con i suoi penetranti occhi verde chiaro..."


translate ita pickUpDoll_07d3bffa:


    kitten "Miiiiao!"


translate ita pickUpDoll_e1a39f3b:


    "Il suo miagolio è acuto, quasi uno squittio..."


translate ita pickUpDoll_5c40811b:


    "... e la bocca è ricoperta di sangue."


translate ita pickUpDoll_dae0ec55:


    you "..."


translate ita pickUpDoll_d40d5f1c:


    "Lo troveresti decisamente adorabile... {w}se non stessi per morire di emorragia..."


translate ita pickUpDoll_90071059:


    "Il gatto vi viene incontro e prende il gattino."


translate ita pickUpDoll_3f40ce34:


    "Ti lancia un'occhiata indecifrabile..."


translate ita pickUpDoll_ca09ce4e:


    "... prima di andare via."


translate ita pickUpDoll_461d72a5:


    "Il gatto torna alla scatola portando con sé il gattino e inizia a pulirlo con cura e attenzione."


translate ita pickUpDoll_19878d53:


    kitten "Miiiiaaoo..."


translate ita pickUpDoll_67107e6c:


    cat "Purr..."


translate ita pickUpDoll_dae0ec55_1:


    you "..."


translate ita pickUpDoll_fb698b9d:


    "Provi ad alzarti ma non ci riesci e cadi nuovamente a terra."


translate ita pickUpDoll_d573f842:


    "Sembra che alla fine..."


translate ita pickUpDoll_d8af5247:


    "... tu abbia trovato un compagno di giochi per il gatto."


translate ita pickUpDoll_a20cefa7_5:


    "..."


translate ita pickUpDoll_51267a7a:


    "Finale 34: Peluche vivente"


translate ita leaveDoll_7f0ac95c:


    cat "..."


translate ita leaveDoll_dae0ec55:


    you "..."


translate ita leaveDoll_9e098551:


    "{size=-10}Piccolo mostriciattolo ingrato.{/size}"


translate ita leaveDoll_f34f5817:


    "Sbuffi, che fastidio!"


translate ita leaveDoll_c6883583:


    you "Beh, {i}{b}prego{/b}{/i}..."


translate ita leaveDoll_10532c8a:


    "Scuoti la testa e ti giri per andartene-"


translate ita leaveDoll_56ebb028:


    you "!!!"


translate ita leaveDoll_5ef96487:


    you "{b}AHH!{/b}" with vpunch


translate ita leaveDoll_1542f023:


    "... un dolore lancinante ti pervade il braccio."


translate ita leaveDoll_d75c3479:


    you "{b}{size=+10}GAHH!!!{/size}{/b}" with vpunch


translate ita leaveDoll_41de37fd:


    "Piangendo, ti afferri il braccio e scopri-"


translate ita leaveDoll_632d1a35:


    you "!!!" with hpunch


translate ita leaveDoll_47103633:


    "{size=-5}... che non c'è più.{/size}"


translate ita leaveDoll_f7c10c20:


    "{size=-8}Il tuo braccio si è appena {i}staccato.{/i}{/size}"


translate ita leaveDoll_145d5b9e:


    "Sotto shock, osservi l'arto sul pavimento."


translate ita leaveDoll_cb3b97dc:


    "Raccogli tutto il tuo coraggio..."


translate ita leaveDoll_3461876b:


    "... e guardi il punto in cui il tuo braccio era collegato al corpo, solo per scoprire..."


translate ita leaveDoll_b8178942:


    you "...?!?"


translate ita leaveDoll_4579d27c:


    "Niente sangue...? È..."


translate ita leaveDoll_6cca42de:


    "È {i}{b}cotone?!?{/b}{/i}"


translate ita leaveDoll_9e6ab9f6:


    "Se lo tocchi, il moncherino non ti fa nemmeno male..."


translate ita leaveDoll_a20cefa7:


    "..."


translate ita leaveDoll_5cf9ed70:


    "Almeno..."


translate ita leaveDoll_a20cefa7_1:


    "..."


translate ita leaveDoll_0c436653:


    "{size=-8}... fino a quando non accade la stessa cosa all'altro braccio.{/size}"


translate ita leaveDoll_b61a60d7:


    you "{b}{size=+10}AAAAHHH!!!{/size}{/b}" with vpunch


translate ita leaveDoll_cd0981ae:


    you "{b}{size=+20}{i}GAAAHHH!!!{/i}{/size}{/b}" with vpunch


translate ita leaveDoll_8ca8510a:


    you "!!!" with vpunch


translate ita leaveDoll_658780db:


    you "AHH!!!" with vpunch


translate ita leaveDoll_43d120d4:


    "Cadi a terra quando la stessa sorte tocca inevitabilmente anche alle gambe..."


translate ita leaveDoll_75cd7bfe:


    "... ti abbandoni all'agonia che va e viene, come se non fosse successo davvero..."


translate ita leaveDoll_4461f216:


    "... come se non fossi a terra, sul pavimento sporco di quel vicolo..."


translate ita leaveDoll_5ca04004:


    "{b}... senza arti{/b}."


translate ita leaveDoll_c03a3d82:


    "{size=-8}Che cosa diamine sta succedendo...?{/size}"


translate ita leaveDoll_78f5a0cd:


    "Non riesci a capire..."


translate ita leaveDoll_97f38b80:


    "A pensare lucidamente..."


translate ita leaveDoll_8dabefc6:


    ".."


translate ita leaveDoll_a20cefa7_2:


    "..."


translate ita leaveDoll_a20cefa7_3:


    "..."


translate ita leaveDoll_ef40bdc4:


    "Il dolore sta svanendo..."


translate ita leaveDoll_95257a22:


    "... lasciandoti con uno strano senso di vuoto nello stomaco."


translate ita leaveDoll_d38ad1a6:


    "Considerando che hai {i}ancora{/i} uno stomaco e non è stato sostituito con..."


translate ita leaveDoll_a20cefa7_4:


    "..."


translate ita leaveDoll_8ba140ab:


    "Ti sdrai sulla schiena... ancora sotto shock, fissando il cielo..."


translate ita leaveDoll_70f07f0b:


    "... quando il muso del gatto ti si para davanti."


translate ita leaveDoll_dae0ec55_1:


    you "..."


translate ita leaveDoll_7f0ac95c_1:


    cat "..."


translate ita leaveDoll_2453d78c:


    "Si lancia sul tuo busto e inizia a morderti e graffiarti il petto, come fossi un giocattolo da masticare."


translate ita leaveDoll_af8ce120:


    "Non senti più dolore..."


translate ita leaveDoll_650a397d:


    "Ma sai che {i}dovresti.{/i}"


translate ita leaveDoll_360e2c6a:


    "Pensi... sia meglio che almeno non faccia {i}{b}male{/b}{/i}..."


translate ita leaveDoll_a20cefa7_5:


    "..."


translate ita leaveDoll_9b7b97b5:


    "Alla fine, senti che il gatto ti {i}tira fuori{/i} qualcosa dal petto..."


translate ita leaveDoll_af048f08:


    "... Una piccola bambola dall'aria molto familiare."


translate ita leaveDoll_230dc578:


    "È difficile da ammettere ma... quella bambola..."


translate ita leaveDoll_eceefbf1:


    "Sei {i}tu{/i}..."


translate ita leaveDoll_31f42f2f:


    "{size=-8}... non è vero?{/size}"


translate ita leaveDoll_e99f1253:


    "Il gatto se ne va e torna verso la scatola con il suo premio."


translate ita leaveDoll_4397d1db:


    "Almeno, {i}credi{/i} sia così..."


translate ita leaveDoll_32485deb:


    "È tutto... {w}{size=-5}troppo buio...{/size} {w}{size=-8}per saperlo con certezza...{/size}"


translate ita leaveDoll_8dabefc6_1:


    ".."


translate ita leaveDoll_a20cefa7_6:


    "..."


translate ita leaveDoll_233e66b3:


    "... Ti svegli e scopri di non poterti muovere."


translate ita leaveDoll_816001ad:


    "Non puoi guardarti intorno."


translate ita leaveDoll_bb663b42:


    "Non puoi nemmeno respirare."


translate ita leaveDoll_6665f0ba:


    "Anche se niente di tutto questo sembra essere... un {i}problema?{/i}"


translate ita leaveDoll_cac600dc:


    "L'unica cosa che vedi è il muso familiare di un gatto acciambellato intorno a te, che fa le fusa nel sonno."


translate ita leaveDoll_b53c4107:


    cat "Purr... Purrr..."


translate ita leaveDoll_aae0b1be:


    "Per qualche motivo, non ti dà fastidio."


translate ita leaveDoll_2f662c10:


    "Ma in fondo perché dovrebbe?"


translate ita leaveDoll_a8aca17f:


    "Cerchi di aggrapparti ai pensieri nella tua testa, sembrano ricordi di un'altra vita..."


translate ita leaveDoll_8e65e29b:


    "Un altro tempo..."


translate ita leaveDoll_f93d2a1b:


    "Un'altra {i}persona{/i}..."


translate ita leaveDoll_b846ccd9:


    "... ma i pensieri svaniscono come sogni dimenticati."


translate ita leaveDoll_8dabefc6_2:


    ".."


translate ita leaveDoll_a20cefa7_7:


    "..."


translate ita leaveDoll_2521d867:


    "Oh, beh."


translate ita leaveDoll_6ff54d13:


    "Va bene così, no?"


translate ita leaveDoll_dbcfd29d:


    "{size=-5}Sei solo una \ {b}b a m b o l a{/b}, dopotutto...{/size}"


translate ita leaveDoll_f17d3908:


    "Un bambola non deve avere {i}pensieri{/i} sciocchi o {i}ricordare{/i} cose importanti..."


translate ita leaveDoll_ad9a2f7f:


    "... deve solo fare {i}compagnia.{/i}"


translate ita leaveDoll_8d3133d1:


    cat "Purrr..."


translate ita leaveDoll_35fc12aa:


    "E a giudicare dalle fusa appagate del gatto..."


translate ita leaveDoll_55c51d80:


    "... stai facendo un ottimo lavoro."


translate ita leaveDoll_8efdd0d0:


    "A questo pensiero, un profondo senso di orgoglio ti pervade."


translate ita leaveDoll_8dbe9dfc:


    "E così {i}anche{/i} tu... {w}sei felice."


translate ita leaveDoll_8dabefc6_3:


    ".."


translate ita leaveDoll_a20cefa7_8:


    "..."


translate ita leaveDoll_bac39afa:


    "Finale 35: Imbambolarsi del Tutto"

translate ita strings:


    old "Leave cat"
    new "Lascia il gatto"


    old "?????"
    new "?????"


    old "{b}You are ready...{/b}"
    new "{b}È il tuo momento...{/b}"


    old "{color=#FF0000}{b}K I L L{/b}{/color}  cat.."
    new "{color=#FF0000}{b}U C C I D I{/b}{/color} il gatto..."


    old "Ignore"
    new "Ignora"


    old "Turn back"
    new "Torna indietro"


    old "I think I'll..."
    new "Credo che..."


    old "Go watch a movie"
    new "Andrò a guardare un film"


    old "Go to the carnival"
    new "Andrò al luna park"


    old "Go to dog park"
    new "Andrò all'area cani"


    old "Go to the old theater."
    new "Andrò al vecchio cinema"


    old "Go to the new cinema."
    new "Andrò al nuovo cinema"


    old "Move to another spot."
    new "Cambia posto"


    old "Confront the stranger."
    new "Parla con lo sconosciuto"


    old "Leave the theater."
    new "Vai via dal cinema"


    old "{size=-8}Don't look behind you. Don't look behind you. Don't look behind you. Don't look behind you.{/size}"
    new "{size=-8}Non ti girare. Non ti girare. Non ti girare. Non ti girare.{/size}"


    old "{b}{color=#FF0000}{s}Don't{/s}{/color} look behind you...{/b}"
    new "{b}{color=#FF0000}{s}Non{/s}{/color} ti girare...{/b}"


    old "Try to leave the theater."
    new "Prova a lasciare il cinema"


    old "Try to blend in with the crowd."
    new "Prova a confonderti con la folla"


    old "Do something else."
    new "Fai qualcos'altro"


    old "Enter the maze."
    new "Entra nel labirinto"


    old "Leave the park."
    new "Vai via dal parco"


    old "Kick the puppy."
    new "Dai un calcio al cucciolo"


    old "Kill the puppy."
    new "Uccidi il cucciolo"


    old "Eat the puppy."
    new "Mangia il cucciolo"


    old "Pick up the puppy."
    new "Prendi in braccio il cucciolo"


    old "{size=+5}DROP IT!{/size}"
    new "{size=+5}LASCIA!{/size}"


    old "{size=-5}Hold on!{/size}"
    new "{size=-5}Aspetta!{/size}"


    old "LEAVE THE PARK."
    new "VAI VIA DAL PARCO"


    old "Stay at the park..."
    new "Resta al parco..."


    old "{size=+40}{b}LEAVE! LEAVE! {color=#FF0000}LEAVE!{/color}{/b}{/size}"
    new "{size=+40}{b}SCAPPA! SCAPPA! {color=#FF0000}SCAPPA!{/color}{/b}{/size}"


    old "{size=-6}THROW!{/size}"
    new "{size=-6}LANCIA!{/size}"


    old "LEAVE."
    new "SCAPPA"


    old "Pet dog."
    new "Accarezza il cane"


    old "{size=+5}{color=#FF0000}l e av e...{/color}{/size}"
    new "{size=+5}{color=#FF0000}va i  v ia...{/color}{/size}"


    old "{size=-5}pet the {b}d{/b}oG.{/size}"
    new "{size=-5}accarezza il {b}c{/b}anE{/size}"


    old "Leave the park?"
    new "Lasci il parco?"


    old "Stay?"
    new "Resti?"


    old "Leave?"
    new "Vai via?"


    old "Leave and... go home..?"
    new "Vai via e... torni a casa...?"


    old "I... I think I'll..."
    new "Io... credo che..."


    old "G o  WAtc h  A  mo vIe"
    new "A ndRò a GUar d are Un fi Lm"


    old "G o  To tHe cArn iVa l"
    new "an drò Al luNa pA rK"


    old "gO  t o DOG pAr k"
    new "A nDRò a ll' aRe a CANI"


    old "Go home..."
    new "Andrò a casa..."


    old "G o tO {b}old theater.{/b}"
    new "A ndRò aL {b}vecchio cinema{/b}"


    old "go t o {b}new cinema.{/b}"
    new "andrò a l {b}cinema nuovo{/b}"


    old ".ezam eht retnE"
    new "otniribal len artnE"


    old "{size=-8}{b}p u p p y.{/b}{/size}"
    new "{size=-8}{b}c u c c i o l o{/b}{/size}"


    old "Check pockets"
    new "Controlla le tasche"


    old "Look around the area"
    new "Guardati intorno"


    old "{color=#FF0000}Blood...{/color}"
    new "{color=#FF0000}Sangue...{/color}"


    old "Beg for forgiveness."
    new "Implora perdono"


    old "Go inside."
    new "Entra"


    old "Spare the mouse."
    new "Risparmia il topo"


    old "Spare the mouse..."
    new "Risparmia il topo..."


    old "{i}Spare the mouse.{/i}"
    new "{i}Risparmia il topo{/i}"


    old "{b}{i}Spare the mouse.{/i}{/b}"
    new "{b}{i}Risparmia il topo{/i}{/b}"


    old "SpaRe tHe {color=#FF0000}{b}mouse{/b}{/color}."
    new "RisParmIa iL {color=#FF0000}{b}topo{/b}{/color}"


    old "Feed mouse to cat."
    new "Dai il topo in pasto al gatto"


    old "{color=#FF0000}{b}Feed mouse to cat.{/b}{/color}"
    new "{color=#FF0000}{b}Dai il topo in pasto al gatto{/b}{/color}"


    old "Stop the cat."
    new "Ferma il gatto"


    old "Let cat feed."
    new "Lascia che il gatto mangi"


    old "Check pockets."
    new "Controlla le tasche"


    old "Look around the area."
    new "Guardati intorno"


    old "Buy a toy"
    new "Compra un giocattolo"


    old "Hang out and do something else?"
    new "Vuoi passare il tempo e fare qualcos'altro?"


    old "Get out of the alley."
    new "Vai via dal vicolo"


    old "Check phone..."
    new "Controlla il telefono..."


    old "Ignore phone..."
    new "Ignora il telefono..."


    old "Try something else?"
    new "Vuoi provare qualcos'altro?"


    old "Keep playing?"
    new "Vuoi continuare a giocare?"


    old "Run..."
    new "Piano A: Scappa!"


    old "Back up..."
    new "Piano B: ...?"


    old "Run {size=-10}restoreBACKUP.exe{/size}"
    new "Esegui {size=-10}backupPIANO_B.exe{/size}"


    old "Begin restoration: _ _ _ _  _ _{#1st_game}"
    new "Avvia backup: _ _ _ _ _  _"


    old "Begin restoration: B _ _ _  _ _"
    new "Esecuzione in corso: P _ _ _ _  _"


    old "Begin restoration: B A _ _  _ _"
    new "Esecuzione in corso: P I _ _ _  _"


    old "Begin restoration: B A C _  _ _"
    new "Esecuzione in corso: P I A _ _  _"


    old "Begin restoration: B A C K  _ _"
    new "Esecuzione in corso: P I A N _  _"


    old "Begin restoration: B A C K  U _"
    new "Esecuzione in corso: P I A N O  _"


    old "Restoration Complete: B A C K  U P"
    new "Backup Completato: P I A N O  B"


    old "{b}B A C K  U P{/b}"
    new "{b}P I A N O  B:  B A C K U P{/b}"


    old "gO HOmE..."
    new "vAI a CAsA..."


    old "Pick up plushie."
    new "Prendi il pelosetto"


    old "Leave."
    new "Vai via"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
