


translate ita newDay_8dabefc6:


    ".."


translate ita newDay_a20cefa7:


    "..."


translate ita newDay_a20cefa7_1:


    "..."


translate ita newDay_9ca326b8:


    "Una giornata... {w}inaspettata...?"


translate ita newDay_a20cefa7_2:


    "..."


translate ita newDay_f75e011d:


    "Sì... È stata {w}{i}piacevole{/i}."


translate ita newDay_82fa61bd:


    "Il mio giorno libero è partito con un tempaccio, che mi ha spinto ad andare al vecchio cinema..."


translate ita newDay_6b209dab:


    "... dove ho visto un film per conto mio. {w}La mia risata ha riempito la sala vuota."


translate ita newDay_5d4d31f0:


    "Quando il film è finito, aveva smesso di piovere..."


translate ita newDay_4e355058:


    "... e mi sentivo così bene che ho fatto un salto al cinema non-più-così-nuovo..."


translate ita newDay_5074d7cd:


    "Non per guardare un altro film..."


translate ita newDay_112fac01:


    "... ma per spassarmela nella sala giochi, scalando i punteggi più alti."


translate ita newDay_5c2bbf14:


    "Visto che avevo ancora voglia di giocare, ho raggiunto il luna park per altre sfide..."


translate ita newDay_61e5a43c:


    "... solo per umiliarmi alla grande."


translate ita newDay_008b7bea:


    "Ma ho {i}vinto{/i} un animaletto di peluche al lancio dell'anello..."


translate ita newDay_1c428f6d:


    "L'aspetto è piuttosto... {w}discutibile..."


translate ita newDay_8dabefc6_1:


    ".."


translate ita newDay_a20cefa7_3:


    "..."


translate ita newDay_cf798fa8:


    "... e mi piace da {b}matti{/b}."


translate ita newDay_8944ff2f:


    "Anche le giostre non erano poi così male."


translate ita newDay_4294899b:


    "Ho legato con un gruppetto per un po', durante la fila per la ruota panoramica..."


translate ita newDay_0c68408c:


    "... parlando della nostra sfiducia comune verso i giostrai dei giochi a premi."


translate ita newDay_e9c1e26b:


    "Ho perfino fatto un giro sulla ruota panoramica con alcuni di loro..."


translate ita newDay_2246cb2d:


    "... e ci siamo scambiati i numeri prima di salutarci."


translate ita newDay_35f5ea23:


    "Non so se li rivedrò ancora, né se qualcuno di loro mi chiamerà mai..."


translate ita newDay_df3e5ab9:


    "... e nemmeno se verrà mai voglia a me di chiamare {i}loro...{/i}"


translate ita newDay_bf0874e3:


    "Ma..."


translate ita newDay_51014aa6:


    "... averne anche solo la possibilità è... {w}bello."


translate ita newDay_5fae18ae:


    "Mi fa sentire bene."


translate ita newDay_a20cefa7_4:


    "..."


translate ita newDay_75f35366:


    "Piccoli passi..."


translate ita newDay_3aa81c02:


    "Dopotutto, anche questa piccola interazione, {w}per quanto divertente... {w}mi ha sfiancato."


translate ita newDay_ff72ab2e:


    "Così ho provato a riprendermi andando all'area cani..."


translate ita newDay_a0654299:


    "... e mi è parso di rinascere alla loro vista... {w}vecchi, giovani, grandi e piccoli, {w}che correvano in giro..."


translate ita newDay_b8191da0:


    "... felici e spensierati."


translate ita newDay_26f7c165:


    "Alcuni padroni mi hanno persino permesso di fare delle foto."


translate ita newDay_81757b6b:


    "... Eh sì."


translate ita newDay_c8368ac2:


    "Oggi è stata una bella giornata."


translate ita newDay_a20cefa7_5:


    "..."


translate ita newDay_c70fb4a0:


    "Non penso molto al gatto, o a qualsiasi \"cosa\" sia... Almeno non in questi giorni..."


translate ita newDay_79c0fad2:


    "È stata dura all'inizio..."


translate ita newDay_37f75de5:


    "Nei giorni e nelle settimane seguenti..."


translate ita newDay_4a9c65e2:


    "... riuscivo a pensare soltanto a ciò che mi era successo."


translate ita newDay_25500d1f:


    "Delle volte mi sentivo in colpa..."


translate ita newDay_d712875a:


    "Altre volte dubitavo delle mie scelte..."


translate ita newDay_5d330940:


    "Tornando al vicolo più volte di quante voglia ammettere..."


translate ita newDay_06bc579c:


    "Il sentimento che mi riempiva alla vista di quella scatola di cartone vuota..."


translate ita newDay_af9d6393:


    "... era così indescrivibile... {w}così {i}{b}travolgente{/b}...{/i}"


translate ita newDay_d7e56945:


    "... che a volte scoppiavo a piangere lì sul posto."


translate ita newDay_1933371e:


    "C'è voluto un po', ma alla fine quell'emozione è diventata sempre più chiara..."


translate ita newDay_28266ef4:


    "... fino a quando ho avuto il coraggio di riconoscerla per ciò che era..."


translate ita newDay_a20cefa7_6:


    "..."


translate ita newDay_d38a0dc6:


    "... \"Sollievo.\""


translate ita newDay_e22ded33:


    "A lungo ho avuto paura di provare una tale emozione..."


translate ita newDay_3ed17d31:


    "... avevo il terrore di abbassare la guardia."


translate ita newDay_a20cefa7_7:


    "..."


translate ita newDay_364a8cff:


    "Ma quel sollievo è tornato alla fine."


translate ita newDay_0e307cdc:


    "Sollievo per la \"sua\" scomparsa..."


translate ita newDay_c6ae1854:


    "Sollievo nel capire che potevo vivere la mia vita..."


translate ita newDay_a20cefa7_8:


    "..."


translate ita newDay_78dc6ac8:


    "... per quanto semplice o straordinaria che fosse, ma a modo {b}{i}mio{/i}{/b}."


translate ita newDay_5374d191:


    "Quelli che \"lui\" aveva imprigionato..."


translate ita newDay_4893c26e:


    "Non ho mai più sentito nemmeno le loro voci..."


translate ita newDay_1f6ffbc9:


    "Ma questo è un bene..."


translate ita newDay_4bc19197:


    "Vivere nel presente..."


translate ita newDay_9c8d77ec:


    "Senza mai dimenticare ciò che hanno fatto per me..."


translate ita newDay_475a8b7e:


    "... e anche ciò che io ho fatto per loro..."


translate ita newDay_a20cefa7_9:


    "..."


translate ita newDay_b361ea6b:


    "Per ora... penso sia sufficiente..."


translate ita newDay_298a3c15:


    "Almeno lo spero..."


translate ita newDay_0a2444b8:


    "... e che ovunque si trovino, possano sentirsi in pace."


translate ita newDay_9e6de573:


    "Sto lottando anche io per la mia pace..."


translate ita newDay_0f1329f4:


    "Un passo alla volta..."


translate ita newDay_a1af867c:


    "Un giorno dopo l'altro..."


translate ita newDay_5795957d:


    "Alla fine... {w}vado verso casa..."


translate ita newDay_3347a2a8:


    "... al mio piccolo appartamento."


translate ita newDay_49ae6019:


    "Una camera... {w}un bagno... {w}e {i}io{/i}, nella più totale solitudine."


translate ita newDay_8dabefc6_2:


    ".."


translate ita newDay_a20cefa7_10:


    "..."


translate ita newDay_bfab167e:


    "Beh..."


translate ita newDay_f1fea4b8:


    "{i}Non proprio{/i}, dopotutto..."


translate ita newDay_15ad7189:


    you "Sono a casa, piccolo~!"


translate ita newDay_f845d69b:


    who "Miiiaooo!" with hpunch


translate ita newDay_426e1e56:


    "Un piccolo gattino maldestro si dimena e corre da me miagolando..."


translate ita newDay_12ef594f:


    kitten "Miiiaooo~"


translate ita newDay_1c0fd25a:


    "Mi inginocchio, guardandolo nell'occhio verde nocciola."


translate ita newDay_c3369978:


    "Il piccoletto era ferito e affamato quando l'ho trovato settimane fa..."


translate ita newDay_1b8a6de6:


    "... ma ha subito recuperato le forze grazie a un po' di cibo e affetto."


translate ita newDay_a0beacdc:


    you "Ti mancavo?"


translate ita newDay_e2c8cb1d:


    kitten "Miiiaoo!" with hpunch


translate ita newDay_2efd6520:


    you "Hai fame, eh?!?"


translate ita newDay_a27db5c6:


    kitten "Miii..."


translate ita newDay_01d545ca:


    you "Eheh! Anche io. È stata una {b}{i}lunga{/i}{/b} giornata..."


translate ita newDay_5a6703df:


    "Sorrido impotente davanti al suo adorabile musetto."


translate ita newDay_24ea3155:


    you "Cerchiamo qualcosa da mangiare, ti va?"


translate ita newDay_bc1c78d9:


    kitten "Purr..."


translate ita newDay_c6f7b15a:


    "Beh... in fondo {i}c'è{/i} qualcun altro a casa mia..."


translate ita newDay_8a9eb749:


    "E... {w}almeno per {i}adesso{/i}..."


translate ita newDay_a20cefa7_11:


    "..."


translate ita newDay_89839a09:


    "... vorrei che tutto rimanesse così com'è."


translate ita newDay_8dabefc6_3:


    ".."


translate ita newDay_a20cefa7_12:


    "..."


translate ita newDay_f883a887:


    "Finale N/A: Un altro giorno..."


translate ita rollCredits_9ea2f78c:


    " "

translate ita strings:

    old "{color=#FF0000}Backgrounds & BG/Art References{/color}\n\nPexels.com"
    new "{color=#FF0000}Sfondi & Riferimenti Artistici/BG{/color}\n\nPexels.com"

    old "{color=#FF0000}Sound Effects{/color}\n\nPixabay.com"
    new "{color=#FF0000}Effetti Audio{/color}\n\nPixabay.com"

    old "{color=#FF0000}Programmed With{/color}\n\nRen'Py"
    new "{color=#FF0000}Programmato con{/color}\n\nRen'Py"

    old "{color=#FF0000}Português-BR Translation{/color}\n\nGeorge Ribeiro"
    new "{color=#FF0000}Localizzazione Portoghese-BR{/color}\n\nGeorge Ribeiro"

    old "{color=#FF0000}Italian Translation{/color}\n\nStar Words Team\n-----\nAlagna Mattia\nCasamassima Stefania\nDe Vincenzi Roberta\nNanni Lucia"
    new "{color=#FF0000}Localizzazione Italiana{/color}\n\nStar Words Team\n-----\nAlagna Mattia\nCasamassima Stefania\nDe Vincenzi Roberta\nNanni Lucia"

    old "{color=#FF0000}And you...{/color}\n\nThank you for playing"
    new "{color=#FF0000}E a te...{/color}\n\nGrazie per aver giocato"

    old "The End"
    new "Fine"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
