





image finBG:
    "MENU/fin1a.png"
    pause .3
    "MENU/fin1b.png"
    pause .3
    "MENU/fin1c.png"
    pause .3
    "MENU/fin1d.png"
    pause .3
    "MENU/fin1e.png"
    pause .3
    "MENU/fin1f.png"
    pause .3
    "MENU/fin1g.png"
    pause .3
    "MENU/fin1h.png"
    pause .3
    "MENU/fin1i.png"
    pause .3
    "MENU/fin1j.png"
    pause .3
    "MENU/fin1k.png"
    pause .3
    "MENU/fin1j.png"
    pause .3
    "MENU/fin1i.png"
    pause .3
    "MENU/fin1h.png"
    pause .3
    "MENU/fin1g.png"
    pause .3
    "MENU/fin1f.png"
    pause .3
    "MENU/fin1e.png"
    pause .3
    "MENU/fin1d.png"
    pause .3
    "MENU/fin1c.png"
    pause .3
    "MENU/fin1b.png"
    pause .3
    repeat



label hereAgain:
    scene black
    pause 3
    play sound "audio/birdsNormal.mp3" volume 0.04
    show finBG
    with fade_Red
    pause 7
    stop sound fadeout 5
    scene black
    with fade_Red
    show screen catEyesFade
    with dissolve

    menu:
        who "play with me..."
        "no. never again.":
            who "..."
            who "then get lost."
            return
        "yes...":
            who "..."
            who "truly?"
            who "you'll abandon this pathetic conclusion..."
            who "...and play with me some more?"
            menu:
                who "Don't promise unless you mean it."
                "no...":
                    who "..."
                    who "then get lost."
                    return
                "yes.":
                    who "...good."
                    who "Very good."
                    who "Find me..."
                    pause 1
                    hide screen catEyesFade
                    pause .5

                    show text "D{alpha=0.0}O NOT BETRAY ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO{alpha=0.0} NOT BETRAY ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO {alpha=0.0}NOT BETRAY ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO N{alpha=0.0}OT BETRAY ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO NO{alpha=0.0}T BETRAY ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO NOT{alpha=0.0} BETRAY ME AGAIN.{/alpha}" at truecenter
                    pause .6
                    show text "DO NOT {alpha=0.0}BETRAY ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO NOT B{alpha=0.0}ETRAY ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO NOT BE{alpha=0.0}TRAY ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO NOT BET{alpha=0.0}RAY ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO NOT BETR{alpha=0.0}AY ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO NOT BETRA{alpha=0.0}Y ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO NOT BETRAY{alpha=0.0} ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO NOT BETRAY {alpha=0.0}ME AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO NOT BETRAY M{alpha=0.0}E AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO NOT BETRAY ME{alpha=0.0} AGAIN.{/alpha}" at truecenter
                    pause .7
                    show text "DO NOT BETRAY ME {alpha=0.0}AGAIN.{/alpha}" at truecenter
                    pause .2
                    show text "DO NOT BETRAY ME A{alpha=0.0}GAIN.{/alpha}" at truecenter
                    pause .5
                    show text "DO NOT BETRAY ME AG{alpha=0.0}AIN.{/alpha}" at truecenter
                    pause .5
                    show text "DO NOT BETRAY ME AGA{alpha=0.0}IN.{/alpha}" at truecenter
                    pause .5
                    show text "DO NOT BETRAY ME AGAI{alpha=0.0}N.{/alpha}" at truecenter
                    pause .5
                    show text "DO NOT BETRAY ME AGAIN{alpha=0.0}.{/alpha}" at truecenter
                    pause .2
                    show text "DO NOT BETRAY ME AGAIN." at truecenter
                    " "
                    hide text
                    with fade_Red
                    pause .3
                    $ persistent.endCounter = 36
                    $ persistent.story3 = 0
                    $ persistent.ending36Done = False
                    $ persistent.ending37aDone = False
                    $ persistent.ending37bDone = False
                    $ persistent.ending38Done = False
                    $ persistent.ending39Done = False
                    $ persistent.questionCounter = 0
                    $ persistent.question1 = 0
                    $ persistent.question2 = 0
                    $ persistent.question3 = 0
                    $ persistent.question4 = 0
                    $ persistent.question5 = 0


return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
