"""Web-only stub for the `requests` package.

Ren'Py Web runs under Emscripten/WASM and doesn't ship the same Python stdlib /
packages as desktop builds. Some games include plugins that do `import requests`
for update checks; this often fails early during import (e.g. urllib3's
emscripten backend importing a `js` module that isn't available).

This stub exists so patched scripts can safely import something on web without
crashing at boot. Calls return an "offline" response object so update-check
plugins won't hard-crash the game if they run at startup.
"""

try:
    import requests as _real_requests
except Exception:
    # Web fallback: no network requests in WASM builds.
    class exceptions:
        class RequestException(Exception):
            pass

    class Response:
        status_code = 0
        ok = False
        text = ""
        content = b""
        headers = {}

        def json(self, *a, **k):
            return {}

        def raise_for_status(self):
            return None

    def _offline(*args, **kwargs):
        return Response()

    get = _offline
    post = _offline
    put = _offline
    delete = _offline
    head = _offline
    patch = _offline

    class Session:
        def get(self, *a, **k): return _offline(*a, **k)
        def post(self, *a, **k): return _offline(*a, **k)
        def put(self, *a, **k): return _offline(*a, **k)
        def delete(self, *a, **k): return _offline(*a, **k)
        def head(self, *a, **k): return _offline(*a, **k)
        def patch(self, *a, **k): return _offline(*a, **k)
else:
    # Desktop fallback: behave like the real `requests` module.
    exceptions = _real_requests.exceptions
    Response = getattr(_real_requests, "Response", object)
    Session = getattr(_real_requests, "Session", object)
    get = _real_requests.get
    post = _real_requests.post
    put = _real_requests.put
    delete = _real_requests.delete
    head = _real_requests.head
    patch = _real_requests.patch
