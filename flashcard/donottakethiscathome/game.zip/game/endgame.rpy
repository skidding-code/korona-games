




define cat3 = Character("I T")
define catEG = Character("Cat", image="EG")

default persistent.questionCounter = 0
default persistent.question1 = 0
default persistent.question2 = 0
default persistent.question3 = 0
default persistent.question4 = 0
default persistent.question5 = 0

image wind:
    "wind1.png"
    pause .1
    "wind2.png"
    pause .1
    "wind3.png"
    pause .1
    "wind4.png"
    pause .1
    "wind5.png"
    pause .1
    "blankFrame.png"

image EG_choice1:
    "ENDGAME/EG_choice01b.png"
    pause .15
    "ENDGAME/EG_choice01c.png"
    pause .15
    "ENDGAME/EG_choice01d.png"
    pause .15
    "ENDGAME/EG_choice01e.png"
    pause .15
    "ENDGAME/EG_choice01f.png"
    pause .15
    "ENDGAME/EG_choice01e.png"
    pause .15
    "ENDGAME/EG_choice01d.png"
    pause .15
    "ENDGAME/EG_choice01c.png"
    pause .15
    repeat

image EG_choice4:
    "ENDGAME/EG_choice04a.png"
    pause .25
    "ENDGAME/EG_choice04b.png"
    pause .25
    "ENDGAME/EG_choice04c.png"
    pause .3
    "ENDGAME/EG_choice04d.png"
    pause .35
    "ENDGAME/EG_choice04e.png"
    pause .35
    "ENDGAME/EG_choice04f.png"
    pause .35
    "ENDGAME/EG_choice04g.png"
    pause .4
    "ENDGAME/EG_choice04h.png"
    pause .45
    "ENDGAME/EG_choice04i.png"
    pause .5
    "ENDGAME/EG_choice03a.png"
    pause .6

image EG_choice5:
    "ENDGAME/EG_choice05a.png"
    pause .25
    "ENDGAME/EG_choice05b.png"
    pause .25
    "ENDGAME/EG_choice05c.png"
    pause .3
    "ENDGAME/EG_choice05d.png"
    pause .35
    "ENDGAME/EG_choice05e.png"
    pause .35
    "ENDGAME/EG_choice05f.png"
    pause .35
    "ENDGAME/EG_choice05g.png"
    pause .4
    "ENDGAME/EG_choice05h.png"
    pause .45
    "ENDGAME/EG_choice05i.png"
    pause .5
    "ENDGAME/EG_choice03a.png"
    pause .6

image EG_choice6:
    "ENDGAME/EG_choice06a.png"
    pause .15
    "ENDGAME/EG_choice06b.png"
    pause .15
    "ENDGAME/EG_choice06c.png"
    pause .15
    "ENDGAME/EG_choice06d.png"
    pause .15
    "ENDGAME/EG_choice06e.png"
    pause .15
    "ENDGAME/EG_choice06f.png"
    pause .15
    "ENDGAME/EG_choice06g.png"
    pause .15
    "ENDGAME/EG_choice06h.png"
    pause .15
    "ENDGAME/EG_choice06i.png"
    pause .15
    "ENDGAME/EG_choice03a.png"
    pause .6

image EG_choice7:
    "ENDGAME/EG_choice07a.png"
    pause .15
    "ENDGAME/EG_choice07b.png"
    pause .15
    "ENDGAME/EG_choice07c.png"
    pause .15
    "ENDGAME/EG_choice07d.png"
    pause .15
    "ENDGAME/EG_choice07e.png"
    pause .15
    "ENDGAME/EG_choice07f.png"
    pause .15
    "ENDGAME/EG_choice07g.png"
    pause .15
    "ENDGAME/EG_choice07h.png"
    pause .15
    "ENDGAME/EG_choice07i.png"
    pause .15
    "ENDGAME/EG_choice03a.png"
    pause .6

image EG_choice8:
    "ENDGAME/EG_choice08a.png"
    pause .15
    "ENDGAME/EG_choice08b.png"
    pause .15
    "ENDGAME/EG_choice08c.png"
    pause .15
    "ENDGAME/EG_choice08d.png"
    pause .15
    "ENDGAME/EG_choice08e.png"
    pause .15
    "ENDGAME/EG_choice08f.png"
    pause .15
    "ENDGAME/EG_choice08g.png"
    pause .15
    "ENDGAME/EG_choice08h.png"
    pause .15
    "ENDGAME/EG_choice08i.png"
    pause .15
    "ENDGAME/EG_choice03a.png"
    pause .6

image EG_choice9:
    "ENDGAME/EG_choice09a.png"
    pause .15
    "ENDGAME/EG_choice09b.png"
    pause .15
    "ENDGAME/EG_choice09c.png"
    pause .15
    "ENDGAME/EG_choice09d.png"
    pause .15
    "ENDGAME/EG_choice09e.png"
    pause .15
    "ENDGAME/EG_choice09f.png"
    pause .15
    "ENDGAME/EG_choice09g.png"
    pause .15
    "ENDGAME/EG_choice09h.png"
    pause .15
    "ENDGAME/EG_choice09i.png"
    pause .15
    "ENDGAME/EG_choice03a.png"
    pause .6

image EG_choice10:
    "ENDGAME/EG_choice10a.png"
    pause .15
    "ENDGAME/EG_choice10b.png"
    pause .15
    "ENDGAME/EG_choice10c.png"
    pause .15
    "ENDGAME/EG_choice10d.png"
    pause .15
    "ENDGAME/EG_choice10e.png"
    pause .15
    "ENDGAME/EG_choice10f.png"
    pause .15
    "ENDGAME/EG_choice10g.png"
    pause .15
    "ENDGAME/EG_choice10h.png"
    pause .15
    "ENDGAME/EG_choice10i.png"
    pause .15
    "ENDGAME/EG_choice03a.png"
    pause .6

image EG_choice11:
    "ENDGAME/EG_choice11a.png"
    pause .15
    "ENDGAME/EG_choice11b.png"
    pause .15
    "ENDGAME/EG_choice11c.png"
    pause .15
    "ENDGAME/EG_choice11d.png"
    pause .15
    "ENDGAME/EG_choice11e.png"
    pause .15
    "ENDGAME/EG_choice11f.png"
    pause .15
    "ENDGAME/EG_choice11g.png"
    pause .15
    "ENDGAME/EG_choice11h.png"
    pause .15
    "ENDGAME/EG_choice11i.png"
    pause .15
    "ENDGAME/EG_choice03a.png"
    pause .6

image EG_choice12:
    "ENDGAME/EG_choice12a.png"
    pause .075
    "ENDGAME/EG_choice12b.png"
    pause .075
    repeat

init:
    image EG upSmile = "ENDGAME/upSmile.png"
    image EG smile = "ENDGAME/downSmile.png"
    image EG angry = "ENDGAME/downAngry.png"
    image EG angryOpen = "ENDGAME/downAngry_open.png"
    image EG slitsGrin = "ENDGAME/downSlits_grin.png"
    image EG slitsSmile = "ENDGAME/downSlits_smile.png"
    image EG slitsSmirk = "ENDGAME/downSlits_smirk.png"
    image EG blinkSmile = "ENDGAME/downSmile_eyesClosed.png"
    image EG glow = "ENDGAME/downSMILE_glow.png"
    image EG pity = "ENDGAME/downSmile_pity.png"
    image EG putUpPaws = "ENDGAME/downSmile_putUpPAWS.png"
    image EG smirk = "ENDGAME/downSmile_smirk.png"
    image EG talk = "ENDGAME/downSmile_talk.png"
    image EG upPaws = "ENDGAME/downSmile_upPAWS.png"
    image EG wide = "ENDGAME/downSmile_wideEyes.png"
    image EG tilt = "ENDGAME/downTilt.png"
    image EG emptyBox = "ENDGAME/emptyBox.png"
    image EG lastDay1a = "ENDGAME/lastDay01a.png"
    image EG lastDay1b = "ENDGAME/lastDay01b.png"
    image EG lastDay1c = "ENDGAME/lastDay01c.png"
    image EG lastDay1d = "ENDGAME/lastDay01d.png"
    image EG lastDay1e = "ENDGAME/lastDay01e.png"
    image EG lastDay1f = "ENDGAME/lastDay01f.png"
    image EG lastDay1g = "ENDGAME/lastDay01g.png"
    image bg EG_choice1a = "ENDGAME/EG_choice01a.png"
    image bg EG_choice1f = "ENDGAME/EG_choice01f.png"
    image bg EG_choice2a = "ENDGAME/EG_choice02a.png"
    image bg EG_choice2b = "ENDGAME/EG_choice02b.png"
    image bg EG_choice2c = "ENDGAME/EG_choice02c.png"
    image bg EG_choice2d = "ENDGAME/EG_choice02d.png"
    image bg EG_choice2e = "ENDGAME/EG_choice02e.png"
    image bg EG_choice2f = "ENDGAME/EG_choice02f.png"
    image bg EG_choice2g = "ENDGAME/EG_choice02g.png"
    image bg EG_choice2h = "ENDGAME/EG_choice02h.png"
    image bg EG_choice2i = "ENDGAME/EG_choice02i.png"
    image bg EG_choice2j = "ENDGAME/EG_choice02j.png"
    image bg EG_choice2k = "ENDGAME/EG_choice02k.png"
    image bg EG_choice2l = "ENDGAME/EG_choice02l.png"
    image bg EG_choice3a = "ENDGAME/EG_choice03a.png"
    image bg EG_choice4a = "ENDGAME/EG_choice04a.png"
    image bg EG_choice4b = "ENDGAME/EG_choice04b.png"
    image bg EG_choice4c = "ENDGAME/EG_choice04c.png"
    image bg EG_choice4d = "ENDGAME/EG_choice04d.png"
    image bg EG_choice4e = "ENDGAME/EG_choice04e.png"
    image bg EG_choice4f = "ENDGAME/EG_choice04f.png"
    image bg EG_choice4g = "ENDGAME/EG_choice04g.png"
    image bg EG_choice4h = "ENDGAME/EG_choice04h.png"
    image bg EG_choice4i = "ENDGAME/EG_choice04i.png"
    image bg EG_choice5a = "ENDGAME/EG_choice05a.png"
    image bg EG_choice5b = "ENDGAME/EG_choice05b.png"
    image bg EG_choice5c = "ENDGAME/EG_choice05c.png"
    image bg EG_choice5d = "ENDGAME/EG_choice05d.png"
    image bg EG_choice5e = "ENDGAME/EG_choice05e.png"
    image bg EG_choice5f = "ENDGAME/EG_choice05f.png"
    image bg EG_choice5g = "ENDGAME/EG_choice05g.png"
    image bg EG_choice5h = "ENDGAME/EG_choice05h.png"
    image bg EG_choice5i = "ENDGAME/EG_choice05i.png"
    image bg EG_choice6a = "ENDGAME/EG_choice06a.png"
    image bg EG_choice6b = "ENDGAME/EG_choice06b.png"
    image bg EG_choice6c = "ENDGAME/EG_choice06c.png"
    image bg EG_choice6d = "ENDGAME/EG_choice06d.png"
    image bg EG_choice6e = "ENDGAME/EG_choice06e.png"
    image bg EG_choice6f = "ENDGAME/EG_choice06f.png"
    image bg EG_choice6g = "ENDGAME/EG_choice06g.png"
    image bg EG_choice6h = "ENDGAME/EG_choice06h.png"
    image bg EG_choice6i = "ENDGAME/EG_choice06i.png"
    image bg EG_choice7a = "ENDGAME/EG_choice07a.png"
    image bg EG_choice7b = "ENDGAME/EG_choice07b.png"
    image bg EG_choice7c = "ENDGAME/EG_choice07c.png"
    image bg EG_choice7d = "ENDGAME/EG_choice07d.png"
    image bg EG_choice7e = "ENDGAME/EG_choice07e.png"
    image bg EG_choice7f = "ENDGAME/EG_choice07f.png"
    image bg EG_choice7g = "ENDGAME/EG_choice07g.png"
    image bg EG_choice7h = "ENDGAME/EG_choice07h.png"
    image bg EG_choice7i = "ENDGAME/EG_choice07i.png"
    image bg EG_choice8a = "ENDGAME/EG_choice08a.png"
    image bg EG_choice8b = "ENDGAME/EG_choice08b.png"
    image bg EG_choice8c = "ENDGAME/EG_choice08c.png"
    image bg EG_choice8d = "ENDGAME/EG_choice08d.png"
    image bg EG_choice8e = "ENDGAME/EG_choice08e.png"
    image bg EG_choice8f = "ENDGAME/EG_choice08f.png"
    image bg EG_choice8g = "ENDGAME/EG_choice08g.png"
    image bg EG_choice8h = "ENDGAME/EG_choice08h.png"
    image bg EG_choice8i = "ENDGAME/EG_choice08i.png"
    image bg EG_choice9a = "ENDGAME/EG_choice09a.png"
    image bg EG_choice9b = "ENDGAME/EG_choice09b.png"
    image bg EG_choice9c = "ENDGAME/EG_choice09c.png"
    image bg EG_choice9d = "ENDGAME/EG_choice09d.png"
    image bg EG_choice9e = "ENDGAME/EG_choice09e.png"
    image bg EG_choice9f = "ENDGAME/EG_choice09f.png"
    image bg EG_choice9g = "ENDGAME/EG_choice09g.png"
    image bg EG_choice9h = "ENDGAME/EG_choice09h.png"
    image bg EG_choice9i = "ENDGAME/EG_choice09i.png"
    image bg EG_choice10a = "ENDGAME/EG_choice10a.png"
    image bg EG_choice10b = "ENDGAME/EG_choice10b.png"
    image bg EG_choice10c = "ENDGAME/EG_choice10c.png"
    image bg EG_choice10d = "ENDGAME/EG_choice10d.png"
    image bg EG_choice10e = "ENDGAME/EG_choice10e.png"
    image bg EG_choice10f = "ENDGAME/EG_choice10f.png"
    image bg EG_choice10g = "ENDGAME/EG_choice10g.png"
    image bg EG_choice10h = "ENDGAME/EG_choice10h.png"
    image bg EG_choice10i = "ENDGAME/EG_choice10i.png"
    image bg EG_choice11a = "ENDGAME/EG_choice11a.png"
    image bg EG_choice11b = "ENDGAME/EG_choice11b.png"
    image bg EG_choice11c = "ENDGAME/EG_choice11c.png"
    image bg EG_choice11d = "ENDGAME/EG_choice11d.png"
    image bg EG_choice11e = "ENDGAME/EG_choice11e.png"
    image bg EG_choice11f = "ENDGAME/EG_choice11f.png"
    image bg EG_choice11g = "ENDGAME/EG_choice11g.png"
    image bg EG_choice11h = "ENDGAME/EG_choice11h.png"
    image bg EG_choice11i = "ENDGAME/EG_choice11i.png"
    image bg EG_choice12c = "ENDGAME/EG_choice12c.png"
    image bg EG_choice12d = "ENDGAME/EG_choice12d.png"
    image bg EG_choice12e = "ENDGAME/EG_choice12e.png"
    image bg EG_choice12f = "ENDGAME/EG_choice12f.png"
    image bg EG_choice12g = "ENDGAME/EG_choice12g.png"
    image bg EG_choice12h = "ENDGAME/EG_choice12h.png"
    image bg EG_choice12i = "ENDGAME/EG_choice12i.png"
    image bg EG_choice12j = "ENDGAME/EG_choice12j.png"
    image bg EG_choice12k = "ENDGAME/EG_choice12k.png"
    image bg EG_choice12l = "ENDGAME/EG_choice12l.png"
    image bg EG_choice12m = "ENDGAME/EG_choice12m.png"
    image bg EG_choice12n = "ENDGAME/EG_choice12n.png"
    image bg EG_choice12o = "ENDGAME/EG_choice12o.png"
    image bg EG_choice12p = "ENDGAME/EG_choice12p.png"
    image bg EG_choice13a = "ENDGAME/EG_choice13a.png"
    image bg EG_choice13b = "ENDGAME/EG_choice13b.png"
    image bg EG_choice13c = "ENDGAME/EG_choice13c.png"
    image bg EG_choice13d = "ENDGAME/EG_choice13d.png"
    image bg EG_choice13e = "ENDGAME/EG_choice13e.png"
    image bg EG_choice13f = "ENDGAME/EG_choice13f.png"
    image bg EG_choice13g = "ENDGAME/EG_choice13g.png"
    image bg EG_choice13h = "ENDGAME/EG_choice13h.png"
    image bg EG_choice13i = "ENDGAME/EG_choice13i.png"
    image bg EG_choice13j = "ENDGAME/EG_choice13j.png"
    image bg EG_choice13k = "ENDGAME/EG_choice13k.png"



label encounterCat:
    scene black
    if persistent.ending37aDone:
        "..."
        "Back again, are you?"
        "You've already reached the best outcome you're going to get."
        "What more are you hoping to achieve?"
        ".."
        "..."
        show screen catEyesFade
        with dissolve
        "You wouldn't be thinking of going back on your promise to join me..."
        "{color=#FF0000}...right?{/color}"
        "Have I not yet satisfied your curiosity?"
        jump moreQuestions

    "..."
    you "..?"
    you "{i}Where... {w}Where am I..?{/i}"
    "..."
    "{alpha=0.4}And so...{/alpha}"
    "{alpha=0.7}You find yourself here...{/alpha}"
    "...yet again."
    you "!!"
    you "Wha-"
    you "Who said that?!"
    you "And where is {i}\"here\"?{/i} {w}I can't {i}see{/i} anything!"
    "..."
    who "Why..."
    play music "audio/LOOPS/47itsThemeLOOP.mp3" loop
    show EG smile
    with dissolve
    pause .3
    show EG talk
    cat "...\"here\" is {i}here,{/i} silly!"
    show EG smile
    you "!!!"
    you "Y... You're..."
    show EG talk
    cat "Well? {w}Do you remember me, this time?"
    show EG tilt
    cat "I never would've thought of my self as being forgettable..."
    show EG blinkSmile
    cat "...but I suppose there's a first time for everything~!"
    show EG smile
    you "..."
    "Your memory slowly pieces together fragments of a moment... {w}An encounter..."
    you "A cat in... {w}in an alley..."
    you "I... {w}took you home with me... {w}didn't I?"
    show EG blinkSmile
    cat "{size=+5}{b}Correct!{/b}{/size}" with hpunch
    show EG talk
    cat "You were daydreaming so long, you even had {i}me{/i} worried! {w}Can you imagine that?"
    show EG slitsSmirk
    cat "Here I am indulging a little in playing with my prey..."
    show EG angry
    cat "...only for you to completely zone out on me!"
    show EG talk
    cat "The game's no fun if you're not {i}present{/i}, you know..."
    show EG smile
    you "I..."
    you "No, I {i}don't{/i} know! I don't understand what's going on at all!"
    show EG tilt
    cat "Hmm... Curious as you are, I should've expected that you'd have questions..."
    show EG smirk
    cat "Well, I suppose you've put me in a good enough mood to be generous and hear you out..."
    show EG blinkSmile
    cat "Very well..."
    show EG smile

label questionCat:
    if persistent.questionCounter >= 5:
        jump finalQuestion

    cat "What would you like to know~?"

    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/47itsThemeLOOP.mp3" loop

    menu:
        "What do you mean I was \"daydreaming\"?" if persistent.question1 == 0:
            jump questionCat1
        "Where are we right now?" if persistent.question2 == 0:
            jump questionCat2
        "Why do you keep killing me?!" if persistent.question3 == 0:
            jump questionCat3
        "You're a cat, how are you talking?" if persistent.question4 == 0:
            jump questionCat4
        "What do you want?" if persistent.question5 == 0:
            jump questionCat5
        "Nothing, I don't care!":
            jump noMoreQuestions

label noMoreQuestions:
    show EG tilt
    "Really?"
    "Perhaps you're not as curious as I thought..."
    "Still..."
    jump returnOrigin

label moreQuestions:
    menu:
        "Yes.":
            "Well then... I'll ask again..."
            "I'm sure you'll pick the correct answer."
            hide screen catEyesFade
            with dissolve
            pause .1
            scene bg p16
            with fade_Red
            "Will you join me..."
            "...or perish?"
            jump finalChoice
        "No...":
            "No?"
            "Well, in that case..."
            hide screen catEyesFade
            with dissolve
            pause .1
            $ persistent.questionCounter = 0
            $ persistent.question1 = 0
            $ persistent.question2 = 0
            $ persistent.question3 = 0
            $ persistent.question4 = 0
            $ persistent.question5 = 0
            show EG smile
            with dissolve
            jump questionCat

label questionCat1:
    show EG tilt
    cat "Hm... It's the first thing that came to mind, really."
    show EG talk
    cat "You were on the brink of death..."
    cat "But instead of watching your life flash before your eyes..."
    show EG smile
    cat "...you got stuck reliving the moment we met... {w}subconsciously coming up with scenarios in which you managed to survive."
    show EG smirk
    cat "Well. {w}Maybe you {i}would{/i} have... but..."
    show EG slitsSmirk
    cat "I couldn't resist messing with your imagination a little bit~"
    show EG angry
    cat "You {i}did{/i} just start ignoring me out of nowhere, after all."
    show EG blinkSmile
    cat "You know by now how much I love attention~"
    show EG smile
    cat "Your little thought experiments were rather amusing..."
    cat "But... If I might say..."
    show EG pity
    cat "...you must have had a {i}pretty{/i} dull life to forgo indulging in precious memories of bygone days..."
    cat "...in favor of daydreaming about a single encounter..."
    show EG smirk
    cat "...over and over and over again."
    show EG angry
    cat "I've heard of having regrets on one's deathbed, but this has been ridiculous!"
    "..."
    show EG blinkSmile
    cat "...Ridiculously {i}intriguing,{/i} that is!"
    show EG smile
    cat "Or perhaps rather than regrets, {i}{b}I{/b}{/i} was what you found intriguing~?"

    menu:
        "Am I still dreaming?":
            show EG tilt
            cat "You're lucid, I'd say. Since you've finally remembered me and all..."
            show EG smile
            cat "Seems you're finally ready to end this farce... amusing as it has been."
            $ persistent.question1 += 1
            $ persistent.questionCounter += 1
            jump questionCat

label questionCat2:
    show EG blinkSmile
    cat "Inside your head, silly!"
    show EG smile
    cat "The real versions of ourselves are halted in time back in your reality. Though I doubt much time has actually passed."
    cat "These things tend to happen in the blink of an eye after all..."
    show EG tilt
    cat "Well... {w}{i}usually,{/i} anyway."
    show EG smile
    $ persistent.question2 += 1
    $ persistent.questionCounter += 1
    jump questionCat


label questionCat3:
    show EG smirk
    cat "Oh don't be so dramatic~"
    show EG blinkSmile
    cat "I don't {i}keep{/i} killing you! I haven't even killed you {i}once{/i} yet..."
    show EG smile
    cat "Those were just thoughts and ideas floating around in your head..."
    show EG smirk
    cat "...that I admittedly had a little fun with."
    show EG angry
    cat "Can you blame me? I would've gotten {i}bored{/i} just waiting for you to wake up."

    menu:
        "You even made me kill {i}you{/i} in the end!":
            show EG smile
            cat "Hm, yes... I suppose I was curious to see if you actually would."
            show EG tilt
            cat "You certainly didn't hold back... {w}You must have been quite angry with me~"
            show EG blinkSmile
            cat "It's fine though. You know what they say about curiosity, yes?"
            show EG smirk
            cat "It was my own choice. And besides..."
            show EG blinkSmile
            pause .7
            show EG wide
            cat "{color=#FF0000}...I got you back, didn't I~?{/color}"
            show EG smile
            $ persistent.question3 += 1
            $ persistent.questionCounter += 1
            jump questionCat


label questionCat4:
    show EG tilt
    cat "..? What do you mean?"
    cat "I've been talking to you all along."
    show EG talk
    cat "Intriguing as your imagination is, it would've ran wild without my help."
    show EG smile
    "I was {b}guiding{/b} you the {i}whole{/i} time..."
    you "!!!" with vpunch
    show EG smirk
    "Didn't you hear me in your thoughts..?"
    show EG slitsSmirk
    "Like {i}this~?{/i}"
    you "..."

    menu:
        "But you're a {i}cat!{/i} How are you doing this?!":
            show EG smile
            cat "I'm quite powerful, yes... but also not so much."
            you "{i}What does {b}that{/b} mean..?{/i}"
            cat "Besides, what makes you so sure I'm a cat?"
            show EG talk
            cat "My appearance? I doubt I resemble any cat you've ever seen before, right?"
            show EG smile
            you "Then what the hell are you, if you're not a cat?"
            show EG tilt
            cat "I didn't say I {i}wasn't{/i} a cat, did I?"
            show EG smile
            you "..."
            cat "..."
            show EG glow
            with fade_Red
            cat "I could be a demon... {w}or a god... {w}or an alien from another galaxy... {w}or an interdimensional abomination..."
            show EG smile
            cat "...or I really {i}could{/i} just be a cat."
            cat "It doesn't {i}really{/i} matter what I am, does it?"
            show EG blinkSmile
            cat "Certainly what I can {b}do{/b} would be a more pressing matter, yes?"
            you "A real cat couldn't have done all this!"
            show EG tilt
            cat "You're really hung up on appearances, aren't you..."
            show EG smile
            cat "Do you have some kind of proof that cats {i}don't{/i} possess powers like mine? {w}I doubt it~"
            show EG angry
            cat "And you know, it's pretty rude of you to keep going on and on about {i}what{/i} I am..."
            show EG angryOpen
            cat "...before you've even asked {i}who{/i} I am or what my {i}name{/i} is!"
            show EG angry
            you "..."
            you "*sigh* Okay... then what's your name-"
            show EG angryOpen
            cat "Well I'm not going to tell you {i}{b}now!{/b}{/i}"
            show EG angry
            cat "Learn some manners first and we'll see. {w}Well..."
            show EG slitsGrin
            cat "...maybe in your {i}next{/i} life, anyway."
            show EG smile
            $ persistent.question4 += 1
            $ persistent.questionCounter += 1
            jump questionCat


label questionCat5:
    show EG tilt
    cat "Hmm..."
    cat "Well if we're talking about my original goals... those are a bit personal, I'd say~"
    you "..."
    show EG talk
    cat "And anyway, things have changed!"
    cat "Right now?"
    show EG blinkSmile
    cat "Well presently, I'd like to have some more fun with you. {w}Your company has been very entertaining thus far."
    show EG smile
    cat "Given more time... {w}and under different circumstances... {w}perhaps we could've even been..."
    show EG pity
    cat "..."
    show EG smirk
    cat "Well... All good things must come to an end."
    cat "You can't truly want to spend what little time you have left in regret and delusion, right?"
    show EG blinkSmile
    cat "Alternatively, {w}I'm also quite {i}hungry{/i} after waiting so long for you to wake up."
    show EG smile
    cat "At this point, I could go either way."
    $ persistent.question5 += 1
    $ persistent.questionCounter += 1
    jump questionCat

label finalQuestion:
    show EG blinkSmile
    cat "Have I satisfied your curiosity now?"
    show EG smile
    you "..."
    you "I just have one more question..."
    you "Why me? Why call out to {i}me{/i} of all people..?"
    show EG talk
    cat "All I did was call out for {i}someone{/i} to hear me."
    cat "I called out... and you were the first person who came to me. {w}Simple as that."
    show EG smile
    you "..."
    show EG tilt
    cat "...Were you hoping for some special reason?"
    you "..."
    show EG smile
    cat "...I'm afraid I don't have one."
    show EG blinkSmile
    cat "Everything I've come to like about you were things discovered {i}after{/i} our initial encounter."
    show EG smile
    you "So there's no big reason for any of this?"
    cat "The reason is far less interesting than the results that came about from our interaction."
    show EG talk
    cat "I only called to satiate my hunger, but in doing so, I found something far more valuable."
    show EG blinkSmile
    cat "I know for a fact that regardless of how this plays out..."
    show EG slitsSmile
    cat "...I will never forget you."
    you "What do you mean?"

label returnOrigin:
    show EG smile
    stop music fadeout 3.5
    cat "I've taken a liking to you, human. And so... I'll grant you another chance..."
    show EG putUpPaws
    pause .15
    show EG upSmile
    with dissolve
    pause .15
    cat "Another choice..."
    show screen blackOut
    hide EG upSmile
    scene bg p16
    pause 2
    hide screen blackOut
    with fade_Red
    you "!!" with vpunch
    you "{i}This place is...{/i}"
    play music "audio/LOOPS/48endgameLOOP.mp3" loop
    show static
    with dissolve
    "..."
    play sound "audio/heartbeatEcho.mp3"
    scene bg p12
    with flash
    "You {i}{b}remember{/b}{/i} this place..."
    play sound "audio/heartbeatEcho.mp3"
    scene bg p13
    with flash
    "Being chased..."
    play sound "audio/heartbeatEcho.mp3"
    scene bg p14
    with flash
    "Being {b}hunted{/b}..."
    play sound "audio/heartbeatEcho.mp3"
    scene bg p15
    with flash
    "Being afraid..."
    scene bg p16
    with dissolve
    hide static
    with dissolve
    "{b}So{/b} afraid..."
    "That fear that {i}so{/i} attracted me to you..."
    "...that instinctive desperation to survive..."
    "I craved it all..."
    "As I am the origin of those delectable emotions..."
    "...you are {i}already{/i} \ {b}m i n e .{/b}"
    "..."
    "But..."
    "I will still permit you the chance to accept the reality of your fate."
    cat "Human..."
    cat "Join me..."
    cat "...or perish."

if not renpy.music.is_playing('music'):
    play music "audio/LOOPS/48endgameLOOP.mp3" loop

label finalChoice:
    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/48endgameLOOP.mp3" loop
    menu:
        "\"I'll join you...\"":
            jump joinCat
        "\"I'd rather die.\"":
            jump refuseCat

label joinCat:
    stop music fadeout 4
    scene bg p15
    with fade_Red
    cat "Splendid."
    play music "audio/LOOPS/49togetherLOOP.mp3" loop
    cat "Come forward, my human."
    scene black
    with dissolve
    "You step forward and pick up the cat."
    "You cradle it in your arms, reaching up to scratch its head."
    play sound "audio/cat_purr.mp3" volume 0.4
    cat "Purr..."
    show static
    with fade_Red
    "Suddenly..."
    you "Wh..?"
    "...you start to feel... {w}sleepy."
    "But the sudden wave of fatigue doesn't cause you to sway on your feet or stumble at all."
    you "What's... Wha's hap... pen...?"
    show screen catEyesFade
    with dissolve
    cat "Shh..."
    cat "Don't worry... You no longer need to worry about anything anymore..."
    cat "Just sleep... and dream those sweet, sweet dreams... for me..."
    you "..."
    you "... {w}... {w}..."
    cat "...Excellent."
    hide screen catEyesFade
    with dissolve
    cat "With this, you will soon become a part of me..."
    stop music fadeout 2
    hide static
    with fade_Red
    ".."
    "..."
    "Ending 37: \ {b}F o r e v e r{/b}"


    if persistent.ending37aDone:
        jump endOfGame
    else:
        $ persistent.ending37aDone = True
        $ persistent.endCounter += 1
        jump endOfGame


label refuseCat:
    cat ".."
    cat "..."
    cat "I see. Then there's nothing left to say."
    scene black
    with fade_Red
    you "..."
    cat "...{w}\"Resigned to your fate...\""
    "...you finally {w}{b} t u r n {w} a r o u n d .{/b}"
    scene bg EG_choice1a
    with dissolve
    pause .6
    show EG_choice1
    with fade_Red
    pause 1
    ".."
    "..."
    "...It's {i}{b}enormous.{/b}{/i}"
    play sound "audio/wind.mp3" volume 0.05
    show wind
    "Shapeless... billowing like thick smoke in the wind..."
    hide wind
    "The shadowlike entity towers above you..."
    "So high it looks like the sky poured it down to Earth... is {i}still{/i} pouring it, even..."
    play sound "audio/wind.mp3" volume 0.05
    show wind
    "It is... unfathomable... that your tiny world is even able to stand..."
    hide wind
    "...under the weight of the {i}reality{/i} of such a being's existence..."
    "...and that {i}you{/i} and your fragile mind haven't fallen to ruin as well."
    "..."
    scene bg EG_choice2a
    with dissolve
    pause .6
    hide EG_choice1
    scene bg EG_choice2b
    with dissolve
    pause .6
    scene bg EG_choice2c
    with dissolve
    pause .6
    scene bg EG_choice2d
    with dissolve
    pause .6
    "You step forward into the monstrous miasma..."
    scene bg EG_choice2e
    pause .15
    scene bg EG_choice2f
    pause .15
    scene bg EG_choice2g
    pause .15
    scene bg EG_choice2h
    pause .15
    scene bg EG_choice2i
    pause .6
    "..."
    stop music
    "...and offer yourself to it."
    play sound "audio/stare.mp3" volume 0.3
    scene bg EG_choice2j
    with vpunch
    pause .6
    play sound "audio/stare.mp3" volume 0.5
    scene bg EG_choice2k
    with vpunch
    pause .6
    play sound "audio/stare.mp3" volume 0.7
    scene bg EG_choice2l
    with vpunch
    pause .6
    show screen blackOut
    scene bg EG_choice3a
    play sound "audio/windLOOP.mp3" loop
    pause 2
    ".."
    "..."
    "{b}{size=+5}d a r k n e s s . . .{/size}{/b}"
    "Surrounded by pure and absolute darkness..."
    "...you are very suddenly hit with the feeling..."
    hide screen blackOut
    with fade_Red
    "{size=-10}...that you are {b}not{/b} alone.{/size}"
    "Like you've just stepped into an unbearably, {i}impossibly{/i} crowded space..."
    "Your ears even start to ring with the sensation of countless conversations..."
    "Words, whispers, {i}screams{/i}... {w}all overlapping..."
    "But..."
    "You don't actually see or hear anyone or anything..."
    "You're alone..."
    "Even as your senses lie to you, trying to make you think otherwise..."
    "{size=-8}...you're more alone than you've ever been.{/size}"
    play sound "audio/theirWill_MEDIUM.mp3"
    scene bg EG_choice4a
    pause .1
    scene bg EG_choice4b
    pause .1
    scene bg EG_choice4c
    pause .1
    scene bg EG_choice4d
    pause .1
    scene bg EG_choice4e
    pause .1
    scene bg EG_choice4f
    pause .1
    scene bg EG_choice4g
    pause .1
    scene bg EG_choice4h
    pause .1
    scene bg EG_choice4i
    pause .1
    scene bg EG_choice3a
    pause .6
    show text "lies..." at truecenter
    with dissolve
    pause 1
    hide text
    with dissolve
    play music "audio/LOOPS/50a_theirThemeLOOP.mp3" loop
    who "lies... {w}lies... {w}listen... {w}listen, {i}please{/i}..."
    you "..?"
    you "Is someone really...?"
    you "I can't see you..."
    you "Where are you?"
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice5a
    pause .1
    scene bg EG_choice5b
    pause .1
    scene bg EG_choice5c
    pause .1
    scene bg EG_choice5d
    pause .1
    scene bg EG_choice5e
    pause .1
    scene bg EG_choice5f
    pause .1
    scene bg EG_choice5g
    pause .1
    scene bg EG_choice5h
    pause .1
    scene bg EG_choice5i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "nothing... {w}nothing left... {w}to see... {w}only hear... {w}hear us..."
    play sound "audio/theirWill_LOW.mp3"
    scene bg EG_choice6a
    pause .1
    scene bg EG_choice6b
    pause .1
    scene bg EG_choice6c
    pause .1
    scene bg EG_choice6d
    pause .1
    scene bg EG_choice6e
    pause .1
    scene bg EG_choice6f
    pause .1
    scene bg EG_choice6g
    pause .1
    scene bg EG_choice6h
    pause .1
    scene bg EG_choice6i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "listen... {w}please..."
    you "Are you... Are you all trapped too? In this place..?"
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice7a
    pause .1
    scene bg EG_choice7b
    pause .1
    scene bg EG_choice7c
    pause .1
    scene bg EG_choice7d
    pause .1
    scene bg EG_choice7e
    pause .1
    scene bg EG_choice7f
    pause .1
    scene bg EG_choice7g
    pause .1
    scene bg EG_choice7h
    pause .1
    scene bg EG_choice7i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "no place... {w}us... {w}all you see... {w}hear... {w}feel... {w}is {i}us{/i}..."
    play sound "audio/theirWill_LOW.mp3"
    scene bg EG_choice8a
    pause .1
    scene bg EG_choice8b
    pause .1
    scene bg EG_choice8c
    pause .1
    scene bg EG_choice8d
    pause .1
    scene bg EG_choice8e
    pause .1
    scene bg EG_choice8f
    pause .1
    scene bg EG_choice8g
    pause .1
    scene bg EG_choice8h
    pause .1
    scene bg EG_choice8i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "us... {w}and {b}{color=#FF0000}I T...{/color}{/b}"
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice9a
    pause .1
    scene bg EG_choice9b
    pause .1
    scene bg EG_choice9c
    pause .1
    scene bg EG_choice9d
    pause .1
    scene bg EG_choice9e
    pause .1
    scene bg EG_choice9f
    pause .1
    scene bg EG_choice9g
    pause .1
    scene bg EG_choice9h
    pause .1
    scene bg EG_choice9i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "we are victims... {w}prey... {w}like you... {w}we are many... {w}beyond counting..."
    play sound "audio/theirWill_MEDIUM.mp3"
    scene bg EG_choice10a
    pause .1
    scene bg EG_choice10b
    pause .1
    scene bg EG_choice10c
    pause .1
    scene bg EG_choice10d
    pause .1
    scene bg EG_choice10e
    pause .1
    scene bg EG_choice10f
    pause .1
    scene bg EG_choice10g
    pause .1
    scene bg EG_choice10h
    pause .1
    scene bg EG_choice10i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "our bodies gone... {w}with time..."
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice11a
    pause .1
    scene bg EG_choice11b
    pause .1
    scene bg EG_choice11c
    pause .1
    scene bg EG_choice11d
    pause .1
    scene bg EG_choice11e
    pause .1
    scene bg EG_choice11f
    pause .1
    scene bg EG_choice11g
    pause .1
    scene bg EG_choice11h
    pause .1
    scene bg EG_choice11i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "wills left behind... {w}us... {w}us... {w}we became... {w}what you see... {w}this \"place\"..."
    show text "is {i}us{/i}..." at truecenter
    with dissolve
    pause 1
    hide text
    with dissolve
    play sound "audio/theirWill_MEDIUM.mp3"
    scene bg EG_choice4a
    pause .1
    scene bg EG_choice4b
    pause .1
    scene bg EG_choice4c
    pause .1
    scene bg EG_choice4d
    pause .1
    scene bg EG_choice4e
    pause .1
    scene bg EG_choice4f
    pause .1
    scene bg EG_choice4g
    pause .1
    scene bg EG_choice4h
    pause .1
    scene bg EG_choice4i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "need you... {w}need your help... {w}help..."
    you "But... What can {i}I{/i} do..?"
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice5a
    pause .1
    scene bg EG_choice5b
    pause .1
    scene bg EG_choice5c
    pause .1
    scene bg EG_choice5d
    pause .1
    scene bg EG_choice5e
    pause .1
    scene bg EG_choice5f
    pause .1
    scene bg EG_choice5g
    pause .1
    scene bg EG_choice5h
    pause .1
    scene bg EG_choice5i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "{b}{color=#FF0000}I T{/color}{/b} too greedy... {w}make mistake... {w}ate too many... {w}we are many... {w}now strong..."
    show text "{i}we{/i} are strong..." at truecenter
    with dissolve
    pause 1
    hide text
    with dissolve
    play sound "audio/theirWill_LOW.mp3"
    scene bg EG_choice6a
    pause .1
    scene bg EG_choice6b
    pause .1
    scene bg EG_choice6c
    pause .1
    scene bg EG_choice6d
    pause .1
    scene bg EG_choice6e
    pause .1
    scene bg EG_choice6f
    pause .1
    scene bg EG_choice6g
    pause .1
    scene bg EG_choice6h
    pause .1
    scene bg EG_choice6i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "made {b}{color=#FF0000}I T{/color}{/b} strong... {w}but make mistake... {w}mistake... {w}error... {w}flaw..."
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice7a
    pause .1
    scene bg EG_choice7b
    pause .1
    scene bg EG_choice7c
    pause .1
    scene bg EG_choice7d
    pause .1
    scene bg EG_choice7e
    pause .1
    scene bg EG_choice7f
    pause .1
    scene bg EG_choice7g
    pause .1
    scene bg EG_choice7h
    pause .1
    scene bg EG_choice7i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "{i}weakness{/i}..."
    you "Then why not escape yourselves?"
    play sound "audio/theirWill_LOW.mp3"
    scene bg EG_choice8a
    pause .1
    scene bg EG_choice8b
    pause .1
    scene bg EG_choice8c
    pause .1
    scene bg EG_choice8d
    pause .1
    scene bg EG_choice8e
    pause .1
    scene bg EG_choice8f
    pause .1
    scene bg EG_choice8g
    pause .1
    scene bg EG_choice8h
    pause .1
    scene bg EG_choice8i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "too long here... {w}too long... {w}one... {w}we are one... {w}with {b}{color=#FF0000}I T...{/color}{/b}"
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice9a
    pause .1
    scene bg EG_choice9b
    pause .1
    scene bg EG_choice9c
    pause .1
    scene bg EG_choice9d
    pause .1
    scene bg EG_choice9e
    pause .1
    scene bg EG_choice9f
    pause .1
    scene bg EG_choice9g
    pause .1
    scene bg EG_choice9h
    pause .1
    scene bg EG_choice9i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "bodies lost... {w}minds... {w}wills... {w}us... {w}all corrupted... {w}no body... {w}can't escape..."
    play sound "audio/theirWill_MEDIUM.mp3"
    scene bg EG_choice10a
    pause .1
    scene bg EG_choice10b
    pause .1
    scene bg EG_choice10c
    pause .1
    scene bg EG_choice10d
    pause .1
    scene bg EG_choice10e
    pause .1
    scene bg EG_choice10f
    pause .1
    scene bg EG_choice10g
    pause .1
    scene bg EG_choice10h
    pause .1
    scene bg EG_choice10i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "you too... {w}you... {w}we... {w}{b}{color=#FF0000}I T...{/color}{/b} {w}one... {w}all of us... {w}all now one..."
    who "..."
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice11a
    pause .1
    scene bg EG_choice11b
    pause .1
    scene bg EG_choice11c
    pause .1
    scene bg EG_choice11d
    pause .1
    scene bg EG_choice11e
    pause .1
    scene bg EG_choice11f
    pause .1
    scene bg EG_choice11g
    pause .1
    scene bg EG_choice11h
    pause .1
    scene bg EG_choice11i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "but you... {w}{i}new{/i}... {w}fresh... {w}body..."
    play sound "audio/theirWill_MEDIUM.mp3"
    scene bg EG_choice4a
    pause .1
    scene bg EG_choice4b
    pause .1
    scene bg EG_choice4c
    pause .1
    scene bg EG_choice4d
    pause .1
    scene bg EG_choice4e
    pause .1
    scene bg EG_choice4f
    pause .1
    scene bg EG_choice4g
    pause .1
    scene bg EG_choice4h
    pause .1
    scene bg EG_choice4i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "still have body..."
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice5a
    pause .1
    scene bg EG_choice5b
    pause .1
    scene bg EG_choice5c
    pause .1
    scene bg EG_choice5d
    pause .1
    scene bg EG_choice5e
    pause .1
    scene bg EG_choice5f
    pause .1
    scene bg EG_choice5g
    pause .1
    scene bg EG_choice5h
    pause .1
    scene bg EG_choice5i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "escape is possible..."
    play sound "audio/theirWill_LOW.mp3"
    scene bg EG_choice6a
    pause .1
    scene bg EG_choice6b
    pause .1
    scene bg EG_choice6c
    pause .1
    scene bg EG_choice6d
    pause .1
    scene bg EG_choice6e
    pause .1
    scene bg EG_choice6f
    pause .1
    scene bg EG_choice6g
    pause .1
    scene bg EG_choice6h
    pause .1
    scene bg EG_choice6i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "because still one... {w}with {b}{color=#FF0000}I T...{/color}{/b}"
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice7a
    pause .1
    scene bg EG_choice7b
    pause .1
    scene bg EG_choice7c
    pause .1
    scene bg EG_choice7d
    pause .1
    scene bg EG_choice7e
    pause .1
    scene bg EG_choice7f
    pause .1
    scene bg EG_choice7g
    pause .1
    scene bg EG_choice7h
    pause .1
    scene bg EG_choice7i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "even just you... {w}if escape... {w}with mind... {w}with body..."
    play sound "audio/theirWill_LOW.mp3"
    scene bg EG_choice8a
    pause .1
    scene bg EG_choice8b
    pause .1
    scene bg EG_choice8c
    pause .1
    scene bg EG_choice8d
    pause .1
    scene bg EG_choice8e
    pause .1
    scene bg EG_choice8f
    pause .1
    scene bg EG_choice8g
    pause .1
    scene bg EG_choice8h
    pause .1
    scene bg EG_choice8i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "{b}{color=#FF0000}I T{/color}{/b} would unravel..."
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice9a
    pause .1
    scene bg EG_choice9b
    pause .1
    scene bg EG_choice9c
    pause .1
    scene bg EG_choice9d
    pause .1
    scene bg EG_choice9e
    pause .1
    scene bg EG_choice9f
    pause .1
    scene bg EG_choice9g
    pause .1
    scene bg EG_choice9h
    pause .1
    scene bg EG_choice9i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "lose power... {w}lose strength... {w}lose {i}us{/i}..."
    play sound "audio/theirWill_MEDIUM.mp3"
    scene bg EG_choice10a
    pause .1
    scene bg EG_choice10b
    pause .1
    scene bg EG_choice10c
    pause .1
    scene bg EG_choice10d
    pause .1
    scene bg EG_choice10e
    pause .1
    scene bg EG_choice10f
    pause .1
    scene bg EG_choice10g
    pause .1
    scene bg EG_choice10h
    pause .1
    scene bg EG_choice10i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "us... {w}set free... {w}forever... {w}finally... {w}escape... {w}help..."
    you "How do I do that?"
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice11a
    pause .1
    scene bg EG_choice11b
    pause .1
    scene bg EG_choice11c
    pause .1
    scene bg EG_choice11d
    pause .1
    scene bg EG_choice11e
    pause .1
    scene bg EG_choice11f
    pause .1
    scene bg EG_choice11g
    pause .1
    scene bg EG_choice11h
    pause .1
    scene bg EG_choice11i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "remember {b}{color=#FF0000}I T{/color}{/b} lies... {w}hidden in truths... {w}lies... {w}lies..."
    play sound "audio/theirWill_MEDIUM.mp3"
    scene bg EG_choice4a
    pause .1
    scene bg EG_choice4b
    pause .1
    scene bg EG_choice4c
    pause .1
    scene bg EG_choice4d
    pause .1
    scene bg EG_choice4e
    pause .1
    scene bg EG_choice4f
    pause .1
    scene bg EG_choice4g
    pause .1
    scene bg EG_choice4h
    pause .1
    scene bg EG_choice4i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "escape... {w}push forward... {w}{b}{color=#FF0000}I T{/color}{/b} lies..."
    show text "persist..." at truecenter
    with dissolve
    pause 1
    hide text
    with dissolve
    pause .6
    show text "{i}persist...{/i}" at truecenter
    with dissolve
    pause 1
    hide text
    with dissolve
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice5a
    pause .1
    scene bg EG_choice5b
    pause .1
    scene bg EG_choice5c
    pause .1
    scene bg EG_choice5d
    pause .1
    scene bg EG_choice5e
    pause .1
    scene bg EG_choice5f
    pause .1
    scene bg EG_choice5g
    pause .1
    scene bg EG_choice5h
    pause .1
    scene bg EG_choice5i
    pause .1
    scene bg EG_choice3a
    pause .6
    who "{size=-8}{b}persist...{/b}{/size}"
    you "..."

    menu:
        "{size=-6}persist...{/size}":
            jump fakePerish

label fakePerish:
    ".."
    "..."
    play sound "audio/tvStatic.mp3" fadein 1.5 loop
    show static
    with dissolve
    stop music
    "{size=-10}you ignore their words.{/size}"
    you "!!" with vpunch
    "deep down you know, there's no way someone like you could win against something like {b}{color=#FF0000}I T...{/color}{/b}"
    "the cat..."
    "trying would be pointless-{w=0.5}{nw}"
    "absurd{w=0.15}{nw}"
    "futile{w=0.15}{nw}"
    "insignficant{w=0.15}{nw}"
    "meaningless{w=0.15}{nw}"
    "stupid{w=0.15}{nw}"
    "useless{w=0.15}{nw}"
    "..."
    "...a pointless effort."
    "the hopes of those words... their wills..."
    "...it would all be wasted on you."
    "so..."
    "you accept your fate..."
    "...and choose to \ {b}p e r i s h.{/b}"
    ".."
    "..."
    stop sound fadeout 2.5
    scene black
    with fade_Red
    "you're not sure how long it takes, but their pathetic pleas eventually grow silent."
    "you almost wish they would've simply turned to insults and threats..."
    "this endless silence... it bears the weight of your guilt and shame..."
    "...long after your body fades away..."
    hide static
    "...and becomes one..."
    "{alpha=0.5}one...{/alpha}"
    "{alpha=0.3}...with me.{/alpha}"
    "..."
    "Ending ???: Perish the thought"


    if persistent.ending37bDone:
        jump finalShowdown
    else:
        $ persistent.ending37bDone = True
        jump finalShowdown


label finalShowdown:
    ".."
    "..."
    you "..."
    you "No..."
    you "No, this... This is another \"daydream\"..."
    you "...isn't it?"
    show screen catEyesFade
    cat "!!"
    cat "You're lucid again? {w}In {i}here?{/i}"
    cat "But... how did you..?"
    you "..."
    you "Well..."
    you "When you've been dreaming about the same day over and over... {w}you kinda start to notice the patterns..."
    cat "..."
    you "Listen... {w}I'm nothing special."
    you "I don't really have any friends."
    you "I don't like crowds or going out most of the time."
    you "And more often than not..."
    you "...I'm alone."
    you "Even in my home..."
    you "One bedroom... {w}one bathroom... {w}and one {i}me{/i} living alone in it."
    you "It'd be easy to say that I don't have much to lose."
    you "My life is admittedly pretty boring."
    you "..."
    you "But it {i}is{/i}... {w}{i}{b}my{/b}{/i}... {w}life."
    you "And if this is {i}my{/i} dream..."
    you "...then you're not calling the shots anymore."
    cat "..."
    show screen blackOut
    hide screen catEyesFade
    show EG_choice12
    pause 1
    hide screen blackOut
    play sound "audio/glitch.mp3"
    "..."
    "{size=-8}I don't think you understand what's going on here.{/size}"
    you "No, {i}you're{/i} the one who isn't getting it."
    "..!"
    you "{b}You{/b} called {i}me.{/i}"
    you "{b}You're{/b} the one who needs {i}me.{/i}"
    you "Whether it's to eat me or kill me or make me yours forever, it doesn't matter."
    you "I'm {b}done{/b} here."
    you "..."
    you "I'm going {b}home.{/b}"
    play sound "audio/glitch.mp3"
    scene bg EG_choice12c
    with hpunch
    pause .25
    play sound "audio/glitch.mp3"
    scene bg EG_choice12d
    with hpunch
    pause .25
    play sound "audio/glitch.mp3"
    scene bg EG_choice12e
    with hpunch
    pause .25
    play sound "audio/beastGrowl.mp3"
    "{size=+15}YOU FORGET YOURSELF, HUMAN!{/size}" with vpunch
    "..."
    "You..."
    play music "audio/LOOPS/49togetherLOOP.mp3" loop
    "You ungrateful little creature..."
    "I give you my patience... my attention... my {i}love...{/i} and you think you can just {i}{b}leave?{/b}{/i}"
    "I didn't {i}have{/i} to, you know? I could've just {b}eaten{/b} you whenever I liked, but instead..."
    "I gave you time to understand... time to accept what was happening..."
    "I gave you a {b}choice.{/b}"
    "{b}YOU.{/b}"
    "An unremarkable little nothing of an existence whom NO ONE would even notice was missing if I'd just taken you as I pleased."
    "Dreaming away about endless possibilities..."
    "Never having to worry about permanent consequences ever again... About choosing wrong..."
    "A little world all your own inside your head..."
    "I offered it all to you... I gave you the choice to join me and have it all..."
    "And you refused."
    "You said you'd rather die, didn't you? And yet here you are trying to go back on your choices..."
    "...only to continue to reject me."
    "To reject my love..."
    "So foolish..."
    "So ungrateful..."
    "Just like the others, you don't even know what you want..."
    "Another bundle of contradictions..."
    "You wish for solitude, yet you fear being left alone..."
    "You fear being forgotten... undesired... unloved..."
    "Yet even I though I love you and desire you..."
    "Even though I promised to never forget you..."
    "Even though {b}I{/b} am the {i}only{/i} one willing to never leave you..."
    "YOU STILL REJECT ME."
    "Stupid little {b}{i}child.{/i}{/b}"
    "I'm {i}done{/i} waiting."
    "You do not get a second chance. You made your choice and you {b}{i}will{/i}{/b} accept the consequences of that choice."
    "You are going to stay here with the rest of these ingrates..."
    ".{w=0.7}.{w=0.7}.{w=0.7}.{w=0.7}f{w=0.7}o{w=0.7}r{w=0.7}e{w=0.7}v{w=0.7}e{w=0.7}r{w=0.7}."
    you "..."
    you "Haven't you ever heard of changing your mind?"
    "Such a thing doesn't erase your original decision. It has been permanently etched into reality."
    "Do you think yourself so important that you are {b}above{/b} facing the truth of that reality?"
    you "No... But that doesn't mean I can't do my best to make things right."
    you "I'm still here, aren't I? That means I can always make more choices... Better choices..."
    "..."
    "You gave yourself to me... {w}{i}You{/i} are already a part of {b}me{/b}..."
    "This might be your pathetic little delusion..."
    "...but don't forget that {i}I'm{/i} the one in control here, human."
    you "Oh yeah, that's right. {w}Those twisted \"choices\" in my dreams were all you, weren't they?"
    stop music
    play sound "audio/theirWill_HIGH.mp3"
    who "{alpha=0.3}we help... help...{/alpha}"
    who "{alpha=0.5}running...{/alpha} endDream.exe..."
    "What's-"
    play sound "audio/theirWill_LOW.mp3"
    who "P {w=0.3}E {w=0.3}R {w=0.3}S {w=0.3}I {w=0.3}S {w=0.3}T"
    "!!!" with hpunch
    "What are you doing you useless traitors?!"
    play sound "audio/beastGrowl.mp3"
    "{size=+15}STOP!{/size}" with hpunch
    you "I think it's about time I started making my {i}own{/i} choices."

    menu:
        "{b}P E R S I S T{/b}":
            play sound "audio/beastRoar.mp3" volume 1.5
            cat "{size=+35}{b}STO-!!{/b}{/size}{w=0.3}{nw}" with hpunch
            stop sound
            scene bg EG_choice12f
            pause .075
            scene bg EG_choice12g
            pause .075
            play sound "audio/theirWill_MEDIUM.mp3"
            scene bg EG_choice12h
            pause .075
            scene bg EG_choice12i
            pause .075
            scene bg EG_choice12j
            pause .075
            scene bg EG_choice12k
            pause .075
            scene bg EG_choice12l
            pause .075
            scene bg EG_choice12m
            pause .075
            scene bg EG_choice12n
            pause .075
            scene bg EG_choice12o
            pause .075
            scene bg EG_choice12p
            pause .075
            show screen whiteOut
            scene black
            pause 2
            hide screen whiteOut
            with fade_Red
            jump finalShowdownChase


label whereItBegan:
    ".."
    "..."
    scene bg alley1
    with fade_Red
    "..."
    "I'm back..."
    "Back where it all began..."
    "The alley..."
    scene black
    with dissolve
    "And in the cardboard box... {w}at the back of the alley..."
    ".."
    "..."
    scene bg EG_choice13a
    with fade_Red
    you "..."
    "There you are..."
    play music "audio/LOOPS/52dontGoIN.mp3"
    queue music "audio/LOOPS/52dontGoLOOP.mp3" loop
    "You look nothing like the impossibly cute cat I met... {w}well... {w}what feels like a lifetime ago..."
    "After escaping and releasing the wills of all of your victims..."
    "...all that's left of you now is an inky black blob seething up at me."
    cat3 "..."
    "The endless hatred pouring out of your singular eye..."
    "..."
    "...doesn't scare me at all."

    menu:
        "Do not take this cat home.":
            cat3 "dont leave"
            cat3 "youre mine"
            you "No..."
            "I'm not."
            cat3 "you took them away"
            cat3 "they were mine"
            cat3 "and now theyre gone"
            cat3 "you took them away"
            cat3 "you took everything from me"
            you "..."
            you "They weren't yours either."
            cat3 "alone"
            you "..."
            "You never {i}had{/i} to be..."
            "If you were lonely... {w}You could've just been their friend..."
            "But you didn't want friendship."
            "They left because you tricked them..."
            "Kidnapped them..."
            "{b}Hurt{/b} them..."
            "You stole their lives... {w}Their time... {w}Never to get any of it back..."
            "..."
            "You brought this on yourself."

    menu:
        "Do not take this cat home.":
            cat3 "you are perfect"
            you "I'm not."
            cat3 "you {i}are{/i}"
            cat3 "dont need the others"
            cat3 "just need you"
            cat3 "stay with me"
            you "I won't."
            cat3 "can give you anything"
            cat3 "can be everything for you"
            you "No... You can't."
            "You couldn't even {i}before...{/i}"
            "You definitely can't {i}now...{/i}"
            "And..."
            "Even if you {i}could{/i} give me everything I ever wanted and more..."
            "..."
            "I'd {b}still{/b} never stay."

    menu:
        "Do not take this cat home.":
            cat3 "i love you"
            you "No you-{w=0.3}{nw}"
            scene bg EG_choice13b
            with vpunch
            cat3 "i {b}do{/b}"
            you "..."
            cat3 "so much"
            cat3 "i love you"
            play sound "audio/tvStatic.mp3" loop fadein 1.5
            show static
            with dissolve
            cat3 "{size=-5}i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you {/size}"
            stop sound
            hide static
            you "{b}{i}Stop.{/i}{/b}"
            cat3 "..."
            you "Maybe you {i}do{/i} love me..."
            you "In some strange, screwed up way I'll never understand..."
            you "But even if that's the case..."
            you "..."
            you "...It's not enough."
            cat3 "..."
            cat3 "please"
            cat3 "dont go"
            cat3 "ill be good"
            you "..."
            you "I don't believe you."
            cat3 "i promise"
            you "..."
            you "I can't trust you."
            cat3 "{size=+10}i promise{/size}" with hpunch
            cat3 "just dont {b}leave{/b}"
            scene bg EG_choice13c
            pause .15
            scene bg EG_choice13d
            pause .15
            cat3 "{size=-5}dont leave me alone{/size}"
            cat3 "{size=-8}please{/size}"
            cat3 "{size=-8}ill die{/size}"
            cat3 "{size=-8}ill {b}die{/b} without you{/size}"
            you "..."


    menu:
        "Do {b}NOT{/b} take this cat home.":
            cat3 ".."
            cat3 "..."
            play music "audio/LOOPS/52dontGoOUT.mp3" noloop
            scene bg EG_choice13a
            with dissolve
            pause 1
            scene bg EG_choice13e
            with fade_Red
            cat3 "{size=-10}i {color=#FF0000}{b}hate{/b}{/color} you{/size}"
            you "..."
            you "Now {b}{i}that{/i}{/b}... {w}I {i}can{/i} believe."
            cat3 "..."
            ".."
            "..."
            "There's nothing left to say."
            play sound "audio/windLOOP.mp3" fadein 0.5 loop
            scene bg EG_choice13f
            with dissolve
            pause .5
            scene bg EG_choice13g
            with dissolve
            pause .5
            scene bg EG_choice13h
            with dissolve
            pause .5
            scene bg EG_choice13i
            with dissolve
            pause .5
            stop sound fadeout 5
            scene bg EG_choice13j
            with fade_Red
            pause .6
            "I watch in silence as the cat..."
            "...as {color=#FF0000}{b}it{/b}{/color}... {w}fades away into nothing..."
            "..."
            play sound "audio/birdsNormal.mp3" volume 0.1 loop
            scene bg EG_choice13k
            with fade_Red
            you "..."
            "{i}Goodbye...{/i}"
            scene bg alley1
            with dissolve
            "With one last glance around the alley..."
            scene bg alley2
            with dissolve
            "I turn..."
            stop sound fadeout 5
            scene bg whiteScreen
            with fade_Red
            pause .6
            scene black
            with dissolve
            pause .6
            "...and leave."
            ".."
            "..."
            "Ending 38: Do NOT Take This Cat Home"


            if persistent.ending38Done:
                jump newDay
            else:
                $ persistent.ending38Done = True
                $ persistent.endCounter += 1
                jump newDay

label endOfGame:


    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
