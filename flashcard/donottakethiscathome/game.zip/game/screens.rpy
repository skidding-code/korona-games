init offset = -1










style default:
    properties gui.text_properties()
    language gui.language

style input:
    properties gui.text_properties("input", accent=True)
    adjust_spacing False

style hyperlink_text:
    properties gui.text_properties("hyperlink", accent=True)
    hover_underline True

style gui_text:
    properties gui.text_properties("interface")


style button:
    properties gui.button_properties("button")

style button_text is gui_text:
    properties gui.text_properties("button")
    yalign 0.5


style label_text is gui_text:
    properties gui.text_properties("label", accent=True)

style prompt_text is gui_text:
    properties gui.text_properties("prompt")


style bar:
    ysize gui.bar_size
    left_bar Frame("gui/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    xsize gui.bar_size
    top_bar Frame("gui/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    ysize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    xsize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    ysize gui.slider_size
    base_bar Frame("gui/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/slider/horizontal_[prefix_]thumb.png"

style vslider:
    xsize gui.slider_size
    base_bar Frame("gui/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/slider/vertical_[prefix_]thumb.png"


style frame:
    padding gui.frame_borders.padding
    background Frame("gui/frame.png", gui.frame_borders, tile=gui.frame_tile)





















screen say(who, what):
    style_prefix "say"

    window:
        id "window"

        if who is not None:

            window:
                id "namebox"
                style "namebox"
                text who id "who"

        text what id "what"




    if not renpy.variant("small"):
        add SideImage() xalign 0.0 yalign 1.0



init python:
    config.character_id_prefixes.append('namebox')

style window is default
style say_label is default
style say_dialogue is default
style say_thought is say_dialogue

style namebox is default
style namebox_label is say_label


style window:
    xalign 0.5
    xfill True
    yalign gui.textbox_yalign
    ysize gui.textbox_height

    background Image("gui/textbox.png", xalign=0.5, yalign=1.0)

style namebox:
    xpos gui.name_xpos
    xanchor gui.name_xalign
    xsize gui.namebox_width
    ypos gui.name_ypos
    ysize gui.namebox_height

    background Frame("gui/namebox.png", gui.namebox_borders, tile=gui.namebox_tile, xalign=gui.name_xalign)
    padding gui.namebox_borders.padding

style say_label:
    properties gui.text_properties("name", accent=True)
    xalign gui.name_xalign
    yalign 0.5

style say_dialogue:
    properties gui.text_properties("dialogue")

    xpos gui.dialogue_xpos
    xsize gui.dialogue_width
    ypos gui.dialogue_ypos












screen input(prompt):
    style_prefix "input"

    window:

        has vbox
        xalign gui.dialogue_text_xalign
        xpos gui.dialogue_xpos
        xsize gui.dialogue_width
        ypos gui.dialogue_ypos

        text prompt style "input_prompt"
        input id "input"

style input_prompt is default

style input_prompt:
    xalign gui.dialogue_text_xalign
    properties gui.text_properties("input_prompt")

style input:
    xalign gui.dialogue_text_xalign
    xmaximum gui.dialogue_width










screen choice(items):
    style_prefix "choice"

    vbox:
        for i in items:
            textbutton i.caption action i.action




define config.narrator_menu = True


style choice_vbox is vbox
style choice_button is button
style choice_button_text is button_text

style choice_vbox:
    xalign 0.5
    ypos 270
    yanchor 0.5

    spacing gui.choice_spacing

style choice_button is default:
    properties gui.button_properties("choice_button")

style choice_button_text is default:
    properties gui.button_text_properties("choice_button")







screen quick_menu():


    zorder 100

    if quick_menu:

        hbox:
            style_prefix "quick"

            xalign 0.5
            yalign 1.0

            textbutton _("Back") action Rollback()
            textbutton _("History") action ShowMenu('history')
            textbutton _("Skip") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("Auto") action Preference("auto-forward", "toggle")
            textbutton _("Save") action ShowMenu('save')
            textbutton _("Q.Save") action QuickSave()

            textbutton _("Prefs") action ShowMenu('preferences')




init python:
    config.overlay_screens.append("quick_menu")

default quick_menu = True

style quick_button is default
style quick_button_text is button_text

style quick_button:
    properties gui.button_properties("quick_button")

style quick_button_text:
    properties gui.button_text_properties("quick_button")











screen navigation():


    vbox:
        style_prefix "navigation"

        xpos gui.navigation_xpos
        yalign 0.5

        spacing gui.navigation_spacing

        if main_menu:

            if persistent.ending39Done:
                textbutton _("...") action Start()
            elif persistent.prologue:
                textbutton _("Continue") action Start()
            else:
                textbutton _("Start") action Start()

        else:

            textbutton _("History") action ShowMenu("history")

            textbutton _("Save") action ShowMenu("save")

        if persistent.ending39Done != True and persistent.prologue:
            if persistent.endCounter == 37 and persistent.story3 == 0 and persistent.ending36Done == True:
                textbutton _("Load") action Start()
            elif persistent.endCounter == 36 and persistent.readyNow == False:
                textbutton _("Load") action Start()
            elif persistent.endCounter == 24 and persistent.story2 == 0:
                textbutton _("Load") action Start()
            elif persistent.endCounter == 12 and persistent.story1 == 0:
                textbutton _("Load") action Start()
            else:
                textbutton _("Load") action ShowMenu("load")

        textbutton _("Preferences") action ShowMenu("preferences")

        if _in_replay:

            textbutton _("End Replay") action EndReplay(confirm=True)

        elif not main_menu:

            textbutton _("Main Menu") action MainMenu()

        if persistent.prologue:
            textbutton _("Endings") action ShowMenu("endings")
        else:
            textbutton _("???")

        textbutton _("About") action ShowMenu("about")

        if renpy.variant("pc") or (renpy.variant("web") and not renpy.variant("mobile")):


            textbutton _("Help") action ShowMenu("help")

        textbutton _("Credits") action ShowMenu("credits")

        if renpy.variant("pc"):



            textbutton _("Quit") action Quit(confirm=not main_menu)


style navigation_button is gui_button
style navigation_button_text is gui_button_text

style navigation_button:
    size_group "navigation"
    properties gui.button_properties("navigation_button")

style navigation_button_text:
    outlines [(1.5, "#000", 0, 0)]
    properties gui.button_text_properties("navigation_button")








screen main_menu():
    tag menu

    if persistent.ending39Done:
        $ persistent.menuMusic = "audio/birdsNormalQUIET.mp3"
    elif persistent.endCounter >= 37:
        $ persistent.menuMusic = "audio/LOOPS/47itsThemeLOOP.mp3"
    elif persistent.endCounter >= 18:
        $ persistent.menuMusic = "audio/tvStatic.mp3"
    elif persistent.prologue:
        $ persistent.menuMusic = "audio/LOOPS/03catTheme.mp3"
    elif persistent.prologue != True:
        $ persistent.menuMusic = "audio/rainLOOP.mp3"
    else:
        pass
    on "show" action Play("music", persistent.menuMusic)



    if persistent.ending39Done:
        add gui.main_menu_background5
    elif persistent.endCounter >= 37:
        add gui.main_menu_background4
    elif persistent.endCounter >= 18:
        add gui.main_menu_background3
    elif persistent.prologue:
        add gui.main_menu_background2
    else:
        add gui.main_menu_background


    frame:
        style "main_menu_frame"



    use navigation

    if gui.show_name:

        vbox:
            style "main_menu_vbox"

            vbox:
                style "main_menu_vbox"

                text "{size=+40}Do Not Take{/size}":
                    outlines [(0, "#000", 0, 0)]
            vbox:
                style "main_menu_vbox"

                if persistent.endCounter >= 37:
                    text "{size=+40}{color=#FF0000}I T {/color} Home{/size}":
                        outlines [(0, "#000", 0, 0)]
                else:
                    text "{size=+40}This Cat Home{/size}":
                        outlines [(0, "#000", 0, 0)]

style main_menu_frame is empty
style main_menu_vbox is vbox
style main_menu_text is gui_text
style main_menu_title is main_menu_text
style main_menu_version is main_menu_text

style main_menu_frame:
    xsize 280
    yfill True

    background "gui/overlay/main_menu2.png"

style main_menu_vbox:
    xalign 1.0
    xoffset -20
    xmaximum 800
    yalign 1.0
    yoffset -20

style main_menu_text:
    properties gui.text_properties("main_menu", accent=True)

style main_menu_title:
    properties gui.text_properties("title")

style main_menu_version:
    properties gui.text_properties("version")











screen game_menu(title, scroll=None, yinitial=0.0):

    style_prefix "game_menu"

    if main_menu:
        if persistent.ending39Done:
            add gui.game_menu_background5
        elif persistent.endCounter >= 37:
            add gui.game_menu_background4
        elif persistent.endCounter >= 18:
            add gui.game_menu_background3
        elif persistent.prologue:
            add gui.game_menu_background2
        else:
            add gui.game_menu_background
    else:
        if persistent.ending39Done:
            add gui.game_menu_background5
        elif persistent.endCounter >= 37:
            add gui.game_menu_background4
        elif persistent.endCounter >= 18:
            add gui.game_menu_background3
        elif persistent.prologue:
            add gui.game_menu_background2
        else:
            add gui.game_menu_background

    frame:
        style "game_menu_outer_frame"

        has hbox


        frame:
            style "game_menu_navigation_frame"

        frame:
            style "game_menu_content_frame"

            if scroll == "viewport":

                viewport:
                    yinitial yinitial
                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    pagekeys True

                    side_yfill True

                    has vbox
                    transclude

            elif scroll == "vpgrid":

                vpgrid:
                    cols 1
                    yinitial yinitial

                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    pagekeys True

                    side_yfill True

                    transclude

            else:

                transclude

    use navigation

    textbutton _("Return"):
        style "return_button"

        action Return()

    label title

    if main_menu:
        key "game_menu" action ShowMenu("main_menu")


style game_menu_outer_frame is empty
style game_menu_navigation_frame is empty
style game_menu_content_frame is empty
style game_menu_viewport is gui_viewport
style game_menu_side is gui_side
style game_menu_scrollbar is gui_vscrollbar

style game_menu_label is gui_label
style game_menu_label_text is gui_label_text

style return_button is navigation_button
style return_button_text is navigation_button_text

style game_menu_outer_frame:
    bottom_padding 30
    top_padding 120

    background "gui/overlay/game_menu.png"

style game_menu_navigation_frame:
    xsize 280
    yfill True

style game_menu_content_frame:
    left_margin 40
    right_margin 20
    top_margin 10

style game_menu_viewport:
    xsize 920

style game_menu_vscrollbar:
    unscrollable gui.unscrollable

style game_menu_side:
    spacing 10

style game_menu_label:
    xpos 50
    ysize 120

style game_menu_label_text:
    size gui.title_text_size
    color gui.accent_color
    yalign 0.5

style return_button:
    xpos gui.navigation_xpos
    yalign 1.0
    yoffset -30









screen about():
    tag menu





    use game_menu(_("About"), scroll="viewport"):

        style_prefix "about"

        vbox:






            text "\nYou find a cat on your day off. From there, you decide what happens next.\n" at center
            text "...Or {i}do{/i} you?" at center

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            add "endingICONS/endingIcon00.png" at center

            text "\n{size=+20}Content/Trigger Warnings{/size}" at center


            text _("\nContains {color=#FF0000}spoilers{/color}!\n\n") at center

            text _("Abuse / abusive relationship(s)") at center
            text _("Agoraphobia") at center
            text _("Amnesia") at center
            text _("Amputation / Dismemberment") at center
            text _("Animal abuse") at center
            text _("Animal death") at center
            text _("Animals/monsters eating humans") at center
            text _("Anxiety / Social Anxiety") at center
            text _("Blood & gore") at center
            text _("Body horror") at center
            text _("Body injury") at center
            text _("Cannibalism") at center
            text _("Child abuse (minor mention/hint of)") at center
            text _("Cosmic horror") at center
            text _("Dead bodies & body parts") at center
            text _("Death / dying") at center
            text _("Decapitation") at center
            text _("Depression") at center
            text _("Dissociation") at center
            text _("Doll animation") at center
            text _("Emotional abuse") at center
            text _("Entrapment") at center
            text _("Epilepsy warning - flashing images & lights/static") at center
            text _("Glitches") at center
            text _("Hallucinations") at center
            text _("Heart attack") at center
            text _("Intrusive thoughts") at center
            text _("Isolation") at center
            text _("Kidnapping / abduction") at center
            text _("Loss of vision") at center
            text _("Loud, sudden and/or repeating noises") at center
            text _("Manipulation / gaslighting") at center
            text _("Mental illness") at center
            text _("Mind control") at center
            text _("Murder") at center
            text _("Paranoia") at center
            text _("Poison / venom") at center
            text _("Psychological horror") at center
            text _("Scary / disturbing images & messages") at center
            text _("Scopophobia") at center
            text _("Seizure") at center
            text _("Self-harm") at center
            text _("Stalking") at center
            text _("Suicide / Suicidal ideation") at center
            text _("Tense situations / gameplay") at center
            text _("Thalassophobia") at center
            text _("Timed gameplay") at center
            text _("Violence") at center
            text _("Vomiting") at center

            text _("\n{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")
            text _("Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]")


style about_label is gui_label
style about_label_text is gui_label_text
style about_text is gui_text

style about_label_text:
    size gui.label_text_size



screen endings():
    tag menu





    use game_menu(_("Endings Found: {color=#fff}[persistent.endCounter] / 40{/color}"), scroll="viewport"):

        style_prefix "endings"

        vbox:
            if gui.endings:
                text "[gui.endings!t]\n"

            if persistent.prologue and persistent.ending36Done != True:
                add "endingICONS/endingIcon00.png"
                text _("Ending 0: It Begins -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}Something... happened. You {b}think{/b}, anyway. You can't really remember what...{/size}{/i}")
            elif persistent.prologue and persistent.ending36Done:
                add "endingICONS/endingIcon00.png"
                text _("\nEnding 0: It Begins -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}The first time you took {color=#FF0000}{b}it{/b}{/color} home.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending1Done:
                add "endingICONS/endingIcon01.png"
                text _("\nEnding 1: A (Not So) Clean Getaway -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You tried to clean your apartment but apparently you're not very good at it.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending2Done:
                add "endingICONS/endingIcon02.png"
                text _("\nEnding 2: Double Trouble -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You found the ones responsible for making a mess of your apartment. Haha, those little pranksters...{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending3Done:
                add "endingICONS/endingIcon03.png"
                text _("\nEnding 3: Silent Film -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You let the cat sit in your favorite chair and watched a scary movie together. Just an ordinary movie night.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending4Done:
                add "endingICONS/endingIcon04.png"
                text _("\nEnding 4: Real \"Subtle\" -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You took back the chair from the cat and enjoyed some silly, little jumpscares alone.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending5Done:
                add "endingICONS/endingIcon05.png"
                text _("\nEnding 5: Do {i}Nyaa-t{/i} Disturb -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You shouldn't bother a cat while it's trying to nap...{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending6Done:
                add "endingICONS/endingIcon06.png"
                text _("\nEnding 6: Just A Cat Nap -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}Resting's good but you should get up and stretch every now and then... and eat... and {b}drink{/b}...{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending7Done:
                add "endingICONS/endingIcon07.png"
                text _("\nEnding 7: Personal Boundaries -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}Knowing how to take \"no\" for an answer is an important life lesson.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending8Done:
                add "endingICONS/endingIcon08.png"
                text _("\nEnding 8: Fish Out of Water -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You fed the cat some tuna. It liked it okay...{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending9Done:
                add "endingICONS/endingIcon09.png"
                text _("\nEnding 9: Leftovers -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You fed the cat some leftover meatloaf. It liked it okay...{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending10Done:
                add "endingICONS/endingIcon10.png"
                text _("\nEnding 10: \"You are what you eat...\" -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You fed the cat... {b}something{/b}... It really, {b}really{/b} liked it...{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending11Done:
                add "endingICONS/endingIcon11.png"
                text _("\nEnding 11: At The End of Your Rope -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}What cat doesn't love playing with some yarn?{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending12Done:
                add "endingICONS/endingIcon12.png"
                text _("\nEnding 12: Targeted -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}The cat loses its mind over a tiny red dot. Hilarious!{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending13Done:
                add "endingICONS/endingIcon13.png"
                text _("\nEnding 13: Disappointing Prey -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You can't run. Apparently you can't hide either.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending14Done:
                add "endingICONS/endingIcon14.png"
                text _("\nEnding 14: Bath Hater -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}Note to self: DO NOT THROW CATS INTO A BATHTUB FULL OF WATER{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending15Done:
                add "endingICONS/endingIcon15.png"
                text _("\nEnding 15: Self-Care Buddies -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}After you give the cat the full spa treatment, it tries its best to return the favor.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending16Done:
                add "endingICONS/endingIcon16.png"
                text _("\nEnding 16: Poor Screening Arrangements -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You go to the old theater and enjoy a film with an interesting stranger.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending17Done:
                add "endingICONS/endingIcon17.png"
                text _("\nEnding 17: Black Sheep -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You weren't a big fan of the movie at the new cinema. The rest of the audience might have opinions about that.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending18Done:
                add "endingICONS/endingIcon18.png"
                text _("\nEnding 18: Happy Birthday -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You have a front-row seat to the touching reunion of multiple siblings at the new cinema.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending19Done:
                if persistent.beatHardMode:
                    add "endingICONS/endingIcon19HARD.png"
                else:
                    add "endingICONS/endingIcon19.png"
                text _("\nEnding 19: You beat the maze :D -- {color=#FF0000}Complete{/color}")
                if persistent.beatHardMode:
                    text _("    {i}{size=-3}Whoa, you beat the maze on {b}hard mode?!{/b/} Holy COW! You're a real gamer, ain't ya?{/size}{/i}")
                else:
                    text _("    {i}{size=-3}Congratulations! You beat the maze.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending20Done:
                add "endingICONS/endingIcon20.png"
                text _("\nEnding 20: You failed the maze :( -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}Better luck next time...{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending21Done:
                add "endingICONS/endingIcon21.png"
                text _("\nEnding 21: {color=#FF0000}d o g{/color}  person -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}...You had a pleasant day at the  {color=#FF0000}{b}d o g{/b}{/color}  park.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending22Done:
                add "endingICONS/endingIcon22.png"
                text _("\nEnding 22: Not Alone -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}Isn't it nice to feel heard?{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending23Done:
                add "endingICONS/endingIcon23.png"
                text _("\nEnding 23: Feedback loop -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You try to leave the alley. It doesn't work. You try to leave the alley. It doesn't work. You try to leave the alley. It doesn't{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending24Done:
                add "endingICONS/endingIcon24.png"
                text _("\nEnding 24: Fishing for pardon -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}Silly you! Chocolate is bad for cats! {s}{color=#FF0000}But you knew that, didn't you?{/color}{/s}{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending25Done:
                add "endingICONS/endingIcon25.png"
                text _("\nEnding 25: Seafood Sacrifice -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You kindly feed some poor, hungry cats a fish. How nice of you!{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending26Done:
                add "endingICONS/endingIcon26.png"
                text _("\nEnding 26: A life spared -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You decide not to feed the poor, hungry cat a {s}helpless{/s} mouse. Meanie...{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending27Done:
                add "endingICONS/endingIcon27.png"
                text _("\nEnding 27: Well-Fed -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}Cats are supposed to eat mice. Huh, wonder what mice are supposed to eat...{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending28Done:
                add "endingICONS/endingIcon28.png"
                text _("\nEnding 28: Personal care package -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You share a nice meal with the cat. A bit high in iron though.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending29Done:
                add "endingICONS/endingIcon29.png"
                text _("\nEnding 29: All You Can Eat Blood-fey -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You give the cat an endless supply of food. Generous.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending30Done:
                add "endingICONS/endingIcon30.png"
                text _("\nEnding 30: Photo bomber -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You really nailed your good side in this one!{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending31Done:
                add "endingICONS/endingIcon31.png"
                text _("\nEnding 31: Headshot -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}It's okay, we all get a little camera shy sometimes.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending32Done:
                add "endingICONS/endingIcon32.png"
                text _("\nEnding 32: Fear Quitter -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}\"When the going gets tough, just give up.\" That's how the saying goes, right?{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending33Done:
                add "endingICONS/endingIcon33.png"
                text _("\nEnding 33: {b}eRRoR{/b} \ FoUnD -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}\"An exception has occurred. Please refrain from going outside of permitted parameters.\"{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending34Done:
                add "endingICONS/endingIcon34.png"
                text _("\nEnding 34: Living doll -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You end up getting the cat a nice companion!{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending35Done:
                add "endingICONS/endingIcon35.png"
                text _("\nEnding 35: Cotton Headed -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You're the only friend it needs.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending36Done:
                add "endingICONS/endingIcon36.png"
                text _("\nEnding 36: Eight more left -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}Well that's {b}one{/b} down... Good luck on the rest.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending37aDone:
                add "endingICONS/endingIcon37.png"
                text _("\nEnding 37: {b}F o r e v e r{/b} -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You join the cat. Now you'll always be together. At least... until...{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending38Done:
                add "endingICONS/endingIcon38.png"
                text _("\nEnding 38: Do NOT Take This Cat Home -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}Bad kitty.{/size}{/i}")
            else:
                text _("???")

            text _("{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n")

            if persistent.ending39Done:
                add "endingICONS/endingIcon39.png"
                text _("\nEnding N/A: Another day... -- {color=#FF0000}Complete{/color}")
                text _("    {i}{size=-3}You have a nice day off and go home to spend the rest of the evening with your cute, little kitten.{/size}{/i}")
            else:
                text _("???")




style endings_label is gui_label
style endings_label_text is gui_label_text
style endings_text is gui_text

style endings_label_text:
    size gui.label_text_size











screen save():
    tag menu


    use file_slots(_("Save"))


screen load():
    tag menu


    use file_slots(_("Load"))


screen file_slots(title):

    default page_name_value = FilePageNameInputValue(pattern=_("Page {}"), auto=_("Automatic saves"), quick=_("Quick saves"))

    use game_menu(title):

        fixed:



            order_reverse True


            button:
                style "page_label"

                key_events True
                xalign 0.5
                action page_name_value.Toggle()

                input:
                    style "page_label_text"
                    value page_name_value


            grid gui.file_slot_cols gui.file_slot_rows:
                style_prefix "slot"

                xalign 0.5
                yalign 0.5

                spacing gui.slot_spacing

                for i in range(gui.file_slot_cols * gui.file_slot_rows):

                    $ slot = i + 1

                    button:
                        action FileAction(slot)

                        has vbox

                        add FileScreenshot(slot) xalign 0.5

                        text FileTime(slot, format=_("{#file_time}%A, %B %d %Y, %H:%M"), empty=_("empty slot")):
                            style "slot_time_text"

                        text FileSaveName(slot):
                            style "slot_name_text"

                        key "save_delete" action FileDelete(slot)


            hbox:
                style_prefix "page"

                xalign 0.5
                yalign 1.0

                spacing gui.page_spacing

                textbutton _("<") action FilePagePrevious()

                if config.has_autosave:
                    textbutton _("{#auto_page}A") action FilePage("auto")

                if config.has_quicksave:
                    textbutton _("{#quick_page}Q") action FilePage("quick")


                for page in range(1, 10):
                    textbutton "[page]" action FilePage(page)

                textbutton _(">") action FilePageNext()


style page_label is gui_label
style page_label_text is gui_label_text
style page_button is gui_button
style page_button_text is gui_button_text

style slot_button is gui_button
style slot_button_text is gui_button_text
style slot_time_text is slot_button_text
style slot_name_text is slot_button_text

style page_label:
    xpadding 50
    ypadding 3

style page_label_text:
    text_align 0.5
    layout "subtitle"
    hover_color gui.hover_color

style page_button:
    properties gui.button_properties("page_button")

style page_button_text:
    properties gui.button_text_properties("page_button")

style slot_button:
    properties gui.button_properties("slot_button")

style slot_button_text:
    properties gui.button_text_properties("slot_button")









screen preferences():
    tag menu


    use game_menu(_("Preferences"), scroll="viewport"):

        vbox:

            hbox:
                box_wrap True

                if renpy.variant("pc") or renpy.variant("web"):

                    vbox:
                        style_prefix "radio"
                        label _("Display")
                        textbutton _("Window") action Preference("display", "window")
                        textbutton _("Fullscreen") action Preference("display", "fullscreen")

                vbox:
                    style_prefix "radio"
                    label _("Rollback Side")
                    textbutton _("Disable") action Preference("rollback side", "disable")
                    textbutton _("Left") action Preference("rollback side", "left")
                    textbutton _("Right") action Preference("rollback side", "right")

                vbox:
                    style_prefix "check"
                    label _("Skip")
                    textbutton _("Unseen Text") action Preference("skip", "toggle")
                    textbutton _("After Choices") action Preference("after choices", "toggle")
                    textbutton _("Transitions") action InvertSelected(Preference("transitions", "toggle"))




                vbox:
                    style_prefix "radio"
                    label _("Language")
                    textbutton "English" action [Language(None), SetVariable("_preferences.language", "eng")]
                    textbutton "Português BR" action [SetVariable("_preferences.language", "pt_br_zenpy"), Language("pt_br")]
                    textbutton "Italiano" action [SetVariable("_preferences.language", "ita_zenpy"), Language("ita")]


            null height (4 * gui.pref_spacing)

            hbox:
                style_prefix "slider"
                box_wrap True

                vbox:

                    label _("Text Speed")

                    bar value Preference("text speed")

                    label _("Auto-Forward Time")

                    bar value Preference("auto-forward time")

                vbox:

                    if config.has_music:
                        label _("Music Volume")

                        hbox:
                            bar value Preference("music volume")

                    if config.has_sound:

                        label _("Sound Volume")

                        hbox:
                            bar value Preference("sound volume")

                            if config.sample_sound:
                                textbutton _("Test") action Play("sound", config.sample_sound)


                    if config.has_voice:
                        label _("Voice Volume")

                        hbox:
                            bar value Preference("voice volume")

                            if config.sample_voice:
                                textbutton _("Test") action Play("voice", config.sample_voice)

                    if config.has_music or config.has_sound or config.has_voice:
                        null height gui.pref_spacing

                        textbutton _("Mute All"):
                            action Preference("all mute", "toggle")
                            style "mute_all_button"


style pref_label is gui_label
style pref_label_text is gui_label_text
style pref_vbox is vbox

style radio_label is pref_label
style radio_label_text is pref_label_text
style radio_button is gui_button
style radio_button_text is gui_button_text
style radio_vbox is pref_vbox

style check_label is pref_label
style check_label_text is pref_label_text
style check_button is gui_button
style check_button_text is gui_button_text
style check_vbox is pref_vbox

style slider_label is pref_label
style slider_label_text is pref_label_text
style slider_slider is gui_slider
style slider_button is gui_button
style slider_button_text is gui_button_text
style slider_pref_vbox is pref_vbox

style mute_all_button is check_button
style mute_all_button_text is check_button_text

style pref_label:
    top_margin gui.pref_spacing
    bottom_margin 2

style pref_label_text:
    yalign 1.0

style pref_vbox:
    xsize 225

style radio_vbox:
    spacing gui.pref_button_spacing

style radio_button:
    properties gui.button_properties("radio_button")
    foreground "gui/button/radio_[prefix_]foreground.png"

style radio_button_text:
    properties gui.button_text_properties("radio_button")

style check_vbox:
    spacing gui.pref_button_spacing

style check_button:
    properties gui.button_properties("check_button")
    foreground "gui/button/check_[prefix_]foreground.png"

style check_button_text:
    properties gui.button_text_properties("check_button")

style slider_slider:
    xsize 350

style slider_button:
    properties gui.button_properties("slider_button")
    yalign 0.5
    left_margin 10

style slider_button_text:
    properties gui.button_text_properties("slider_button")

style slider_vbox:
    xsize 450










screen history():
    tag menu



    predict False

    use game_menu(_("History"), scroll=("vpgrid" if gui.history_height else "viewport"), yinitial=1.0):

        style_prefix "history"

        for h in _history_list:

            window:


                has fixed
                yfit True

                if h.who:

                    label h.who:
                        style "history_name"
                        substitute False



                        if "color" in h.who_args:
                            text_color h.who_args["color"]

                $ what = renpy.filter_text_tags(h.what, allow=gui.history_allow_tags)
                text what:
                    substitute False

        if not _history_list:
            label _("The dialogue history is empty.")




define gui.history_allow_tags = { "alt", "noalt" }


style history_window is empty

style history_name is gui_label
style history_name_text is gui_label_text
style history_text is gui_text

style history_text is gui_text

style history_label is gui_label
style history_label_text is gui_label_text

style history_window:
    xfill True
    ysize gui.history_height

style history_name:
    xpos gui.history_name_xpos
    xanchor gui.history_name_xalign
    ypos gui.history_name_ypos
    xsize gui.history_name_width

style history_name_text:
    min_width gui.history_name_width
    text_align gui.history_name_xalign

style history_text:
    xpos gui.history_text_xpos
    ypos gui.history_text_ypos
    xanchor gui.history_text_xalign
    xsize gui.history_text_width
    min_width gui.history_text_width
    text_align gui.history_text_xalign
    layout ("subtitle" if gui.history_text_xalign else "tex")

style history_label:
    xfill True

style history_label_text:
    xalign 0.5








screen help():
    tag menu


    default device = "keyboard"

    use game_menu(_("Help"), scroll="viewport"):

        style_prefix "help"

        vbox:
            spacing 15

            hbox:

                textbutton _("Keyboard") action SetScreenVariable("device", "keyboard")
                textbutton _("Mouse") action SetScreenVariable("device", "mouse")

                if GamepadExists():
                    textbutton _("Gamepad") action SetScreenVariable("device", "gamepad")

            if device == "keyboard":
                use keyboard_help
            elif device == "mouse":
                use mouse_help
            elif device == "gamepad":
                use gamepad_help


screen keyboard_help():

    hbox:
        label _("Enter")
        text _("Advances dialogue and activates the interface.")

    hbox:
        label _("Space")
        text _("Advances dialogue without selecting choices.")

    hbox:
        label _("Arrow Keys")
        text _("Navigate the interface.")

    hbox:
        label _("Escape")
        text _("Accesses the game menu.")

    hbox:
        label _("Ctrl")
        text _("Skips dialogue while held down.")

    hbox:
        label _("Tab")
        text _("Toggles dialogue skipping.")

    hbox:
        label _("Page Up")
        text _("Rolls back to earlier dialogue.")

    hbox:
        label _("Page Down")
        text _("Rolls forward to later dialogue.")

    hbox:
        label "H"
        text _("Hides the user interface.")

    hbox:
        label "S"
        text _("Takes a screenshot.")

    hbox:
        label "V"
        text _("Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}.")

    hbox:
        label "*Delete Save"
        text _("Select save file with directional pad and press \"delete\" key.")


screen mouse_help():

    hbox:
        label _("Left Click")
        text _("Advances dialogue and activates the interface.")

    hbox:
        label _("Middle Click")
        text _("Hides the user interface.")

    hbox:
        label _("Right Click")
        text _("Accesses the game menu.")

    hbox:
        label _("Mouse Wheel Up\nClick Rollback Side")
        text _("Rolls back to earlier dialogue.")

    hbox:
        label _("Mouse Wheel Down")
        text _("Rolls forward to later dialogue.")

    hbox:
        label "*Delete Save"
        text _("Hover mouse over save file and press \"delete\" key.")


screen gamepad_help():

    hbox:
        label _("Right Trigger\nA/Bottom Button")
        text _("Advances dialogue and activates the interface.")

    hbox:
        label _("Left Trigger\nLeft Shoulder")
        text _("Rolls back to earlier dialogue.")

    hbox:
        label _("Right Shoulder")
        text _("Rolls forward to later dialogue.")


    hbox:
        label _("D-Pad, Sticks")
        text _("Navigate the interface.")

    hbox:
        label _("Start, Guide")
        text _("Accesses the game menu.")

    hbox:
        label _("Y/Top Button")
        text _("Hides the user interface.")

    textbutton _("Calibrate") action GamepadCalibrate()


style help_button is gui_button
style help_button_text is gui_button_text
style help_label is gui_label
style help_label_text is gui_label_text
style help_text is gui_text

style help_button:
    properties gui.button_properties("help_button")
    xmargin 8

style help_button_text:
    properties gui.button_text_properties("help_button")

style help_label:
    xsize 250
    right_padding 20

style help_label_text:
    size gui.text_size
    xalign 1.0
    text_align 1.0




screen credits():
    tag menu





    use game_menu(_("Credits"), scroll="viewport"):

        style_prefix "credits"

        vbox:
            xalign 1.0

            hbox:
                spacing 60
                add "MENU/creditsPic.png" yalign 0.35
                vbox:
                    label _("Backgrounds &") at center
                    label _("BG/Art References") at center
                    text _("Pexels.com\n") at center
                    label _("Sound Effects") at center
                    text _("Pixabay.com\n") at center
                    label _("Programmed with") at center
                    text _("Ren'Py\n") at center
                    label _("Português-BR Translation") at center
                    text _("George Ribeiro\n") at center
                    label _("Italian Translation") at center
                    text _("Star Words Team") at center
                    text _("-----") at center
                    text _("Alagna Mattia") at center
                    text _("Casamassima Stefania") at center
                    text _("De Vincenzi Roberta") at center
                    text _("Nanni Lucia\n") at center
                    label _("And you...") at center
                    text _("Thank you for playing!\n") at center



style credits_label is gui_label
style credits_label_text is gui_label_text
style creditss_text is gui_text

style credits_label_text:
    size gui.label_text_size
    xalign 1.0
    text_align 1.0












screen confirm(message, yes_action, no_action):


    modal True

    zorder 200

    style_prefix "confirm"

    add "gui/overlay/confirm.png"

    frame:

        has vbox
        xalign .5
        yalign .5
        spacing 30

        label _(message):
            style "confirm_prompt"
            xalign 0.5

        hbox:
            xalign 0.5
            spacing 100

            textbutton _("Yes") action yes_action
            textbutton _("No") action no_action


    key "game_menu" action no_action


style confirm_frame is gui_frame
style confirm_prompt is gui_prompt
style confirm_prompt_text is gui_prompt_text
style confirm_button is gui_medium_button
style confirm_button_text is gui_medium_button_text

style confirm_frame:
    background Frame([ "gui/confirm_frame.png", "gui/frame.png"], gui.confirm_frame_borders, tile=gui.frame_tile)
    padding gui.confirm_frame_borders.padding
    xalign .5
    yalign .5

style confirm_prompt_text:
    text_align 0.5
    layout "subtitle"

style confirm_button:
    properties gui.button_properties("confirm_button")

style confirm_button_text:
    properties gui.button_text_properties("confirm_button")









screen skip_indicator():

    zorder 100
    style_prefix "skip"

    frame:

        has hbox
        spacing 6

        text _("Skipping")

        text "▸" at delayed_blink(0.0, 1.0) style "skip_triangle"
        text "▸" at delayed_blink(0.2, 1.0) style "skip_triangle"
        text "▸" at delayed_blink(0.4, 1.0) style "skip_triangle"



transform delayed_blink(delay, cycle):
    alpha .5

    pause delay

    block:
        linear .2 alpha 1.0
        pause .2
        linear .2 alpha 0.5
        pause (cycle - .4)
        repeat


style skip_frame is empty
style skip_text is gui_text
style skip_triangle is skip_text

style skip_frame:
    ypos gui.skip_ypos
    background Frame("gui/skip.png", gui.skip_frame_borders, tile=gui.frame_tile)
    padding gui.skip_frame_borders.padding

style skip_text:
    size gui.notify_text_size

style skip_triangle:


    font "DejaVuSans.ttf"









screen notify(message):

    zorder 100
    style_prefix "notify"

    frame at notify_appear:
        text "[message!tq]"

    timer 3.25 action Hide('notify')


transform notify_appear:
    on show:
        alpha 0
        linear .25 alpha 1.0
    on hide:
        linear .5 alpha 0.0


style notify_frame is empty
style notify_text is gui_text

style notify_frame:
    ypos gui.notify_ypos

    background Frame("gui/notify.png", gui.notify_frame_borders, tile=gui.frame_tile)
    padding gui.notify_frame_borders.padding

style notify_text:
    properties gui.text_properties("notify")









screen nvl(dialogue, items=None):

    window:
        style "nvl_window"

        has vbox
        spacing gui.nvl_spacing


        if gui.nvl_height:

            vpgrid:
                cols 1
                yinitial 1.0

                use nvl_dialogue(dialogue)

        else:

            use nvl_dialogue(dialogue)



        for i in items:

            textbutton i.caption:
                action i.action
                style "nvl_button"

    add SideImage() xalign 0.0 yalign 1.0


screen nvl_dialogue(dialogue):

    for d in dialogue:

        window:
            id d.window_id

            has fixed
            yfit gui.nvl_height is None

            if d.who is not None:

                text d.who:
                    id d.who_id

            text d.what:
                id d.what_id




define config.nvl_list_length = gui.nvl_list_length

style nvl_window is default
style nvl_entry is default

style nvl_label is say_label
style nvl_dialogue is say_dialogue

style nvl_button is button
style nvl_button_text is button_text

style nvl_window:
    xfill True
    yfill True

    background "gui/nvl.png"
    padding gui.nvl_borders.padding

style nvl_entry:
    xfill True
    ysize gui.nvl_height

style nvl_label:
    xpos gui.nvl_name_xpos
    xanchor gui.nvl_name_xalign
    ypos gui.nvl_name_ypos
    yanchor 0.0
    xsize gui.nvl_name_width
    min_width gui.nvl_name_width
    text_align gui.nvl_name_xalign

style nvl_dialogue:
    xpos gui.nvl_text_xpos
    xanchor gui.nvl_text_xalign
    ypos gui.nvl_text_ypos
    xsize gui.nvl_text_width
    min_width gui.nvl_text_width
    text_align gui.nvl_text_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_thought:
    xpos gui.nvl_thought_xpos
    xanchor gui.nvl_thought_xalign
    ypos gui.nvl_thought_ypos
    xsize gui.nvl_thought_width
    min_width gui.nvl_thought_width
    text_align gui.nvl_thought_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_button:
    properties gui.button_properties("nvl_button")
    xpos gui.nvl_button_xpos
    xanchor gui.nvl_button_xalign

style nvl_button_text:
    properties gui.button_text_properties("nvl_button")







style pref_vbox:
    variant "medium"
    xsize 450



screen quick_menu():
    variant "touch"

    zorder 100

    if quick_menu:

        hbox:
            style_prefix "quick"

            xalign 0.5
            yalign 1.0

            textbutton _("Back") action Rollback()
            textbutton _("Skip") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("Auto") action Preference("auto-forward", "toggle")
            textbutton _("Menu") action ShowMenu()


style window:
    variant "small"
    background "gui/phone/textbox.png"

style radio_button:
    variant "small"
    foreground "gui/phone/button/radio_[prefix_]foreground.png"

style check_button:
    variant "small"
    foreground "gui/phone/button/check_[prefix_]foreground.png"

style nvl_window:
    variant "small"
    background "gui/phone/nvl.png"

style main_menu_frame:
    variant "small"
    background "gui/phone/overlay/main_menu.png"

style game_menu_outer_frame:
    variant "small"
    background "gui/phone/overlay/game_menu.png"

style game_menu_navigation_frame:
    variant "small"
    xsize 340

style game_menu_content_frame:
    variant "small"
    top_margin 0

style pref_vbox:
    variant "small"
    xsize 400

style bar:
    variant "small"
    ysize gui.bar_size
    left_bar Frame("gui/phone/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/phone/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    variant "small"
    xsize gui.bar_size
    top_bar Frame("gui/phone/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/phone/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    variant "small"
    ysize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    variant "small"
    xsize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    variant "small"
    ysize gui.slider_size
    base_bar Frame("gui/phone/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/horizontal_[prefix_]thumb.png"

style vslider:
    variant "small"
    xsize gui.slider_size
    base_bar Frame("gui/phone/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/vertical_[prefix_]thumb.png"

style slider_vbox:
    variant "small"
    xsize None

style slider_slider:
    variant "small"
    xsize 600
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
