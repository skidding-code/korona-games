




default ready_clock = 0

default readyCounter = 0
default hintCounter = 0
default brightCounter = 0
















screen ready_timer():
    text "[ready_clock]" size 72 color "#FFF"
    if ready_clock <= 10:
        text "[ready_clock]" size 72 color "#FF0000"
    if ready_clock >= 1:
        timer 1 repeat True action [
                SetVariable("ready_clock", ready_clock - 1),
                renpy.restart_interaction
            ]
    else:
        timer 1 action [
                Hide("ready_timer"),
                Jump("menuReset")
            ]



label runEndgame:


    menu:
        "Hint?":

            if hintCounter == 0:
                jump end_Hint
            if hintCounter == 1:
                jump end_Hint2
            if hintCounter == 2:
                jump end_Hint3
            if hintCounter == 3:
                jump end_Hint4
            if hintCounter == 4:
                jump end_Hint5
        "Begin restoration: _ _ _ _  _ _{#2nd_game}" if readyCounter == 0:

            jump restoreK2
        "Begin restoration: K _ _ _  _ _" if readyCounter == 1:

            jump restoreI
        "Begin restoration: K I _ _  _ _" if readyCounter == 2:

            jump restoreL
        "Begin restoration: K I L _  _ _" if readyCounter == 3:

            jump restoreL2
        "Begin restoration: K I L L  _ _" if readyCounter == 4:

            jump restoreI2
        "Begin restoration: K I L L  I _" if readyCounter == 5:

            if _preferences.language == "pt_br":
                $ lastAlleyChoice += 1
                scene bg alleyCat2
                jump inAlley_start
            else:
                jump restoreT
        "Restoration Complete: K I L L  I T" if readyCounter > 5:

            $ lastAlleyChoice += 1
            scene bg alleyCat2
            jump inAlley_start





























































label end_Hint:
    "What should you do with a cat that has been {i}very...{/i}"
    "{i}very...{/i}"
    "{i}{size=+10}very...{/size}{/i}"
    "{color=#FF0000}{b}n a u g h t y . . ?{/b}{/color}"

    menu:
        "Ok, got it.":
            jump runEndgame
        "Need another hint.":
            $ hintCounter += 1
            jump end_Hint2

label end_Hint2:
    "It's something it {color=#FF0000}deserves.{/color}"
    "Something... {w}{color=#FF0000}{b}final...{/b}{/color}"

    menu:
        "Ok, got it.":
            jump runEndgame
        "Gonna need another hint.":
            $ hintCounter += 1
            jump end_Hint3

label end_Hint3:
    "Something it has been doing to you this entire time."
    "...Over and over and {i}{b}over{/b}{/i} again."

    menu:
        "Ok, got it.":
            jump runEndgame
        "Still not following...":
            $ hintCounter += 1
            jump end_Hint4

label end_Hint4:
    "..?"
    "The act of taking a life..?"

    menu:
        "Ok, got it.":
            jump runEndgame
        "Okay, one more hint...":
            $ hintCounter += 1
            "{alpha=0.1}kill it{/alpha}"
            jump end_Hint5Menu

label end_Hint5:

    if brightCounter == 0:
        "{alpha=0.1}kill it{/alpha}"
        jump end_Hint5Menu
    if brightCounter == 1:
        "{alpha=0.3}kill it{/alpha}"
        jump end_Hint5Menu
    if brightCounter == 2:
        "{alpha=0.5}{size=+5}kill it{/size}{/alpha}"
        jump end_Hint5Menu
    if brightCounter == 3:
        "{alpha=0.7}{size=+10}kill it{/size}{/alpha}"
        jump end_Hint5Menu
    if brightCounter == 4:
        "{size=+20}{color=#FF0000}{b}kill it{/b}{/color}{/size}"
        jump runEndgame

label end_Hint5Menu:
    menu:
        "Ok, got it.":
            jump runEndgame
        "..?":
            $ brightCounter += 1
            jump end_Hint5



label restoreK2:
    $ ready_clock = 3
    show screen ready_timer
    menu:
        "-G-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-X-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-K-" if _preferences.language == "eng":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-M-" if _preferences.language == "pt_br":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-U-" if _preferences.language == "ita":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-H-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-J-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-P-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame

label restoreI:
    $ ready_clock = 3
    show screen ready_timer
    menu:
        "-T-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-I-" if _preferences.language == "eng":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-A-" if _preferences.language == "pt_br":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-C-" if _preferences.language == "ita":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-L-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-1-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-C-" if _preferences.language != "ita":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-O-" if _preferences.language == "ita":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-8-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame

label restoreL:
    $ ready_clock = 3
    show screen ready_timer
    menu:
        "-Y-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-1-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-J-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-<-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-L-" if _preferences.language == "eng":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-T-" if _preferences.language == "pt_br":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-C-" if _preferences.language == "ita":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-P-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame


label restoreL2:
    $ ready_clock = 3
    show screen ready_timer
    menu:
        "-E-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-3-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-L-" if _preferences.language == "eng":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-A-" if _preferences.language == "pt_br":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-I-" if _preferences.language == "ita":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-Z-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-B-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-Q-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame


label restoreI2:
    $ ready_clock = 3
    show screen ready_timer
    menu:
        "-K-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-I-" if _preferences.language == "eng":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-R-" if _preferences.language == "pt_br":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-D-" if _preferences.language == "ita":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-U-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-O-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-A-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-N-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame

label restoreT:
    $ ready_clock = 3
    show screen ready_timer
    menu:
        "-4-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-G-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-C-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-F-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-O-":
            play sound "audio/glitch.mp3"
            hide screen ready_timer
            jump runEndgame
        "-T-" if _preferences.language == "eng":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame
        "-I-" if _preferences.language == "ita":
            play sound "audio/dataReveal.mp3"
            $ readyCounter += 1
            hide screen ready_timer
            jump runEndgame

    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
