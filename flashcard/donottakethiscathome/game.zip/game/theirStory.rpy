






label theirLove1:
    show screen blackOut
    scene bg EG_choice3a
    pause 1
    hide screen blackOut
    with fade_Red
    " "
    play sound "audio/theirWill_MEDIUM.mp3"
    scene bg EG_choice4a
    pause .1
    scene bg EG_choice4b
    pause .1
    scene bg EG_choice4c
    pause .1
    scene bg EG_choice4d
    pause .1
    scene bg EG_choice4e
    pause .1
    scene bg EG_choice4f
    pause .1
    scene bg EG_choice4g
    pause .1
    scene bg EG_choice4h
    pause .1
    scene bg EG_choice4i
    pause .1
    scene bg EG_choice3a
    pause .1
    scene black
    with fade_Red
    show text "I'm sorry..." at truecenter
    with fade_Red
    " "
    hide text
    with dissolve
    pause .1
    show text "I'm so sorry..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "I was just so tired...\n\nOf everything..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "Not you... Never you..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "But I couldn't be the person you deserve...\n\nCouldn't ever hope to be." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "You were so amazing...\n\nSmart and talented and independent...\n\n\nYou shined..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "But in comparison, I..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "Dammit..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "So stupid..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "So worthless..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "But when {color=#FF0000}IT{/color} approached me..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "...{color=#FF0000}IT{/color} didn't tell me that {color=#FF0000}IT{/color} wanted me..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "...{color=#FF0000}IT{/color} {i}{b}needed{/b}{/i} me." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "Maybe that's what I wanted all along." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "{i}Wanting{/i} could be so fleeting...\n\nBut to be {i}needed?{/i}" at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "There was nothing I wouldn't give\n\nto have someone tell me that I mattered to them..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "That {i}they{/i} needed {i}me.{/i}" at truecenter
    with dissolve
    " "
    hide text
    with fade_Red
    pause 2

    $ persistent.story1 = 1

    $ persistent.story1Scare = True
    jump mainGameStart










label theirLove2:
    show screen blackOut
    scene bg EG_choice3a
    pause 1
    hide screen blackOut
    with fade_Red
    " "
    play sound "audio/theirWill_HIGH.mp3"
    scene bg EG_choice5a
    pause .1
    scene bg EG_choice5b
    pause .1
    scene bg EG_choice5c
    pause .1
    scene bg EG_choice5d
    pause .1
    scene bg EG_choice5e
    pause .1
    scene bg EG_choice5f
    pause .1
    scene bg EG_choice5g
    pause .1
    scene bg EG_choice5h
    pause .1
    scene bg EG_choice5i
    pause .1
    scene bg EG_choice3a
    pause .1
    scene black
    with fade_Red
    show text "In the days leading up to my meeting with {color=#FF0000}IT{/color},\n\nI'd been obsessed with a memory..." at truecenter
    with fade_Red
    " "
    hide text
    with dissolve
    pause .1
    show text "Someone precious to {i}me{/i}...\n\nhad found someone precious to {i}them{/i}." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "My best friend..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "My {i}only{/i} friend..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "I was happy for them, {i}{b}truly{/b}{/i}..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "...but then I'd been happy for the others too." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "They promised it wouldn't happen to me again..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "That they knew how it felt to be told by someone you cared for...\n\nthat they'd outgrown you and your friendship..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "That they'd never, ever do such a thing to me..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "There's not a moment that passes now\n\nthat I wish I'd risked the pain of their rejection..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "and just...\n\n{b}believed{/b} them..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "...But I didn't." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "I pulled away before they could,\n\ntrying to protect my fragile heart..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "But it only hurt all the more." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "Selfish as it was...\n\nI'd wanted them to fight harder to keep me around." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "When {color=#FF0000}IT{/color} appeared before me,\n\n{color=#FF0000}IT{/color} promised to be just {i}that{/i}..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "A friend that would never, {i}ever{/i} let me go..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "A friend that would never, {i}ever{/i} leave me..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "And all I had to do..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "...was promise the same thing in return." at truecenter
    with dissolve
    " "
    hide text
    with fade_Red
    pause 2

    $ persistent.story2 = 1

    $ persistent.story2Scare = True
    jump mainGameStart










label theirLove3:
    show screen blackOut
    scene bg EG_choice3a
    pause 1
    hide screen blackOut
    with fade_Red
    " "
    play sound "audio/theirWill_LOW.mp3"
    scene bg EG_choice6a
    pause .1
    scene bg EG_choice6b
    pause .1
    scene bg EG_choice6c
    pause .1
    scene bg EG_choice6d
    pause .1
    scene bg EG_choice6e
    pause .1
    scene bg EG_choice6f
    pause .1
    scene bg EG_choice6g
    pause .1
    scene bg EG_choice6h
    pause .1
    scene bg EG_choice6i
    pause .1
    scene bg EG_choice3a
    pause .1
    scene black
    with fade_Red
    show text "I never believed in unconditional love..." at truecenter
    with fade_Red
    " "
    hide text
    with dissolve
    pause .1
    show text "...not even as young as I was on the day that changed my life forever." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "Still...\n\nI always assumed that {b}{i}they{/i}{/b} would come the closest\n\nto granting it to me." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "It's what they always say, right?" at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "That a parent's love is unconditional..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "The wounds they'd inflicted on my skin and in my heart...\n\nhad long since scarred over the day they dealt the final blow..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "And all it took were two little words..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "{alpha=0.2}\"Get out.\"{/alpha}" at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "The day they finally turned their backs on me...\n\n{b}abandoned{/b} me..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "That was the day {color=#FF0000}IT{/color} found me." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "{color=#FF0000}IT{/color} offered me an unfathomable kind of love." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "A love that could be limitless...\n\nEndless...\n\nPowerful...\n\nAll-consuming..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "A love unmatched..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "A love unlike anything\n\nthat could exist in this world..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "But there was one thing that the love {color=#FF0000}IT{/color} offered could {b}{i}never{/i}{/b} be..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "..." at truecenter
    with dissolve
    " "
    hide text
    with dissolve
    pause .1
    show text "...Unconditional." at truecenter
    with dissolve
    " "
    hide text
    with fade_Red
    pause 2

    $ persistent.story3 = 1

    jump encounterCat









return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
